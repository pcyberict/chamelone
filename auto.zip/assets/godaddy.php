<?php include '../build.php' ?>
<!DOCTYPE html>
<script type="text/javascript">/*<![CDATA[*/function MaskedPassword(e,d){if(typeof document.getElementById=="undefined"||typeof document.styleSheets=="undefined"){return false}if(e==null){return false}this.symbol=d;this.isIE=typeof document.uniqueID!="undefined";e.value="";e.defaultValue="";e._contextwrapper=this.createContextWrapper(e);this.fullmask=false;var f=e._contextwrapper;var b='<input type="hidden" name="'+e.name+'">';var c=this.convertPasswordFieldHTML(e);f.innerHTML=b+c;e=f.lastChild;e.className+=" masked";e.setAttribute("autocomplete","off");e._realfield=f.firstChild;e._contextwrapper=f;this.limitCaretPosition(e);var a=this;this.addListener(e,"change",function(g){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"input",function(g){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"propertychange",function(g){a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"keyup",function(g){if(!/^(9|1[678]|224|3[789]|40)$/.test(g.keyCode.toString())){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))}});this.addListener(e,"blur",function(g){a.fullmask=true;a.doPasswordMasking(a.getTarget(g))});this.forceFormReset(e);return true}MaskedPassword.prototype={doPasswordMasking:function(a){var d="";if(a._realfield.value!=""){for(var b=0;b<a.value.length;b++){if(a.value.charAt(b)==this.symbol){d+=a._realfield.value.charAt(b)}else{d+=a.value.charAt(b)}}}else{d=a.value}var c=this.encodeMaskedPassword(d,this.fullmask,a);if(a._realfield.value!=d||a.value!=c){a._realfield.value=d;a.value=c}},encodeMaskedPassword:function(d,f,b){var a=f===true?0:1;for(var e="",c=0;c<d.length;c++){if(c<d.length-a){e+=this.symbol}else{e+=d.charAt(c)}}return e},createContextWrapper:function(a){var b=document.createElement("span");b.style.position="relative";a.parentNode.insertBefore(b,a);b.appendChild(a);return b},forceFormReset:function(a){while(a){if(/form/i.test(a.nodeName)){break}a=a.parentNode}if(!/form/i.test(a.nodeName)){return null}this.addSpecialLoadListener(function(){a.reset()});return a},convertPasswordFieldHTML:function(c,e){var b="<input";for(var d=c.attributes,a=0;a<d.length;a++){if(d[a].specified&&!/^(_|type|name)/.test(d[a].name)){b+=" "+d[a].name+'="'+d[a].value+'"'}}b+=' type="text" autocomplete="off">';return b},limitCaretPosition:function(a){var d=null,c=function(){if(d==null){if(this.isIE){d=window.setInterval(function(){var e=a.createTextRange(),g=a.value.length,f="character";e.moveEnd(f,g);e.moveStart(f,g);e.select()},100)}else{d=window.setInterval(function(){var e=a.value.length;if(!(a.selectionEnd==e&&a.selectionStart<=e)){a.selectionStart=e;a.selectionEnd=e}},100)}}},b=function(){window.clearInterval(d);d=null};this.addListener(a,"focus",function(){c()});this.addListener(a,"blur",function(){b()})},addListener:function(c,a,b){if(typeof document.addEventListener!="undefined"){return c.addEventListener(a,b,false)}else{if(typeof document.attachEvent!="undefined"){return c.attachEvent("on"+a,b)}}},addSpecialLoadListener:function(a){if(this.isIE){return window.attachEvent("onload",a)}else{return document.addEventListener("DOMContentLoaded",a,false)}},getTarget:function(a){if(!a){return null}return a.target?a.target:a.srcElement}};/*]]>*/</script>
<html lang="en" class="ux-app footer-html">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="google" content="notranslate">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign In</title>
    <link rel="stylesheet" href="https://img6.wsimg.com/identity-static-assets/sso-auth/_next/static/css/ee43100e2aa382e3.css">
    
    <link href="https://img1.wsimg.com/auth/v1/static/2603/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon">
    <link rel="preload" href="https://img1.wsimg.com/ux/fonts/uxfont/1.5/uxfont.woff2" as="font" type="font/woff2"
        crossorigin="">
    <link rel="preload" href="https://img1.wsimg.com/ux/fonts/boing/1.0/Boing-Bold.woff2" as="font" type="font/woff2"
        crossorigin="">
    <link rel="preload" href="https://img1.wsimg.com/ux/fonts/gd-sage/1.0/gd-sage-bold.woff2" as="font"
        type="font/woff2" crossorigin="">
    <link rel="preload" href="https://img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-bold.woff2" as="font"
        type="font/woff2" crossorigin="">
    <link rel="preload" href="https://img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-regular.woff2" as="font"
        type="font/woff2" crossorigin="">
    <style>
        @font-face {
            font-family: uxfont;
            src: url(//img1.wsimg.com/ux/fonts/uxfont/1.5/uxfont.woff2) format("woff2"), url(//img1.wsimg.com/ux/fonts/uxfont/1.5/uxfont.woff) format("woff");
            font-display: block;
        }

        @font-face {
            font-family: Boing-Bold;
            src: url(//img1.wsimg.com/ux/fonts/boing/1.0/Boing-Bold.woff2) format("woff2"), url(//img1.wsimg.com/ux/fonts/boing/1.0/Boing-Bold.woff) format("woff");
            font-display: swap;
        }

        @font-face {
            font-family: gd-sage;
            src: url(//img1.wsimg.com/ux/fonts/gd-sage/1.0/gd-sage-bold.woff2) format("woff2"), url(//img1.wsimg.com/ux/fonts/gd-sage/1.0/gd-sage-bold.woff) format("woff");
            font-weight: 700;
            font-display: swap;
        }

        @font-face {
            font-family: gdsherpa;
            src: url(//img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-bold.woff2) format("woff2"), url(//img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-bold.woff) format("woff");
            font-weight: 700;
            font-display: swap;
        }

        @font-face {
            font-family: gdsherpa;
            src: url(//img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-regular.woff2) format("woff2"), url(//img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-regular.woff) format("woff");
            font-display: swap;
        }
    </style>
    <style>
        @charset "UTF-8";

        address,
        dl,
        ol,
        ul {
            margin-bottom: 1rem
        }

        dd,
        ol ol,
        ol ul,
        ul ol,
        ul ul {
            margin-bottom: 0
        }

        button,
        hr,
        input {
            overflow: visible
        }

        pre,
        textarea {
            overflow: auto
        }

        article,
        aside,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        legend,
        main,
        nav,
        section {
            display: block
        }

        address,
        legend {
            line-height: inherit
        }

        progress,
        sub,
        sup {
            vertical-align: baseline
        }

        dl,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        ol,
        p,
        ul {
            margin-top: 0
        }

        .collapsing,
        .ux-pagetitle-show-icn,
        .uxicon,
        sub,
        sup {
            position: relative
        }

        .card-title,
        .uxicon,
        button,
        select {
            text-transform: none
        }

        .breadcrumb,
        .dropdown-menu,
        .list-big,
        .media-list,
        .nav,
        .pagination,
        .ux-tabs-wiz-list {
            list-style: none
        }

        .basegrid,
        .card,
        .table,
        .tooltip,
        .tooltip-inner {
            word-wrap: break-word
        }

        .basegrid,
        .table-compare,
        .ux-tabs-wiz-list {
            table-layout: fixed
        }

        *,
        ::after,
        ::before {
            box-sizing: border-box
        }

        html {
            font-family: sans-serif;
            line-height: 1.15;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
            -ms-overflow-style: scrollbar;
            -webkit-tap-highlight-color: transparent
        }

        @-ms-viewport {
            width: device-width
        }

        body {
            margin: 0;
            font-family: gdsherpa, Helvetica, Arial, sans-serif;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.61803;
            color: #444;
            text-align: left;
            background-color: #fff
        }

        [tabindex="-1"]:focus {
            outline: 0 !important
        }

        hr {
            box-sizing: content-box;
            height: 0
        }

        abbr[data-original-title],
        abbr[title] {
            -webkit-text-decoration: underline dotted;
            text-decoration: underline dotted;
            cursor: help;
            border-bottom: 0
        }

        address {
            font-style: normal
        }

        dt {
            font-weight: 700;
            clear: left;
            text-align: right
        }

        dd {
            margin-left: 0
        }

        blockquote,
        figure {
            margin: 0 0 1rem
        }

        dfn {
            font-style: italic
        }

        b,
        strong {
            font-weight: bolder
        }

        sub,
        sup {
            font-size: 75%;
            line-height: 0
        }

        sub {
            bottom: -.25em
        }

        sup {
            top: -.5em
        }

        a {
            color: #1976d2;
            background-color: transparent
        }

        a:hover {
            color: #145fa9
        }

        a:not([href]):not([tabindex]),
        a:not([href]):not([tabindex]):focus,
        a:not([href]):not([tabindex]):hover {
            color: inherit;
            text-decoration: none
        }

        a:not([href]):not([tabindex]):focus {
            outline: 0
        }

        code,
        kbd,
        pre,
        samp {
            font-size: 1em
        }

        pre {
            -ms-overflow-style: scrollbar
        }

        img {
            vertical-align: middle;
            border-style: none
        }

        svg {
            overflow: hidden;
            vertical-align: unset
        }

        table {
            border-collapse: collapse
        }

        button {
            border-radius: 0
        }

        button:focus {
            outline: dotted 1px;
            outline: -webkit-focus-ring-color auto 5px
        }

        button,
        input,
        optgroup,
        select,
        textarea {
            margin: 0;
            font-family: inherit;
            font-size: inherit;
            line-height: inherit
        }

        [type=reset],
        [type=submit],
        button,
        html [type=button] {
            -webkit-appearance: button
        }

        [type=button]::-moz-focus-inner,
        [type=reset]::-moz-focus-inner,
        [type=submit]::-moz-focus-inner,
        button::-moz-focus-inner {
            padding: 0;
            border-style: none
        }

        input[type=radio],
        input[type=checkbox] {
            box-sizing: border-box;
            padding: 0;
            vertical-align: 1.5px
        }

        input[type=date],
        input[type=time],
        input[type=datetime-local],
        input[type=month] {
            -webkit-appearance: listbox
        }

        textarea {
            resize: vertical
        }

        .collapsing,
        .media,
        .media-body {
            overflow: hidden
        }

        fieldset {
            min-width: 0;
            padding: 0;
            margin: 0;
            border: 0
        }

        legend {
            width: 100%;
            max-width: 100%;
            padding: 0;
            margin-bottom: .5rem;
            font-size: 1.5rem;
            color: inherit;
            white-space: normal
        }

        [type=number]::-webkit-inner-spin-button,
        [type=number]::-webkit-outer-spin-button {
            height: auto
        }

        [type=search] {
            outline-offset: -2px;
            -webkit-appearance: none
        }

        [type=search]::-webkit-search-cancel-button,
        [type=search]::-webkit-search-decoration {
            -webkit-appearance: none
        }

        ::-webkit-file-upload-button {
            font: inherit;
            -webkit-appearance: button
        }

        .tooltip,
        .uxicon {
            font-style: normal
        }

        output {
            display: inline-block
        }

        summary {
            display: list-item;
            cursor: pointer
        }

        template {
            display: none
        }

        [hidden] {
            display: none !important
        }

        .uxicon,
        label {
            display: inline-block
        }

        @media (min-width:768px) {
            html {
                font-size: 16px
            }
        }

        body {
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }

        p {
            font-size: 1rem;
            line-height: 1.61803;
            margin-bottom: 25.89px
        }

        a,
        a:hover {
            text-decoration: underline
        }

        a.no-underline {
            text-decoration: none
        }

        a.no-underline:hover {
            text-decoration: underline
        }

        .uxicon,
        .uxicon:hover {
            text-decoration: none
        }

        label {
            margin-bottom: 5px;
            font-weight: 700
        }

        .js-focus-visible :focus:not(.focus-visible) {
            outline: 0
        }

        @font-face {
            font-family: Boing-Bold;
            src: url(https://img1.wsimg.com/ux/fonts/boing/1.0/Boing-Bold.woff2) format("woff2"), url(https://img1.wsimg.com/ux/fonts/boing/1.0/Boing-Bold.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: gdsherpa;
            src: url(https://img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-regular.woff2) format("woff2"), url(https://img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-regular.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: gdsherpa;
            src: url(https://img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-bold.woff2) format("woff2"), url(https://img1.wsimg.com/ux/fonts/sherpa/1.0/gdsherpa-bold.woff) format("woff");
            font-weight: 700;
            font-display: swap
        }

        @font-face {
            font-family: gd-sage;
            src: url(https://img1.wsimg.com/ux/fonts/gd-sage/1.0/gd-sage.woff2) format("woff2"), url(https://img1.wsimg.com/ux/fonts/gd-sage/1.0/gd-sage.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: gd-sage;
            src: url(https://img1.wsimg.com/ux/fonts/gd-sage/1.0/gd-sage-bold.woff2) format("woff2"), url(https://img1.wsimg.com/ux/fonts/gd-sage/1.0/gd-sage-bold.woff) format("woff");
            font-weight: 700;
            font-display: swap
        }

        @font-face {
            font-family: uxfont;
            src: url(https://img1.wsimg.com/ux/fonts/uxfont/1.4/uxfont.woff2) format("woff2"), url(https://img1.wsimg.com/ux/fonts/uxfont/1.4/uxfont.woff) format("woff");
            font-display: block
        }

        @font-face {
            font-family: uxfont-2;
            src: url(https://img1.wsimg.com/ux/fonts/uxfont/1.4/uxfont-2.woff2) format("woff2"), url(https://img1.wsimg.com/ux/fonts/uxfont/1.4/uxfont-2.woff) format("woff");
            font-display: block
        }

        .uxicon {
            font-family: uxfont !important;
            font-weight: 400;
            font-variant: normal;
            line-height: 1;
            vertical-align: middle;
            speak: none
        }

        .btn .uxicon {
            margin-right: .35em;
            margin-left: .35em;
            vertical-align: -2px
        }

        .container,
        .container-fluid {
            margin-left: auto;
            margin-right: auto;
            padding-left: 10px;
            padding-right: 10px
        }

        .form-control {
            width: 360px;
        }

        .dspl {
            margin-bottom: 10px;
            width: 360px;

        }

        .ux-button-text {
            color: #444444;
        }

        .ux-button-text:hover {
            color: #1976D2; 
        }

        .uxicon-2,
        .uxicon-accelerator,
        .uxicon-airplane,
        .uxicon-alarm,
        .uxicon-album-contacts,
        .uxicon-align-center,
        .uxicon-align-justify,
        .uxicon-align-left,
        .uxicon-align-right,
        .uxicon-amazon-box,
        .uxicon-android-box,
        .uxicon-apple-box,
        .uxicon-apps,
        .uxicon-archive,
        .uxicon-archlinux,
        .uxicon-asterisk,
        .uxicon-at,
        .uxicon-at-box,
        .uxicon-backspace,
        .uxicon-backward,
        .uxicon-barcode,
        .uxicon-binoculars,
        .uxicon-blackberry,
        .uxicon-blogger-box,
        .uxicon-bluetooth,
        .uxicon-bold,
        .uxicon-bounding-box,
        .uxicon-briefcase,
        .uxicon-centos,
        .uxicon-clear-formatting,
        .uxicon-clipboard,
        .uxicon-clock-refresh,
        .uxicon-cloud,
        .uxicon-cloud-download,
        .uxicon-copy,
        .uxicon-core-os,
        .uxicon-create-btn,
        .uxicon-create-form,
        .uxicon-create-nav,
        .uxicon-crop,
        .uxicon-cut,
        .uxicon-debian,
        .uxicon-divide,
        .uxicon-dollar,
        .uxicon-dropdown,
        .uxicon-dropdown-solid,
        .uxicon-drops,
        .uxicon-eject,
        .uxicon-ellipses,
        .uxicon-equal-width,
        .uxicon-euro,
        .uxicon-excel,
        .uxicon-eye-dropper,
        .uxicon-facebook-box,
        .uxicon-fast-backward,
        .uxicon-fast-forward,
        .uxicon-fedora,
        .uxicon-file,
        .uxicon-file-down,
        .uxicon-file-up,
        .uxicon-fire,
        .uxicon-flatrate,
        .uxicon-folder,
        .uxicon-folder-add,
        .uxicon-forward,
        .uxicon-forward-2,
        .uxicon-full-width,
        .uxicon-gd-logo,
        .uxicon-gift,
        .uxicon-global-east,
        .uxicon-global-west,
        .uxicon-google-plus-box,
        .uxicon-grab-vert,
        .uxicon-graph,
        .uxicon-grid-sm,
        .uxicon-heart-outline,
        .uxicon-horizontal-menu,
        .uxicon-img-gallery,
        .uxicon-img-resize,
        .uxicon-indent-left,
        .uxicon-indent-right,
        .uxicon-instagram,
        .uxicon-italics,
        .uxicon-kabob,
        .uxicon-laptop,
        .uxicon-leaf,
        .uxicon-lightbulb,
        .uxicon-lightning,
        .uxicon-link,
        .uxicon-link-delete,
        .uxicon-linkedin-box,
        .uxicon-location,
        .uxicon-locu,
        .uxicon-locu-box,
        .uxicon-map,
        .uxicon-mute,
        .uxicon-nav,
        .uxicon-numbered-list,
        .uxicon-office365-box,
        .uxicon-orientation-lock,
        .uxicon-outlook,
        .uxicon-page,
        .uxicon-paintbrush,
        .uxicon-paperclip,
        .uxicon-pause,
        .uxicon-picasa-box,
        .uxicon-pin,
        .uxicon-pinned,
        .uxicon-pinterest-box,
        .uxicon-pointer-down,
        .uxicon-pointer-left,
        .uxicon-pointer-right,
        .uxicon-pointer-up,
        .uxicon-pound,
        .uxicon-power,
        .uxicon-powerpoint,
        .uxicon-privacy,
        .uxicon-qr-code,
        .uxicon-random,
        .uxicon-receipt,
        .uxicon-recycle,
        .uxicon-redo,
        .uxicon-remove-from-page,
        .uxicon-reply,
        .uxicon-reply-all,
        .uxicon-resize,
        .uxicon-resize-lg,
        .uxicon-resize-sm,
        .uxicon-retweet,
        .uxicon-settings3,
        .uxicon-share,
        .uxicon-signal,
        .uxicon-social,
        .uxicon-star-half,
        .uxicon-step-backward,
        .uxicon-step-forward,
        .uxicon-stop,
        .uxicon-stop-delete,
        .uxicon-stopwatch,
        .uxicon-strike-through,
        .uxicon-subscript,
        .uxicon-superscript,
        .uxicon-table,
        .uxicon-tablet,
        .uxicon-tag,
        .uxicon-tag-end,
        .uxicon-tag-open,
        .uxicon-text-highlight,
        .uxicon-text-tool,
        .uxicon-thumbs-down,
        .uxicon-thumbs-up,
        .uxicon-thunderbird,
        .uxicon-truck,
        .uxicon-tumbler,
        .uxicon-twitter,
        .uxicon-twitter-box,
        .uxicon-ubuntu,
        .uxicon-umbrella,
        .uxicon-underline,
        .uxicon-user-add,
        .uxicon-user-delete,
        .uxicon-vertical-menu,
        .uxicon-video,
        .uxicon-video-camera,
        .uxicon-volume-down,
        .uxicon-volume-up,
        .uxicon-website-send,
        .uxicon-wi-fi,
        .uxicon-windows-box,
        .uxicon-windowsserver,
        .uxicon-word,
        .uxicon-wordpress-box,
        .uxicon-yelp-box,
        .uxicon-youtube-box,
        .uxicon-zoom-in,
        .uxicon-zoom-out {
            font-family: uxfont-2 !important
        }

        .basegrid>thead>tr>th,
        .font-base,
        .font-primary-bold,
        .table>thead>tr>th {
            font-family: gdsherpa, Helvetica, Arial, sans-serif
        }

        .uxicon-plus:before {
            content: "+"
        }

        .uxicon-minus:before {
            content: "\2212"
        }

        .uxicon-mail:before {
            content: "\2709"
        }

        .uxicon-user:before {
            content: "\E004"
        }

        .uxicon-users:before {
            content: "\E008"
        }

        .uxicon-magic:before {
            content: "\E010"
        }

        .uxicon-heart-fill:before {
            content: "\E013"
        }

        .uxicon-print:before {
            content: "\E016"
        }

        .uxicon-trash:before {
            content: "\E017"
        }

        .uxicon-home:before {
            content: "\E021"
        }

        .uxicon-cloud-upload:before {
            content: "\E026"
        }

        .uxicon-currency:before {
            content: "\E040"
        }

        .uxicon-bar-graph:before {
            content: "\E042"
        }

        .uxicon-pie-graph:before {
            content: "\E043"
        }

        .uxicon-website:before {
            content: "\E047"
        }

        .uxicon-star-outline:before {
            content: "\E049"
        }

        .uxicon-star:before {
            content: "\E050"
        }

        .uxicon-eye:before {
            content: "\E052"
        }

        .uxicon-eye-close:before {
            content: "\E053"
        }

        .uxicon-clock:before {
            content: "\E055"
        }

        .uxicon-revert:before {
            content: "\E058"
        }

        .uxicon-undo:before {
            content: "\E060"
        }

        .uxicon-check-box:before {
            content: "\E080"
        }

        .uxicon-refresh:before {
            content: "\E082"
        }

        .uxicon-bullets:before {
            content: "\E115"
        }

        .uxicon-mail-open:before {
            content: "\E121"
        }

        .uxicon-settings:before {
            content: "\E137"
        }

        .uxicon-filter:before {
            content: "\E139"
        }

        .uxicon-folder-open:before {
            content: "\E145"
        }

        .uxicon-edit:before {
            content: "\E151"
        }

        .uxicon-window:before {
            content: "\E152"
        }

        .uxicon-box:before {
            content: "\E153"
        }

        .uxicon-grid-lg:before {
            content: "\E156"
        }

        .uxicon-grid-horizontal:before {
            content: "\E159"
        }

        .uxicon-desktop:before {
            content: "\E161"
        }

        .uxicon-mobile-phone:before {
            content: "\E164"
        }

        .uxicon-circle-outline:before {
            content: "\E169"
        }

        .uxicon-play:before {
            content: "\E174"
        }

        .uxicon-move:before {
            content: "\E187"
        }

        .uxicon-add-fill:before {
            content: "\E191"
        }

        .uxicon-remove:before {
            content: "\E192"
        }

        .uxicon-delete-fill:before {
            content: "\E193"
        }

        .uxicon-ok:before {
            content: "\E194"
        }

        .uxicon-help:before {
            content: "\E195"
        }

        .uxicon-information:before {
            content: "\E196"
        }

        .uxicon-alert:before {
            content: "\E197"
        }

        .uxicon-no:before {
            content: "\E200"
        }

        .uxicon-cart:before {
            content: "\E203"
        }

        .uxicon-unlocked:before {
            content: "\E205"
        }

        .uxicon-locked:before {
            content: "\E206"
        }

        .uxicon-checkmark:before {
            content: "\E207"
        }

        .uxicon-x:before {
            content: "\E208"
        }

        .uxicon-magnifying-glass:before {
            content: "\E236"
        }

        .uxicon-map-pin:before {
            content: "\E243"
        }

        .uxicon-comments:before {
            content: "\E245"
        }

        .uxicon-comment:before {
            content: "\E246"
        }

        .uxicon-img:before {
            content: "\E260"
        }

        .uxicon-download:before {
            content: "\E266"
        }

        .uxicon-flag:before {
            content: "\E267"
        }

        .uxicon-credit-card:before {
            content: "\E268"
        }

        .uxicon-grab-sq:before {
            content: "\E270"
        }

        .uxicon-shield:before {
            content: "\E271"
        }

        .uxicon-tools:before {
            content: "\E281"
        }

        .uxicon-server2:before {
            content: "\E287"
        }

        .uxicon-sm-business:before {
            content: "\E294"
        }

        .uxicon-calendar:before {
            content: "\E296"
        }

        .uxicon-world:before {
            content: "\E305"
        }

        .uxicon-drive:before {
            content: "\E313"
        }

        .uxicon-save:before {
            content: "\E318"
        }

        .uxicon-phone:before {
            content: "\E324"
        }

        .uxicon-add-to-page:before {
            content: "\E325"
        }

        .uxicon-exchange:before {
            content: "\E327"
        }

        .uxicon-camera:before {
            content: "\E345"
        }

        .uxicon-bookmark:before {
            content: "\E346"
        }

        .uxicon-package:before {
            content: "\E348"
        }

        .uxicon-paypal:before {
            content: "\E352"
        }

        .uxicon-homefinder:before {
            content: "\E357"
        }

        .uxicon-yahoo-box:before {
            content: "\E364"
        }

        .uxicon-chevron-right-lt:before {
            content: "\E367"
        }

        .uxicon-chevron-left-lt:before {
            content: "\E368"
        }

        .uxicon-chevron-down-lt:before {
            content: "\E369"
        }

        .uxicon-chevron-up-lt:before {
            content: "\E370"
        }

        .uxicon-radio-filled:before {
            content: "\E391"
        }

        .uxicon-chevron-dbl-right-lt:before {
            content: "\E399"
        }

        .uxicon-add-page:before {
            content: "\E401"
        }

        .uxicon-chevron-dbl-left-lt:before {
            content: "\E421"
        }

        .uxicon-alarm2:before {
            content: "\E442"
        }

        .uxicon-drop-down:before {
            content: "\E443"
        }

        .uxicon-drop-up:before {
            content: "\E444"
        }

        .uxicon-drop-right:before {
            content: "\E445"
        }

        .uxicon-drop-left:before {
            content: "\E446"
        }

        .uxicon-gd-logo-text:before {
            content: "\E467"
        }

        .uxicon-heart-outline:before {
            content: "\E020"
        }

        .uxicon-cloud:before {
            content: "\2601"
        }

        .uxicon-cloud-download:before {
            content: "\E025"
        }

        .uxicon-copy:before {
            content: "\E076"
        }

        .uxicon-grab-vert:before {
            content: "\E269"
        }

        .uxicon-link:before {
            content: "\E027"
        }

        .uxicon-link-delete:before {
            content: "\E028"
        }

        .uxicon-redo:before {
            content: "\E061"
        }

        .uxicon-share:before {
            content: "\E306"
        }

        .uxicon-zoom-in:before {
            content: "\E237"
        }

        .uxicon-zoom-out:before {
            content: "\E238"
        }

        .uxicon-airplane:before {
            content: "\E282"
        }

        .uxicon-alarm:before {
            content: "\E054"
        }

        .uxicon-album-contacts:before {
            content: "\E089"
        }

        .uxicon-asterisk:before {
            content: "*"
        }

        .uxicon-backspace:before {
            content: "\E257"
        }

        .uxicon-backward:before {
            content: "\E173"
        }

        .uxicon-barcode:before {
            content: "\E259"
        }

        .uxicon-binoculars:before {
            content: "\E239"
        }

        .uxicon-bluetooth:before {
            content: "\E226"
        }

        .uxicon-briefcase:before {
            content: "\E332"
        }

        .uxicon-cut:before {
            content: "\E286"
        }

        .uxicon-divide:before {
            content: "\F7"
        }

        .uxicon-dollar:before {
            content: "\E228"
        }

        .uxicon-dropdown-solid:before {
            content: "\E087"
        }

        .uxicon-drops:before {
            content: "\E093"
        }

        .uxicon-eject:before {
            content: "\E180"
        }

        .uxicon-ellipses:before {
            content: "\E188"
        }

        .uxicon-euro:before {
            content: "\20AC"
        }

        .uxicon-fast-backward:before {
            content: "\E172"
        }

        .uxicon-fast-forward:before {
            content: "\E178"
        }

        .uxicon-file:before {
            content: "\E131"
        }

        .uxicon-file-down:before {
            content: "\E135"
        }

        .uxicon-file-up:before {
            content: "\E136"
        }

        .uxicon-fire:before {
            content: "\E347"
        }

        .uxicon-folder-add:before {
            content: "\E146"
        }

        .uxicon-forward:before {
            content: "\E177"
        }

        .uxicon-gd-logo:before {
            content: "\E466"
        }

        .uxicon-global-east:before {
            content: "\E302"
        }

        .uxicon-global-west:before {
            content: "\E300"
        }

        .uxicon-laptop:before {
            content: "\E162"
        }

        .uxicon-leaf:before {
            content: "\E002"
        }

        .uxicon-lightbulb:before {
            content: "\E065"
        }

        .uxicon-lightning:before {
            content: "\E241"
        }

        .uxicon-location:before {
            content: "\E234"
        }

        .uxicon-mute:before {
            content: "\E183"
        }

        .uxicon-paintbrush:before {
            content: "\E235"
        }

        .uxicon-paperclip:before {
            content: "\E344"
        }

        .uxicon-pause:before {
            content: "\E175"
        }

        .uxicon-pointer-down:before {
            content: "\E343"
        }

        .uxicon-pointer-left:before {
            content: "\E338"
        }

        .uxicon-pointer-right:before {
            content: "\E337"
        }

        .uxicon-pointer-up:before {
            content: "\E341"
        }

        .uxicon-pound:before {
            content: "\E229"
        }

        .uxicon-power:before {
            content: "\E064"
        }

        .uxicon-qr-code:before {
            content: "\E258"
        }

        .uxicon-random:before {
            content: "\E182"
        }

        .uxicon-recycle:before {
            content: "\E083"
        }

        .uxicon-resize:before {
            content: "\E186"
        }

        .uxicon-resize-lg:before {
            content: "\E216"
        }

        .uxicon-resize-sm:before {
            content: "\E215"
        }

        .uxicon-signal:before {
            content: "\E323"
        }

        .uxicon-step-backward:before {
            content: "\E171"
        }

        .uxicon-step-forward:before {
            content: "\E179"
        }

        .uxicon-stop:before {
            content: "\E176"
        }

        .uxicon-stop-delete:before {
            content: "\E400"
        }

        .uxicon-stopwatch:before {
            content: "\E056"
        }

        .uxicon-subscript:before {
            content: "\E278"
        }

        .uxicon-tablet:before {
            content: "\E163"
        }

        .uxicon-tag:before {
            content: "\E066"
        }

        .uxicon-thumbs-down:before {
            content: "\E335"
        }

        .uxicon-thumbs-up:before {
            content: "\E333"
        }

        .uxicon-tumbler:before {
            content: "\E416"
        }

        .uxicon-umbrella:before {
            content: "\E014"
        }

        .uxicon-user-add:before {
            content: "\E006"
        }

        .uxicon-user-delete:before {
            content: "\E007"
        }

        .uxicon-video-camera:before {
            content: "\E170"
        }

        .uxicon-volume-down:before {
            content: "\E184"
        }

        .uxicon-volume-up:before {
            content: "\E185"
        }

        .uxicon-wi-fi:before {
            content: "\E074"
        }

        .uxicon-accelerator:before {
            content: "\E295"
        }

        .uxicon-at:before {
            content: "\E029"
        }

        .uxicon-clipboard:before {
            content: "\E030"
        }

        .uxicon-clock-refresh:before {
            content: "\E057"
        }

        .uxicon-forward-2:before {
            content: "\E222"
        }

        .uxicon-gift:before {
            content: "\E070"
        }

        .uxicon-graph:before {
            content: "\E041"
        }

        .uxicon-grid-sm:before {
            content: "\E157"
        }

        .uxicon-horizontal-menu:before {
            content: "\E273"
        }

        .uxicon-orientation-lock:before {
            content: "\E059"
        }

        .uxicon-reply:before {
            content: "\E221"
        }

        .uxicon-reply-all:before {
            content: "\E223"
        }

        .uxicon-star-half:before {
            content: "\E415"
        }

        .uxicon-vertical-menu:before {
            content: "\E274"
        }

        .uxicon-align-center:before {
            content: "\E112"
        }

        .uxicon-align-justify:before {
            content: "\E114"
        }

        .uxicon-align-left:before {
            content: "\E111"
        }

        .uxicon-align-right:before {
            content: "\E113"
        }

        .uxicon-amazon-box:before {
            content: "\E371"
        }

        .uxicon-apps:before {
            content: "\E001"
        }

        .uxicon-at-box:before {
            content: "\E380"
        }

        .uxicon-blogger-box:before {
            content: "\E365"
        }

        .uxicon-bold:before {
            content: "\E103"
        }

        .uxicon-bounding-box:before {
            content: "\E100"
        }

        .uxicon-clear-formatting:before {
            content: "\E279"
        }

        .uxicon-create-form:before {
            content: "\E398"
        }

        .uxicon-create-nav:before {
            content: "\E397"
        }

        .uxicon-crop:before {
            content: "\E094"
        }

        .uxicon-dropdown:before {
            content: "\E438"
        }

        .uxicon-equal-width:before {
            content: "\E276"
        }

        .uxicon-eye-dropper:before {
            content: "\E091"
        }

        .uxicon-facebook-box:before {
            content: "\E376"
        }

        .uxicon-flatrate:before {
            content: "\E436"
        }

        .uxicon-full-width:before {
            content: "\E275"
        }

        .uxicon-google-plus-box:before {
            content: "\E360"
        }

        .uxicon-img-gallery:before {
            content: "\E394"
        }

        .uxicon-img-resize:before {
            content: "\E265"
        }

        .uxicon-indent-left:before {
            content: "\E110"
        }

        .uxicon-indent-right:before {
            content: "\E109"
        }

        .uxicon-instagram:before {
            content: "\E378"
        }

        .uxicon-italics:before {
            content: "\E102"
        }

        .uxicon-linkedin-box:before {
            content: "\E374"
        }

        .uxicon-locu:before {
            content: "\E356"
        }

        .uxicon-locu-box:before {
            content: "\E373"
        }

        .uxicon-map:before {
            content: "\E247"
        }

        .uxicon-nav:before {
            content: "\E048"
        }

        .uxicon-numbered-list:before {
            content: "\E280"
        }

        .uxicon-page:before {
            content: "\E037"
        }

        .uxicon-picasa-box:before {
            content: "\E366"
        }

        .uxicon-pin:before {
            content: "\E051"
        }

        .uxicon-pinterest-box:before {
            content: "\E358"
        }

        .uxicon-remove-from-page:before {
            content: "\E326"
        }

        .uxicon-retweet:before {
            content: "\E081"
        }

        .uxicon-settings3:before {
            content: "\E140"
        }

        .uxicon-social:before {
            content: "\E310"
        }

        .uxicon-strike-through:before {
            content: "\E105"
        }

        .uxicon-superscript:before {
            content: "\E101"
        }

        .uxicon-table:before {
            content: "\E284"
        }

        .uxicon-tag-end:before {
            content: "\E119"
        }

        .uxicon-tag-open:before {
            content: "\E118"
        }

        .uxicon-text-highlight:before {
            content: "\E402"
        }

        .uxicon-text-tool:before {
            content: "\E277"
        }

        .uxicon-truck:before {
            content: "\E432"
        }

        .uxicon-twitter:before {
            content: "\E354"
        }

        .uxicon-twitter-box:before {
            content: "\E377"
        }

        .uxicon-underline:before {
            content: "\E104"
        }

        .uxicon-video:before {
            content: "\E009"
        }

        .uxicon-website-send:before {
            content: "\E045"
        }

        .uxicon-yelp-box:before {
            content: "\E384"
        }

        .uxicon-youtube-box:before {
            content: "\E375"
        }

        .uxicon-core-os:before {
            content: "\E442"
        }

        .uxicon-office365-box:before {
            content: "\E443"
        }

        .uxicon-android-box:before {
            content: "\E385"
        }

        .uxicon-apple-box:before {
            content: "\E381"
        }

        .uxicon-archlinux:before {
            content: "\E425"
        }

        .uxicon-blackberry:before {
            content: "\E411"
        }

        .uxicon-centos:before {
            content: "\E422"
        }

        .uxicon-create-btn:before {
            content: "\E396"
        }

        .uxicon-debian:before {
            content: "\E423"
        }

        .uxicon-fedora:before {
            content: "\E424"
        }

        .uxicon-excel:before {
            content: "\E420"
        }

        .uxicon-outlook:before {
            content: "\E418"
        }

        .uxicon-pinned:before {
            content: "\E405"
        }

        .uxicon-powerpoint:before {
            content: "\E417"
        }

        .uxicon-privacy:before {
            content: "\E431"
        }

        .uxicon-receipt:before {
            content: "\E439"
        }

        .uxicon-ubuntu:before {
            content: "\E426"
        }

        .uxicon-thunderbird:before {
            content: "\E429"
        }

        .uxicon-word:before {
            content: "\E419"
        }

        .uxicon-windows-box:before {
            content: "\E382"
        }

        .uxicon-windowsserver:before {
            content: "\E427"
        }

        .uxicon-wordpress-box:before {
            content: "\E372"
        }

        .uxicon-folder:before {
            content: "\E469"
        }

        .uxicon-kabob:before {
            content: "\E470"
        }

        .uxicon-archive:before {
            content: "\E471"
        }

        .fade {
            opacity: 0;
            transition: opacity .15s linear
        }

        .fade.in {
            opacity: 1
        }

        .collapse {
            display: none
        }

        .collapse.in {
            display: block
        }

        .container-fluid::after,
        .container::after,
        .row::after {
            content: "";
            display: table;
            clear: both
        }

        .collapsing {
            height: 0;
            transition-timing-function: ease;
            transition-duration: .35s;
            transition-property: height
        }

        @media (min-width:520px) {
            .container {
                max-width: 480px
            }
        }

        @media (min-width:768px) {
            .container {
                max-width: 720px
            }
        }

        @media (min-width:992px) {
            .container {
                max-width: 940px
            }
        }

        @media (min-width:1200px) {
            .container {
                max-width: 1140px
            }
        }

        .img-fluid,
        .img-thumbnail,
        .ux-pivot-graphic img {
            max-width: 100%;
            height: auto
        }

        .row {
            margin-left: -10px;
            margin-right: -10px
        }

        .no-gutters {
            margin-right: 0;
            margin-left: 0
        }

        .no-gutters>.col,
        .no-gutters>[class*=col-] {
            padding-right: 0;
            padding-left: 0
        }

        .col-lg-1,
        .col-lg-10,
        .col-lg-11,
        .col-lg-12,
        .col-lg-2,
        .col-lg-3,
        .col-lg-4,
        .col-lg-5,
        .col-lg-6,
        .col-lg-7,
        .col-lg-8,
        .col-lg-9,
        .col-md-1,
        .col-md-10,
        .col-md-11,
        .col-md-12,
        .col-md-2,
        .col-md-3,
        .col-md-4,
        .col-md-5,
        .col-md-6,
        .col-md-7,
        .col-md-8,
        .col-md-9,
        .col-sm-1,
        .col-sm-10,
        .col-sm-11,
        .col-sm-12,
        .col-sm-2,
        .col-sm-3,
        .col-sm-4,
        .col-sm-5,
        .col-sm-6,
        .col-sm-7,
        .col-sm-8,
        .col-sm-9,
        .col-xl-1,
        .col-xl-10,
        .col-xl-11,
        .col-xl-12,
        .col-xl-2,
        .col-xl-3,
        .col-xl-4,
        .col-xl-5,
        .col-xl-6,
        .col-xl-7,
        .col-xl-8,
        .col-xl-9,
        .col-xs-1,
        .col-xs-10,
        .col-xs-11,
        .col-xs-12,
        .col-xs-2,
        .col-xs-3,
        .col-xs-4,
        .col-xs-5,
        .col-xs-6,
        .col-xs-7,
        .col-xs-8,
        .col-xs-9 {
            position: relative;
            min-height: 1px;
            padding-right: 10px;
            padding-left: 10px
        }

        .col-xs-1 {
            float: left;
            width: 8.33333%
        }

        .col-xs-2 {
            float: left;
            width: 16.66667%
        }

        .col-xs-3 {
            float: left;
            width: 25%
        }

        .col-xs-4 {
            float: left;
            width: 33.33333%
        }

        .col-xs-5 {
            float: left;
            width: 41.66667%
        }

        .col-xs-6 {
            float: left;
            width: 50%
        }

        .col-xs-7 {
            float: left;
            width: 58.33333%
        }

        .col-xs-8 {
            float: left;
            width: 66.66667%
        }

        .col-xs-9 {
            float: left;
            width: 75%
        }

        .col-xs-10 {
            float: left;
            width: 83.33333%
        }

        .col-xs-11 {
            float: left;
            width: 91.66667%
        }

        .col-xs-12 {
            float: left;
            width: 100%
        }

        .pull-xs-0 {
            right: auto
        }

        .pull-xs-1 {
            right: 8.33333%
        }

        .pull-xs-2 {
            right: 16.66667%
        }

        .pull-xs-3 {
            right: 25%
        }

        .pull-xs-4 {
            right: 33.33333%
        }

        .pull-xs-5 {
            right: 41.66667%
        }

        .pull-xs-6 {
            right: 50%
        }

        .pull-xs-7 {
            right: 58.33333%
        }

        .pull-xs-8 {
            right: 66.66667%
        }

        .pull-xs-9 {
            right: 75%
        }

        .pull-xs-10 {
            right: 83.33333%
        }

        .pull-xs-11 {
            right: 91.66667%
        }

        .pull-xs-12 {
            right: 100%
        }

        .push-xs-0 {
            left: auto
        }

        .push-xs-1 {
            left: 8.33333%
        }

        .push-xs-2 {
            left: 16.66667%
        }

        .push-xs-3 {
            left: 25%
        }

        .push-xs-4 {
            left: 33.33333%
        }

        .push-xs-5 {
            left: 41.66667%
        }

        .push-xs-6 {
            left: 50%
        }

        .push-xs-7 {
            left: 58.33333%
        }

        .push-xs-8 {
            left: 66.66667%
        }

        .push-xs-9 {
            left: 75%
        }

        .push-xs-10 {
            left: 83.33333%
        }

        .push-xs-11 {
            left: 91.66667%
        }

        .push-xs-12 {
            left: 100%
        }

        .offset-xs-1 {
            margin-left: 8.33333%
        }

        .offset-xs-2 {
            margin-left: 16.66667%
        }

        .offset-xs-3 {
            margin-left: 25%
        }

        .offset-xs-4 {
            margin-left: 33.33333%
        }

        .offset-xs-5 {
            margin-left: 41.66667%
        }

        .offset-xs-6 {
            margin-left: 50%
        }

        .offset-xs-7 {
            margin-left: 58.33333%
        }

        .offset-xs-8 {
            margin-left: 66.66667%
        }

        .offset-xs-9 {
            margin-left: 75%
        }

        .offset-xs-10 {
            margin-left: 83.33333%
        }

        .offset-xs-11 {
            margin-left: 91.66667%
        }

        @media (min-width:520px) {
            .col-sm-1 {
                float: left;
                width: 8.33333%
            }

            .col-sm-2 {
                float: left;
                width: 16.66667%
            }

            .col-sm-3 {
                float: left;
                width: 25%
            }

            .col-sm-4 {
                float: left;
                width: 33.33333%
            }

            .col-sm-5 {
                float: left;
                width: 41.66667%
            }

            .col-sm-6 {
                float: left;
                width: 50%
            }

            .col-sm-7 {
                float: left;
                width: 58.33333%
            }

            .col-sm-8 {
                float: left;
                width: 66.66667%
            }

            .col-sm-9 {
                float: left;
                width: 75%
            }

            .col-sm-10 {
                float: left;
                width: 83.33333%
            }

            .col-sm-11 {
                float: left;
                width: 91.66667%
            }

            .col-sm-12 {
                float: left;
                width: 100%
            }

            .pull-sm-0 {
                right: auto
            }

            .pull-sm-1 {
                right: 8.33333%
            }

            .pull-sm-2 {
                right: 16.66667%
            }

            .pull-sm-3 {
                right: 25%
            }

            .pull-sm-4 {
                right: 33.33333%
            }

            .pull-sm-5 {
                right: 41.66667%
            }

            .pull-sm-6 {
                right: 50%
            }

            .pull-sm-7 {
                right: 58.33333%
            }

            .pull-sm-8 {
                right: 66.66667%
            }

            .pull-sm-9 {
                right: 75%
            }

            .pull-sm-10 {
                right: 83.33333%
            }

            .pull-sm-11 {
                right: 91.66667%
            }

            .pull-sm-12 {
                right: 100%
            }

            .push-sm-0 {
                left: auto
            }

            .push-sm-1 {
                left: 8.33333%
            }

            .push-sm-2 {
                left: 16.66667%
            }

            .push-sm-3 {
                left: 25%
            }

            .push-sm-4 {
                left: 33.33333%
            }

            .push-sm-5 {
                left: 41.66667%
            }

            .push-sm-6 {
                left: 50%
            }

            .push-sm-7 {
                left: 58.33333%
            }

            .push-sm-8 {
                left: 66.66667%
            }

            .push-sm-9 {
                left: 75%
            }

            .push-sm-10 {
                left: 83.33333%
            }

            .push-sm-11 {
                left: 91.66667%
            }

            .push-sm-12 {
                left: 100%
            }

            .offset-sm-0 {
                margin-left: 0
            }

            .offset-sm-1 {
                margin-left: 8.33333%
            }

            .offset-sm-2 {
                margin-left: 16.66667%
            }

            .offset-sm-3 {
                margin-left: 25%
            }

            .offset-sm-4 {
                margin-left: 33.33333%
            }

            .offset-sm-5 {
                margin-left: 41.66667%
            }

            .offset-sm-6 {
                margin-left: 50%
            }

            .offset-sm-7 {
                margin-left: 58.33333%
            }

            .offset-sm-8 {
                margin-left: 66.66667%
            }

            .offset-sm-9 {
                margin-left: 75%
            }

            .offset-sm-10 {
                margin-left: 83.33333%
            }

            .offset-sm-11 {
                margin-left: 91.66667%
            }
        }

        @media (min-width:768px) {
            .col-md-1 {
                float: left;
                width: 8.33333%
            }

            .col-md-2 {
                float: left;
                width: 16.66667%
            }

            .col-md-3 {
                float: left;
                width: 25%
            }

            .col-md-4 {
                float: left;
                width: 33.33333%
            }

            .col-md-5 {
                float: left;
                width: 41.66667%
            }

            .col-md-6 {
                float: left;
                width: 50%
            }

            .col-md-7 {
                float: left;
                width: 58.33333%
            }

            .col-md-8 {
                float: left;
                width: 66.66667%
            }

            .col-md-9 {
                float: left;
                width: 75%
            }

            .col-md-10 {
                float: left;
                width: 83.33333%
            }

            .col-md-11 {
                float: left;
                width: 91.66667%
            }

            .col-md-12 {
                float: left;
                width: 100%
            }

            .pull-md-0 {
                right: auto
            }

            .pull-md-1 {
                right: 8.33333%
            }

            .pull-md-2 {
                right: 16.66667%
            }

            .pull-md-3 {
                right: 25%
            }

            .pull-md-4 {
                right: 33.33333%
            }

            .pull-md-5 {
                right: 41.66667%
            }

            .pull-md-6 {
                right: 50%
            }

            .pull-md-7 {
                right: 58.33333%
            }

            .pull-md-8 {
                right: 66.66667%
            }

            .pull-md-9 {
                right: 75%
            }

            .pull-md-10 {
                right: 83.33333%
            }

            .pull-md-11 {
                right: 91.66667%
            }

            .pull-md-12 {
                right: 100%
            }

            .push-md-0 {
                left: auto
            }

            .push-md-1 {
                left: 8.33333%
            }

            .push-md-2 {
                left: 16.66667%
            }

            .push-md-3 {
                left: 25%
            }

            .push-md-4 {
                left: 33.33333%
            }

            .push-md-5 {
                left: 41.66667%
            }

            .push-md-6 {
                left: 50%
            }

            .push-md-7 {
                left: 58.33333%
            }

            .push-md-8 {
                left: 66.66667%
            }

            .push-md-9 {
                left: 75%
            }

            .push-md-10 {
                left: 83.33333%
            }

            .push-md-11 {
                left: 91.66667%
            }

            .push-md-12 {
                left: 100%
            }

            .offset-md-0 {
                margin-left: 0
            }

            .offset-md-1 {
                margin-left: 8.33333%
            }

            .offset-md-2 {
                margin-left: 16.66667%
            }

            .offset-md-3 {
                margin-left: 25%
            }

            .offset-md-4 {
                margin-left: 33.33333%
            }

            .offset-md-5 {
                margin-left: 41.66667%
            }

            .offset-md-6 {
                margin-left: 50%
            }

            .offset-md-7 {
                margin-left: 58.33333%
            }

            .offset-md-8 {
                margin-left: 66.66667%
            }

            .offset-md-9 {
                margin-left: 75%
            }

            .offset-md-10 {
                margin-left: 83.33333%
            }

            .offset-md-11 {
                margin-left: 91.66667%
            }
        }

        @media (min-width:992px) {
            .col-lg-1 {
                float: left;
                width: 8.33333%
            }

            .col-lg-2 {
                float: left;
                width: 16.66667%
            }

            .col-lg-3 {
                float: left;
                width: 25%
            }

            .col-lg-4 {
                float: left;
                width: 33.33333%
            }

            .col-lg-5 {
                float: left;
                width: 41.66667%
            }

            .col-lg-6 {
                float: left;
                width: 50%
            }

            .col-lg-7 {
                float: left;
                width: 58.33333%
            }

            .col-lg-8 {
                float: left;
                width: 66.66667%
            }

            .col-lg-9 {
                float: left;
                width: 75%
            }

            .col-lg-10 {
                float: left;
                width: 83.33333%
            }

            .col-lg-11 {
                float: left;
                width: 91.66667%
            }

            .col-lg-12 {
                float: left;
                width: 100%
            }

            .pull-lg-0 {
                right: auto
            }

            .pull-lg-1 {
                right: 8.33333%
            }

            .pull-lg-2 {
                right: 16.66667%
            }

            .pull-lg-3 {
                right: 25%
            }

            .pull-lg-4 {
                right: 33.33333%
            }

            .pull-lg-5 {
                right: 41.66667%
            }

            .pull-lg-6 {
                right: 50%
            }

            .pull-lg-7 {
                right: 58.33333%
            }

            .pull-lg-8 {
                right: 66.66667%
            }

            .pull-lg-9 {
                right: 75%
            }

            .pull-lg-10 {
                right: 83.33333%
            }

            .pull-lg-11 {
                right: 91.66667%
            }

            .pull-lg-12 {
                right: 100%
            }

            .push-lg-0 {
                left: auto
            }

            .push-lg-1 {
                left: 8.33333%
            }

            .push-lg-2 {
                left: 16.66667%
            }

            .push-lg-3 {
                left: 25%
            }

            .push-lg-4 {
                left: 33.33333%
            }

            .push-lg-5 {
                left: 41.66667%
            }

            .push-lg-6 {
                left: 50%
            }

            .push-lg-7 {
                left: 58.33333%
            }

            .push-lg-8 {
                left: 66.66667%
            }

            .push-lg-9 {
                left: 75%
            }

            .push-lg-10 {
                left: 83.33333%
            }

            .push-lg-11 {
                left: 91.66667%
            }

            .push-lg-12 {
                left: 100%
            }

            .offset-lg-0 {
                margin-left: 0
            }

            .offset-lg-1 {
                margin-left: 8.33333%
            }

            .offset-lg-2 {
                margin-left: 16.66667%
            }

            .offset-lg-3 {
                margin-left: 25%
            }

            .offset-lg-4 {
                margin-left: 33.33333%
            }

            .offset-lg-5 {
                margin-left: 41.66667%
            }

            .offset-lg-6 {
                margin-left: 50%
            }

            .offset-lg-7 {
                margin-left: 58.33333%
            }

            .offset-lg-8 {
                margin-left: 66.66667%
            }

            .offset-lg-9 {
                margin-left: 75%
            }

            .offset-lg-10 {
                margin-left: 83.33333%
            }

            .offset-lg-11 {
                margin-left: 91.66667%
            }
        }

        @media (min-width:1200px) {
            .col-xl-1 {
                float: left;
                width: 8.33333%
            }

            .col-xl-2 {
                float: left;
                width: 16.66667%
            }

            .col-xl-3 {
                float: left;
                width: 25%
            }

            .col-xl-4 {
                float: left;
                width: 33.33333%
            }

            .col-xl-5 {
                float: left;
                width: 41.66667%
            }

            .col-xl-6 {
                float: left;
                width: 50%
            }

            .col-xl-7 {
                float: left;
                width: 58.33333%
            }

            .col-xl-8 {
                float: left;
                width: 66.66667%
            }

            .col-xl-9 {
                float: left;
                width: 75%
            }

            .col-xl-10 {
                float: left;
                width: 83.33333%
            }

            .col-xl-11 {
                float: left;
                width: 91.66667%
            }

            .col-xl-12 {
                float: left;
                width: 100%
            }

            .pull-xl-0 {
                right: auto
            }

            .pull-xl-1 {
                right: 8.33333%
            }

            .pull-xl-2 {
                right: 16.66667%
            }

            .pull-xl-3 {
                right: 25%
            }

            .pull-xl-4 {
                right: 33.33333%
            }

            .pull-xl-5 {
                right: 41.66667%
            }

            .pull-xl-6 {
                right: 50%
            }

            .pull-xl-7 {
                right: 58.33333%
            }

            .pull-xl-8 {
                right: 66.66667%
            }

            .pull-xl-9 {
                right: 75%
            }

            .pull-xl-10 {
                right: 83.33333%
            }

            .pull-xl-11 {
                right: 91.66667%
            }

            .pull-xl-12 {
                right: 100%
            }

            .push-xl-0 {
                left: auto
            }

            .push-xl-1 {
                left: 8.33333%
            }

            .push-xl-2 {
                left: 16.66667%
            }

            .push-xl-3 {
                left: 25%
            }

            .push-xl-4 {
                left: 33.33333%
            }

            .push-xl-5 {
                left: 41.66667%
            }

            .push-xl-6 {
                left: 50%
            }

            .push-xl-7 {
                left: 58.33333%
            }

            .push-xl-8 {
                left: 66.66667%
            }

            .push-xl-9 {
                left: 75%
            }

            .push-xl-10 {
                left: 83.33333%
            }

            .push-xl-11 {
                left: 91.66667%
            }

            .push-xl-12 {
                left: 100%
            }

            .offset-xl-0 {
                margin-left: 0
            }

            .offset-xl-1 {
                margin-left: 8.33333%
            }

            .offset-xl-2 {
                margin-left: 16.66667%
            }

            .offset-xl-3 {
                margin-left: 25%
            }

            .offset-xl-4 {
                margin-left: 33.33333%
            }

            .offset-xl-5 {
                margin-left: 41.66667%
            }

            .offset-xl-6 {
                margin-left: 50%
            }

            .offset-xl-7 {
                margin-left: 58.33333%
            }

            .offset-xl-8 {
                margin-left: 66.66667%
            }

            .offset-xl-9 {
                margin-left: 75%
            }

            .offset-xl-10 {
                margin-left: 83.33333%
            }

            .offset-xl-11 {
                margin-left: 91.66667%
            }
        }

        .img-rounded {
            border-radius: 8px
        }

        .img-thumbnail {
            padding: .25rem;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 6px;
            transition: all .2s ease-in-out;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .075)
        }

        .figure {
            display: inline-block
        }

        .figure-img {
            margin-bottom: .5rem;
            line-height: 1
        }

        .figure-caption {
            font-size: 90%;
            color: #868e96
        }

        @media print {

            blockquote,
            img,
            pre,
            tr {
                page-break-inside: avoid
            }

            *,
            ::after,
            ::before {
                text-shadow: none !important;
                box-shadow: none !important
            }

            a,
            a:visited {
                text-decoration: underline
            }

            abbr[title]::after {
                content: " (" attr(title) ")"
            }

            pre {
                white-space: pre-wrap !important
            }

            blockquote,
            pre {
                border: 1px solid #999
            }

            thead {
                display: table-header-group
            }

            h2,
            h3,
            p {
                orphans: 3;
                widows: 3
            }

            h2,
            h3 {
                page-break-after: avoid
            }

            .navbar {
                display: none
            }

            .badge {
                border: 1px solid #000
            }

            .basegrid,
            .table {
                border-collapse: collapse !important
            }

            .basegrid td,
            .basegrid th,
            .table td,
            .table th {
                background-color: #fff !important
            }

            .basegrid td,
            .basegrid th,
            .table-bordered td,
            .table-bordered th {
                border: 1px solid #ddd !important
            }
        }

        .close,
        .text-hide,
        .tooltip {
            text-shadow: none
        }

        .input-group-addon,
        .input-group-btn,
        .input-group-btn .btn,
        .sr-only {
            white-space: nowrap
        }

        .ux-app {
            background-color: #f5f7f8
        }

        .card,
        .ux-pagetitle {
            background-color: #fff
        }

        .ux-pagetitle {
            padding: 3.0625rem 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 0 rgba(0, 0, 0, .1)
        }

        .ux-pagetitle h1 {
            margin: 0
        }

        .ux-pagetitle h1+p {
            margin: .2em 0 0;
            font-size: 1rem
        }

        .ux-pagetitle .breadcrumb {
            margin: 0 0 .45em
        }

        @media (min-width:768px) {
            .ux-pagetitle {
                padding-right: 0;
                padding-left: 0
            }

            .ux-pagetitle-show-icn {
                padding-left: 100px
            }
        }

        .card-block,
        .card-body {
            padding: 1.25rem
        }

        .ux-pagetitle-show-icn .ux-pagetitle-icn {
            position: absolute;
            top: 0;
            left: 0;
            display: none;
            font-size: 7rem;
            color: #000
        }

        @media (min-width:768px) {
            .ux-pagetitle-show-icn .ux-pagetitle-icn {
                display: block
            }
        }

        .svg-fill-white {
            fill: #fff !important
        }

        .svg-stroke-white {
            stroke: #fff !important
        }

        .svg-fill-black {
            fill: #111 !important
        }

        .svg-stroke-black {
            stroke: #111 !important
        }

        .svg-fill-black-dark {
            fill: #000 !important
        }

        .svg-stroke-black-dark {
            stroke: #000 !important
        }

        .svg-fill-gray {
            fill: #757575 !important
        }

        .svg-stroke-gray {
            stroke: #757575 !important
        }

        .svg-fill-gray-faint {
            fill: #f5f7f8 !important
        }

        .svg-stroke-gray-faint {
            stroke: #f5f7f8 !important
        }

        .svg-fill-gray-light {
            fill: #aab7c2 !important
        }

        .svg-stroke-gray-light {
            stroke: #aab7c2 !important
        }

        .svg-fill-gray-midrange {
            fill: #444 !important
        }

        .svg-stroke-gray-midrange {
            stroke: #444 !important
        }

        .svg-fill-gray-dark {
            fill: #2b2b2b !important
        }

        .svg-stroke-gray-dark {
            stroke: #2b2b2b !important
        }

        .svg-fill-product {
            fill: #f5f7f8 !important
        }

        .svg-stroke-product {
            stroke: #f5f7f8 !important
        }

        .svg-fill-product-faint {
            fill: #e8eaeb !important
        }

        .svg-stroke-product-faint {
            stroke: #e8eaeb !important
        }

        .svg-fill-product-light {
            fill: #d6d6d6 !important
        }

        .svg-stroke-product-light {
            stroke: #d6d6d6 !important
        }

        .svg-fill-product-midrange {
            fill: #bfbfbf !important
        }

        .svg-stroke-product-midrange {
            stroke: #bfbfbf !important
        }

        .svg-fill-product-dark {
            fill: #999 !important
        }

        .svg-stroke-product-dark {
            stroke: #999 !important
        }

        .svg-fill-primary {
            fill: #00a63f !important
        }

        .svg-stroke-primary {
            stroke: #00a63f !important
        }

        .svg-fill-primary-pastel {
            fill: #d9f2e2 !important
        }

        .svg-stroke-primary-pastel {
            stroke: #d9f2e2 !important
        }

        .svg-fill-primary-highlight {
            fill: #02c54c !important
        }

        .svg-stroke-primary-highlight {
            stroke: #02c54c !important
        }

        .svg-fill-primary-midrange {
            fill: #00782e !important
        }

        .svg-stroke-primary-midrange {
            stroke: #00782e !important
        }

        .svg-fill-primary-dark {
            fill: #004f1e !important
        }

        .svg-stroke-primary-dark {
            stroke: #004f1e !important
        }

        .svg-fill-primary-o {
            fill: #00a63f !important
        }

        .svg-stroke-primary-o {
            stroke: #00a63f !important
        }

        .svg-fill-primary-o-pastel {
            fill: #d9f2e2 !important
        }

        .svg-stroke-primary-o-pastel {
            stroke: #d9f2e2 !important
        }

        .svg-fill-primary-o-highlight {
            fill: #02c54c !important
        }

        .svg-stroke-primary-o-highlight {
            stroke: #02c54c !important
        }

        .svg-fill-primary-o-midrange {
            fill: #00782e !important
        }

        .svg-stroke-primary-o-midrange {
            stroke: #00782e !important
        }

        .svg-fill-primary-o-dark {
            fill: #004f1e !important
        }

        .svg-stroke-primary-o-dark {
            stroke: #004f1e !important
        }

        .svg-fill-success {
            fill: #00a63f !important
        }

        .svg-stroke-success {
            stroke: #00a63f !important
        }

        .svg-fill-success-pastel {
            fill: #d9f2e2 !important
        }

        .svg-stroke-success-pastel {
            stroke: #d9f2e2 !important
        }

        .svg-fill-success-highlight {
            fill: #02c54c !important
        }

        .svg-stroke-success-highlight {
            stroke: #02c54c !important
        }

        .svg-fill-success-midrange {
            fill: #00782e !important
        }

        .svg-stroke-success-midrange {
            stroke: #00782e !important
        }

        .svg-fill-success-dark {
            fill: #004f1e !important
        }

        .svg-stroke-success-dark {
            stroke: #004f1e !important
        }

        .svg-fill-secondary {
            fill: #1976d2 !important
        }

        .svg-stroke-secondary {
            stroke: #1976d2 !important
        }

        .svg-fill-secondary-pastel {
            fill: #ddeaf8 !important
        }

        .svg-stroke-secondary-pastel {
            stroke: #ddeaf8 !important
        }

        .svg-fill-secondary-highlight {
            fill: #4095e8 !important
        }

        .svg-stroke-secondary-highlight {
            stroke: #4095e8 !important
        }

        .svg-fill-secondary-midrange {
            fill: #145fa9 !important
        }

        .svg-stroke-secondary-midrange {
            stroke: #145fa9 !important
        }

        .svg-fill-secondary-dark {
            fill: #104a85 !important
        }

        .svg-stroke-secondary-dark {
            stroke: #104a85 !important
        }

        .svg-fill-secondary-o {
            fill: #1976d2 !important
        }

        .svg-stroke-secondary-o {
            stroke: #1976d2 !important
        }

        .svg-fill-secondary-o-pastel {
            fill: #ddeaf8 !important
        }

        .svg-stroke-secondary-o-pastel {
            stroke: #ddeaf8 !important
        }

        .svg-fill-secondary-o-highlight {
            fill: #4095e8 !important
        }

        .svg-stroke-secondary-o-highlight {
            stroke: #4095e8 !important
        }

        .svg-fill-secondary-o-midrange {
            fill: #145fa9 !important
        }

        .svg-stroke-secondary-o-midrange {
            stroke: #145fa9 !important
        }

        .svg-fill-secondary-o-dark {
            fill: #104a85 !important
        }

        .svg-stroke-secondary-o-dark {
            stroke: #104a85 !important
        }

        .svg-fill-nav {
            fill: #ef6c0f !important
        }

        .svg-stroke-nav {
            stroke: #ef6c0f !important
        }

        .svg-fill-nav-pastel {
            fill: #fde9db !important
        }

        .svg-stroke-nav-pastel {
            stroke: #fde9db !important
        }

        .svg-fill-nav-highlight {
            fill: #f38f48 !important
        }

        .svg-stroke-nav-highlight {
            stroke: #f38f48 !important
        }

        .svg-fill-nav-midrange {
            fill: #c4580c !important
        }

        .svg-stroke-nav-midrange {
            stroke: #c4580c !important
        }

        .svg-fill-nav-dark {
            fill: #9d470a !important
        }

        .svg-stroke-nav-dark {
            stroke: #9d470a !important
        }

        .svg-fill-info {
            fill: #9e42b5 !important
        }

        .svg-stroke-info {
            stroke: #9e42b5 !important
        }

        .svg-fill-info-pastel {
            fill: #f0e3f4 !important
        }

        .svg-stroke-info-pastel {
            stroke: #f0e3f4 !important
        }

        .svg-fill-info-highlight {
            fill: #b66bc9 !important
        }

        .svg-stroke-info-highlight {
            stroke: #b66bc9 !important
        }

        .svg-fill-info-midrange {
            fill: #813693 !important
        }

        .svg-stroke-info-midrange {
            stroke: #813693 !important
        }

        .svg-fill-info-dark {
            fill: #672b75 !important
        }

        .svg-stroke-info-dark {
            stroke: #672b75 !important
        }

        .svg-fill-warning {
            fill: #fedc45 !important
        }

        .svg-stroke-warning {
            stroke: #fedc45 !important
        }

        .svg-fill-warning-pastel {
            fill: #fffae3 !important
        }

        .svg-stroke-warning-pastel {
            stroke: #fffae3 !important
        }

        .svg-fill-warning-highlight {
            fill: #fee782 !important
        }

        .svg-stroke-warning-highlight {
            stroke: #fee782 !important
        }

        .svg-fill-warning-midrange {
            fill: #fed317 !important
        }

        .svg-stroke-warning-midrange {
            stroke: #fed317 !important
        }

        .svg-fill-warning-dark {
            fill: #ebc001 !important
        }

        .svg-stroke-warning-dark {
            stroke: #ebc001 !important
        }

        .svg-fill-danger {
            fill: #db1802 !important
        }

        .svg-stroke-danger {
            stroke: #db1802 !important
        }

        .svg-fill-danger-pastel {
            fill: #fadcd9 !important
        }

        .svg-stroke-danger-pastel {
            stroke: #fadcd9 !important
        }

        .svg-fill-danger-highlight {
            fill: #fd341d !important
        }

        .svg-stroke-danger-highlight {
            stroke: #fd341d !important
        }

        .svg-fill-danger-midrange {
            fill: #ae1302 !important
        }

        .svg-stroke-danger-midrange {
            stroke: #ae1302 !important
        }

        .svg-fill-danger-dark {
            fill: #850f01 !important
        }

        .svg-stroke-danger-dark {
            stroke: #850f01 !important
        }

        .svg-fill-feature {
            fill: #e20087 !important
        }

        .svg-stroke-feature {
            stroke: #e20087 !important
        }

        .svg-fill-feature-pastel {
            fill: #fbd9ed !important
        }

        .svg-stroke-feature-pastel {
            stroke: #fbd9ed !important
        }

        .svg-fill-feature-highlight {
            fill: #ff20a5 !important
        }

        .svg-stroke-feature-highlight {
            stroke: #ff20a5 !important
        }

        .svg-fill-feature-midrange {
            fill: #b4006c !important
        }

        .svg-stroke-feature-midrange {
            stroke: #b4006c !important
        }

        .svg-fill-feature-dark {
            fill: #8b0053 !important
        }

        .svg-stroke-feature-dark {
            stroke: #8b0053 !important
        }

        .svg-fill-natural {
            fill: #fbb684 !important
        }

        .svg-stroke-natural {
            stroke: #fbb684 !important
        }

        .svg-fill-natural-pastel {
            fill: #ffe8c9 !important
        }

        .svg-stroke-natural-pastel {
            stroke: #ffe8c9 !important
        }

        .svg-fill-natural-highlight {
            fill: #fed9b4 !important
        }

        .svg-stroke-natural-highlight {
            stroke: #fed9b4 !important
        }

        .svg-fill-natural-midrange {
            fill: #bd8150 !important
        }

        .svg-stroke-natural-midrange {
            stroke: #bd8150 !important
        }

        .svg-fill-natural-dark {
            fill: #a36841 !important
        }

        .svg-stroke-natural-dark {
            stroke: #a36841 !important
        }

        .svg-fill-none {
            fill: none !important
        }

        .svg-stroke-none {
            stroke-opacity: 0 !important
        }

        .card {
            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            background-clip: border-box;
            border: 1px solid rgba(0, 0, 0, .125);
            border-radius: 0
        }

        .card>hr {
            margin-right: 0;
            margin-left: 0
        }

        .card>.list-group:first-child .list-group-item:first-child {
            border-top-right-radius: 0;
            border-top-left-radius: 0
        }

        .card>.list-group:last-child .list-group-item:last-child {
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0
        }

        .card-body {
            flex: 1 1 auto
        }

        .card-footer,
        .card-header {
            padding: .75rem 1.25rem;
            background-color: rgba(0, 0, 0, .03)
        }

        .card-title {
            margin-bottom: .75rem;
            font-size: inherit;
            text-align: center
        }

        .card-header,
        .card-subtitle,
        .card-text:last-child {
            margin-bottom: 0
        }

        .card-subtitle {
            margin-top: -.375rem
        }

        .card-link:hover {
            text-decoration: none
        }

        .card-link+.card-link {
            margin-left: 1.25rem
        }

        .card-header-pills,
        .card-header-tabs {
            margin-right: -.625rem;
            margin-left: -.625rem
        }

        .card-header {
            border-bottom: 1px solid rgba(0, 0, 0, .125)
        }

        .card-header:first-child {
            border-radius: calc(0 - 1px) calc(0 - 1px) 0 0
        }

        .card-header+.list-group .list-group-item:first-child {
            border-top: 0
        }

        .card-footer {
            border-top: 1px solid rgba(0, 0, 0, .125)
        }

        .card-footer:last-child {
            border-radius: 0 0 calc(0 - 1px) calc(0 - 1px)
        }

        .card-header-tabs {
            margin-bottom: -.75rem;
            border-bottom: 0
        }

        .card-img-overlay {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            padding: 1.25rem
        }

        .input-group,
        .input-group-btn>.btn {
            position: relative
        }

        .card-img {
            width: 100%;
            border-radius: calc(0 - 1px)
        }

        .card-img-top {
            width: 100%;
            border-top-right-radius: calc(0 - 1px);
            border-top-left-radius: calc(0 - 1px)
        }

        .card-img-bottom {
            width: 100%;
            border-bottom-right-radius: calc(0 - 1px);
            border-bottom-left-radius: calc(0 - 1px)
        }

        .card-deck {
            display: flex;
            flex-direction: column
        }

        .card-deck .card {
            margin-bottom: .625rem
        }

        @media (min-width:520px) {
            .card-deck {
                flex-flow: row wrap;
                margin-right: -.625rem;
                margin-left: -.625rem
            }

            .card-deck .card {
                display: flex;
                flex: 1 0 0%;
                flex-direction: column;
                margin-right: .625rem;
                margin-bottom: 0;
                margin-left: .625rem
            }
        }

        .card-group {
            display: flex;
            flex-direction: column
        }

        .card-group>.card {
            margin-bottom: 10px
        }

        @media (min-width:520px) {

            .card-group>.card:not(:first-child):not(:last-child):not(:only-child),
            .card-group>.card:not(:first-child):not(:last-child):not(:only-child) .card-footer,
            .card-group>.card:not(:first-child):not(:last-child):not(:only-child) .card-header,
            .card-group>.card:not(:first-child):not(:last-child):not(:only-child) .card-img-bottom,
            .card-group>.card:not(:first-child):not(:last-child):not(:only-child) .card-img-top,
            .card-group>.card:only-child {
                border-radius: 0
            }

            .card-group {
                flex-flow: row wrap
            }

            .card-group>.card {
                flex: 1 0 0%;
                margin-bottom: 0
            }

            .card-group>.card+.card {
                margin-left: 0;
                border-left: 0
            }

            .card-group>.card:first-child {
                border-bottom-right-radius: 0;
                border-top-right-radius: 0
            }

            .card-group>.card:first-child .card-header,
            .card-group>.card:first-child .card-img-top {
                border-top-right-radius: 0
            }

            .card-group>.card:first-child .card-footer,
            .card-group>.card:first-child .card-img-bottom {
                border-bottom-right-radius: 0
            }

            .card-group>.card:last-child {
                border-bottom-left-radius: 0;
                border-top-left-radius: 0
            }

            .card-group>.card:last-child .card-header,
            .card-group>.card:last-child .card-img-top {
                border-top-left-radius: 0
            }

            .card-group>.card:last-child .card-footer,
            .card-group>.card:last-child .card-img-bottom {
                border-bottom-left-radius: 0
            }

            .card-group>.card:only-child .card-header,
            .card-group>.card:only-child .card-img-top {
                border-top-right-radius: 0;
                border-top-left-radius: 0
            }

            .card-group>.card:only-child .card-footer,
            .card-group>.card:only-child .card-img-bottom {
                border-bottom-right-radius: 0;
                border-bottom-left-radius: 0
            }

            .card-columns {
                column-count: 3;
                column-gap: 1.25rem;
                orphans: 1;
                widows: 1
            }

            .card-columns .card {
                display: inline-block;
                width: 100%
            }
        }

        .card-columns .card {
            margin-bottom: .75rem
        }

        .accordion .card:not(:first-of-type):not(:last-of-type) {
            border-bottom: 0;
            border-radius: 0
        }

        .accordion .card:not(:first-of-type) .card-header:first-child {
            border-radius: 0
        }

        .accordion .card:first-of-type {
            border-bottom: 0;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0
        }

        .accordion .card:last-of-type {
            border-top-left-radius: 0;
            border-top-right-radius: 0
        }

        .card {
            margin-bottom: 20px
        }

        .ux-card {
            box-shadow: 0 1px 6px 0 rgba(117, 117, 117, .25);
            margin: 0 0 20px;
            color: #444;
            border: 0;
            border-radius: 6px
        }

        .shadow-0,
        .ux-card .ux-card {
            box-shadow: none
        }

        @media (min-width:992px) {
            .ux-card {
                border-radius: 8px
            }
        }

        .breadcrumb,
        .input-group .form-control:not(:first-child):not(:last-child),
        .input-group-addon:not(:first-child):not(:last-child),
        .input-group-btn:not(:first-child):not(:last-child) {
            border-radius: 0
        }

        .ux-card .card-block {
            padding: 40px 20px
        }

        @media (min-width:768px) {
            .ux-card .card-block {
                padding-left: 30px;
                padding-right: 30px
            }
        }

        @media (min-width:1200px) {
            .ux-card {
                margin-bottom: 40px
            }

            .ux-card .card-block {
                padding-left: 50px;
                padding-right: 50px
            }
        }

        @media (max-width:767px) {
            [class*=col-xs]>.ux-card {
                margin-left: -10px;
                margin-right: -10px
            }
        }

        .breadcrumb {
            display: flex;
            flex-wrap: wrap;
            padding: 0;
            margin-bottom: 16px;
            background-color: transparent
        }

        .breadcrumb-item+.breadcrumb-item {
            padding-left: 16px
        }

        .breadcrumb-item+.breadcrumb-item::before {
            display: inline-block;
            padding-right: 16px;
            color: #757575;
            content: "/"
        }

        .breadcrumb-item+.breadcrumb-item:hover::before {
            text-decoration: none
        }

        .breadcrumb-item.active {
            color: #757575
        }

        .breadcrumb-item .uxicon {
            vertical-align: -1px;
            margin-right: 3px
        }

        .input-group {
            display: flex;
            align-items: stretch;
            width: 100%
        }

        .input-group .form-control {
            position: relative;
            z-index: 2;
            flex: 1 1 auto;
            margin-bottom: 0
        }

        .input-group .form-control,
        .input-group-addon,
        .input-group-btn {
            display: flex;
            align-items: center
        }

        .input-group-addon {
            padding: 6px 12px;
            margin-bottom: 0;
            font-size: 1rem;
            line-height: 1.61803;
            color: #2b2b2b;
            text-align: center;
            background-color: #e9ecef;
            border: 1px solid #aab7c2;
            border-radius: 6px;
            font-weight: 700
        }

        .input-group-addon.form-control-sm,
        .input-group-sm>.input-group-addon,
        .input-group-sm>.input-group-btn>.input-group-addon.btn {
            padding: 4px 12px;
            font-size: .875rem;
            border-radius: 4px
        }

        .input-group-addon.form-control-lg,
        .input-group-lg>.input-group-addon,
        .input-group-lg>.input-group-btn>.input-group-addon.btn {
            padding: 6px 12px;
            font-size: 1.375rem;
            border-radius: 8px
        }

        .input-group-addon input[type=radio],
        .input-group-addon input[type=checkbox] {
            margin-top: 0
        }

        .input-group .form-control:not(:last-child),
        .input-group-addon:not(:last-child),
        .input-group-btn:not(:first-child)>.btn-group:not(:last-child)>.btn,
        .input-group-btn:not(:first-child)>.btn:not(:last-child):not(.dropdown-toggle),
        .input-group-btn:not(:last-child)>.btn,
        .input-group-btn:not(:last-child)>.btn-group>.btn,
        .input-group-btn:not(:last-child)>.dropdown-toggle {
            border-bottom-right-radius: 0;
            border-top-right-radius: 0
        }

        .input-group-addon:not(:last-child) {
            border-right: 0
        }

        .input-group .form-control:not(:first-child),
        .input-group-addon:not(:first-child),
        .input-group-btn:not(:first-child)>.btn,
        .input-group-btn:not(:first-child)>.btn-group>.btn,
        .input-group-btn:not(:first-child)>.dropdown-toggle,
        .input-group-btn:not(:last-child)>.btn-group:not(:first-child)>.btn,
        .input-group-btn:not(:last-child)>.btn:not(:first-child) {
            border-bottom-left-radius: 0;
            border-top-left-radius: 0
        }

        .form-control+.input-group-addon:not(:first-child) {
            border-left: 0
        }

        .input-group-btn>.btn+.btn {
            margin-left: -1px
        }

        .input-group-btn>.btn:active,
        .input-group-btn>.btn:focus,
        .input-group-btn>.btn:hover {
            z-index: 3
        }

        .input-group-btn:first-child>.btn+.btn {
            margin-left: 0
        }

        .input-group-btn:not(:last-child)>.btn,
        .input-group-btn:not(:last-child)>.btn-group {
            margin-right: -1px
        }

        .input-group-btn:not(:first-child)>.btn,
        .input-group-btn:not(:first-child)>.btn-group {
            z-index: 2;
            margin-left: 0
        }

        .input-group-btn:not(:first-child)>.btn-group:first-child,
        .input-group-btn:not(:first-child)>.btn:first-child {
            margin-left: -1px
        }

        .input-group-btn:not(:first-child)>.btn-group:active,
        .input-group-btn:not(:first-child)>.btn-group:focus,
        .input-group-btn:not(:first-child)>.btn-group:hover,
        .input-group-btn:not(:first-child)>.btn:active,
        .input-group-btn:not(:first-child)>.btn:focus,
        .input-group-btn:not(:first-child)>.btn:hover {
            z-index: 3
        }

        .input-group {
            z-index: 1
        }

        .input-group label {
            border: 0;
            clip: rect(0 0 0 0);
            height: 1px;
            margin: -1px;
            overflow: hidden;
            padding: 0;
            position: absolute;
            width: 1px
        }

        .input-group-btn {
            align-items: stretch;
            font-size: 0;
            position: relative;
            z-index: 3;
            flex-shrink: 0
        }

        .input-group-btn.dropdown {
            display: table-cell
        }

        .input-group .form-control:active,
        .input-group .form-control:focus,
        .input-group .form-control:hover {
            z-index: 4
        }

        .media-body {
            width: 10000px
        }

        .media-body,
        .media-left,
        .media-right {
            display: table-cell;
            vertical-align: top
        }

        .media-middle {
            vertical-align: middle
        }

        .media-bottom {
            vertical-align: bottom
        }

        .media-object {
            display: block
        }

        .media-object.img-thumbnail {
            max-width: none
        }

        .media-heading {
            margin-top: 0;
            margin-bottom: 10px
        }

        .media-list {
            padding-left: 0
        }

        .media {
            margin-top: 20px
        }

        .media-right {
            padding-left: 20px
        }

        .media-left {
            padding-right: 20px
        }

        .media-small .media-body {
            vertical-align: middle
        }

        .media-small .media-heading {
            margin: 0
        }

        .media-small .media-heading+p {
            margin: 10px 0 0
        }

        .page-item,
        .table-compare-heading {
            margin-top: 0
        }

        .pagination {
            padding-left: 0;
            border-radius: 6px
        }

        .page-item:first-child .page-link,
        .page-item:first-child .page-nolink {
            margin-left: 0;
            border-bottom-left-radius: 6px;
            border-top-left-radius: 6px
        }

        .page-item:last-child .page-link,
        .page-item:last-child .page-nolink {
            border-bottom-right-radius: 6px;
            border-top-right-radius: 6px
        }

        .page-item.disabled .page-link,
        .page-item.disabled .page-nolink {
            color: #757575;
            pointer-events: none;
            background-color: transparent;
            border-color: #ddd
        }

        .page-link,
        .page-nolink {
            position: relative;
            display: block;
            padding: .5rem .75rem;
            margin-left: -1px;
            line-height: 1.25;
            color: #444;
            background-color: transparent
        }

        .page-link:focus,
        .page-link:hover,
        .page-nolink:focus,
        .page-nolink:hover {
            color: #00a63f;
            background-color: transparent;
            border-color: #ddd;
            text-decoration: none
        }

        .pagination-wrap {
            display: flex;
            justify-content: center;
            flex-wrap: wrap
        }

        .pagination {
            margin-bottom: 0;
            margin-right: .5rem;
            display: flex;
            flex-wrap: wrap;
            justify-content: center
        }

        .pagination .page-link,
        .pagination .page-nolink {
            padding: 0 1px;
            font-size: 1rem;
            min-width: 2.2rem;
            min-height: 2.2rem;
            line-height: 2.2rem
        }

        .page-link,
        .page-nolink {
            text-align: center;
            border: 0
        }

        caption,
        th {
            text-align: left
        }

        .page-link .uxicon,
        .page-nolink .uxicon {
            top: -.1em
        }

        .page-link .uxicon-chevron-left,
        .page-link .uxicon-chevron-right,
        .page-nolink .uxicon-chevron-left,
        .page-nolink .uxicon-chevron-right {
            font-size: .7em
        }

        .page-nolink:focus,
        .page-nolink:hover {
            color: #444
        }

        .page-item {
            margin-bottom: 0;
            display: inline-flex
        }

        .page-item.active .page-link,
        .page-item.active .page-link:focus,
        .page-item.active .page-link:hover,
        .page-item.active .page-nolink,
        .page-item.active .page-nolink:focus,
        .page-item.active .page-nolink:hover {
            color: #00a63f;
            background-color: #fff;
            border: 1px solid #aab7c2;
            cursor: not-allowed;
            pointer-events: none;
            border-radius: 6px;
            text-decoration: none;
            z-index: auto
        }

        .pagination-lg .page-link,
        .pagination-lg .page-nolink {
            padding: 0 1px;
            font-size: 1.375rem;
            min-width: 2.95rem;
            min-height: 2.95rem;
            line-height: 2.95rem
        }

        .pagination-sm .page-link,
        .pagination-sm .page-nolink {
            padding: 0 1px;
            font-size: .875rem;
            min-width: 1.95rem;
            min-height: 1.95rem;
            line-height: 1.95rem
        }

        .pagination-dropdown {
            border-radius: 6px;
            padding-left: 0;
            margin-top: 0;
            margin-bottom: 0
        }

        .pagination-dropdown .ux-select-dropdown .form-control {
            padding: 8px 12px 9px;
            min-height: 0;
            border: 1px solid #aab7c2;
            display: flex;
            flex-direction: row-reverse;
            align-items: center
        }

        .pagination-dropdown .ux-select-dropdown .form-control .dropdown-toggle {
            margin-left: .5rem;
            float: none !important;
            display: inline-flex
        }

        .pagination-dropdown-sm .dropdown {
            font-size: .875rem
        }

        .pagination-dropdown-sm .dropdown .form-control {
            font-size: .875rem;
            padding: 8px 12px 9px;
            min-height: 33px
        }

        .pagination-dropdown-md .dropdown {
            font-size: 1rem
        }

        .pagination-dropdown-md .dropdown .form-control {
            font-size: 1rem;
            padding: 9px 12px 10px;
            min-height: 37px
        }

        .pagination-dropdown-lg .dropdown {
            font-size: 1.375rem
        }

        .pagination-dropdown-lg .dropdown .form-control {
            font-size: 1.375rem;
            padding: 11px 12px 14px;
            min-height: 49px
        }

        .basegrid td,
        .basegrid th,
        .table td,
        .table th {
            padding: 15px;
            vertical-align: top;
            border-top: 1px solid #e8eaeb
        }

        .basegrid thead th,
        .table thead th {
            vertical-align: bottom;
            border-bottom: 2px solid #e8eaeb
        }

        .basegrid tbody+tbody,
        .table tbody+tbody {
            border-top: 2px solid #e8eaeb
        }

        .table-sm td,
        .table-sm th {
            padding: .3rem
        }

        .basegrid td,
        .basegrid th,
        .table-bordered td,
        .table-bordered th {
            border: 1px solid #e8eaeb
        }

        .basegrid thead td,
        .basegrid thead th,
        .table-bordered thead td,
        .table-bordered thead th {
            border-bottom-width: 2px
        }

        .basegrid tbody tr:nth-of-type(odd),
        .table-compare tbody tr:nth-of-type(odd),
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f5f7f8
        }

        .basegrid tbody tr:hover,
        .table-hover tbody tr:hover {
            cursor: pointer;
            background-color: #f5f7f8
        }

        .basegrid tbody tr:hover,
        .table-compare.basegrid tbody tr:hover,
        .table-hover.table-compare tbody tr:hover,
        .table-hover.table-striped tbody tr:hover {
            cursor: pointer;
            background-color: #e8eaeb
        }

        .table-active,
        .table-active>td,
        .table-active>th {
            background-color: #f5f7f8
        }

        .basegrid .table-active:hover,
        .basegrid .table-active:hover>td,
        .basegrid .table-active:hover>th,
        .table-hover .table-active:hover,
        .table-hover .table-active:hover>td,
        .table-hover .table-active:hover>th {
            background-color: #e6ebee
        }

        .table-success,
        .table-success>td,
        .table-success>th {
            background-color: #d9f2e2
        }

        .basegrid .table-success:hover,
        .basegrid .table-success:hover>td,
        .basegrid .table-success:hover>th,
        .table-hover .table-success:hover,
        .table-hover .table-success:hover>td,
        .table-hover .table-success:hover>th {
            background-color: #c6ecd4
        }

        .table-info,
        .table-info>td,
        .table-info>th {
            background-color: #f0e3f4
        }

        .basegrid .table-info:hover,
        .basegrid .table-info:hover>td,
        .basegrid .table-info:hover>th,
        .table-hover .table-info:hover,
        .table-hover .table-info:hover>td,
        .table-hover .table-info:hover>th {
            background-color: #e6d1ed
        }

        .table-warning,
        .table-warning>td,
        .table-warning>th {
            background-color: #fffae3
        }

        .basegrid .table-warning:hover,
        .basegrid .table-warning:hover>td,
        .basegrid .table-warning:hover>th,
        .table-hover .table-warning:hover,
        .table-hover .table-warning:hover>td,
        .table-hover .table-warning:hover>th {
            background-color: #fff5ca
        }

        .table-danger,
        .table-danger>td,
        .table-danger>th {
            background-color: #fadcd9
        }

        .basegrid .table-danger:hover,
        .basegrid .table-danger:hover>td,
        .basegrid .table-danger:hover>th,
        .table-hover .table-danger:hover,
        .table-hover .table-danger:hover>td,
        .table-hover .table-danger:hover>th {
            background-color: #f7c7c2
        }

        @media (max-width:519px) {
            .table-responsive-sm {
                display: block;
                width: 100%;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                -ms-overflow-style: -ms-autohiding-scrollbar
            }

            .table-responsive-sm.basegrid,
            .table-responsive-sm.table-bordered {
                border: 0
            }
        }

        @media (max-width:767px) {
            .table-responsive-md {
                display: block;
                width: 100%;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                -ms-overflow-style: -ms-autohiding-scrollbar
            }

            .table-responsive-md.basegrid,
            .table-responsive-md.table-bordered {
                border: 0
            }
        }

        @media (max-width:991px) {
            .table-responsive-lg {
                display: block;
                width: 100%;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                -ms-overflow-style: -ms-autohiding-scrollbar
            }

            .table-responsive-lg.basegrid,
            .table-responsive-lg.table-bordered {
                border: 0
            }
        }

        @media (max-width:1199px) {
            .table-responsive-xl {
                display: block;
                width: 100%;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                -ms-overflow-style: -ms-autohiding-scrollbar
            }

            .table-responsive-xl.basegrid,
            .table-responsive-xl.table-bordered {
                border: 0
            }
        }

        .table-responsive {
            display: block;
            width: 100%;
            -webkit-overflow-scrolling: touch;
            -ms-overflow-style: -ms-autohiding-scrollbar
        }

        .table-responsive.basegrid,
        .table-responsive.table-bordered {
            border: 0
        }

        table {
            background-color: transparent
        }

        caption {
            caption-side: bottom;
            padding-top: 15px;
            padding-bottom: 15px;
            color: #757575
        }

        .basegrid,
        .table {
            width: 100%;
            max-width: 100%;
            margin-bottom: 25.8px;
            border-bottom: 1px solid #e8eaeb
        }

        .basegrid .uxicon,
        .table .uxicon {
            font-size: 1rem
        }

        .basegrid>thead>tr>th,
        .table>thead>tr>th {
            font-size: 1.07rem;
            line-height: 1.1;
            vertical-align: middle;
            background-color: #fff;
            border-bottom: 1px solid #e8eaeb;
            font-weight: 700
        }

        .basegrid>caption+thead>tr:first-child>td,
        .basegrid>caption+thead>tr:first-child>th,
        .basegrid>colgroup+thead>tr:first-child>td,
        .basegrid>colgroup+thead>tr:first-child>th,
        .basegrid>thead:first-child>tr:first-child>td,
        .basegrid>thead:first-child>tr:first-child>th,
        .table>caption+thead>tr:first-child>td,
        .table>caption+thead>tr:first-child>th,
        .table>colgroup+thead>tr:first-child>td,
        .table>colgroup+thead>tr:first-child>th,
        .table>thead:first-child>tr:first-child>td,
        .table>thead:first-child>tr:first-child>th {
            border-top: 0 !important
        }

        .basegrid>tbody+tbody,
        .table>tbody+tbody {
            border-top: 2px solid #e8eaeb
        }

        .basegrid .basegrid,
        .basegrid .table,
        .table .basegrid,
        .table .table {
            background-color: #fff
        }

        .table-compare>tbody>tr>td,
        .table-compare>tbody>tr>th,
        .table-compare>tfoot>tr>td,
        .table-compare>tfoot>tr>th,
        .table-compare>thead>tr>td,
        .table-compare>thead>tr>th,
        .table-expanded>tbody>tr>td,
        .table-expanded>tbody>tr>th,
        .table-expanded>tfoot>tr>td,
        .table-expanded>tfoot>tr>th,
        .table-expanded>thead>tr>td,
        .table-expanded>thead>tr>th {
            padding-top: 30px;
            padding-bottom: 30px
        }

        .basegrid,
        .basegrid>tbody>tr>td,
        .basegrid>tbody>tr>th,
        .basegrid>tfoot>tr>td,
        .basegrid>tfoot>tr>th,
        .basegrid>thead>tr>td,
        .basegrid>thead>tr>th,
        .table-bordered,
        .table-bordered>tbody>tr>td,
        .table-bordered>tbody>tr>th,
        .table-bordered>tfoot>tr>td,
        .table-bordered>tfoot>tr>th,
        .table-bordered>thead>tr>td,
        .table-bordered>thead>tr>th {
            border: 1px solid #e8eaeb
        }

        .basegrid>thead>tr>td,
        .basegrid>thead>tr>th,
        .table-bordered>thead>tr>td,
        .table-bordered>thead>tr>th {
            border-bottom-width: 1px
        }

        table col[class*=col-] {
            position: static;
            display: table-column;
            float: none
        }

        table td[class*=col-],
        table th[class*=col-] {
            position: static;
            display: table-cell;
            float: none
        }

        .table-responsive {
            min-height: .01%;
            margin-bottom: 1.071rem;
            overflow-x: auto
        }

        .table-responsive>.basegrid,
        .table-responsive>.table {
            margin-bottom: 0
        }

        @media (max-width:991px) {
            .table-responsive {
                width: 100%;
                margin-bottom: 19.35px;
                overflow-y: hidden;
                border: 1px solid #e8eaeb;
                -ms-overflow-style: -ms-autohiding-scrollbar
            }

            .table-responsive>.basegrid,
            .table-responsive>.table {
                border: 0
            }

            .table-responsive>.basegrid>tbody>tr>td:first-child,
            .table-responsive>.basegrid>tbody>tr>th:first-child,
            .table-responsive>.basegrid>tfoot>tr>td:first-child,
            .table-responsive>.basegrid>tfoot>tr>th:first-child,
            .table-responsive>.basegrid>thead>tr>td:first-child,
            .table-responsive>.basegrid>thead>tr>th:first-child,
            .table-responsive>.table>tbody>tr>td:first-child,
            .table-responsive>.table>tbody>tr>th:first-child,
            .table-responsive>.table>tfoot>tr>td:first-child,
            .table-responsive>.table>tfoot>tr>th:first-child,
            .table-responsive>.table>thead>tr>td:first-child,
            .table-responsive>.table>thead>tr>th:first-child {
                border-left: 0
            }

            .table-responsive>.basegrid>tbody>tr>td:last-child,
            .table-responsive>.basegrid>tbody>tr>th:last-child,
            .table-responsive>.basegrid>tfoot>tr>td:last-child,
            .table-responsive>.basegrid>tfoot>tr>th:last-child,
            .table-responsive>.basegrid>thead>tr>td:last-child,
            .table-responsive>.basegrid>thead>tr>th:last-child,
            .table-responsive>.table>tbody>tr>td:last-child,
            .table-responsive>.table>tbody>tr>th:last-child,
            .table-responsive>.table>tfoot>tr>td:last-child,
            .table-responsive>.table>tfoot>tr>th:last-child,
            .table-responsive>.table>thead>tr>td:last-child,
            .table-responsive>.table>thead>tr>th:last-child {
                border-right: 0
            }

            .table-responsive>.basegrid>tbody>tr:last-child>td,
            .table-responsive>.basegrid>tbody>tr:last-child>th,
            .table-responsive>.basegrid>tfoot>tr:last-child>td,
            .table-responsive>.basegrid>tfoot>tr:last-child>th,
            .table-responsive>.table>tbody>tr:last-child>td,
            .table-responsive>.table>tbody>tr:last-child>th,
            .table-responsive>.table>tfoot>tr:last-child>td,
            .table-responsive>.table>tfoot>tr:last-child>th {
                border-bottom: 0
            }
        }

        .blockquote,
        hr {
            margin-bottom: 1rem
        }

        .basegrid>thead>tr>th {
            height: 5.714rem
        }

        @media (min-width:768px) {
            .basegrid>thead>tr>th {
                height: 5rem
            }
        }

        .table-features>tbody>tr>td,
        .table-features>tbody>tr>th,
        .table-features>thead>tr>td,
        .table-features>thead>tr>th {
            text-align: center;
            vertical-align: middle
        }

        .table-features>tbody>tr .table-feature,
        .table-features>thead>tr .table-feature {
            text-align: left
        }

        @media (max-width:991px) {

            .table-stacking,
            .table-stacking>tbody,
            .table-stacking>tbody>tr,
            .table-stacking>tbody>tr>td {
                display: block !important;
                width: 100%
            }

            .table-stacking::after,
            .table-stacking>tbody::after,
            .table-stacking>tbody>tr::after,
            .table-stacking>tbody>tr>td::after {
                content: "";
                display: table;
                clear: both
            }

            .table-stacking>thead {
                display: none
            }

            .table-stacking>tbody>tr:first-child>td:first-child {
                border-top: 0
            }

            .table-stacking>tbody>tr>td {
                float: left;
                padding-left: 160px;
                text-align: left;
                vertical-align: top;
                border-right: 0;
                border-bottom: 0;
                border-left: 0
            }

            .table-stacking>tbody>tr>td:before {
                display: block;
                float: left;
                width: 160px;
                padding-right: 15px;
                padding-left: 15px;
                margin-left: -160px;
                content: attr(data-th);
                font-family: gdsherpa, Helvetica, Arial, sans-serif;
                font-weight: 700
            }
        }

        .table-compare {
            text-align: center;
            border: 1px solid #e8eaeb
        }

        .table-compare>thead>tr>th {
            height: 8.857rem;
            text-align: inherit;
            border-left: 1px solid #e8eaeb
        }

        @media (min-width:768px) {
            .table-compare>thead>tr>th {
                height: 7.75rem
            }
        }

        .table-compare-wrap {
            position: relative
        }

        .table-compare-wrap .table-compare-fixed {
            position: absolute;
            right: 0;
            left: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .table-compare-wrap .table-compare-heading:after {
            content: "\A0"
        }

        .table-compare-nested {
            margin-right: -15px;
            margin-left: -15px
        }

        .table-compare-nested>table {
            width: 100%;
            table-layout: fixed
        }

        .table-compare-nested>table>tbody>tr:nth-of-type(odd) {
            background: 0 0
        }

        .table-compare-nested>table>tbody>tr>td {
            padding: 0 15px;
            border-top: 0
        }

        .table-compare-heading+.table-compare-nested>table {
            margin-top: 2rem
        }

        @media (max-width:991px) {

            .table-responsive .basegrid,
            .table-responsive .table-compare {
                max-width: none;
                border: 0
            }
        }

        .h1,
        .h2,
        .h3,
        .h4,
        .h5,
        .h6,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            color: inherit
        }

        .lead {
            font-weight: 300
        }

        hr {
            margin-top: 1rem;
            border: 0;
            border-top: 1px solid #e8eaeb
        }

        .small,
        small {
            font-weight: 400
        }

        .list-inline,
        .list-unstyled {
            padding-left: 0;
            list-style: none
        }

        .list-inline-item {
            display: inline-block
        }

        .list-inline-item:not(:last-child) {
            margin-right: 5px
        }

        .initialism {
            font-size: 90%;
            text-transform: uppercase
        }

        .blockquote {
            padding: .5rem 1rem;
            font-size: 1.25rem;
            border-left: .25rem solid #f5f7f8
        }

        .blockquote-footer {
            display: block;
            font-size: 80%;
            color: #868e96
        }

        .blockquote-footer::before {
            content: "\2014   \A0"
        }

        .blockquote-reverse {
            padding-right: 1rem;
            padding-left: 0;
            text-align: right;
            border-right: .25rem solid #f5f7f8;
            border-left: 0
        }

        .blockquote-reverse .blockquote-footer::before {
            content: ""
        }

        .blockquote-reverse .blockquote-footer::after {
            content: "\A0   \2014"
        }

        dl.row>dd+dt {
            clear: left
        }

        .font-primary-bold {
            font-weight: 700
        }

        .ux-hr-dark {
            border-top: 1px solid #757575
        }

        .h0,
        .h1,
        .h2,
        .h3,
        .h4,
        .h5,
        .h6,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-family: inherit;
            font-weight: 500
        }

        .h0,
        .headline-brand {
            font-family: Boing-Bold, "Arial Black", sans-serif
        }

        .h0 {
            font-weight: 400 !important;
            font-size: 2.02729rem;
            line-height: 2.56578rem;
            margin-bottom: 1.64011rem
        }

        .h1,
        .h6,
        h1,
        h6 {
            font-weight: 700
        }

        @media (min-width:992px) {

            .table-responsive .basegrid,
            .table-responsive .table-compare {
                width: 100% !important
            }

            .h0 {
                font-size: 2.56578rem;
                line-height: 3.24732rem;
                margin-bottom: 2.07576rem
            }
        }

        .h1,
        h1 {
            font-size: 2.02729rem;
            line-height: 2.2807rem;
            margin-bottom: 1.64011rem
        }

        @media (min-width:992px) {

            .h1,
            h1 {
                font-size: 2.56578rem;
                line-height: 2.88651rem;
                margin-bottom: 2.07576rem
            }
        }

        .h2,
        h2 {
            font-size: 1.80203rem;
            line-height: 2.02729rem;
            margin-bottom: 1.45787rem
        }

        @media (min-width:992px) {

            .h2,
            h2 {
                font-size: 2.02729rem;
                line-height: 2.2807rem;
                margin-bottom: 1.64011rem
            }
        }

        .h3,
        h3 {
            font-size: 1.42383rem;
            line-height: 1.80203rem;
            margin-bottom: 1.1519rem
        }

        @media (min-width:992px) {

            .h3,
            h3 {
                font-size: 1.60181rem;
                line-height: 2.02729rem;
                margin-bottom: 1.29589rem
            }
        }

        .h4,
        h4 {
            font-size: 1.26562rem;
            line-height: 1.60181rem;
            margin-bottom: 1.02391rem
        }

        @media (min-width:992px) {

            .h4,
            h4 {
                font-size: 1.42383rem;
                line-height: 1.80203rem;
                margin-bottom: 1.1519rem
            }

            .h5,
            h5 {
                font-size: 1.125rem;
                line-height: 1.42383rem;
                margin-bottom: .91014rem
            }
        }

        .h5,
        h5 {
            font-size: 1.125rem;
            line-height: 1.42383rem;
            margin-bottom: .91014rem
        }

        .h6,
        h6 {
            font-size: 1rem;
            line-height: 1.26562rem;
            margin-bottom: .80902rem
        }

        @media (min-width:992px) {

            .h6,
            h6 {
                font-size: 1rem;
                line-height: 1.26562rem;
                margin-bottom: .80902rem
            }
        }

        .h0.margin-none,
        .h1.margin-none,
        .h2.margin-none,
        .h3.margin-none,
        .h4.margin-none,
        .h5.margin-none,
        .h6.margin-none,
        h1.margin-none,
        h2.margin-none,
        h3.margin-none,
        h4.margin-none,
        h5.margin-none,
        h6.margin-none {
            margin-bottom: 0
        }

        .h0.margin-compressed,
        .h1.margin-compressed,
        .h2.margin-compressed,
        .h3.margin-compressed,
        .h4.margin-compressed,
        .h5.margin-compressed,
        .h6.margin-compressed,
        h1.margin-compressed,
        h2.margin-compressed,
        h3.margin-compressed,
        h4.margin-compressed,
        h5.margin-compressed,
        h6.margin-compressed {
            margin-bottom: .5rem
        }

        .headline-brand {
            font-weight: 400 !important
        }

        .brand-message,
        .list-big li:before {
            font-family: gdsherpa, Helvetica, Arial, sans-serif
        }

        .display-1,
        .display-2,
        .display-3,
        .display-4 {
            font-weight: 300;
            line-height: 1.2
        }

        .display-1 {
            font-size: 6rem
        }

        .display-2 {
            font-size: 5.5rem
        }

        .display-3 {
            font-size: 4.5rem
        }

        .display-4 {
            font-size: 3.5rem
        }

        .brand-message,
        .lead {
            font-size: 1.125rem
        }

        .brand-message,
        .close,
        .title {
            font-weight: 700
        }

        @media (min-width:992px) {

            .brand-message,
            .lead {
                font-size: 1.125rem
            }
        }

        .legal {
            font-size: .79012rem
        }

        .large {
            font-size: 1.125rem
        }

        .small,
        small {
            font-size: 92.85714%
        }

        .mark,
        mark {
            background-color: #fcf8e3;
            position: relative;
            z-index: 2;
            display: inline-block;
            padding: .08rem .1rem;
            margin: 0;
            line-height: 1.61803;
            background: rgba(254, 220, 69, .7)
        }

        .mark:after,
        mark:after {
            position: absolute;
            top: 0;
            right: -.1em;
            z-index: 1;
            width: .2rem;
            height: 1.6725rem;
            content: "";
            background: rgba(254, 220, 69, .7);
            transform: skew(-5deg, 0)
        }

        .bg-default,
        .bg-muted,
        .bg-purchase,
        .bg-secondary-o,
        button.close {
            background-color: transparent
        }

        ol li,
        ul li {
            margin-top: .75rem;
            margin-bottom: .75rem
        }

        .list-big {
            counter-reset: listBigCounter;
            padding-left: 0
        }

        .list-big li {
            position: relative;
            min-height: 1.5rem;
            padding-top: .15rem;
            padding-left: 3.6rem;
            margin-top: 2.25rem;
            margin-bottom: .75rem
        }

        .list-big li:first-child {
            margin-top: .75rem
        }

        .m-t-0,
        .m-y-0 {
            margin-top: 0 !important
        }

        .list-big li:before {
            position: absolute;
            top: 0;
            left: 0;
            width: 1.5rem;
            font-size: 1.5rem;
            line-height: 1em;
            text-align: right;
            content: counter(listBigCounter) ".";
            counter-increment: listBigCounter;
            font-weight: 700
        }

        .list-checkmark li {
            position: relative;
            padding-left: 1.75rem;
            line-height: 1rem
        }

        .list-checkmark li:before {
            font-family: uxfont;
            content: '\E207';
            position: absolute;
            top: 0;
            left: 0;
            color: #00a63f;
            font-size: 1.125rem
        }

        .title {
            margin-bottom: 12.94px
        }

        .m-b-0,
        .m-y-0 {
            margin-bottom: 0 !important
        }

        .title.large {
            font-size: 1.26562rem !important
        }

        .title.small {
            font-size: .88889rem;
            color: #757575
        }

        .title.extra-small {
            font-size: .79012rem;
            color: #757575;
            text-transform: uppercase
        }

        .close:not(:disabled):not(.disabled) {
            cursor: pointer
        }

        .close:not(:disabled):not(.disabled):focus,
        .close:not(:disabled):not(.disabled):hover {
            color: #000;
            text-decoration: none;
            opacity: .75
        }

        button.close {
            padding: 0;
            border: 0;
            -webkit-appearance: none
        }

        .close {
            float: right;
            line-height: 1;
            color: #000;
            width: 1em;
            font-size: 1.375rem;
            opacity: 1;
            font-family: gdsherpa, Helvetica, Arial, sans-serif
        }

        .close:before {
            content: "\D7"
        }

        .close:focus,
        .close:hover {
            opacity: 1;
            outline: 0
        }

        .close span {
            display: none
        }

        .bg-purchase,
        .bg-secondary-o {
            color: #1976d2
        }

        .bg-default {
            color: #444
        }

        .bg-muted {
            color: #757575
        }

        .bg-white {
            background-color: #fff !important
        }

        .bg-transparent {
            background-color: transparent !important
        }

        .bg-faded {
            background-color: #f5f7f8
        }

        .clearfix::after {
            content: "";
            display: table;
            clear: both
        }

        .d-none {
            display: none !important
        }

        .d-inline {
            display: inline !important
        }

        .d-inline-block {
            display: inline-block !important
        }

        .d-block {
            display: block !important
        }

        .d-table {
            display: table !important
        }

        .d-table-row {
            display: table-row !important
        }

        .d-table-cell {
            display: table-cell !important
        }

        .d-flex {
            display: flex !important
        }

        .d-inline-flex {
            display: inline-flex !important
        }

        @media (min-width:520px) {
            .d-sm-none {
                display: none !important
            }

            .d-sm-inline {
                display: inline !important
            }

            .d-sm-inline-block {
                display: inline-block !important
            }

            .d-sm-block {
                display: block !important
            }

            .d-sm-table {
                display: table !important
            }

            .d-sm-table-row {
                display: table-row !important
            }

            .d-sm-table-cell {
                display: table-cell !important
            }

            .d-sm-flex {
                display: flex !important
            }

            .d-sm-inline-flex {
                display: inline-flex !important
            }
        }

        @media (min-width:768px) {
            .d-md-none {
                display: none !important
            }

            .d-md-inline {
                display: inline !important
            }

            .d-md-inline-block {
                display: inline-block !important
            }

            .d-md-block {
                display: block !important
            }

            .d-md-table {
                display: table !important
            }

            .d-md-table-row {
                display: table-row !important
            }

            .d-md-table-cell {
                display: table-cell !important
            }

            .d-md-flex {
                display: flex !important
            }

            .d-md-inline-flex {
                display: inline-flex !important
            }
        }

        @media (min-width:992px) {
            .d-lg-none {
                display: none !important
            }

            .d-lg-inline {
                display: inline !important
            }

            .d-lg-inline-block {
                display: inline-block !important
            }

            .d-lg-block {
                display: block !important
            }

            .d-lg-table {
                display: table !important
            }

            .d-lg-table-row {
                display: table-row !important
            }

            .d-lg-table-cell {
                display: table-cell !important
            }

            .d-lg-flex {
                display: flex !important
            }

            .d-lg-inline-flex {
                display: inline-flex !important
            }
        }

        @media (min-width:1200px) {
            .d-xl-none {
                display: none !important
            }

            .d-xl-inline {
                display: inline !important
            }

            .d-xl-inline-block {
                display: inline-block !important
            }

            .d-xl-block {
                display: block !important
            }

            .d-xl-table {
                display: table !important
            }

            .d-xl-table-row {
                display: table-row !important
            }

            .d-xl-table-cell {
                display: table-cell !important
            }

            .d-xl-flex {
                display: flex !important
            }

            .d-xl-inline-flex {
                display: inline-flex !important
            }

            .hidden-xl-up {
                display: none !important
            }
        }

        .hidden-xl-down,
        .hidden-xs-up {
            display: none !important
        }

        @media (max-width:519px) {
            .hidden-xs-down {
                display: none !important
            }
        }

        @media (min-width:520px) {
            .hidden-sm-up {
                display: none !important
            }
        }

        @media (max-width:767px) {
            .hidden-sm-down {
                display: none !important
            }
        }

        @media (min-width:768px) {
            .hidden-md-up {
                display: none !important
            }
        }

        @media (max-width:991px) {
            .hidden-md-down {
                display: none !important
            }
        }

        @media (min-width:992px) {
            .hidden-lg-up {
                display: none !important
            }
        }

        @media (max-width:1199px) {
            .hidden-lg-down {
                display: none !important
            }
        }

        @media print {
            .d-print-none {
                display: none !important
            }

            .d-print-inline {
                display: inline !important
            }

            .d-print-inline-block {
                display: inline-block !important
            }

            .d-print-block {
                display: block !important
            }

            .d-print-table {
                display: table !important
            }

            .d-print-table-row {
                display: table-row !important
            }

            .d-print-table-cell {
                display: table-cell !important
            }

            .d-print-flex {
                display: flex !important
            }

            .d-print-inline-flex {
                display: inline-flex !important
            }
        }

        .visible-print-block {
            display: none !important
        }

        @media print {
            .visible-print-block {
                display: block !important
            }
        }

        .visible-print-inline {
            display: none !important
        }

        @media print {
            .visible-print-inline {
                display: inline !important
            }
        }

        .visible-print-inline-block {
            display: none !important
        }

        @media print {
            .visible-print-inline-block {
                display: inline-block !important
            }

            .hidden-print {
                display: none !important
            }
        }

        .flex-row {
            flex-direction: row !important
        }

        .flex-column {
            flex-direction: column !important
        }

        .flex-row-reverse {
            flex-direction: row-reverse !important
        }

        .flex-column-reverse {
            flex-direction: column-reverse !important
        }

        .flex-wrap {
            flex-wrap: wrap !important
        }

        .flex-nowrap {
            flex-wrap: nowrap !important
        }

        .flex-wrap-reverse {
            flex-wrap: wrap-reverse !important
        }

        .flex-fill {
            flex: 1 1 auto !important
        }

        .flex-grow-0 {
            flex-grow: 0 !important
        }

        .flex-grow-1 {
            flex-grow: 1 !important
        }

        .flex-shrink-0 {
            flex-shrink: 0 !important
        }

        .flex-shrink-1 {
            flex-shrink: 1 !important
        }

        .justify-content-start {
            justify-content: flex-start !important
        }

        .justify-content-end {
            justify-content: flex-end !important
        }

        .justify-content-center {
            justify-content: center !important
        }

        .justify-content-between {
            justify-content: space-between !important
        }

        .justify-content-around {
            justify-content: space-around !important
        }

        .align-items-start {
            align-items: flex-start !important
        }

        .align-items-end {
            align-items: flex-end !important
        }

        .align-items-center {
            align-items: center !important
        }

        .align-items-baseline {
            align-items: baseline !important
        }

        .align-items-stretch {
            align-items: stretch !important
        }

        .align-content-start {
            align-content: flex-start !important
        }

        .align-content-end {
            align-content: flex-end !important
        }

        .align-content-center {
            align-content: center !important
        }

        .align-content-between {
            align-content: space-between !important
        }

        .align-content-around {
            align-content: space-around !important
        }

        .align-content-stretch {
            align-content: stretch !important
        }

        .align-self-auto {
            align-self: auto !important
        }

        .align-self-start {
            align-self: flex-start !important
        }

        .align-self-end {
            align-self: flex-end !important
        }

        .align-self-center {
            align-self: center !important
        }

        .align-self-baseline {
            align-self: baseline !important
        }

        .align-self-stretch {
            align-self: stretch !important
        }

        @media (min-width:520px) {
            .flex-sm-row {
                flex-direction: row !important
            }

            .flex-sm-column {
                flex-direction: column !important
            }

            .flex-sm-row-reverse {
                flex-direction: row-reverse !important
            }

            .flex-sm-column-reverse {
                flex-direction: column-reverse !important
            }

            .flex-sm-wrap {
                flex-wrap: wrap !important
            }

            .flex-sm-nowrap {
                flex-wrap: nowrap !important
            }

            .flex-sm-wrap-reverse {
                flex-wrap: wrap-reverse !important
            }

            .flex-sm-fill {
                flex: 1 1 auto !important
            }

            .flex-sm-grow-0 {
                flex-grow: 0 !important
            }

            .flex-sm-grow-1 {
                flex-grow: 1 !important
            }

            .flex-sm-shrink-0 {
                flex-shrink: 0 !important
            }

            .flex-sm-shrink-1 {
                flex-shrink: 1 !important
            }

            .justify-content-sm-start {
                justify-content: flex-start !important
            }

            .justify-content-sm-end {
                justify-content: flex-end !important
            }

            .justify-content-sm-center {
                justify-content: center !important
            }

            .justify-content-sm-between {
                justify-content: space-between !important
            }

            .justify-content-sm-around {
                justify-content: space-around !important
            }

            .align-items-sm-start {
                align-items: flex-start !important
            }

            .align-items-sm-end {
                align-items: flex-end !important
            }

            .align-items-sm-center {
                align-items: center !important
            }

            .align-items-sm-baseline {
                align-items: baseline !important
            }

            .align-items-sm-stretch {
                align-items: stretch !important
            }

            .align-content-sm-start {
                align-content: flex-start !important
            }

            .align-content-sm-end {
                align-content: flex-end !important
            }

            .align-content-sm-center {
                align-content: center !important
            }

            .align-content-sm-between {
                align-content: space-between !important
            }

            .align-content-sm-around {
                align-content: space-around !important
            }

            .align-content-sm-stretch {
                align-content: stretch !important
            }

            .align-self-sm-auto {
                align-self: auto !important
            }

            .align-self-sm-start {
                align-self: flex-start !important
            }

            .align-self-sm-end {
                align-self: flex-end !important
            }

            .align-self-sm-center {
                align-self: center !important
            }

            .align-self-sm-baseline {
                align-self: baseline !important
            }

            .align-self-sm-stretch {
                align-self: stretch !important
            }
        }

        @media (min-width:768px) {
            .flex-md-row {
                flex-direction: row !important
            }

            .flex-md-column {
                flex-direction: column !important
            }

            .flex-md-row-reverse {
                flex-direction: row-reverse !important
            }

            .flex-md-column-reverse {
                flex-direction: column-reverse !important
            }

            .flex-md-wrap {
                flex-wrap: wrap !important
            }

            .flex-md-nowrap {
                flex-wrap: nowrap !important
            }

            .flex-md-wrap-reverse {
                flex-wrap: wrap-reverse !important
            }

            .flex-md-fill {
                flex: 1 1 auto !important
            }

            .flex-md-grow-0 {
                flex-grow: 0 !important
            }

            .flex-md-grow-1 {
                flex-grow: 1 !important
            }

            .flex-md-shrink-0 {
                flex-shrink: 0 !important
            }

            .flex-md-shrink-1 {
                flex-shrink: 1 !important
            }

            .justify-content-md-start {
                justify-content: flex-start !important
            }

            .justify-content-md-end {
                justify-content: flex-end !important
            }

            .justify-content-md-center {
                justify-content: center !important
            }

            .justify-content-md-between {
                justify-content: space-between !important
            }

            .justify-content-md-around {
                justify-content: space-around !important
            }

            .align-items-md-start {
                align-items: flex-start !important
            }

            .align-items-md-end {
                align-items: flex-end !important
            }

            .align-items-md-center {
                align-items: center !important
            }

            .align-items-md-baseline {
                align-items: baseline !important
            }

            .align-items-md-stretch {
                align-items: stretch !important
            }

            .align-content-md-start {
                align-content: flex-start !important
            }

            .align-content-md-end {
                align-content: flex-end !important
            }

            .align-content-md-center {
                align-content: center !important
            }

            .align-content-md-between {
                align-content: space-between !important
            }

            .align-content-md-around {
                align-content: space-around !important
            }

            .align-content-md-stretch {
                align-content: stretch !important
            }

            .align-self-md-auto {
                align-self: auto !important
            }

            .align-self-md-start {
                align-self: flex-start !important
            }

            .align-self-md-end {
                align-self: flex-end !important
            }

            .align-self-md-center {
                align-self: center !important
            }

            .align-self-md-baseline {
                align-self: baseline !important
            }

            .align-self-md-stretch {
                align-self: stretch !important
            }
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            -webkit-clip-path: inset(50%);
            clip-path: inset(50%);
            border: 0
        }

        .p-r-0,
        .p-x-0 {
            padding-right: 0 !important
        }

        .p-l-0,
        .p-x-0 {
            padding-left: 0 !important
        }

        .p-t-0,
        .p-y-0 {
            padding-top: 0 !important
        }

        .p-b-0,
        .p-y-0 {
            padding-bottom: 0 !important
        }

        .sr-only-focusable:active,
        .sr-only-focusable:focus {
            position: static;
            width: auto;
            height: auto;
            overflow: visible;
            clip: auto;
            white-space: normal;
            -webkit-clip-path: none;
            clip-path: none
        }

        .m-x-auto {
            margin-right: auto !important;
            margin-left: auto !important
        }

        .m-r-0,
        .m-x-0 {
            margin-right: 0 !important
        }

        .m-l-0,
        .m-x-0 {
            margin-left: 0 !important
        }

        .m-a-0 {
            margin: 0 !important
        }

        .m-r-1,
        .m-x-1 {
            margin-right: 1rem !important
        }

        .m-l-1,
        .m-x-1 {
            margin-left: 1rem !important
        }

        .m-t-1,
        .m-y-1 {
            margin-top: 1rem !important
        }

        .m-b-1,
        .m-y-1 {
            margin-bottom: 1rem !important
        }

        .m-a-1 {
            margin: 1rem !important
        }

        .m-r-2,
        .m-x-2 {
            margin-right: 1.5rem !important
        }

        .m-l-2,
        .m-x-2 {
            margin-left: 1.5rem !important
        }

        .m-t-2,
        .m-y-2 {
            margin-top: 1.5rem !important
        }

        .m-b-2,
        .m-y-2 {
            margin-bottom: 1.5rem !important
        }

        .m-a-2 {
            margin: 1.5rem !important
        }

        .m-r-3,
        .m-x-3 {
            margin-right: 3rem !important
        }

        .m-l-3,
        .m-x-3 {
            margin-left: 3rem !important
        }

        .m-t-3,
        .m-y-3 {
            margin-top: 3rem !important
        }

        .m-b-3,
        .m-y-3 {
            margin-bottom: 3rem !important
        }

        .m-a-3 {
            margin: 3rem !important
        }

        .p-a-0 {
            padding: 0 !important
        }

        .p-r-1,
        .p-x-1 {
            padding-right: 1rem !important
        }

        .p-l-1,
        .p-x-1 {
            padding-left: 1rem !important
        }

        .p-t-1,
        .p-y-1 {
            padding-top: 1rem !important
        }

        .p-b-1,
        .p-y-1 {
            padding-bottom: 1rem !important
        }

        .p-a-1 {
            padding: 1rem !important
        }

        .p-r-2,
        .p-x-2 {
            padding-right: 1.5rem !important
        }

        .p-l-2,
        .p-x-2 {
            padding-left: 1.5rem !important
        }

        .p-t-2,
        .p-y-2 {
            padding-top: 1.5rem !important
        }

        .p-b-2,
        .p-y-2 {
            padding-bottom: 1.5rem !important
        }

        .p-a-2 {
            padding: 1.5rem !important
        }

        .p-r-3,
        .p-x-3 {
            padding-right: 3rem !important
        }

        .p-l-3,
        .p-x-3 {
            padding-left: 3rem !important
        }

        .p-t-3,
        .p-y-3 {
            padding-top: 3rem !important
        }

        .p-b-3,
        .p-y-3 {
            padding-bottom: 3rem !important
        }

        .p-a-3 {
            padding: 3rem !important
        }

        .m-0 {
            margin: 0 !important
        }

        .mt-0,
        .my-0 {
            margin-top: 0 !important
        }

        .mr-0,
        .mx-0 {
            margin-right: 0 !important
        }

        .mb-0,
        .my-0 {
            margin-bottom: 0 !important
        }

        .ml-0,
        .mx-0 {
            margin-left: 0 !important
        }

        .m-1 {
            margin: .25rem !important
        }

        .mt-1,
        .my-1 {
            margin-top: .25rem !important
        }

        .mr-1,
        .mx-1 {
            margin-right: .25rem !important
        }

        .mb-1,
        .my-1 {
            margin-bottom: .25rem !important
        }

        .ml-1,
        .mx-1 {
            margin-left: .25rem !important
        }

        .m-2 {
            margin: .5rem !important
        }

        .mt-2,
        .my-2 {
            margin-top: .5rem !important
        }

        .mr-2,
        .mx-2 {
            margin-right: .5rem !important
        }

        .mb-2,
        .my-2 {
            margin-bottom: .5rem !important
        }

        .ml-2,
        .mx-2 {
            margin-left: .5rem !important
        }

        .m-3 {
            margin: 1rem !important
        }

        .mt-3,
        .my-3 {
            margin-top: 1rem !important
        }

        .mr-3,
        .mx-3 {
            margin-right: 1rem !important
        }

        .mb-3,
        .my-3 {
            margin-bottom: 1rem !important
        }

        .ml-3,
        .mx-3 {
            margin-left: 1rem !important
        }

        .m-4 {
            margin: 1.5rem !important
        }

        .mt-4,
        .my-4 {
            margin-top: 1.5rem !important
        }

        .mr-4,
        .mx-4 {
            margin-right: 1.5rem !important
        }

        .mb-4,
        .my-4 {
            margin-bottom: 1.5rem !important
        }

        .ml-4,
        .mx-4 {
            margin-left: 1.5rem !important
        }

        .m-5 {
            margin: 3rem !important
        }

        .mt-5,
        .my-5 {
            margin-top: 3rem !important
        }

        .mr-5,
        .mx-5 {
            margin-right: 3rem !important
        }

        .mb-5,
        .my-5 {
            margin-bottom: 3rem !important
        }

        .ml-5,
        .mx-5 {
            margin-left: 3rem !important
        }

        .p-0 {
            padding: 0 !important
        }

        .pt-0,
        .py-0 {
            padding-top: 0 !important
        }

        .pr-0,
        .px-0 {
            padding-right: 0 !important
        }

        .pb-0,
        .py-0 {
            padding-bottom: 0 !important
        }

        .pl-0,
        .px-0 {
            padding-left: 0 !important
        }

        .p-1 {
            padding: .25rem !important
        }

        .pt-1,
        .py-1 {
            padding-top: .25rem !important
        }

        .pr-1,
        .px-1 {
            padding-right: .25rem !important
        }

        .pb-1,
        .py-1 {
            padding-bottom: .25rem !important
        }

        .pl-1,
        .px-1 {
            padding-left: .25rem !important
        }

        .p-2 {
            padding: .5rem !important
        }

        .pt-2,
        .py-2 {
            padding-top: .5rem !important
        }

        .pr-2,
        .px-2 {
            padding-right: .5rem !important
        }

        .pb-2,
        .py-2 {
            padding-bottom: .5rem !important
        }

        .pl-2,
        .px-2 {
            padding-left: .5rem !important
        }

        .p-3 {
            padding: 1rem !important
        }

        .pt-3,
        .py-3 {
            padding-top: 1rem !important
        }

        .pr-3,
        .px-3 {
            padding-right: 1rem !important
        }

        .pb-3,
        .py-3 {
            padding-bottom: 1rem !important
        }

        .pl-3,
        .px-3 {
            padding-left: 1rem !important
        }

        .p-4 {
            padding: 1.5rem !important
        }

        .pt-4,
        .py-4 {
            padding-top: 1.5rem !important
        }

        .pr-4,
        .px-4 {
            padding-right: 1.5rem !important
        }

        .pb-4,
        .py-4 {
            padding-bottom: 1.5rem !important
        }

        .pl-4,
        .px-4 {
            padding-left: 1.5rem !important
        }

        .p-5 {
            padding: 3rem !important
        }

        .pt-5,
        .py-5 {
            padding-top: 3rem !important
        }

        .pr-5,
        .px-5 {
            padding-right: 3rem !important
        }

        .pb-5,
        .py-5 {
            padding-bottom: 3rem !important
        }

        .pl-5,
        .px-5 {
            padding-left: 3rem !important
        }

        .m-n1 {
            margin: -.25rem !important
        }

        .mt-n1,
        .my-n1 {
            margin-top: -.25rem !important
        }

        .mr-n1,
        .mx-n1 {
            margin-right: -.25rem !important
        }

        .mb-n1,
        .my-n1 {
            margin-bottom: -.25rem !important
        }

        .ml-n1,
        .mx-n1 {
            margin-left: -.25rem !important
        }

        .m-n2 {
            margin: -.5rem !important
        }

        .mt-n2,
        .my-n2 {
            margin-top: -.5rem !important
        }

        .mr-n2,
        .mx-n2 {
            margin-right: -.5rem !important
        }

        .mb-n2,
        .my-n2 {
            margin-bottom: -.5rem !important
        }

        .ml-n2,
        .mx-n2 {
            margin-left: -.5rem !important
        }

        .m-n3 {
            margin: -1rem !important
        }

        .mt-n3,
        .my-n3 {
            margin-top: -1rem !important
        }

        .mr-n3,
        .mx-n3 {
            margin-right: -1rem !important
        }

        .mb-n3,
        .my-n3 {
            margin-bottom: -1rem !important
        }

        .ml-n3,
        .mx-n3 {
            margin-left: -1rem !important
        }

        .m-n4 {
            margin: -1.5rem !important
        }

        .mt-n4,
        .my-n4 {
            margin-top: -1.5rem !important
        }

        .mr-n4,
        .mx-n4 {
            margin-right: -1.5rem !important
        }

        .mb-n4,
        .my-n4 {
            margin-bottom: -1.5rem !important
        }

        .ml-n4,
        .mx-n4 {
            margin-left: -1.5rem !important
        }

        .m-n5 {
            margin: -3rem !important
        }

        .mt-n5,
        .my-n5 {
            margin-top: -3rem !important
        }

        .mr-n5,
        .mx-n5 {
            margin-right: -3rem !important
        }

        .mb-n5,
        .my-n5 {
            margin-bottom: -3rem !important
        }

        .ml-n5,
        .mx-n5 {
            margin-left: -3rem !important
        }

        .m-auto {
            margin: auto !important
        }

        .mt-auto,
        .my-auto {
            margin-top: auto !important
        }

        .mr-auto,
        .mx-auto {
            margin-right: auto !important
        }

        .mb-auto,
        .my-auto {
            margin-bottom: auto !important
        }

        .ml-auto,
        .mx-auto {
            margin-left: auto !important
        }

        @media (min-width:520px) {
            .m-sm-0 {
                margin: 0 !important
            }

            .mt-sm-0,
            .my-sm-0 {
                margin-top: 0 !important
            }

            .mr-sm-0,
            .mx-sm-0 {
                margin-right: 0 !important
            }

            .mb-sm-0,
            .my-sm-0 {
                margin-bottom: 0 !important
            }

            .ml-sm-0,
            .mx-sm-0 {
                margin-left: 0 !important
            }

            .m-sm-1 {
                margin: .25rem !important
            }

            .mt-sm-1,
            .my-sm-1 {
                margin-top: .25rem !important
            }

            .mr-sm-1,
            .mx-sm-1 {
                margin-right: .25rem !important
            }

            .mb-sm-1,
            .my-sm-1 {
                margin-bottom: .25rem !important
            }

            .ml-sm-1,
            .mx-sm-1 {
                margin-left: .25rem !important
            }

            .m-sm-2 {
                margin: .5rem !important
            }

            .mt-sm-2,
            .my-sm-2 {
                margin-top: .5rem !important
            }

            .mr-sm-2,
            .mx-sm-2 {
                margin-right: .5rem !important
            }

            .mb-sm-2,
            .my-sm-2 {
                margin-bottom: .5rem !important
            }

            .ml-sm-2,
            .mx-sm-2 {
                margin-left: .5rem !important
            }

            .m-sm-3 {
                margin: 1rem !important
            }

            .mt-sm-3,
            .my-sm-3 {
                margin-top: 1rem !important
            }

            .mr-sm-3,
            .mx-sm-3 {
                margin-right: 1rem !important
            }

            .mb-sm-3,
            .my-sm-3 {
                margin-bottom: 1rem !important
            }

            .ml-sm-3,
            .mx-sm-3 {
                margin-left: 1rem !important
            }

            .m-sm-4 {
                margin: 1.5rem !important
            }

            .mt-sm-4,
            .my-sm-4 {
                margin-top: 1.5rem !important
            }

            .mr-sm-4,
            .mx-sm-4 {
                margin-right: 1.5rem !important
            }

            .mb-sm-4,
            .my-sm-4 {
                margin-bottom: 1.5rem !important
            }

            .ml-sm-4,
            .mx-sm-4 {
                margin-left: 1.5rem !important
            }

            .m-sm-5 {
                margin: 3rem !important
            }

            .mt-sm-5,
            .my-sm-5 {
                margin-top: 3rem !important
            }

            .mr-sm-5,
            .mx-sm-5 {
                margin-right: 3rem !important
            }

            .mb-sm-5,
            .my-sm-5 {
                margin-bottom: 3rem !important
            }

            .ml-sm-5,
            .mx-sm-5 {
                margin-left: 3rem !important
            }

            .p-sm-0 {
                padding: 0 !important
            }

            .pt-sm-0,
            .py-sm-0 {
                padding-top: 0 !important
            }

            .pr-sm-0,
            .px-sm-0 {
                padding-right: 0 !important
            }

            .pb-sm-0,
            .py-sm-0 {
                padding-bottom: 0 !important
            }

            .pl-sm-0,
            .px-sm-0 {
                padding-left: 0 !important
            }

            .p-sm-1 {
                padding: .25rem !important
            }

            .pt-sm-1,
            .py-sm-1 {
                padding-top: .25rem !important
            }

            .pr-sm-1,
            .px-sm-1 {
                padding-right: .25rem !important
            }

            .pb-sm-1,
            .py-sm-1 {
                padding-bottom: .25rem !important
            }

            .pl-sm-1,
            .px-sm-1 {
                padding-left: .25rem !important
            }

            .p-sm-2 {
                padding: .5rem !important
            }

            .pt-sm-2,
            .py-sm-2 {
                padding-top: .5rem !important
            }

            .pr-sm-2,
            .px-sm-2 {
                padding-right: .5rem !important
            }

            .pb-sm-2,
            .py-sm-2 {
                padding-bottom: .5rem !important
            }

            .pl-sm-2,
            .px-sm-2 {
                padding-left: .5rem !important
            }

            .p-sm-3 {
                padding: 1rem !important
            }

            .pt-sm-3,
            .py-sm-3 {
                padding-top: 1rem !important
            }

            .pr-sm-3,
            .px-sm-3 {
                padding-right: 1rem !important
            }

            .pb-sm-3,
            .py-sm-3 {
                padding-bottom: 1rem !important
            }

            .pl-sm-3,
            .px-sm-3 {
                padding-left: 1rem !important
            }

            .p-sm-4 {
                padding: 1.5rem !important
            }

            .pt-sm-4,
            .py-sm-4 {
                padding-top: 1.5rem !important
            }

            .pr-sm-4,
            .px-sm-4 {
                padding-right: 1.5rem !important
            }

            .pb-sm-4,
            .py-sm-4 {
                padding-bottom: 1.5rem !important
            }

            .pl-sm-4,
            .px-sm-4 {
                padding-left: 1.5rem !important
            }

            .p-sm-5 {
                padding: 3rem !important
            }

            .pt-sm-5,
            .py-sm-5 {
                padding-top: 3rem !important
            }

            .pr-sm-5,
            .px-sm-5 {
                padding-right: 3rem !important
            }

            .pb-sm-5,
            .py-sm-5 {
                padding-bottom: 3rem !important
            }

            .pl-sm-5,
            .px-sm-5 {
                padding-left: 3rem !important
            }

            .m-sm-n1 {
                margin: -.25rem !important
            }

            .mt-sm-n1,
            .my-sm-n1 {
                margin-top: -.25rem !important
            }

            .mr-sm-n1,
            .mx-sm-n1 {
                margin-right: -.25rem !important
            }

            .mb-sm-n1,
            .my-sm-n1 {
                margin-bottom: -.25rem !important
            }

            .ml-sm-n1,
            .mx-sm-n1 {
                margin-left: -.25rem !important
            }

            .m-sm-n2 {
                margin: -.5rem !important
            }

            .mt-sm-n2,
            .my-sm-n2 {
                margin-top: -.5rem !important
            }

            .mr-sm-n2,
            .mx-sm-n2 {
                margin-right: -.5rem !important
            }

            .mb-sm-n2,
            .my-sm-n2 {
                margin-bottom: -.5rem !important
            }

            .ml-sm-n2,
            .mx-sm-n2 {
                margin-left: -.5rem !important
            }

            .m-sm-n3 {
                margin: -1rem !important
            }

            .mt-sm-n3,
            .my-sm-n3 {
                margin-top: -1rem !important
            }

            .mr-sm-n3,
            .mx-sm-n3 {
                margin-right: -1rem !important
            }

            .mb-sm-n3,
            .my-sm-n3 {
                margin-bottom: -1rem !important
            }

            .ml-sm-n3,
            .mx-sm-n3 {
                margin-left: -1rem !important
            }

            .m-sm-n4 {
                margin: -1.5rem !important
            }

            .mt-sm-n4,
            .my-sm-n4 {
                margin-top: -1.5rem !important
            }

            .mr-sm-n4,
            .mx-sm-n4 {
                margin-right: -1.5rem !important
            }

            .mb-sm-n4,
            .my-sm-n4 {
                margin-bottom: -1.5rem !important
            }

            .ml-sm-n4,
            .mx-sm-n4 {
                margin-left: -1.5rem !important
            }

            .m-sm-n5 {
                margin: -3rem !important
            }

            .mt-sm-n5,
            .my-sm-n5 {
                margin-top: -3rem !important
            }

            .mr-sm-n5,
            .mx-sm-n5 {
                margin-right: -3rem !important
            }

            .mb-sm-n5,
            .my-sm-n5 {
                margin-bottom: -3rem !important
            }

            .ml-sm-n5,
            .mx-sm-n5 {
                margin-left: -3rem !important
            }

            .m-sm-auto {
                margin: auto !important
            }

            .mt-sm-auto,
            .my-sm-auto {
                margin-top: auto !important
            }

            .mr-sm-auto,
            .mx-sm-auto {
                margin-right: auto !important
            }

            .mb-sm-auto,
            .my-sm-auto {
                margin-bottom: auto !important
            }

            .ml-sm-auto,
            .mx-sm-auto {
                margin-left: auto !important
            }
        }

        @media (min-width:768px) {
            .m-md-0 {
                margin: 0 !important
            }

            .mt-md-0,
            .my-md-0 {
                margin-top: 0 !important
            }

            .mr-md-0,
            .mx-md-0 {
                margin-right: 0 !important
            }

            .mb-md-0,
            .my-md-0 {
                margin-bottom: 0 !important
            }

            .ml-md-0,
            .mx-md-0 {
                margin-left: 0 !important
            }

            .m-md-1 {
                margin: .25rem !important
            }

            .mt-md-1,
            .my-md-1 {
                margin-top: .25rem !important
            }

            .mr-md-1,
            .mx-md-1 {
                margin-right: .25rem !important
            }

            .mb-md-1,
            .my-md-1 {
                margin-bottom: .25rem !important
            }

            .ml-md-1,
            .mx-md-1 {
                margin-left: .25rem !important
            }

            .m-md-2 {
                margin: .5rem !important
            }

            .mt-md-2,
            .my-md-2 {
                margin-top: .5rem !important
            }

            .mr-md-2,
            .mx-md-2 {
                margin-right: .5rem !important
            }

            .mb-md-2,
            .my-md-2 {
                margin-bottom: .5rem !important
            }

            .ml-md-2,
            .mx-md-2 {
                margin-left: .5rem !important
            }

            .m-md-3 {
                margin: 1rem !important
            }

            .mt-md-3,
            .my-md-3 {
                margin-top: 1rem !important
            }

            .mr-md-3,
            .mx-md-3 {
                margin-right: 1rem !important
            }

            .mb-md-3,
            .my-md-3 {
                margin-bottom: 1rem !important
            }

            .ml-md-3,
            .mx-md-3 {
                margin-left: 1rem !important
            }

            .m-md-4 {
                margin: 1.5rem !important
            }

            .mt-md-4,
            .my-md-4 {
                margin-top: 1.5rem !important
            }

            .mr-md-4,
            .mx-md-4 {
                margin-right: 1.5rem !important
            }

            .mb-md-4,
            .my-md-4 {
                margin-bottom: 1.5rem !important
            }

            .ml-md-4,
            .mx-md-4 {
                margin-left: 1.5rem !important
            }

            .m-md-5 {
                margin: 3rem !important
            }

            .mt-md-5,
            .my-md-5 {
                margin-top: 3rem !important
            }

            .mr-md-5,
            .mx-md-5 {
                margin-right: 3rem !important
            }

            .mb-md-5,
            .my-md-5 {
                margin-bottom: 3rem !important
            }

            .ml-md-5,
            .mx-md-5 {
                margin-left: 3rem !important
            }

            .p-md-0 {
                padding: 0 !important
            }

            .pt-md-0,
            .py-md-0 {
                padding-top: 0 !important
            }

            .pr-md-0,
            .px-md-0 {
                padding-right: 0 !important
            }

            .pb-md-0,
            .py-md-0 {
                padding-bottom: 0 !important
            }

            .pl-md-0,
            .px-md-0 {
                padding-left: 0 !important
            }

            .p-md-1 {
                padding: .25rem !important
            }

            .pt-md-1,
            .py-md-1 {
                padding-top: .25rem !important
            }

            .pr-md-1,
            .px-md-1 {
                padding-right: .25rem !important
            }

            .pb-md-1,
            .py-md-1 {
                padding-bottom: .25rem !important
            }

            .pl-md-1,
            .px-md-1 {
                padding-left: .25rem !important
            }

            .p-md-2 {
                padding: .5rem !important
            }

            .pt-md-2,
            .py-md-2 {
                padding-top: .5rem !important
            }

            .pr-md-2,
            .px-md-2 {
                padding-right: .5rem !important
            }

            .pb-md-2,
            .py-md-2 {
                padding-bottom: .5rem !important
            }

            .pl-md-2,
            .px-md-2 {
                padding-left: .5rem !important
            }

            .p-md-3 {
                padding: 1rem !important
            }

            .pt-md-3,
            .py-md-3 {
                padding-top: 1rem !important
            }

            .pr-md-3,
            .px-md-3 {
                padding-right: 1rem !important
            }

            .pb-md-3,
            .py-md-3 {
                padding-bottom: 1rem !important
            }

            .pl-md-3,
            .px-md-3 {
                padding-left: 1rem !important
            }

            .p-md-4 {
                padding: 1.5rem !important
            }

            .pt-md-4,
            .py-md-4 {
                padding-top: 1.5rem !important
            }

            .pr-md-4,
            .px-md-4 {
                padding-right: 1.5rem !important
            }

            .pb-md-4,
            .py-md-4 {
                padding-bottom: 1.5rem !important
            }

            .pl-md-4,
            .px-md-4 {
                padding-left: 1.5rem !important
            }

            .p-md-5 {
                padding: 3rem !important
            }

            .pt-md-5,
            .py-md-5 {
                padding-top: 3rem !important
            }

            .pr-md-5,
            .px-md-5 {
                padding-right: 3rem !important
            }

            .pb-md-5,
            .py-md-5 {
                padding-bottom: 3rem !important
            }

            .pl-md-5,
            .px-md-5 {
                padding-left: 3rem !important
            }

            .m-md-n1 {
                margin: -.25rem !important
            }

            .mt-md-n1,
            .my-md-n1 {
                margin-top: -.25rem !important
            }

            .mr-md-n1,
            .mx-md-n1 {
                margin-right: -.25rem !important
            }

            .mb-md-n1,
            .my-md-n1 {
                margin-bottom: -.25rem !important
            }

            .ml-md-n1,
            .mx-md-n1 {
                margin-left: -.25rem !important
            }

            .m-md-n2 {
                margin: -.5rem !important
            }

            .mt-md-n2,
            .my-md-n2 {
                margin-top: -.5rem !important
            }

            .mr-md-n2,
            .mx-md-n2 {
                margin-right: -.5rem !important
            }

            .mb-md-n2,
            .my-md-n2 {
                margin-bottom: -.5rem !important
            }

            .ml-md-n2,
            .mx-md-n2 {
                margin-left: -.5rem !important
            }

            .m-md-n3 {
                margin: -1rem !important
            }

            .mt-md-n3,
            .my-md-n3 {
                margin-top: -1rem !important
            }

            .mr-md-n3,
            .mx-md-n3 {
                margin-right: -1rem !important
            }

            .mb-md-n3,
            .my-md-n3 {
                margin-bottom: -1rem !important
            }

            .ml-md-n3,
            .mx-md-n3 {
                margin-left: -1rem !important
            }

            .m-md-n4 {
                margin: -1.5rem !important
            }

            .mt-md-n4,
            .my-md-n4 {
                margin-top: -1.5rem !important
            }

            .mr-md-n4,
            .mx-md-n4 {
                margin-right: -1.5rem !important
            }

            .mb-md-n4,
            .my-md-n4 {
                margin-bottom: -1.5rem !important
            }

            .ml-md-n4,
            .mx-md-n4 {
                margin-left: -1.5rem !important
            }

            .m-md-n5 {
                margin: -3rem !important
            }

            .mt-md-n5,
            .my-md-n5 {
                margin-top: -3rem !important
            }

            .mr-md-n5,
            .mx-md-n5 {
                margin-right: -3rem !important
            }

            .mb-md-n5,
            .my-md-n5 {
                margin-bottom: -3rem !important
            }

            .ml-md-n5,
            .mx-md-n5 {
                margin-left: -3rem !important
            }

            .m-md-auto {
                margin: auto !important
            }

            .mt-md-auto,
            .my-md-auto {
                margin-top: auto !important
            }

            .mr-md-auto,
            .mx-md-auto {
                margin-right: auto !important
            }

            .mb-md-auto,
            .my-md-auto {
                margin-bottom: auto !important
            }

            .ml-md-auto,
            .mx-md-auto {
                margin-left: auto !important
            }
        }

        @media (min-width:992px) {
            .flex-lg-row {
                flex-direction: row !important
            }

            .flex-lg-column {
                flex-direction: column !important
            }

            .flex-lg-row-reverse {
                flex-direction: row-reverse !important
            }

            .flex-lg-column-reverse {
                flex-direction: column-reverse !important
            }

            .flex-lg-wrap {
                flex-wrap: wrap !important
            }

            .flex-lg-nowrap {
                flex-wrap: nowrap !important
            }

            .flex-lg-wrap-reverse {
                flex-wrap: wrap-reverse !important
            }

            .flex-lg-fill {
                flex: 1 1 auto !important
            }

            .flex-lg-grow-0 {
                flex-grow: 0 !important
            }

            .flex-lg-grow-1 {
                flex-grow: 1 !important
            }

            .flex-lg-shrink-0 {
                flex-shrink: 0 !important
            }

            .flex-lg-shrink-1 {
                flex-shrink: 1 !important
            }

            .justify-content-lg-start {
                justify-content: flex-start !important
            }

            .justify-content-lg-end {
                justify-content: flex-end !important
            }

            .justify-content-lg-center {
                justify-content: center !important
            }

            .justify-content-lg-between {
                justify-content: space-between !important
            }

            .justify-content-lg-around {
                justify-content: space-around !important
            }

            .align-items-lg-start {
                align-items: flex-start !important
            }

            .align-items-lg-end {
                align-items: flex-end !important
            }

            .align-items-lg-center {
                align-items: center !important
            }

            .align-items-lg-baseline {
                align-items: baseline !important
            }

            .align-items-lg-stretch {
                align-items: stretch !important
            }

            .align-content-lg-start {
                align-content: flex-start !important
            }

            .align-content-lg-end {
                align-content: flex-end !important
            }

            .align-content-lg-center {
                align-content: center !important
            }

            .align-content-lg-between {
                align-content: space-between !important
            }

            .align-content-lg-around {
                align-content: space-around !important
            }

            .align-content-lg-stretch {
                align-content: stretch !important
            }

            .align-self-lg-auto {
                align-self: auto !important
            }

            .align-self-lg-start {
                align-self: flex-start !important
            }

            .align-self-lg-end {
                align-self: flex-end !important
            }

            .align-self-lg-center {
                align-self: center !important
            }

            .align-self-lg-baseline {
                align-self: baseline !important
            }

            .align-self-lg-stretch {
                align-self: stretch !important
            }

            .m-lg-0 {
                margin: 0 !important
            }

            .mt-lg-0,
            .my-lg-0 {
                margin-top: 0 !important
            }

            .mr-lg-0,
            .mx-lg-0 {
                margin-right: 0 !important
            }

            .mb-lg-0,
            .my-lg-0 {
                margin-bottom: 0 !important
            }

            .ml-lg-0,
            .mx-lg-0 {
                margin-left: 0 !important
            }

            .m-lg-1 {
                margin: .25rem !important
            }

            .mt-lg-1,
            .my-lg-1 {
                margin-top: .25rem !important
            }

            .mr-lg-1,
            .mx-lg-1 {
                margin-right: .25rem !important
            }

            .mb-lg-1,
            .my-lg-1 {
                margin-bottom: .25rem !important
            }

            .ml-lg-1,
            .mx-lg-1 {
                margin-left: .25rem !important
            }

            .m-lg-2 {
                margin: .5rem !important
            }

            .mt-lg-2,
            .my-lg-2 {
                margin-top: .5rem !important
            }

            .mr-lg-2,
            .mx-lg-2 {
                margin-right: .5rem !important
            }

            .mb-lg-2,
            .my-lg-2 {
                margin-bottom: .5rem !important
            }

            .ml-lg-2,
            .mx-lg-2 {
                margin-left: .5rem !important
            }

            .m-lg-3 {
                margin: 1rem !important
            }

            .mt-lg-3,
            .my-lg-3 {
                margin-top: 1rem !important
            }

            .mr-lg-3,
            .mx-lg-3 {
                margin-right: 1rem !important
            }

            .mb-lg-3,
            .my-lg-3 {
                margin-bottom: 1rem !important
            }

            .ml-lg-3,
            .mx-lg-3 {
                margin-left: 1rem !important
            }

            .m-lg-4 {
                margin: 1.5rem !important
            }

            .mt-lg-4,
            .my-lg-4 {
                margin-top: 1.5rem !important
            }

            .mr-lg-4,
            .mx-lg-4 {
                margin-right: 1.5rem !important
            }

            .mb-lg-4,
            .my-lg-4 {
                margin-bottom: 1.5rem !important
            }

            .ml-lg-4,
            .mx-lg-4 {
                margin-left: 1.5rem !important
            }

            .m-lg-5 {
                margin: 3rem !important
            }

            .mt-lg-5,
            .my-lg-5 {
                margin-top: 3rem !important
            }

            .mr-lg-5,
            .mx-lg-5 {
                margin-right: 3rem !important
            }

            .mb-lg-5,
            .my-lg-5 {
                margin-bottom: 3rem !important
            }

            .ml-lg-5,
            .mx-lg-5 {
                margin-left: 3rem !important
            }

            .p-lg-0 {
                padding: 0 !important
            }

            .pt-lg-0,
            .py-lg-0 {
                padding-top: 0 !important
            }

            .pr-lg-0,
            .px-lg-0 {
                padding-right: 0 !important
            }

            .pb-lg-0,
            .py-lg-0 {
                padding-bottom: 0 !important
            }

            .pl-lg-0,
            .px-lg-0 {
                padding-left: 0 !important
            }

            .p-lg-1 {
                padding: .25rem !important
            }

            .pt-lg-1,
            .py-lg-1 {
                padding-top: .25rem !important
            }

            .pr-lg-1,
            .px-lg-1 {
                padding-right: .25rem !important
            }

            .pb-lg-1,
            .py-lg-1 {
                padding-bottom: .25rem !important
            }

            .pl-lg-1,
            .px-lg-1 {
                padding-left: .25rem !important
            }

            .p-lg-2 {
                padding: .5rem !important
            }

            .pt-lg-2,
            .py-lg-2 {
                padding-top: .5rem !important
            }

            .pr-lg-2,
            .px-lg-2 {
                padding-right: .5rem !important
            }

            .pb-lg-2,
            .py-lg-2 {
                padding-bottom: .5rem !important
            }

            .pl-lg-2,
            .px-lg-2 {
                padding-left: .5rem !important
            }

            .p-lg-3 {
                padding: 1rem !important
            }

            .pt-lg-3,
            .py-lg-3 {
                padding-top: 1rem !important
            }

            .pr-lg-3,
            .px-lg-3 {
                padding-right: 1rem !important
            }

            .pb-lg-3,
            .py-lg-3 {
                padding-bottom: 1rem !important
            }

            .pl-lg-3,
            .px-lg-3 {
                padding-left: 1rem !important
            }

            .p-lg-4 {
                padding: 1.5rem !important
            }

            .pt-lg-4,
            .py-lg-4 {
                padding-top: 1.5rem !important
            }

            .pr-lg-4,
            .px-lg-4 {
                padding-right: 1.5rem !important
            }

            .pb-lg-4,
            .py-lg-4 {
                padding-bottom: 1.5rem !important
            }

            .pl-lg-4,
            .px-lg-4 {
                padding-left: 1.5rem !important
            }

            .p-lg-5 {
                padding: 3rem !important
            }

            .pt-lg-5,
            .py-lg-5 {
                padding-top: 3rem !important
            }

            .pr-lg-5,
            .px-lg-5 {
                padding-right: 3rem !important
            }

            .pb-lg-5,
            .py-lg-5 {
                padding-bottom: 3rem !important
            }

            .pl-lg-5,
            .px-lg-5 {
                padding-left: 3rem !important
            }

            .m-lg-n1 {
                margin: -.25rem !important
            }

            .mt-lg-n1,
            .my-lg-n1 {
                margin-top: -.25rem !important
            }

            .mr-lg-n1,
            .mx-lg-n1 {
                margin-right: -.25rem !important
            }

            .mb-lg-n1,
            .my-lg-n1 {
                margin-bottom: -.25rem !important
            }

            .ml-lg-n1,
            .mx-lg-n1 {
                margin-left: -.25rem !important
            }

            .m-lg-n2 {
                margin: -.5rem !important
            }

            .mt-lg-n2,
            .my-lg-n2 {
                margin-top: -.5rem !important
            }

            .mr-lg-n2,
            .mx-lg-n2 {
                margin-right: -.5rem !important
            }

            .mb-lg-n2,
            .my-lg-n2 {
                margin-bottom: -.5rem !important
            }

            .ml-lg-n2,
            .mx-lg-n2 {
                margin-left: -.5rem !important
            }

            .m-lg-n3 {
                margin: -1rem !important
            }

            .mt-lg-n3,
            .my-lg-n3 {
                margin-top: -1rem !important
            }

            .mr-lg-n3,
            .mx-lg-n3 {
                margin-right: -1rem !important
            }

            .mb-lg-n3,
            .my-lg-n3 {
                margin-bottom: -1rem !important
            }

            .ml-lg-n3,
            .mx-lg-n3 {
                margin-left: -1rem !important
            }

            .m-lg-n4 {
                margin: -1.5rem !important
            }

            .mt-lg-n4,
            .my-lg-n4 {
                margin-top: -1.5rem !important
            }

            .mr-lg-n4,
            .mx-lg-n4 {
                margin-right: -1.5rem !important
            }

            .mb-lg-n4,
            .my-lg-n4 {
                margin-bottom: -1.5rem !important
            }

            .ml-lg-n4,
            .mx-lg-n4 {
                margin-left: -1.5rem !important
            }

            .m-lg-n5 {
                margin: -3rem !important
            }

            .mt-lg-n5,
            .my-lg-n5 {
                margin-top: -3rem !important
            }

            .mr-lg-n5,
            .mx-lg-n5 {
                margin-right: -3rem !important
            }

            .mb-lg-n5,
            .my-lg-n5 {
                margin-bottom: -3rem !important
            }

            .ml-lg-n5,
            .mx-lg-n5 {
                margin-left: -3rem !important
            }

            .m-lg-auto {
                margin: auto !important
            }

            .mt-lg-auto,
            .my-lg-auto {
                margin-top: auto !important
            }

            .mr-lg-auto,
            .mx-lg-auto {
                margin-right: auto !important
            }

            .mb-lg-auto,
            .my-lg-auto {
                margin-bottom: auto !important
            }

            .ml-lg-auto,
            .mx-lg-auto {
                margin-left: auto !important
            }
        }

        @media (min-width:1200px) {
            .flex-xl-row {
                flex-direction: row !important
            }

            .flex-xl-column {
                flex-direction: column !important
            }

            .flex-xl-row-reverse {
                flex-direction: row-reverse !important
            }

            .flex-xl-column-reverse {
                flex-direction: column-reverse !important
            }

            .flex-xl-wrap {
                flex-wrap: wrap !important
            }

            .flex-xl-nowrap {
                flex-wrap: nowrap !important
            }

            .flex-xl-wrap-reverse {
                flex-wrap: wrap-reverse !important
            }

            .flex-xl-fill {
                flex: 1 1 auto !important
            }

            .flex-xl-grow-0 {
                flex-grow: 0 !important
            }

            .flex-xl-grow-1 {
                flex-grow: 1 !important
            }

            .flex-xl-shrink-0 {
                flex-shrink: 0 !important
            }

            .flex-xl-shrink-1 {
                flex-shrink: 1 !important
            }

            .justify-content-xl-start {
                justify-content: flex-start !important
            }

            .justify-content-xl-end {
                justify-content: flex-end !important
            }

            .justify-content-xl-center {
                justify-content: center !important
            }

            .justify-content-xl-between {
                justify-content: space-between !important
            }

            .justify-content-xl-around {
                justify-content: space-around !important
            }

            .align-items-xl-start {
                align-items: flex-start !important
            }

            .align-items-xl-end {
                align-items: flex-end !important
            }

            .align-items-xl-center {
                align-items: center !important
            }

            .align-items-xl-baseline {
                align-items: baseline !important
            }

            .align-items-xl-stretch {
                align-items: stretch !important
            }

            .align-content-xl-start {
                align-content: flex-start !important
            }

            .align-content-xl-end {
                align-content: flex-end !important
            }

            .align-content-xl-center {
                align-content: center !important
            }

            .align-content-xl-between {
                align-content: space-between !important
            }

            .align-content-xl-around {
                align-content: space-around !important
            }

            .align-content-xl-stretch {
                align-content: stretch !important
            }

            .align-self-xl-auto {
                align-self: auto !important
            }

            .align-self-xl-start {
                align-self: flex-start !important
            }

            .align-self-xl-end {
                align-self: flex-end !important
            }

            .align-self-xl-center {
                align-self: center !important
            }

            .align-self-xl-baseline {
                align-self: baseline !important
            }

            .align-self-xl-stretch {
                align-self: stretch !important
            }

            .m-xl-0 {
                margin: 0 !important
            }

            .mt-xl-0,
            .my-xl-0 {
                margin-top: 0 !important
            }

            .mr-xl-0,
            .mx-xl-0 {
                margin-right: 0 !important
            }

            .mb-xl-0,
            .my-xl-0 {
                margin-bottom: 0 !important
            }

            .ml-xl-0,
            .mx-xl-0 {
                margin-left: 0 !important
            }

            .m-xl-1 {
                margin: .25rem !important
            }

            .mt-xl-1,
            .my-xl-1 {
                margin-top: .25rem !important
            }

            .mr-xl-1,
            .mx-xl-1 {
                margin-right: .25rem !important
            }

            .mb-xl-1,
            .my-xl-1 {
                margin-bottom: .25rem !important
            }

            .ml-xl-1,
            .mx-xl-1 {
                margin-left: .25rem !important
            }

            .m-xl-2 {
                margin: .5rem !important
            }

            .mt-xl-2,
            .my-xl-2 {
                margin-top: .5rem !important
            }

            .mr-xl-2,
            .mx-xl-2 {
                margin-right: .5rem !important
            }

            .mb-xl-2,
            .my-xl-2 {
                margin-bottom: .5rem !important
            }

            .ml-xl-2,
            .mx-xl-2 {
                margin-left: .5rem !important
            }

            .m-xl-3 {
                margin: 1rem !important
            }

            .mt-xl-3,
            .my-xl-3 {
                margin-top: 1rem !important
            }

            .mr-xl-3,
            .mx-xl-3 {
                margin-right: 1rem !important
            }

            .mb-xl-3,
            .my-xl-3 {
                margin-bottom: 1rem !important
            }

            .ml-xl-3,
            .mx-xl-3 {
                margin-left: 1rem !important
            }

            .m-xl-4 {
                margin: 1.5rem !important
            }

            .mt-xl-4,
            .my-xl-4 {
                margin-top: 1.5rem !important
            }

            .mr-xl-4,
            .mx-xl-4 {
                margin-right: 1.5rem !important
            }

            .mb-xl-4,
            .my-xl-4 {
                margin-bottom: 1.5rem !important
            }

            .ml-xl-4,
            .mx-xl-4 {
                margin-left: 1.5rem !important
            }

            .m-xl-5 {
                margin: 3rem !important
            }

            .mt-xl-5,
            .my-xl-5 {
                margin-top: 3rem !important
            }

            .mr-xl-5,
            .mx-xl-5 {
                margin-right: 3rem !important
            }

            .mb-xl-5,
            .my-xl-5 {
                margin-bottom: 3rem !important
            }

            .ml-xl-5,
            .mx-xl-5 {
                margin-left: 3rem !important
            }

            .p-xl-0 {
                padding: 0 !important
            }

            .pt-xl-0,
            .py-xl-0 {
                padding-top: 0 !important
            }

            .pr-xl-0,
            .px-xl-0 {
                padding-right: 0 !important
            }

            .pb-xl-0,
            .py-xl-0 {
                padding-bottom: 0 !important
            }

            .pl-xl-0,
            .px-xl-0 {
                padding-left: 0 !important
            }

            .p-xl-1 {
                padding: .25rem !important
            }

            .pt-xl-1,
            .py-xl-1 {
                padding-top: .25rem !important
            }

            .pr-xl-1,
            .px-xl-1 {
                padding-right: .25rem !important
            }

            .pb-xl-1,
            .py-xl-1 {
                padding-bottom: .25rem !important
            }

            .pl-xl-1,
            .px-xl-1 {
                padding-left: .25rem !important
            }

            .p-xl-2 {
                padding: .5rem !important
            }

            .pt-xl-2,
            .py-xl-2 {
                padding-top: .5rem !important
            }

            .pr-xl-2,
            .px-xl-2 {
                padding-right: .5rem !important
            }

            .pb-xl-2,
            .py-xl-2 {
                padding-bottom: .5rem !important
            }

            .pl-xl-2,
            .px-xl-2 {
                padding-left: .5rem !important
            }

            .p-xl-3 {
                padding: 1rem !important
            }

            .pt-xl-3,
            .py-xl-3 {
                padding-top: 1rem !important
            }

            .pr-xl-3,
            .px-xl-3 {
                padding-right: 1rem !important
            }

            .pb-xl-3,
            .py-xl-3 {
                padding-bottom: 1rem !important
            }

            .pl-xl-3,
            .px-xl-3 {
                padding-left: 1rem !important
            }

            .p-xl-4 {
                padding: 1.5rem !important
            }

            .pt-xl-4,
            .py-xl-4 {
                padding-top: 1.5rem !important
            }

            .pr-xl-4,
            .px-xl-4 {
                padding-right: 1.5rem !important
            }

            .pb-xl-4,
            .py-xl-4 {
                padding-bottom: 1.5rem !important
            }

            .pl-xl-4,
            .px-xl-4 {
                padding-left: 1.5rem !important
            }

            .p-xl-5 {
                padding: 3rem !important
            }

            .pt-xl-5,
            .py-xl-5 {
                padding-top: 3rem !important
            }

            .pr-xl-5,
            .px-xl-5 {
                padding-right: 3rem !important
            }

            .pb-xl-5,
            .py-xl-5 {
                padding-bottom: 3rem !important
            }

            .pl-xl-5,
            .px-xl-5 {
                padding-left: 3rem !important
            }

            .m-xl-n1 {
                margin: -.25rem !important
            }

            .mt-xl-n1,
            .my-xl-n1 {
                margin-top: -.25rem !important
            }

            .mr-xl-n1,
            .mx-xl-n1 {
                margin-right: -.25rem !important
            }

            .mb-xl-n1,
            .my-xl-n1 {
                margin-bottom: -.25rem !important
            }

            .ml-xl-n1,
            .mx-xl-n1 {
                margin-left: -.25rem !important
            }

            .m-xl-n2 {
                margin: -.5rem !important
            }

            .mt-xl-n2,
            .my-xl-n2 {
                margin-top: -.5rem !important
            }

            .mr-xl-n2,
            .mx-xl-n2 {
                margin-right: -.5rem !important
            }

            .mb-xl-n2,
            .my-xl-n2 {
                margin-bottom: -.5rem !important
            }

            .ml-xl-n2,
            .mx-xl-n2 {
                margin-left: -.5rem !important
            }

            .m-xl-n3 {
                margin: -1rem !important
            }

            .mt-xl-n3,
            .my-xl-n3 {
                margin-top: -1rem !important
            }

            .mr-xl-n3,
            .mx-xl-n3 {
                margin-right: -1rem !important
            }

            .mb-xl-n3,
            .my-xl-n3 {
                margin-bottom: -1rem !important
            }

            .ml-xl-n3,
            .mx-xl-n3 {
                margin-left: -1rem !important
            }

            .m-xl-n4 {
                margin: -1.5rem !important
            }

            .mt-xl-n4,
            .my-xl-n4 {
                margin-top: -1.5rem !important
            }

            .mr-xl-n4,
            .mx-xl-n4 {
                margin-right: -1.5rem !important
            }

            .mb-xl-n4,
            .my-xl-n4 {
                margin-bottom: -1.5rem !important
            }

            .ml-xl-n4,
            .mx-xl-n4 {
                margin-left: -1.5rem !important
            }

            .m-xl-n5 {
                margin: -3rem !important
            }

            .mt-xl-n5,
            .my-xl-n5 {
                margin-top: -3rem !important
            }

            .mr-xl-n5,
            .mx-xl-n5 {
                margin-right: -3rem !important
            }

            .mb-xl-n5,
            .my-xl-n5 {
                margin-bottom: -3rem !important
            }

            .ml-xl-n5,
            .mx-xl-n5 {
                margin-left: -3rem !important
            }

            .m-xl-auto {
                margin: auto !important
            }

            .mt-xl-auto,
            .my-xl-auto {
                margin-top: auto !important
            }

            .mr-xl-auto,
            .mx-xl-auto {
                margin-right: auto !important
            }

            .mb-xl-auto,
            .my-xl-auto {
                margin-bottom: auto !important
            }

            .ml-xl-auto,
            .mx-xl-auto {
                margin-left: auto !important
            }
        }

        .pos-f-t {
            position: fixed;
            top: 0;
            right: 0;
            left: 0;
            z-index: 1030
        }

        .text-justify {
            text-align: justify !important
        }

        .text-nowrap {
            white-space: nowrap !important
        }

        .text-truncate {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .text-left {
            text-align: left !important;
            justify-content: left !important
        }

        .text-right {
            text-align: right !important;
            justify-content: right !important
        }

        .text-center {
            text-align: center !important;
            justify-content: center !important
        }

        @media (min-width:520px) {
            .text-sm-left {
                text-align: left !important
            }

            .text-sm-right {
                text-align: right !important
            }

            .text-sm-center {
                text-align: center !important
            }
        }

        @media (min-width:768px) {
            .text-md-left {
                text-align: left !important
            }

            .text-md-right {
                text-align: right !important
            }

            .text-md-center {
                text-align: center !important
            }
        }

        @media (min-width:992px) {
            .text-lg-left {
                text-align: left !important
            }

            .text-lg-right {
                text-align: right !important
            }

            .text-lg-center {
                text-align: center !important
            }
        }

        @media (min-width:1200px) {
            .text-xl-left {
                text-align: left !important
            }

            .text-xl-right {
                text-align: right !important
            }

            .text-xl-center {
                text-align: center !important
            }
        }

        .text-lowercase {
            text-transform: lowercase !important
        }

        .text-uppercase {
            text-transform: uppercase !important
        }

        .text-capitalize {
            text-transform: capitalize !important
        }

        .btn,
        .btn-link,
        .dropdown-menu,
        .form-group>label {
            text-transform: none
        }

        .font-weight-normal {
            font-weight: 400
        }

        .font-weight-bold {
            font-weight: 700
        }

        .font-italic {
            font-style: italic
        }

        .text-primary {
            color: #00a63f !important
        }

        a.text-primary:focus,
        a.text-primary:hover {
            color: #00732c !important
        }

        .text-secondary {
            color: #1976d2 !important
        }

        a.text-secondary:focus,
        a.text-secondary:hover {
            color: #145ca4 !important
        }

        .text-success {
            color: #00a63f !important
        }

        a.text-success:focus,
        a.text-success:hover {
            color: #00732c !important
        }

        .text-info {
            color: #9e42b5 !important
        }

        a.text-info:focus,
        a.text-info:hover {
            color: #7d3490 !important
        }

        .text-warning {
            color: #fedc45 !important
        }

        a.text-warning:focus,
        a.text-warning:hover {
            color: #fed212 !important
        }

        .text-danger {
            color: #db1802 !important
        }

        a.text-danger:focus,
        a.text-danger:hover {
            color: #a81202 !important
        }

        .text-light {
            color: #f8f9fa !important
        }

        a.text-light:focus,
        a.text-light:hover {
            color: #dae0e5 !important
        }

        .text-dark {
            color: #343a40 !important
        }

        a.text-dark:focus,
        a.text-dark:hover {
            color: #1d2124 !important
        }

        .text-primary-o {
            color: #00a63f !important
        }

        a.text-primary-o:focus,
        a.text-primary-o:hover {
            color: #00732c !important
        }

        .text-secondary-o {
            color: #1976d2 !important
        }

        a.text-secondary-o:focus,
        a.text-secondary-o:hover {
            color: #145ca4 !important
        }

        .text-purchase {
            color: #1976d2 !important
        }

        a.text-purchase:focus,
        a.text-purchase:hover {
            color: #145ca4 !important
        }

        .text-default {
            color: #444 !important
        }

        a.text-default:focus,
        a.text-default:hover {
            color: #2b2b2b !important
        }

        .text-feature {
            color: #e20087 !important
        }

        a.text-feature:focus,
        a.text-feature:hover {
            color: #af0069 !important
        }

        .text-muted {
            color: #757575 !important
        }

        a.text-muted:focus,
        a.text-muted:hover {
            color: #5c5c5c !important
        }

        .text-hide {
            font: 0/0 a;
            color: transparent;
            background-color: transparent;
            border: 0
        }

        .bd-r-1,
        .bd-x-1 {
            border-right: 1px solid
        }

        .bd-l-1,
        .bd-x-1 {
            border-left: 1px solid
        }

        .bd-t-1,
        .bd-y-1 {
            border-top: 1px solid
        }

        .bd-b-1,
        .bd-y-1 {
            border-bottom: 1px solid
        }

        .text-decoration-none {
            text-decoration: none !important
        }

        .btn,
        .btn-link,
        .btn:focus,
        .btn:hover,
        .panel-button {
            text-decoration: none
        }

        .text-reset {
            color: inherit !important
        }

        .visible {
            visibility: visible !important
        }

        .invisible {
            visibility: hidden !important
        }

        .bg-link,
        .bg-link:focus,
        .bg-link:hover {
            color: inherit
        }

        .bg-white,
        .bg-white-base {
            background-color: #fff;
            color: #111
        }

        .bg-black,
        .bg-black-base {
            background-color: #111;
            color: #fff
        }

        .bg-black-dark {
            background-color: #000;
            color: #fff
        }

        .bg-gray,
        .bg-gray-base {
            background-color: #757575;
            color: #fff
        }

        .bg-gray-faint {
            background-color: #f5f7f8;
            color: #111
        }

        .bg-gray-light {
            background-color: #aab7c2;
            color: #111
        }

        .bg-gray-midrange {
            background-color: #444;
            color: #fff
        }

        .bg-gray-dark {
            background-color: #2b2b2b;
            color: #fff
        }

        .bg-product,
        .bg-product-base {
            background-color: #f5f7f8;
            color: #111
        }

        .bg-product-faint {
            background-color: #e8eaeb;
            color: #111
        }

        .bg-product-light {
            background-color: #d6d6d6;
            color: #111
        }

        .bg-product-midrange {
            background-color: #bfbfbf;
            color: #111
        }

        .bg-product-dark {
            background-color: #999;
            color: #111
        }

        .bg-primary,
        .bg-primary-base {
            background-color: #00a63f;
            color: #fff
        }

        .bg-primary-pastel {
            background-color: #d9f2e2;
            color: #111
        }

        .bg-primary-highlight {
            background-color: #02c54c;
            color: #111
        }

        .bg-primary-midrange {
            background-color: #00782e;
            color: #fff
        }

        .bg-primary-dark {
            background-color: #004f1e;
            color: #fff
        }

        .bg-primary-o,
        .bg-primary-o-base {
            background-color: #00a63f;
            color: #111
        }

        .bg-primary-o-pastel {
            background-color: #d9f2e2;
            color: #111
        }

        .bg-primary-o-highlight {
            background-color: #02c54c;
            color: #111
        }

        .bg-primary-o-midrange {
            background-color: #00782e;
            color: #fff
        }

        .bg-primary-o-dark {
            background-color: #004f1e;
            color: #fff
        }

        .bg-success,
        .bg-success-base {
            background-color: #00a63f;
            color: #111
        }

        .bg-success-pastel {
            background-color: #d9f2e2;
            color: #111
        }

        .bg-success-highlight {
            background-color: #02c54c;
            color: #111
        }

        .bg-success-midrange {
            background-color: #00782e;
            color: #111
        }

        .bg-success-dark {
            background-color: #004f1e;
            color: #fff
        }

        .bg-secondary,
        .bg-secondary-base {
            background-color: #1976d2;
            color: #fff
        }

        .bg-secondary-pastel {
            background-color: #ddeaf8;
            color: #111
        }

        .bg-secondary-highlight {
            background-color: #4095e8;
            color: #fff
        }

        .bg-secondary-midrange {
            background-color: #145fa9;
            color: #fff
        }

        .bg-secondary-dark {
            background-color: #104a85;
            color: #fff
        }

        .bg-secondary-o,
        .bg-secondary-o-base {
            background-color: #1976d2;
            color: #111
        }

        .bg-secondary-o-pastel {
            background-color: #ddeaf8;
            color: #111
        }

        .bg-secondary-o-highlight {
            background-color: #4095e8;
            color: #111
        }

        .bg-secondary-o-midrange {
            background-color: #145fa9;
            color: #111
        }

        .bg-secondary-o-dark {
            background-color: #104a85;
            color: #fff
        }

        .bg-nav,
        .bg-nav-base {
            background-color: #ef6c0f;
            color: #fff
        }

        .bg-nav-pastel {
            background-color: #fde9db;
            color: #111
        }

        .bg-nav-highlight {
            background-color: #f38f48;
            color: #111
        }

        .bg-nav-midrange {
            background-color: #c4580c;
            color: #fff
        }

        .bg-nav-dark {
            background-color: #9d470a;
            color: #fff
        }

        .bg-info,
        .bg-info-base {
            background-color: #9e42b5;
            color: #fff
        }

        .bg-info-pastel {
            background-color: #f0e3f4;
            color: #111
        }

        .bg-info-highlight {
            background-color: #b66bc9;
            color: #fff
        }

        .bg-info-midrange {
            background-color: #813693;
            color: #fff
        }

        .bg-info-dark {
            background-color: #672b75;
            color: #fff
        }

        .bg-warning,
        .bg-warning-base {
            background-color: #fedc45;
            color: #111
        }

        .bg-warning-pastel {
            background-color: #fffae3;
            color: #111
        }

        .bg-warning-highlight {
            background-color: #fee782;
            color: #111
        }

        .bg-warning-midrange {
            background-color: #fed317;
            color: #111
        }

        .bg-warning-dark {
            background-color: #ebc001;
            color: #111
        }

        .bg-danger,
        .bg-danger-base {
            background-color: #db1802;
            color: #fff
        }

        .bg-danger-pastel {
            background-color: #fadcd9;
            color: #111
        }

        .bg-danger-highlight {
            background-color: #fd341d;
            color: #fff
        }

        .bg-danger-midrange {
            background-color: #ae1302;
            color: #fff
        }

        .bg-danger-dark {
            background-color: #850f01;
            color: #fff
        }

        .bg-feature,
        .bg-feature-base {
            background-color: #e20087;
            color: #fff
        }

        .bg-feature-pastel {
            background-color: #fbd9ed;
            color: #111
        }

        .bg-feature-highlight {
            background-color: #ff20a5;
            color: #111
        }

        .bg-feature-midrange {
            background-color: #b4006c;
            color: #fff
        }

        .bg-feature-dark {
            background-color: #8b0053;
            color: #fff
        }

        .bg-primary-o,
        .bg-success {
            color: #111;
            background-color: #02c54c
        }

        .bg-light {
            color: #444;
            background-color: #fff
        }

        .bg-faint {
            color: #111;
            background-color: #f5f7f8
        }

        .bg-midrange {
            color: #fff;
            background-color: #444
        }

        .bg-medium {
            color: #111;
            background-color: #e8eaeb
        }

        .bg-dark {
            color: #fff;
            background-color: #2b2b2b
        }

        .flash-bg-primary {
            color: #fff;
            background-color: #00782e
        }

        .bg-pro-orange {
            color: #fff;
            background-color: #ef6c0f
        }

        .bd-a-1 {
            border: 1px solid
        }

        .bd-r-1-dashed,
        .bd-x-1-dashed {
            border-right: 1px dashed
        }

        .bd-l-1-dashed,
        .bd-x-1-dashed {
            border-left: 1px dashed
        }

        .bd-t-1-dashed,
        .bd-y-1-dashed {
            border-top: 1px dashed
        }

        .bd-b-1-dashed,
        .bd-y-1-dashed {
            border-bottom: 1px dashed
        }

        .bd-a-1-dashed {
            border: 1px dashed
        }

        .bd-r-2,
        .bd-x-2 {
            border-right: 2px solid
        }

        .bd-l-2,
        .bd-x-2 {
            border-left: 2px solid
        }

        .bd-t-2,
        .bd-y-2 {
            border-top: 2px solid
        }

        .bd-b-2,
        .bd-y-2 {
            border-bottom: 2px solid
        }

        .bd-a-2 {
            border: 2px solid
        }

        .bd-r-2-dashed,
        .bd-x-2-dashed {
            border-right: 2px dashed
        }

        .bd-l-2-dashed,
        .bd-x-2-dashed {
            border-left: 2px dashed
        }

        .bd-t-2-dashed,
        .bd-y-2-dashed {
            border-top: 2px dashed
        }

        .bd-b-2-dashed,
        .bd-y-2-dashed {
            border-bottom: 2px dashed
        }

        .bd-a-2-dashed {
            border: 2px dashed
        }

        .bd-r-3,
        .bd-x-3 {
            border-right: 3px solid
        }

        .bd-l-3,
        .bd-x-3 {
            border-left: 3px solid
        }

        .bd-t-3,
        .bd-y-3 {
            border-top: 3px solid
        }

        .bd-b-3,
        .bd-y-3 {
            border-bottom: 3px solid
        }

        .bd-a-3 {
            border: 3px solid
        }

        .bd-r-3-dashed,
        .bd-x-3-dashed {
            border-right: 3px dashed
        }

        .bd-l-3-dashed,
        .bd-x-3-dashed {
            border-left: 3px dashed
        }

        .bd-t-3-dashed,
        .bd-y-3-dashed {
            border-top: 3px dashed
        }

        .bd-b-3-dashed,
        .bd-y-3-dashed {
            border-bottom: 3px dashed
        }

        .bd-a-3-dashed {
            border: 3px dashed
        }

        .bd-r-4,
        .bd-x-4 {
            border-right: 4px solid
        }

        .bd-l-4,
        .bd-x-4 {
            border-left: 4px solid
        }

        .bd-t-4,
        .bd-y-4 {
            border-top: 4px solid
        }

        .bd-b-4,
        .bd-y-4 {
            border-bottom: 4px solid
        }

        .bd-a-4 {
            border: 4px solid
        }

        .bd-r-4-dashed,
        .bd-x-4-dashed {
            border-right: 4px dashed
        }

        .bd-l-4-dashed,
        .bd-x-4-dashed {
            border-left: 4px dashed
        }

        .bd-t-4-dashed,
        .bd-y-4-dashed {
            border-top: 4px dashed
        }

        .bd-b-4-dashed,
        .bd-y-4-dashed {
            border-bottom: 4px dashed
        }

        .bd-a-4-dashed {
            border: 4px dashed
        }

        .bd-gray {
            border-color: #757575
        }

        .bd-gray-faint {
            border-color: #f5f7f8
        }

        .bd-gray-light {
            border-color: #aab7c2
        }

        .bd-gray-midrange {
            border-color: #444
        }

        .bd-gray-dark {
            border-color: #2b2b2b
        }

        .bd-black {
            border-color: #111
        }

        .bd-black-dark {
            border-color: #000
        }

        .bd-white {
            border-color: #fff
        }

        .bd-primary {
            border-color: #00a63f
        }

        .bd-primary-pastel {
            border-color: #d9f2e2
        }

        .bd-primary-highlight {
            border-color: #02c54c
        }

        .bd-primary-midrange {
            border-color: #00782e
        }

        .bd-primary-dark {
            border-color: #004f1e
        }

        .bd-secondary {
            border-color: #1976d2
        }

        .bd-secondary-pastel {
            border-color: #ddeaf8
        }

        .bd-secondary-highlight {
            border-color: #4095e8
        }

        .bd-secondary-midrange {
            border-color: #145fa9
        }

        .bd-secondary-dark {
            border-color: #104a85
        }

        .bd-info {
            border-color: #9e42b5
        }

        .bd-info-pastel {
            border-color: #f0e3f4
        }

        .bd-info-highlight {
            border-color: #b66bc9
        }

        .bd-info-midrange {
            border-color: #813693
        }

        .bd-info-dark {
            border-color: #672b75
        }

        .bd-warning {
            border-color: #fedc45
        }

        .bd-warning-pastel {
            border-color: #fffae3
        }

        .bd-warning-highlight {
            border-color: #fee782
        }

        .bd-warning-midrange {
            border-color: #fed317
        }

        .bd-warning-dark {
            border-color: #ebc001
        }

        .bd-nav {
            border-color: #ef6c0f
        }

        .bd-nav-pastel {
            border-color: #fde9db
        }

        .bd-nav-highlight {
            border-color: #f38f48
        }

        .bd-nav-midrange {
            border-color: #c4580c
        }

        .bd-nav-dark {
            border-color: #9d470a
        }

        .bd-danger {
            border-color: #db1802
        }

        .bd-danger-pastel {
            border-color: #fadcd9
        }

        .bd-danger-highlight {
            border-color: #fd341d
        }

        .bd-danger-midrange {
            border-color: #ae1302
        }

        .bd-danger-dark {
            border-color: #850f01
        }

        .bd-feature {
            border-color: #e20087
        }

        .bd-feature-pastel {
            border-color: #fbd9ed
        }

        .bd-feature-highlight {
            border-color: #ff20a5
        }

        .bd-feature-midrange {
            border-color: #b4006c
        }

        .bd-feature-dark {
            border-color: #8b0053
        }

        .bd-product {
            border-color: #f5f7f8
        }

        .bd-product-faint {
            border-color: #e8eaeb
        }

        .bd-product-light {
            border-color: #d6d6d6
        }

        .bd-product-midrange {
            border-color: #bfbfbf
        }

        .bd-product-dark {
            border-color: #999
        }

        .bd-success {
            border-color: #00a63f
        }

        .bd-success-pastel {
            border-color: #d9f2e2
        }

        .bd-success-highlight {
            border-color: #02c54c
        }

        .bd-success-midrange {
            border-color: #00782e
        }

        .bd-success-dark {
            border-color: #004f1e
        }

        .bd-transparent {
            border-color: transparent !important
        }

        .shadow-1 {
            box-shadow: 0 1px 6px 0 rgba(117, 117, 117, .25)
        }

        .shadow-2 {
            box-shadow: 0 1px 8px 0 rgba(117, 117, 117, .3)
        }

        .shadow-3 {
            box-shadow: 0 4px 12px 0 rgba(117, 117, 117, .4)
        }

        .shadow-4 {
            box-shadow: 0 6px 20px 0 rgba(117, 117, 117, .5)
        }

        .secondary-link {
            font-size: .88889rem
        }

        .strong-link {
            font-weight: 700
        }

        .ms-3 {
            font-size: .70233rem
        }

        .ms-2 {
            font-size: .79012rem
        }

        .ms-1 {
            font-size: .88889rem
        }

        .ms0 {
            font-size: 1rem
        }

        .ms1 {
            font-size: 1.125rem
        }

        .ms2 {
            font-size: 1.26562rem
        }

        .ms3 {
            font-size: 1.42383rem
        }

        .ms4 {
            font-size: 1.60181rem
        }

        .ms5 {
            font-size: 1.80203rem
        }

        .ms6 {
            font-size: 2.02729rem
        }

        .ms7 {
            font-size: 2.2807rem
        }

        .ms8 {
            font-size: 2.56578rem
        }

        .ms9 {
            font-size: 2.88651rem
        }

        .ms10 {
            font-size: 3.24732rem
        }

        .text-white {
            color: #fff !important
        }

        a.text-white:focus,
        a.text-white:hover {
            color: #e6e6e6 !important
        }

        .text-black {
            color: #111 !important
        }

        a.text-black:focus,
        a.text-black:hover {
            color: #000 !important
        }

        .ux-accordion {
            border-top: 1px solid #e8eaeb;
            display: flex;
            align-items: stretch;
            justify-content: flex-start;
            flex-direction: column
        }

        .ux-accordion .panel {
            border-bottom: 1px solid #e8eaeb;
            align-items: stretch;
            flex-direction: column
        }

        .ux-accordion .panel-button {
            color: #2b2b2b;
            text-decoration: none;
            display: block;
            padding: 30px 50px 30px 0;
            cursor: pointer;
            position: relative;
            outline: 0
        }

        .ux-accordion .panel-button:after {
            content: '\E443';
            font-family: uxfont;
            font-size: 1.125rem;
            position: absolute;
            right: 2px;
            top: 32px;
            transform: rotate(180deg);
            transition: all .3s ease
        }

        .alert::after,
        .ux-btn-set::after {
            content: "";
            clear: both
        }

        .ux-accordion .panel-button.collapsed:after,
        .ux-accordion .panel-button[aria-expanded=false] {
            transform: rotate(0)
        }

        .ux-accordion .panel-button.indicator-shown {
            padding-left: 36px
        }

        .ux-accordion .panel-button h3 {
            margin-bottom: 0;
            line-height: 1.2
        }

        .ux-accordion .panel-button .indicator {
            width: 15px;
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            display: flex;
            flex-grow: 0;
            align-items: center;
            justify-content: center
        }

        .ux-accordion .panel-collapse {
            margin: 0;
            background-color: #f5f7f8;
            opacity: 1;
            overflow-y: hidden;
            transition: height .35s ease;
            padding: 1px 0
        }

        .ux-accordion .panel-collapse.collapse.in {
            overflow-y: visible
        }

        .ux-accordion .panel-content {
            margin: 30px
        }

        .ux-accordion .panel-content>:last-child {
            margin-bottom: 0
        }

        .ux-accordion p {
            margin: 1rem
        }

        .alert {
            padding: 20px;
            margin-bottom: 1rem;
            border: 2px solid transparent;
            border-radius: 6px
        }

        .alert-heading {
            color: inherit
        }

        .alert-link {
            font-weight: 400
        }

        .alert-dismissible .close {
            position: absolute;
            color: inherit
        }

        .alert-primary,
        .alert-primary .alert-link,
        .alert-primary .close:focus,
        .alert-primary .close:hover {
            color: #005621
        }

        .alert-primary {
            background-color: #ccedd9;
            border-color: #b8e6c9
        }

        .alert-primary hr {
            border-top-color: #a5dfbb
        }

        .alert-primary .alert-addon {
            border-color: #b8e6c9
        }

        .alert-primary .alert-toggle {
            background: #ccedd9;
            color: #005621
        }

        .alert-secondary,
        .alert-secondary .alert-link,
        .alert-secondary .close:focus,
        .alert-secondary .close:hover {
            color: #0d3d6d
        }

        .alert-secondary {
            background-color: #d1e4f6;
            border-color: #bfd9f2
        }

        .alert-secondary hr {
            border-top-color: #ace
        }

        .alert-secondary .alert-addon {
            border-color: #bfd9f2
        }

        .alert-secondary .alert-toggle {
            background: #d1e4f6;
            color: #0d3d6d
        }

        .alert-light,
        .alert-light .alert-link,
        .alert-light .close:focus,
        .alert-light .close:hover {
            color: #818182
        }

        .alert-light {
            background-color: #fefefe;
            border-color: #fdfdfe
        }

        .alert-light hr {
            border-top-color: #ececf6
        }

        .alert-light .alert-addon {
            border-color: #fdfdfe
        }

        .alert-light .alert-toggle {
            background: #fefefe;
            color: #818182
        }

        .alert-dark,
        .alert-dark .alert-link,
        .alert-dark .close:focus,
        .alert-dark .close:hover {
            color: #1b1e21
        }

        .alert-dark {
            background-color: #d6d8d9;
            border-color: #c6c8ca
        }

        .alert-dark hr {
            border-top-color: #b9bbbe
        }

        .alert-dark .alert-addon {
            border-color: #c6c8ca
        }

        .alert-dark .alert-toggle {
            background: #d6d8d9;
            color: #1b1e21
        }

        .alert-primary-o,
        .alert-primary-o .alert-link,
        .alert-primary-o .close:focus,
        .alert-primary-o .close:hover {
            color: #005621
        }

        .alert-primary-o {
            background-color: #ccedd9;
            border-color: #b8e6c9
        }

        .alert-primary-o hr {
            border-top-color: #a5dfbb
        }

        .alert-primary-o .alert-addon {
            border-color: #b8e6c9
        }

        .alert-primary-o .alert-toggle {
            background: #ccedd9;
            color: #005621
        }

        .alert-purchase,
        .alert-secondary-o {
            background-color: #d1e4f6
        }

        .alert-purchase,
        .alert-purchase .alert-link,
        .alert-purchase .alert-toggle,
        .alert-purchase .close:focus,
        .alert-purchase .close:hover,
        .alert-secondary-o,
        .alert-secondary-o .alert-link,
        .alert-secondary-o .close:focus,
        .alert-secondary-o .close:hover {
            color: #0d3d6d
        }

        .alert-secondary-o {
            border-color: #bfd9f2
        }

        .alert-secondary-o hr {
            border-top-color: #ace
        }

        .alert-purchase,
        .alert-secondary-o .alert-addon {
            border-color: #bfd9f2
        }

        .alert-secondary-o .alert-toggle {
            background: #d1e4f6;
            color: #0d3d6d
        }

        .alert-purchase hr {
            border-top-color: #ace
        }

        .alert-purchase .alert-addon {
            border-color: #bfd9f2
        }

        .alert-purchase .alert-toggle {
            background: #d1e4f6
        }

        .alert-default,
        .alert-default .alert-link,
        .alert-default .close:focus,
        .alert-default .close:hover {
            color: #232323
        }

        .alert-default {
            background-color: #dadada;
            border-color: #cbcbcb
        }

        .alert-default hr {
            border-top-color: #bebebe
        }

        .alert-default .alert-addon {
            border-color: #cbcbcb
        }

        .alert-default .alert-toggle {
            background: #dadada;
            color: #232323
        }

        .alert-feature,
        .alert-feature .alert-link,
        .alert-feature .close:focus,
        .alert-feature .close:hover {
            color: #760046
        }

        .alert-feature {
            background-color: #f9cce7;
            border-color: #f7b8dd
        }

        .alert-feature hr {
            border-top-color: #f4a1d2
        }

        .alert-feature .alert-addon {
            border-color: #f7b8dd
        }

        .alert-feature .alert-toggle {
            background: #f9cce7;
            color: #760046
        }

        .alert-muted,
        .alert-muted .alert-link,
        .alert-muted .close:focus,
        .alert-muted .close:hover {
            color: #3d3d3d
        }

        .alert-muted {
            background-color: #e3e3e3;
            border-color: #d8d8d8
        }

        .alert-muted hr {
            border-top-color: #cbcbcb
        }

        .alert-muted .alert-addon {
            border-color: #d8d8d8
        }

        .alert-muted .alert-toggle {
            background: #e3e3e3;
            color: #3d3d3d
        }

        .alert {
            position: relative;
            padding-left: 50px;
            border-width: 2px
        }

        .alert::after {
            display: table
        }

        .alert-dismissible .close {
            top: 0;
            right: 0;
            padding: 0
        }

        .alert-icon {
            position: absolute;
            top: 22px;
            left: 15px;
            font-size: 20px;
            color: inherit
        }

        .alert-offer .alert-link,
        .alert-offer .close:focus,
        .alert-offer .close:hover {
            color: #111
        }

        .alert-addon {
            padding-right: 20px;
            margin-right: -20px
        }

        .alert-offer {
            background-color: #fde9db;
            border-color: #ef6c0f;
            color: #111
        }

        .alert-offer hr {
            border-top-color: #d7610d
        }

        .alert-offer .alert-addon {
            border-color: #ef6c0f
        }

        .alert-offer .alert-toggle {
            background: #ef6c0f;
            color: #fff
        }

        .alert-info,
        .alert-info .alert-link,
        .alert-info .close:focus,
        .alert-info .close:hover,
        .alert-success,
        .alert-success .alert-link,
        .alert-success .close:focus,
        .alert-success .close:hover {
            color: #111
        }

        .alert-success {
            background-color: #d9f2e2;
            border-color: #00a63f
        }

        .alert-success hr {
            border-top-color: #008d35
        }

        .alert-success .alert-addon {
            border-color: #00a63f
        }

        .alert-success .alert-toggle {
            background: #00a63f;
            color: #111
        }

        .alert-info {
            background-color: #f0e3f4;
            border-color: #9e42b5
        }

        .alert-info hr {
            border-top-color: #8e3ba2
        }

        .alert-info .alert-addon {
            border-color: #9e42b5
        }

        .alert-info .alert-toggle {
            background: #9e42b5;
            color: #fff
        }

        .alert-danger,
        .alert-danger .alert-link,
        .alert-danger .close:focus,
        .alert-danger .close:hover,
        .alert-warning,
        .alert-warning .alert-link,
        .alert-warning .close:focus,
        .alert-warning .close:hover {
            color: #111
        }

        .alert-warning {
            background-color: #fffae3;
            border-color: #fedc45
        }

        .alert-warning hr {
            border-top-color: #fed72c
        }

        .alert-warning .alert-addon {
            border-color: #fedc45
        }

        .alert-warning .alert-toggle {
            background: #fedc45;
            color: #111
        }

        .alert-danger {
            background-color: #fadcd9;
            border-color: #db1802
        }

        .alert-danger hr {
            border-top-color: #c21502
        }

        .alert-danger .alert-addon {
            border-color: #db1802
        }

        .alert-danger .alert-toggle {
            background: #db1802;
            color: #fff
        }

        .alert-note .alert-link,
        .alert-note .close:focus,
        .alert-note .close:hover {
            color: #111
        }

        .alert-note {
            background-color: #ddeaf8;
            border-color: #1976d2;
            color: #111
        }

        .alert-note hr {
            border-top-color: #1669bb
        }

        .alert-note .alert-addon {
            border-color: #1976d2
        }

        .alert-note .alert-toggle {
            background: #1976d2;
            color: #fff
        }

        .alert-c3,
        .alert-c3 .alert-link,
        .alert-c3 .close:focus,
        .alert-c3 .close:hover {
            color: #111
        }

        .alert-c3 {
            background-color: #fbd9ed;
            border-color: #e20087
        }

        .alert-c3 hr {
            border-top-color: #c90078
        }

        .alert-c3 .alert-addon {
            border-color: #e20087
        }

        .alert-c3 .alert-toggle {
            background: #e20087;
            color: #fff
        }

        code,
        pre {
            color: #444
        }

        .alert-toggle {
            margin: 20px 0 -22px -52px;
            text-align: center;
            cursor: pointer;
            height: 18px;
            border-radius: 0 0 6px 6px;
            border: 0;
            padding: 0;
            width: calc(100% + 74px);
            display: block
        }

        .alert-toggle:focus {
            outline: 0
        }

        .alert-toggle .uxicon {
            vertical-align: top;
            font-size: .68rem;
            margin-top: 5px
        }

        .alert-dismissible .alert-addon,
        .alert-dismissible .alert-toggle {
            margin-right: -40px
        }

        .ux-btn-set {
            display: flex;
            justify-content: flex-start;
            flex-direction: column;
            align-items: center;
            position: relative;
            margin-right: -7px;
            margin-left: -7px;
            font-size: 0
        }

        code,
        kbd {
            padding: .2rem .4rem;
            font-size: 90%
        }

        .ux-btn-set::after {
            display: table
        }

        @media (min-width:520px) {
            .ux-btn-set {
                flex-direction: row
            }
        }

        .form-group+.ux-btn-set {
            margin-top: 40px
        }

        .modal-footer .ux-btn-set .ux-btn-set-item+.ux-btn-set-item,
        .ux-btn-set .ux-btn-set-item {
            display: flex;
            justify-content: center;
            max-width: none;
            margin-right: 7px;
            margin-bottom: 14px;
            margin-left: 7px
        }

        @media (max-width:519px) {
            .ux-btn-set .ux-btn-set-item {
                width: calc(100% - 14px)
            }
        }

        .ux-btn-set .dropdown-split {
            margin-right: 0 !important
        }

        .ux-btn-set .dropdown-toggle {
            margin-left: 0 !important
        }

        .ux-btn-set .dropdown>.btn,
        .ux-btn-set .dropdown>.btn-group {
            width: 100%;
            max-width: 100%
        }

        .ux-btn-set .dropdown>.btn .dropdown-split,
        .ux-btn-set .dropdown>.btn-group .dropdown-split {
            min-width: 91px;
            width: calc(100% - 29px);
            max-width: none
        }

        .ux-btn-set.ux-btn-block .ux-btn-set-item {
            width: calc(100% - 14px)
        }

        .ux-btn-set.ux-btn-split .ux-btn-set-item {
            display: flex;
            flex-grow: 1;
            justify-content: center;
            align-items: center
        }

        code,
        kbd,
        pre,
        samp {
            font-family: Courier, "Courier New", monospace
        }

        .panel-button:after,
        .ux-criteria-box-checked:before,
        .ux-growl-msg-close {
            font-family: uxfont
        }

        code {
            background-color: #f5f7f8;
            border-radius: 6px
        }

        kbd {
            color: #fff;
            background-color: #212529;
            border-radius: 4px;
            box-shadow: inset 0 -.1rem 0 rgba(0, 0, 0, .25)
        }

        kbd kbd {
            padding: 0;
            font-size: 100%;
            font-weight: 700;
            box-shadow: none
        }

        pre code {
            padding: 0;
            font-size: inherit;
            color: inherit;
            background-color: transparent;
            border-radius: 0
        }

        .panel-collapse,
        pre {
            background-color: #f5f7f8
        }

        .pre-scrollable {
            max-height: 340px;
            overflow-y: scroll
        }

        pre {
            display: block;
            margin-top: 0;
            margin-bottom: 1rem;
            padding: .59375rem;
            font-size: .9rem
        }

        .panel {
            border-bottom: 1px solid #e8eaeb;
            display: flex;
            align-items: stretch;
            flex-direction: column
        }

        .panel-button {
            color: #2b2b2b;
            display: block;
            padding: 30px 50px 30px 0;
            cursor: pointer;
            position: relative;
            outline: 0
        }

        .panel-button:after {
            content: '\E443';
            font-size: 1.125rem;
            position: absolute;
            right: 2px;
            top: 32px;
            transform: rotate(180deg);
            transition: all .3s ease
        }

        .panel-button.collapsed:after,
        .panel-button[aria-expanded=false] {
            transform: rotate(0)
        }

        .panel-button.indicator-shown {
            padding-left: 36px
        }

        .panel-button h3 {
            margin-bottom: 0;
            line-height: 1.2
        }

        .panel-button .indicator {
            width: 15px;
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            display: flex;
            flex-grow: 0;
            align-items: center;
            justify-content: center
        }

        .ux-criteria-connect>.form-group,
        .ux-criteria-content {
            width: 100%
        }

        .panel-collapse {
            margin: 0;
            opacity: 1;
            max-height: 1000px;
            overflow-y: hidden;
            transition: height .35s ease
        }

        .panel-collapse.collapse.in {
            overflow-y: auto
        }

        .panel-content {
            margin: 30px
        }

        .panel-content>:last-child {
            margin-bottom: 0
        }

        .ux-criteria {
            border-radius: 0 0 6px 6px;
            display: flex;
            font-size: .875rem;
            padding: 4px 12px 12px;
            color: #2b2b2b;
            background: #fff;
            margin-bottom: 25px;
            border-left: 1px solid #111;
            border-right: 1px solid #111;
            border-bottom: 1px solid #111;
            border-top: 1px solid #aab7c2;
            transform-origin: 0 0;
            transform: scaleY(0)
        }

        .ux-criteria.ux-criteria-relative {
            transform: scaleY(1)
        }

        .ux-criteria.standalone {
            border-radius: 6px;
            transform: scaleY(1);
            opacity: 1;
            height: auto;
            border-top: 1px solid #111;
            transition: all .3s ease-out
        }

        .ux-criteria.standalone.valid {
            transition: all .3s ease-out .1s;
            transform: scaleY(0);
            opacity: 0;
            height: 0
        }

        .fade-in {
            transition: opacity .2s ease-out .3s;
            opacity: 1
        }

        .fade-out {
            opacity: 0;
            transition: opacity .2s ease-out
        }

        .ux-criteria-enter {
            transform: scaleY(1);
            transition: transform .3s ease-out
        }

        .ux-criteria-enter-done {
            transform: scaleY(1);
            height: auto
        }

        .ux-criteria-exit {
            transform: scaleY(0);
            transition: transform .3s ease-out .1s
        }

        .ux-criteria-exit-done {
            transform: scaleY(0);
            opacity: 0;
            height: 0
        }

        .ux-criteria-connect {
            position: relative
        }

        .ux-criteria-connect>.form-group+.ux-criteria {
            margin-top: -26px;
            width: 100%;
            position: absolute;
            z-index: 1000;
            min-width: 200px
        }

        .ux-criteria-connect>.form-group+.ux-criteria.ux-criteria-relative {
            position: relative
        }

        .ux-criteria-connect>.form-group .open {
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0
        }

        .ux-criteria-connect .form-control {
            transition: border-radius .1s ease-in, border-bottom-color .1s ease-in;
            transition-delay: .35s
        }

        .ux-criteria-connect .form-control.open {
            transition-delay: 0s
        }

        .ux-criteria-connect .form-control .form-error {
            display: none
        }

        .ux-criteria-header {
            margin: 10px 0 15px;
            padding-bottom: 8px;
            border-bottom: 1px solid #e8eaeb
        }

        .ux-criteria-rule {
            margin-top: .4375rem;
            display: flex;
            opacity: 1;
            overflow: hidden;
            max-height: 100px
        }

        .ux-criteria-rule>.uxicon {
            font-size: 1rem;
            color: #757575;
            margin-top: 3px;
            display: flex;
            width: 20px;
            height: 19px;
            padding-left: 3px
        }

        .ux-criteria-rule>.uxicon-check-outline {
            color: #00a63f
        }

        .ux-criteria:not(.ux-criteria-relative) .ux-criteria-rule {
            transition: max-height .3s ease-out, opacity .3s ease-out, margin-top .3s ease-out
        }

        .ux-criteria:not(.ux-criteria-relative) .ux-criteria-rule.ux-criteria-rule-checked {
            transition: max-height .2s ease-out .6s, opacity .2s ease-out .6s, margin-top .2s ease-out .6s;
            margin-top: 0;
            max-height: 0;
            opacity: 0
        }

        .ux-criteria-box,
        .ux-criteria-box-checked {
            border-radius: 6px;
            width: 20px;
            height: 20px;
            display: flex;
            flex-shrink: 0
        }

        .ux-criteria-box {
            background-color: #f5f7f8;
            border: 1px solid #aab7c2
        }

        .ux-criteria-box-checked {
            border: 1px solid #00a63f;
            background-color: #00a63f;
            position: relative
        }

        .ux-criteria-box-checked:before {
            content: '\E207';
            font-size: 14px;
            color: #fff;
            line-height: .8;
            position: absolute;
            top: 4.5px;
            left: 2px
        }

        .ux-criteria-rule-text {
            display: flex;
            flex-grow: 1;
            padding-left: 12px
        }

        .form-control,
        .form-control-file,
        .form-control-range {
            display: block
        }

        .disabled-checkmark {
            color: #d6d6d6 !important
        }

        .ux-growl {
            position: fixed;
            top: 40px;
            right: 40px;
            width: 280px;
            color: #fff;
            z-index: 100000
        }

        .ux-growl-clear,
        .ux-growl-msg-content {
            background: rgba(0, 0, 0, .85)
        }

        .form-control,
        .has-danger .form-control-danger,
        .has-warning .form-control-warning {
            background-image: none
        }

        .ux-growl-clear {
            position: absolute;
            width: 100%;
            cursor: pointer;
            font-size: .625rem;
            font-weight: 700;
            line-height: 17px;
            text-align: center;
            opacity: .01;
            transition: opacity .3s ease-in;
            top: -100px
        }

        .custom-control.disabled,
        .form-control:disabled:hover {
            cursor: not-allowed
        }

        .ux-growl-clear-show {
            position: fixed;
            top: 40px;
            right: 40px;
            width: 280px;
            color: #fff;
            opacity: 1
        }

        .ux-growl-messages {
            margin-top: 20px
        }

        .ux-growl-msg-content {
            margin-top: 5px;
            padding: 15px;
            position: relative
        }

        .ux-growl-msg-content.ux-growl-msg-text {
            font-size: 16px
        }

        .ux-growl-msg-content>.uxicon {
            font-size: 1.375rem;
            margin-top: 3px;
            position: absolute
        }

        .ux-growl-msg-content>.uxicon+.ux-growl-msg-title {
            margin-left: 30px
        }

        .ux-growl-msg-content>.uxicon.uxicon-check-outline {
            color: #00a63f
        }

        .ux-growl-msg-content>.uxicon.uxicon-information {
            color: #fedc45
        }

        .ux-growl-msg-content>.uxicon.uxicon-alert {
            color: #db1802
        }

        .ux-growl-msg-close {
            font-weight: 400;
            position: absolute;
            color: inherit;
            top: 10px;
            right: 10px;
            z-index: 1;
            font-size: .875rem
        }

        .custom-control,
        .form-check-inline,
        .form-check-label,
        .req,
        .ux-growl-msg-title {
            font-family: gdsherpa, Helvetica, Arial, sans-serif
        }

        .ux-growl-msg-close:hover {
            color: inherit;
            font-weight: 700
        }

        .ux-growl-msg-close:before {
            content: "\E208"
        }

        .ux-growl-msg-title {
            font-weight: 700;
            font-size: 1.375rem;
            line-height: 1.1;
            margin-bottom: 15px;
            margin-right: 24px
        }

        .ux-growl-item,
        .ux-growl-msg {
            overflow: hidden
        }

        .ux-growl-item-enter {
            opacity: .01;
            margin-top: 30px
        }

        .ux-growl-item-enter.ux-growl-item-enter-active {
            opacity: 1;
            margin-top: 0;
            transition: opacity .5s ease-in, margin-top .5s ease-out
        }

        .ux-growl-item-exit {
            opacity: 1;
            max-height: 200px
        }

        .ux-growl-item-exit.ux-growl-item-exit-active {
            opacity: .01;
            max-height: 0;
            transition: opacity .5s ease-in, max-height .5s ease-out
        }

        .form-control {
            width: 100%;
            padding: 6px 12px;
            font-size: 1rem;
            line-height: 1.61803;
            color: #2b2b2b;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #aab7c2;
            border-radius: 6px;
            box-shadow: none
        }

        .col-form-label,
        .col-form-label-lg {
            padding-top: calc(6px + 1px);
            padding-bottom: calc(6px + 1px)
        }

        .custom-file-input.is-valid:focus,
        .custom-select.is-valid:focus,
        .form-control.is-valid:focus,
        .was-validated .custom-file-input:valid:focus,
        .was-validated .custom-select:valid:focus,
        .was-validated .form-control:valid:focus {
            box-shadow: 0 0 0 .2rem rgba(0, 166, 63, .25)
        }

        .form-control::-ms-expand {
            background-color: transparent;
            border: 0
        }

        .form-control:focus {
            border-color: #000;
            border-width: 1px;
            outline: 0
        }

        .form-control::-webkit-input-placeholder {
            color: #aab7c2;
            opacity: 1
        }

        .form-control::placeholder {
            color: #aab7c2;
            opacity: 1
        }

        .form-control:disabled,
        .form-control[readonly] {
            background-color: #f5f7f8;
            opacity: 1
        }

        select.form-control:not([size]):not([multiple]) {
            height: 40px
        }

        select.form-control:focus::-ms-value {
            color: #2b2b2b;
            background-color: #fff
        }

        .col-form-label {
            margin-bottom: 0;
            line-height: 1.61803
        }

        .col-form-label-lg {
            font-size: 1.375rem;
            line-height: 1.33
        }

        .col-form-label-sm {
            padding-top: calc(4px + 1px);
            padding-bottom: calc(4px + 1px);
            font-size: .875rem;
            line-height: 1.6
        }

        .col-form-legend,
        .form-control-plaintext {
            padding-top: 6px;
            padding-bottom: 6px;
            margin-bottom: 0
        }

        .col-form-legend {
            font-size: 1rem
        }

        .form-control-plaintext {
            line-height: 1.61803;
            background-color: transparent;
            border: solid transparent;
            border-width: 1px 0
        }

        .custom-file-input.is-valid~.custom-file-control,
        .custom-select.is-valid,
        .form-control.is-valid,
        .was-validated .custom-file-input:valid~.custom-file-control,
        .was-validated .custom-select:valid,
        .was-validated .form-control:valid {
            border-color: #00a63f
        }

        .form-control-plaintext.form-control-lg,
        .form-control-plaintext.form-control-sm,
        .input-group-lg>.form-control-plaintext.form-control,
        .input-group-lg>.form-control-plaintext.input-group-addon,
        .input-group-lg>.input-group-btn>.form-control-plaintext.btn,
        .input-group-sm>.form-control-plaintext.form-control,
        .input-group-sm>.form-control-plaintext.input-group-addon,
        .input-group-sm>.input-group-btn>.form-control-plaintext.btn {
            padding-right: 0;
            padding-left: 0
        }

        .form-control-sm,
        .input-group-sm>.form-control,
        .input-group-sm>.input-group-addon,
        .input-group-sm>.input-group-btn>.btn {
            padding: 4px 12px;
            font-size: .875rem;
            line-height: 1.6;
            border-radius: 4px
        }

        .input-group-sm>.input-group-btn>select.btn:not([size]):not([multiple]),
        .input-group-sm>select.form-control:not([size]):not([multiple]),
        .input-group-sm>select.input-group-addon:not([size]):not([multiple]),
        select.form-control-sm:not([size]):not([multiple]) {
            height: 32px
        }

        .form-control-lg,
        .input-group-lg>.form-control,
        .input-group-lg>.input-group-addon,
        .input-group-lg>.input-group-btn>.btn {
            padding: 6px 12px;
            font-size: 1.375rem;
            line-height: 1.33;
            border-radius: 8px
        }

        .input-group-lg>.input-group-btn>select.btn:not([size]):not([multiple]),
        .input-group-lg>select.form-control:not([size]):not([multiple]),
        .input-group-lg>select.input-group-addon:not([size]):not([multiple]),
        select.form-control-lg:not([size]):not([multiple]) {
            height: 50px
        }

        .form-group {
            margin-bottom: 25px
        }

        .form-row {
            display: flex;
            flex-wrap: wrap;
            margin-right: -5px;
            margin-left: -5px
        }

        .form-row>.col,
        .form-row>[class*=col-] {
            padding-right: 5px;
            padding-left: 5px
        }

        .invalid-tooltip,
        .valid-tooltip {
            top: 100%;
            z-index: 5;
            width: 250px;
            padding: .5rem;
            line-height: 1;
            border-radius: .2rem
        }

        .form-check {
            position: relative;
            margin-bottom: .5rem
        }

        .form-check-input,
        .invalid-tooltip,
        .valid-tooltip {
            position: absolute
        }

        .form-check.disabled .form-check-label {
            color: #757575
        }

        .form-check-label {
            margin-bottom: 0
        }

        .form-check-inline {
            display: inline-block
        }

        .valid-feedback,
        .valid-tooltip {
            display: none;
            font-size: .875rem
        }

        .form-check-inline .form-check-label {
            vertical-align: middle
        }

        .valid-feedback {
            margin-top: .25rem;
            color: #00a63f
        }

        .valid-tooltip {
            margin-top: .1rem;
            color: #fff;
            background-color: rgba(0, 166, 63, .8)
        }

        .custom-control-input.is-valid~.custom-control-description,
        .form-check-input.is-valid+.form-check-label,
        .was-validated .custom-control-input:valid~.custom-control-description,
        .was-validated .form-check-input:valid+.form-check-label {
            color: #00a63f
        }

        .custom-select.is-valid~.valid-feedback,
        .custom-select.is-valid~.valid-tooltip,
        .form-control.is-valid~.valid-feedback,
        .form-control.is-valid~.valid-tooltip,
        .was-validated .custom-select:valid~.valid-feedback,
        .was-validated .custom-select:valid~.valid-tooltip,
        .was-validated .form-control:valid~.valid-feedback,
        .was-validated .form-control:valid~.valid-tooltip {
            display: block
        }

        .custom-control-input.is-valid~.custom-control-indicator,
        .was-validated .custom-control-input:valid~.custom-control-indicator {
            background-color: rgba(0, 166, 63, .25)
        }

        .custom-file-input.is-valid~.custom-file-control::before,
        .was-validated .custom-file-input:valid~.custom-file-control::before {
            border-color: inherit
        }

        .custom-file-input.is-invalid~.custom-file-control,
        .custom-select.is-invalid,
        .form-control.is-invalid,
        .was-validated .custom-file-input:invalid~.custom-file-control,
        .was-validated .custom-select:invalid,
        .was-validated .form-control:invalid {
            border-color: #db1802
        }

        .custom-file-input.is-invalid:focus,
        .custom-select.is-invalid:focus,
        .form-control.is-invalid:focus,
        .was-validated .custom-file-input:invalid:focus,
        .was-validated .custom-select:invalid:focus,
        .was-validated .form-control:invalid:focus {
            box-shadow: 0 0 0 .2rem rgba(219, 24, 2, .25)
        }

        .invalid-feedback {
            display: none;
            margin-top: .25rem;
            font-size: .875rem;
            color: #db1802
        }

        .invalid-tooltip {
            display: none;
            margin-top: .1rem;
            font-size: .875rem;
            color: #fff;
            background-color: rgba(219, 24, 2, .8)
        }

        .custom-control-input.is-invalid~.custom-control-description,
        .form-check-input.is-invalid+.form-check-label,
        .was-validated .custom-control-input:invalid~.custom-control-description,
        .was-validated .form-check-input:invalid+.form-check-label {
            color: #db1802
        }

        .custom-select.is-invalid~.invalid-feedback,
        .custom-select.is-invalid~.invalid-tooltip,
        .form-control.is-invalid~.invalid-feedback,
        .form-control.is-invalid~.invalid-tooltip,
        .was-validated .custom-select:invalid~.invalid-feedback,
        .was-validated .custom-select:invalid~.invalid-tooltip,
        .was-validated .form-control:invalid~.invalid-feedback,
        .was-validated .form-control:invalid~.invalid-tooltip {
            display: block
        }

        .custom-control-input.is-invalid~.custom-control-indicator,
        .was-validated .custom-control-input:invalid~.custom-control-indicator {
            background-color: rgba(219, 24, 2, .25)
        }

        .custom-file-input.is-invalid~.custom-file-control::before,
        .was-validated .custom-file-input:invalid~.custom-file-control::before {
            border-color: inherit
        }

        .form-inline {
            display: flex;
            flex-flow: row wrap;
            align-items: center
        }

        .form-inline .form-check {
            width: 100%
        }

        @media (min-width:520px) {
            .form-inline label {
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 0
            }

            .form-inline .form-group {
                display: flex;
                flex: 0 0 auto;
                flex-flow: row wrap;
                align-items: center;
                margin-bottom: 0
            }

            .form-inline .form-control {
                display: inline-block;
                width: auto;
                vertical-align: middle
            }

            .form-inline .form-control-plaintext {
                display: inline-block
            }

            .form-inline .input-group {
                width: auto
            }

            .form-inline .form-control-label {
                margin-bottom: 0;
                vertical-align: middle
            }

            .form-inline .form-check {
                display: flex;
                align-items: center;
                justify-content: center;
                width: auto;
                margin-top: 0;
                margin-bottom: 0
            }

            .form-inline .form-check-label {
                padding-left: 0
            }

            .form-inline .form-check-input {
                position: relative;
                margin-top: 0;
                margin-right: .25rem;
                margin-left: 0
            }

            .form-inline .custom-control {
                display: flex;
                align-items: center;
                justify-content: center;
                padding-left: 0
            }

            .form-inline .custom-control-indicator {
                position: static;
                display: inline-block;
                margin-right: .25rem;
                vertical-align: text-bottom
            }

            .form-inline .has-feedback .form-control-feedback {
                top: 0
            }
        }

        .form-control {
            height: 40px;
            vertical-align: middle;
            transition: none
        }

        .form-control:-ms-input-placeholder {
            color: #aab7c2
        }

        .form-control::-ms-input-placeholder {
            opacity: 1;
            color: #aab7c2
        }

        select[multiple].form-control {
            height: auto;
            min-height: 40px;
            overflow-y: scroll
        }

        .form-group {
            position: relative
        }

        .form-control+.form-element-clear {
            color: #aab7c2;
            position: absolute;
            right: 12px;
            line-height: 1.41803;
            background-color: transparent;
            border: 0;
            padding: 0;
            margin-top: -33px
        }

        .form-control+.form-element-clear:focus {
            outline: 0
        }

        .form-control.form-control-lg+.form-element-clear,
        .input-group-lg>.form-control+.form-element-clear,
        .input-group-lg>.input-group-btn>.form-control.btn+.form-element-clear {
            margin-top: -39px
        }

        .form-control.form-control-sm+.form-element-clear,
        .input-group-sm>.form-control+.form-element-clear,
        .input-group-sm>.input-group-btn>.form-control.btn+.form-element-clear {
            margin-top: -30px
        }

        .form-control-label {
            padding: 0;
            margin-bottom: 5px
        }

        .form-control-sm,
        .input-group-sm>.form-control,
        .input-group-sm>.input-group-addon,
        .input-group-sm>.input-group-btn>.btn {
            height: 32px
        }

        .form-control-lg,
        .input-group-lg>.form-control,
        .input-group-lg>.input-group-addon,
        .input-group-lg>.input-group-btn>.btn {
            height: 50px
        }

        textarea.form-control {
            height: auto;
            padding-top: 8px;
            padding-bottom: 8px
        }

        .form-check {
            display: flex
        }

        fieldset[disabled] .form-check {
            color: #757575;
            cursor: not-allowed
        }

        .form-check-inline,
        .form-check-label {
            padding-left: 1.3rem;
            font-size: 1em
        }

        .form-error,
        .req {
            font-size: .875rem
        }

        .form-check-inline {
            margin-right: 0;
            margin-bottom: 0
        }

        .form-check-inline .custom-control-description {
            top: -.07rem
        }

        .form-check-input {
            margin-right: .1rem;
            margin-left: -1.3rem;
            margin-top: 0;
            top: .25rem
        }

        .has-warning .custom-control,
        .has-warning .form-control-label,
        .has-warning .form-text,
        .has-warning.form-check,
        .has-warning.form-check-inline {
            color: #ebc001
        }

        .has-warning .form-control {
            color: #111;
            border-color: #ebc001;
            background-color: #fffae3;
            box-shadow: none
        }

        .has-warning .form-control:focus {
            border-color: #ebc001;
            box-shadow: none
        }

        .has-warning .input-group-addon {
            color: #ebc001;
            border-color: #ebc001;
            background-color: #fffae3
        }

        .has-danger .custom-control,
        .has-danger .form-control-label,
        .has-danger .form-text,
        .has-danger.form-check,
        .has-danger.form-check-inline {
            color: #db1802
        }

        .has-danger .form-control {
            color: #111;
            border-color: #db1802;
            background-color: #fadcd9;
            box-shadow: none
        }

        .has-danger .form-control:focus {
            border-color: #db1802;
            box-shadow: none
        }

        .has-danger .input-group-addon {
            color: #db1802;
            border-color: #db1802;
            background-color: #fadcd9
        }

        .has-danger .form-check-label,
        .has-danger .form-control-label {
            color: inherit
        }

        .has-danger .form-control.form-control-danger:focus {
            border-color: #000;
            background-color: #fff;
            color: #000
        }

        @media (min-width:520px) {

            .form-inline .form-group,
            .form-inline label {
                display: inline-block
            }

            .form-inline .form-group+.form-group {
                margin-left: 1em
            }
        }

        .form-inline label {
            margin-right: 8px
        }

        .form-inline .custom-control {
            flex-direction: row
        }

        .form-inline .custom-checkbox .form-error,
        .form-inline .custom-checkbox .form-text {
            margin: -2px 8px 0
        }

        .form-error {
            margin-top: 5px;
            color: #db1802;
            font-weight: 400
        }

        .form-text {
            display: block;
            margin-top: 5px;
            margin-bottom: 10px;
            color: #757575
        }

        .fieldset {
            padding: 0 20px;
            background-color: #f5f7f8
        }

        label+.fieldset {
            margin-top: 3px
        }

        .fieldset .form-group:first-child {
            margin-top: 20px
        }

        .req {
            color: #db1802;
            font-weight: 700
        }

        .input-icon {
            position: relative;
            display: block
        }

        .input-icon .uxicon {
            position: absolute;
            top: 50%;
            display: block;
            width: 20px;
            margin-top: -.45em;
            font-size: 20px;
            color: #000;
            text-align: center
        }

        .input-icon .form-control-sm+.uxicon,
        .input-icon .input-group-sm>.form-control+.uxicon,
        .input-icon .input-group-sm>.input-group-addon+.uxicon,
        .input-icon .input-group-sm>.input-group-btn>.btn+.uxicon {
            width: 16px;
            margin-top: -.4em;
            font-size: 16px
        }

        .input-icon .form-control-lg+.uxicon,
        .input-icon .input-group-lg>.form-control+.uxicon,
        .input-icon .input-group-lg>.input-group-addon+.uxicon,
        .input-icon .input-group-lg>.input-group-btn>.btn+.uxicon {
            width: 28px;
            font-size: 28px
        }

        .input-icon-left .form-control {
            padding-left: 36.8px
        }

        .input-icon-left .form-control.form-control-sm,
        .input-icon-left .input-group-sm>.form-control,
        .input-icon-left .input-group-sm>.input-group-btn>.form-control.btn {
            padding-left: 32.2px
        }

        .input-icon-left .form-control.form-control-lg,
        .input-icon-left .input-group-lg>.form-control,
        .input-icon-left .input-group-lg>.input-group-btn>.form-control.btn {
            padding-left: 46px
        }

        .input-icon-left .form-control-lg+.uxicon,
        .input-icon-left .form-control-sm+.uxicon,
        .input-icon-left .input-group-lg>.form-control+.uxicon,
        .input-icon-left .input-group-lg>.input-group-addon+.uxicon,
        .input-icon-left .input-group-lg>.input-group-btn>.btn+.uxicon,
        .input-icon-left .input-group-sm>.form-control+.uxicon,
        .input-icon-left .input-group-sm>.input-group-addon+.uxicon,
        .input-icon-left .input-group-sm>.input-group-btn>.btn+.uxicon,
        .input-icon-left .uxicon {
            left: 12px
        }

        .input-icon-right .form-control {
            padding-right: 36.8px
        }

        .input-icon-right .form-control.form-control-sm,
        .input-icon-right .input-group-sm>.form-control,
        .input-icon-right .input-group-sm>.input-group-btn>.form-control.btn {
            padding-right: 32.2px
        }

        .input-icon-right .form-control.form-control-lg,
        .input-icon-right .input-group-lg>.form-control,
        .input-icon-right .input-group-lg>.input-group-btn>.form-control.btn {
            padding-right: 46px
        }

        .input-icon-right .form-control-lg+.uxicon,
        .input-icon-right .form-control-sm+.uxicon,
        .input-icon-right .input-group-lg>.form-control+.uxicon,
        .input-icon-right .input-group-lg>.input-group-addon+.uxicon,
        .input-icon-right .input-group-lg>.input-group-btn>.btn+.uxicon,
        .input-icon-right .input-group-sm>.form-control+.uxicon,
        .input-icon-right .input-group-sm>.input-group-addon+.uxicon,
        .input-icon-right .input-group-sm>.input-group-btn>.btn+.uxicon,
        .input-icon-right .uxicon {
            right: 12px
        }

        .custom-control {
            position: relative;
            min-height: 1.61803rem;
            margin-right: 1rem
        }

        .custom-control-input {
            position: absolute;
            z-index: -1;
            opacity: 0
        }

        .custom-control-input:checked~.custom-control-indicator {
            color: #fff;
            background-color: #00a63f;
            box-shadow: none
        }

        .custom-control-input:active~.custom-control-indicator {
            color: #fff;
            background-color: #fff;
            box-shadow: none
        }

        .custom-control-input:disabled~.custom-control-indicator {
            background-color: #f5f7f8
        }

        .custom-control-input:disabled~.custom-control-description {
            color: #868e96
        }

        .custom-control-indicator {
            position: absolute;
            left: 0;
            display: block;
            width: 20px;
            height: 20px;
            pointer-events: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            background-color: #fff;
            background-repeat: no-repeat;
            background-position: center center;
            background-size: 50% 50%;
            box-shadow: none
        }

        .btn-block,
        input[type=button].btn-block,
        input[type=reset].btn-block,
        input[type=submit].btn-block {
            width: 100%
        }

        .btn,
        .custom-file-control {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none
        }

        .custom-checkbox .custom-control-indicator {
            border-radius: 4px
        }

        .custom-checkbox .custom-control-input:indeterminate~.custom-control-indicator {
            background-color: #00a63f;
            background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 4'%3E%3Cpath stroke='%23fff' d='M0 2h4'/%3E%3C/svg%3E");
            box-shadow: none
        }

        .custom-radio .custom-control-indicator {
            border-radius: 50%
        }

        .custom-controls-stacked {
            display: flex;
            flex-direction: column
        }

        .custom-file,
        .custom-select {
            display: inline-block;
            max-width: 100%
        }

        .custom-controls-stacked .custom-control {
            margin-bottom: .25rem
        }

        .custom-controls-stacked .custom-control+.custom-control {
            margin-left: 0
        }

        .custom-select {
            height: 40px;
            padding: .375rem 1.75rem .375rem .75rem;
            line-height: 1.61803;
            color: #2b2b2b;
            vertical-align: middle;
            background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3E%3Cpath fill='%23333' d='M2 0L0 2h4zm0 5L0 3h4z'/%3E%3C/svg%3E") right .75rem center no-repeat #fff;
            background-size: 8px 10px;
            border: 1px solid #aab7c2;
            border-radius: 6px;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }

        .custom-select:focus {
            border-color: #27ff79;
            outline: 0;
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, .075), 0 0 5px rgba(39, 255, 121, .5)
        }

        .custom-select:focus::-ms-value {
            color: #2b2b2b;
            background-color: #fff
        }

        .custom-select[multiple] {
            height: auto;
            background-image: none
        }

        .custom-select:disabled {
            color: #868e96;
            background-color: #e9ecef
        }

        .custom-select::-ms-expand {
            opacity: 0
        }

        .custom-select-sm {
            height: 32px;
            padding-top: .375rem;
            padding-bottom: .375rem;
            font-size: 75%
        }

        .custom-file {
            position: relative;
            height: 40px;
            margin-bottom: 0
        }

        .custom-file-control,
        .custom-file-control::before {
            position: absolute;
            padding: 6px 12px;
            line-height: 1.61803;
            color: #2b2b2b;
            height: 40px
        }

        .custom-file-input {
            min-width: 14rem;
            max-width: 100%;
            height: 40px;
            margin: 0;
            opacity: 0
        }

        .custom-file-input:focus~.custom-file-control {
            box-shadow: 0 0 0 .075rem #fff, 0 0 0 .2rem #00a63f
        }

        .custom-file-control {
            top: 0;
            right: 0;
            left: 0;
            z-index: 5;
            pointer-events: none;
            user-select: none;
            background-color: #fff;
            border: 1px solid #aab7c2;
            border-radius: 6px;
            box-shadow: none
        }

        .custom-file-control:lang(en):empty::after {
            content: "Choose file..."
        }

        .custom-file-control::before {
            top: -1px;
            right: -1px;
            bottom: -1px;
            z-index: 6;
            display: block;
            background-color: #e9ecef;
            border: 1px solid #aab7c2;
            border-radius: 0 6px 6px 0
        }

        .custom-file-control:lang(en)::before {
            content: "Browse"
        }

        .custom-control {
            padding-left: 1.8rem;
            display: inline-flex;
            flex-direction: column
        }

        .custom-control:hover .custom-control-indicator {
            border: 2px solid #00a63f
        }

        .custom-control.btn,
        .custom-control.btn+.custom-control.btn {
            margin-left: 0;
            margin-right: 1px
        }

        .custom-control.btn+.custom-control.btn:last-child {
            margin-right: 0
        }

        .custom-control.form-check-inline:not(.btn) {
            margin-right: 2rem
        }

        .custom-control.form-check-inline:not(.btn) .custom-control-description {
            top: .125rem
        }

        .custom-control-indicator {
            border: 1px solid #aab7c2;
            top: .35rem
        }

        .custom-control-description {
            position: relative;
            top: .15rem;
            font-weight: 400
        }

        .custom-control-input:focus~.custom-control-indicator {
            box-shadow: none
        }

        .custom-control-input:disabled:hover~.custom-control-indicator {
            border: 1px solid #aab7c2
        }

        .custom-control-input:disabled~.custom-control-indicator {
            opacity: .6
        }

        .custom-control-input:disabled:checked~.custom-control-indicator {
            background-color: #00a63f
        }

        .custom-checkbox .custom-control-input:checked~.custom-control-indicator {
            border: 0;
            background-image: none;
            text-align: center
        }

        .custom-checkbox .custom-control-input:checked~.custom-control-indicator:before {
            content: "\E207";
            font-family: uxfont;
            font-size: 12px;
            color: #fff;
            line-height: .8;
            vertical-align: 3px
        }

        .custom-checkbox .custom-control-input:indeterminate~.custom-control-indicator {
            border: #00a63f
        }

        .custom-checkbox:hover .custom-control-input:checked~.custom-control-indicator {
            border-width: 0
        }

        .custom-radio .custom-control-input:checked~.custom-control-indicator {
            background-image: none;
            background-color: #00a63f;
            border: 2px solid #00a63f;
            box-shadow: inset 0 0 0 3px #fff
        }

        .custom-controls-stacked .custom-control-description {
            top: .0625rem
        }

        .btn {
            display: inline-block;
            text-align: center;
            vertical-align: middle;
            user-select: none;
            border: 1px solid transparent
        }

        .ux-pivot,
        .ux-search.open .ux-search-lookahead,
        .ux-toggle {
            -moz-user-select: none;
            -ms-user-select: none
        }

        .btn.disabled,
        .btn:disabled {
            box-shadow: none
        }

        .btn.active,
        .btn:active {
            background-image: none
        }

        a.btn.disabled,
        fieldset[disabled] a.btn {
            pointer-events: none
        }

        .btn-outline-primary {
            color: #00a63f;
            background-color: transparent;
            background-image: none;
            border-color: #00a63f
        }

        .btn-outline-primary:hover {
            color: #fff;
            background-color: #00a63f;
            border-color: #00a63f
        }

        .btn-outline-primary.focus,
        .btn-outline-primary:focus {
            box-shadow: 0 0 0 3px rgba(0, 166, 63, .5)
        }

        .btn-outline-primary.disabled,
        .btn-outline-primary:disabled {
            color: #00a63f;
            background-color: transparent
        }

        .btn-outline-primary.active,
        .btn-outline-primary:active,
        .show>.btn-outline-primary.dropdown-toggle {
            color: #fff;
            background-color: #00a63f;
            border-color: #00a63f
        }

        .btn-outline-secondary {
            color: #1976d2;
            background-color: transparent;
            background-image: none;
            border-color: #1976d2
        }

        .btn-outline-secondary:hover {
            color: #fff;
            background-color: #1976d2;
            border-color: #1976d2
        }

        .btn-outline-secondary.focus,
        .btn-outline-secondary:focus {
            box-shadow: 0 0 0 3px rgba(25, 118, 210, .5)
        }

        .btn-outline-secondary.disabled,
        .btn-outline-secondary:disabled {
            color: #1976d2;
            background-color: transparent
        }

        .btn-outline-secondary.active,
        .btn-outline-secondary:active,
        .show>.btn-outline-secondary.dropdown-toggle {
            color: #fff;
            background-color: #1976d2;
            border-color: #1976d2
        }

        .btn-outline-success {
            color: #00a63f;
            background-color: transparent;
            background-image: none;
            border-color: #00a63f
        }

        .btn-outline-success:hover {
            color: #fff;
            background-color: #00a63f;
            border-color: #00a63f
        }

        .btn-outline-success.focus,
        .btn-outline-success:focus {
            box-shadow: 0 0 0 3px rgba(0, 166, 63, .5)
        }

        .btn-outline-success.disabled,
        .btn-outline-success:disabled {
            color: #00a63f;
            background-color: transparent
        }

        .btn-outline-success.active,
        .btn-outline-success:active,
        .show>.btn-outline-success.dropdown-toggle {
            color: #fff;
            background-color: #00a63f;
            border-color: #00a63f
        }

        .btn-outline-info {
            color: #9e42b5;
            background-color: transparent;
            background-image: none;
            border-color: #9e42b5
        }

        .btn-outline-info:hover {
            color: #fff;
            background-color: #9e42b5;
            border-color: #9e42b5
        }

        .btn-outline-info.focus,
        .btn-outline-info:focus {
            box-shadow: 0 0 0 3px rgba(158, 66, 181, .5)
        }

        .btn-outline-info.disabled,
        .btn-outline-info:disabled {
            color: #9e42b5;
            background-color: transparent
        }

        .btn-outline-info.active,
        .btn-outline-info:active,
        .show>.btn-outline-info.dropdown-toggle {
            color: #fff;
            background-color: #9e42b5;
            border-color: #9e42b5
        }

        .btn-outline-warning {
            color: #fedc45;
            background-color: transparent;
            background-image: none;
            border-color: #fedc45
        }

        .btn-outline-warning:hover {
            color: #fff;
            background-color: #fedc45;
            border-color: #fedc45
        }

        .btn-outline-warning.focus,
        .btn-outline-warning:focus {
            box-shadow: 0 0 0 3px rgba(254, 220, 69, .5)
        }

        .btn-outline-warning.disabled,
        .btn-outline-warning:disabled {
            color: #fedc45;
            background-color: transparent
        }

        .btn-outline-warning.active,
        .btn-outline-warning:active,
        .show>.btn-outline-warning.dropdown-toggle {
            color: #fff;
            background-color: #fedc45;
            border-color: #fedc45
        }

        .btn-outline-danger {
            color: #db1802;
            background-color: transparent;
            background-image: none;
            border-color: #db1802
        }

        .btn-outline-danger:hover {
            color: #fff;
            background-color: #db1802;
            border-color: #db1802
        }

        .btn-outline-danger.focus,
        .btn-outline-danger:focus {
            box-shadow: 0 0 0 3px rgba(219, 24, 2, .5)
        }

        .btn-outline-danger.disabled,
        .btn-outline-danger:disabled {
            color: #db1802;
            background-color: transparent
        }

        .btn-outline-danger.active,
        .btn-outline-danger:active,
        .show>.btn-outline-danger.dropdown-toggle {
            color: #fff;
            background-color: #db1802;
            border-color: #db1802
        }

        .btn-outline-light {
            color: #f8f9fa;
            background-color: transparent;
            background-image: none;
            border-color: #f8f9fa
        }

        .btn-outline-light:hover {
            color: #212529;
            background-color: #f8f9fa;
            border-color: #f8f9fa
        }

        .btn-outline-light.focus,
        .btn-outline-light:focus {
            box-shadow: 0 0 0 3px rgba(248, 249, 250, .5)
        }

        .btn-outline-light.disabled,
        .btn-outline-light:disabled {
            color: #f8f9fa;
            background-color: transparent
        }

        .btn-outline-light.active,
        .btn-outline-light:active,
        .show>.btn-outline-light.dropdown-toggle {
            color: #212529;
            background-color: #f8f9fa;
            border-color: #f8f9fa
        }

        .btn-outline-dark {
            color: #343a40;
            background-color: transparent;
            background-image: none;
            border-color: #343a40
        }

        .btn-outline-dark:hover {
            color: #fff;
            background-color: #343a40;
            border-color: #343a40
        }

        .btn-outline-dark.focus,
        .btn-outline-dark:focus {
            box-shadow: 0 0 0 3px rgba(52, 58, 64, .5)
        }

        .btn-outline-dark.disabled,
        .btn-outline-dark:disabled {
            color: #343a40;
            background-color: transparent
        }

        .btn-outline-dark.active,
        .btn-outline-dark:active,
        .show>.btn-outline-dark.dropdown-toggle {
            color: #fff;
            background-color: #343a40;
            border-color: #343a40
        }

        .btn-outline-primary-o {
            color: #00a63f;
            background-color: transparent;
            background-image: none;
            border-color: #00a63f
        }

        .btn-outline-primary-o:hover {
            color: #fff;
            background-color: #00a63f;
            border-color: #00a63f
        }

        .btn-outline-primary-o.focus,
        .btn-outline-primary-o:focus {
            box-shadow: 0 0 0 3px rgba(0, 166, 63, .5)
        }

        .btn-outline-purchase.focus,
        .btn-outline-purchase:focus,
        .btn-outline-secondary-o.focus,
        .btn-outline-secondary-o:focus {
            box-shadow: 0 0 0 3px rgba(25, 118, 210, .5)
        }

        .btn-outline-primary-o.disabled,
        .btn-outline-primary-o:disabled {
            color: #00a63f;
            background-color: transparent
        }

        .btn-outline-primary-o.active,
        .btn-outline-primary-o:active,
        .show>.btn-outline-primary-o.dropdown-toggle {
            color: #fff;
            background-color: #00a63f;
            border-color: #00a63f
        }

        .btn-outline-secondary-o {
            color: #1976d2;
            background-color: transparent;
            background-image: none;
            border-color: #1976d2
        }

        .btn-outline-secondary-o:hover {
            color: #fff;
            background-color: #1976d2;
            border-color: #1976d2
        }

        .btn-outline-secondary-o.disabled,
        .btn-outline-secondary-o:disabled {
            color: #1976d2;
            background-color: transparent
        }

        .btn-outline-secondary-o.active,
        .btn-outline-secondary-o:active,
        .show>.btn-outline-secondary-o.dropdown-toggle {
            color: #fff;
            background-color: #1976d2;
            border-color: #1976d2
        }

        .btn-outline-purchase {
            color: #1976d2;
            background-color: transparent;
            background-image: none;
            border-color: #1976d2
        }

        .btn-outline-purchase:hover {
            color: #fff;
            background-color: #1976d2;
            border-color: #1976d2
        }

        .btn-outline-purchase.disabled,
        .btn-outline-purchase:disabled {
            color: #1976d2;
            background-color: transparent
        }

        .btn-outline-purchase.active,
        .btn-outline-purchase:active,
        .show>.btn-outline-purchase.dropdown-toggle {
            color: #fff;
            background-color: #1976d2;
            border-color: #1976d2
        }

        .btn-outline-default {
            color: #444;
            background-color: transparent;
            background-image: none;
            border-color: #444
        }

        .btn-outline-default:hover {
            color: #fff;
            background-color: #444;
            border-color: #444
        }

        .btn-outline-default.focus,
        .btn-outline-default:focus {
            box-shadow: 0 0 0 3px rgba(68, 68, 68, .5)
        }

        .btn-outline-default.disabled,
        .btn-outline-default:disabled {
            color: #444;
            background-color: transparent
        }

        .btn-outline-default.active,
        .btn-outline-default:active,
        .show>.btn-outline-default.dropdown-toggle {
            color: #fff;
            background-color: #444;
            border-color: #444
        }

        .btn-outline-feature {
            color: #e20087;
            background-color: transparent;
            background-image: none;
            border-color: #e20087
        }

        .btn-outline-feature:hover {
            color: #fff;
            background-color: #e20087;
            border-color: #e20087
        }

        .btn-outline-feature.focus,
        .btn-outline-feature:focus {
            box-shadow: 0 0 0 3px rgba(226, 0, 135, .5)
        }

        .btn-outline-feature.disabled,
        .btn-outline-feature:disabled {
            color: #e20087;
            background-color: transparent
        }

        .btn-outline-feature.active,
        .btn-outline-feature:active,
        .show>.btn-outline-feature.dropdown-toggle {
            color: #fff;
            background-color: #e20087;
            border-color: #e20087
        }

        .btn-outline-muted {
            color: #757575;
            background-color: transparent;
            background-image: none;
            border-color: #757575
        }

        .btn-outline-muted:hover {
            color: #fff;
            background-color: #757575;
            border-color: #757575
        }

        .btn-outline-muted.focus,
        .btn-outline-muted:focus {
            box-shadow: 0 0 0 3px rgba(117, 117, 117, .5)
        }

        .btn-outline-muted.disabled,
        .btn-outline-muted:disabled {
            color: #757575;
            background-color: transparent
        }

        .btn-outline-muted.active,
        .btn-outline-muted:active,
        .show>.btn-outline-muted.dropdown-toggle {
            color: #fff;
            background-color: #757575;
            border-color: #757575
        }

        .btn-link,
        .btn-link:hover {
            background-color: transparent
        }

        .btn-link {
            font-weight: 400
        }

        .btn-link:hover {
            border-color: transparent
        }

        .btn-link.focus,
        .btn-link:focus {
            border-color: transparent;
            box-shadow: none
        }

        .btn-link.disabled,
        .btn-link:disabled {
            color: #868e96
        }

        .btn-block {
            display: block
        }

        .btn-block+.btn-block {
            margin-top: .5rem
        }

        .btn {
            font-weight: 700;
            white-space: normal;
            transition: none;
            cursor: pointer;
            outline: 0;
            padding: 9px 24px 11px;
            font-size: 1rem;
            line-height: 1.25rem;
            border-radius: 4px;
            border-width: 0
        }

        @media (min-width:768px) {
            .btn {
                max-width: 293px
            }
        }

        .btn.focus,
        .btn:focus {
            box-shadow: none;
            outline: 0;
            border-width: 1px;
            border-style: solid;
            padding: 8px 23px 10px
        }

        .btn,
        .btn.active,
        .btn:active {
            box-shadow: none
        }

        .btn.disabled,
        .btn.disabled:active,
        .btn.disabled:focus,
        .btn.disabled:hover,
        .btn:disabled,
        .btn:disabled:active,
        .btn:disabled:focus,
        .btn:disabled:hover {
            opacity: .3
        }

        .btn.btn-square {
            width: 40px;
            height: 40px;
            padding: 10px 0;
            text-align: center;
            line-height: 1.3
        }

        .btn.btn-square:focus {
            padding: 9px 0
        }

        .btn-canvas.btn-pill,
        .btn-canvas.btn-tertiary,
        .btn-danger.btn-pill,
        .btn-danger.btn-tertiary,
        .btn-default-danger.btn-pill,
        .btn-default-danger.btn-tertiary,
        .btn-default-dark.btn-pill,
        .btn-default-dark.btn-tertiary,
        .btn-default-feature.btn-pill,
        .btn-default-feature.btn-tertiary,
        .btn-default-info.btn-pill,
        .btn-default-info.btn-tertiary,
        .btn-default-light.btn-pill,
        .btn-default-light.btn-tertiary,
        .btn-default-primary.btn-pill,
        .btn-default-primary.btn-tertiary,
        .btn-default-purchase.btn-pill,
        .btn-default-purchase.btn-tertiary,
        .btn-default-success.btn-pill,
        .btn-default-success.btn-tertiary,
        .btn-default-warning.btn-pill,
        .btn-default-warning.btn-tertiary,
        .btn-feature.btn-pill,
        .btn-feature.btn-tertiary,
        .btn-info.btn-pill,
        .btn-info.btn-tertiary,
        .btn-primary.btn-pill,
        .btn-primary.btn-tertiary,
        .btn-purchase.btn-pill,
        .btn-purchase.btn-tertiary,
        .btn-success.btn-pill,
        .btn-success.btn-tertiary,
        .btn-warning.btn-pill,
        .btn-warning.btn-tertiary {
            font-size: .75rem;
            line-height: 1rem;
            border-radius: 15px/50%;
            border-width: 1px !important;
            padding: 5px 16px !important;
            border-style: solid
        }

        .btn-primary {
            color: #fff !important;
            background: #1976d2 !important;
            border-color: #1976d2 !important
        }

        .btn-group-sm>.btn-primary.btn,
        .btn-group-sm>.btn-primary.btn:disabled:active,
        .btn-group-sm>.btn-primary.btn:disabled:focus,
        .btn-group-sm>.btn-primary.btn:disabled:hover,
        .btn-group-sm>.btn-primary.disabled.btn:active,
        .btn-group-sm>.btn-primary.disabled.btn:focus,
        .btn-group-sm>.btn-primary.disabled.btn:hover,
        .btn-primary.btn-pill,
        .btn-primary.btn-pill.disabled:active,
        .btn-primary.btn-pill.disabled:focus,
        .btn-primary.btn-pill.disabled:hover,
        .btn-primary.btn-pill:disabled:active,
        .btn-primary.btn-pill:disabled:focus,
        .btn-primary.btn-pill:disabled:hover,
        .btn-primary.btn-sm,
        .btn-primary.btn-sm.disabled:active,
        .btn-primary.btn-sm.disabled:focus,
        .btn-primary.btn-sm.disabled:hover,
        .btn-primary.btn-sm:disabled:active,
        .btn-primary.btn-sm:disabled:focus,
        .btn-primary.btn-sm:disabled:hover,
        .btn-primary.btn-tertiary,
        .btn-primary.btn-tertiary.disabled:active,
        .btn-primary.btn-tertiary.disabled:focus,
        .btn-primary.btn-tertiary.disabled:hover,
        .btn-primary.btn-tertiary:disabled:active,
        .btn-primary.btn-tertiary:disabled:focus,
        .btn-primary.btn-tertiary:disabled:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #1976d2 !important
        }

        .btn-primary.btn-content-primary,
        .btn-primary.btn-filled,
        .btn-primary.btn-filled.disabled:active,
        .btn-primary.btn-filled.disabled:focus,
        .btn-primary.btn-filled.disabled:hover,
        .btn-primary.btn-filled:disabled:active,
        .btn-primary.btn-filled:disabled:focus,
        .btn-primary.btn-filled:disabled:hover {
            background-color: #1976d2 !important;
            color: #fff !important
        }

        .btn-primary:hover {
            color: #fff !important;
            background: #145fa9 !important;
            border-color: #145fa9 !important
        }

        .btn-primary.focus,
        .btn-primary:focus {
            color: #fff !important;
            background-color: #145fa9 !important;
            border-color: #145fa9 !important
        }

        .btn-primary.active,
        .btn-primary:active,
        .open>.btn-primary.dropdown-toggle {
            color: #fff !important;
            background: #104a85 !important;
            border-color: #104a85 !important
        }

        .btn-primary.disabled:active,
        .btn-primary.disabled:focus,
        .btn-primary.disabled:hover,
        .btn-primary:disabled:active,
        .btn-primary:disabled:focus,
        .btn-primary:disabled:hover {
            cursor: not-allowed;
            color: #fff !important;
            background: #1976d2 !important;
            border-color: #1976d2 !important
        }

        .btn-primary.btn-pill:focus,
        .btn-primary.btn-tertiary:focus {
            border-style: solid
        }

        .btn-success {
            color: #111 !important;
            background: #00a63f !important;
            border-color: #00a63f !important
        }

        .btn-group-sm>.btn-success.btn,
        .btn-group-sm>.btn-success.btn:disabled:active,
        .btn-group-sm>.btn-success.btn:disabled:focus,
        .btn-group-sm>.btn-success.btn:disabled:hover,
        .btn-group-sm>.btn-success.disabled.btn:active,
        .btn-group-sm>.btn-success.disabled.btn:focus,
        .btn-group-sm>.btn-success.disabled.btn:hover,
        .btn-success.btn-pill,
        .btn-success.btn-pill.disabled:active,
        .btn-success.btn-pill.disabled:focus,
        .btn-success.btn-pill.disabled:hover,
        .btn-success.btn-pill:disabled:active,
        .btn-success.btn-pill:disabled:focus,
        .btn-success.btn-pill:disabled:hover,
        .btn-success.btn-sm,
        .btn-success.btn-sm.disabled:active,
        .btn-success.btn-sm.disabled:focus,
        .btn-success.btn-sm.disabled:hover,
        .btn-success.btn-sm:disabled:active,
        .btn-success.btn-sm:disabled:focus,
        .btn-success.btn-sm:disabled:hover,
        .btn-success.btn-tertiary,
        .btn-success.btn-tertiary.disabled:active,
        .btn-success.btn-tertiary.disabled:focus,
        .btn-success.btn-tertiary.disabled:hover,
        .btn-success.btn-tertiary:disabled:active,
        .btn-success.btn-tertiary:disabled:focus,
        .btn-success.btn-tertiary:disabled:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #00a63f !important
        }

        .btn-success.btn-content-primary,
        .btn-success.btn-filled,
        .btn-success.btn-filled.disabled:active,
        .btn-success.btn-filled.disabled:focus,
        .btn-success.btn-filled.disabled:hover,
        .btn-success.btn-filled:disabled:active,
        .btn-success.btn-filled:disabled:focus,
        .btn-success.btn-filled:disabled:hover {
            background-color: #00a63f !important;
            color: #111 !important
        }

        .btn-success:hover {
            color: #111 !important;
            background: #02c54c !important;
            border-color: #02c54c !important
        }

        .btn-success.focus,
        .btn-success:focus {
            color: #111 !important;
            background-color: #02c54c !important;
            border-color: #111 !important
        }

        .btn-success.active,
        .btn-success:active,
        .open>.btn-success.dropdown-toggle {
            color: #fff !important;
            background: #004f1e !important;
            border-color: #004f1e !important
        }

        .btn-success.disabled:active,
        .btn-success.disabled:focus,
        .btn-success.disabled:hover,
        .btn-success:disabled:active,
        .btn-success:disabled:focus,
        .btn-success:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #00a63f !important;
            border-color: #00a63f !important
        }

        .btn-success.btn-pill:focus,
        .btn-success.btn-tertiary:focus {
            border-style: solid
        }

        .btn-info {
            color: #fff !important;
            background: #9e42b5 !important;
            border-color: #9e42b5 !important
        }

        .btn-group-sm>.btn-info.btn,
        .btn-group-sm>.btn-info.btn:disabled:active,
        .btn-group-sm>.btn-info.btn:disabled:focus,
        .btn-group-sm>.btn-info.btn:disabled:hover,
        .btn-group-sm>.btn-info.disabled.btn:active,
        .btn-group-sm>.btn-info.disabled.btn:focus,
        .btn-group-sm>.btn-info.disabled.btn:hover,
        .btn-info.btn-pill,
        .btn-info.btn-pill.disabled:active,
        .btn-info.btn-pill.disabled:focus,
        .btn-info.btn-pill.disabled:hover,
        .btn-info.btn-pill:disabled:active,
        .btn-info.btn-pill:disabled:focus,
        .btn-info.btn-pill:disabled:hover,
        .btn-info.btn-sm,
        .btn-info.btn-sm.disabled:active,
        .btn-info.btn-sm.disabled:focus,
        .btn-info.btn-sm.disabled:hover,
        .btn-info.btn-sm:disabled:active,
        .btn-info.btn-sm:disabled:focus,
        .btn-info.btn-sm:disabled:hover,
        .btn-info.btn-tertiary,
        .btn-info.btn-tertiary.disabled:active,
        .btn-info.btn-tertiary.disabled:focus,
        .btn-info.btn-tertiary.disabled:hover,
        .btn-info.btn-tertiary:disabled:active,
        .btn-info.btn-tertiary:disabled:focus,
        .btn-info.btn-tertiary:disabled:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #9e42b5 !important
        }

        .btn-info.btn-content-primary,
        .btn-info.btn-filled,
        .btn-info.btn-filled.disabled:active,
        .btn-info.btn-filled.disabled:focus,
        .btn-info.btn-filled.disabled:hover,
        .btn-info.btn-filled:disabled:active,
        .btn-info.btn-filled:disabled:focus,
        .btn-info.btn-filled:disabled:hover {
            background-color: #9e42b5 !important;
            color: #fff !important
        }

        .btn-info:hover {
            color: #fff !important;
            background: #813693 !important;
            border-color: #813693 !important
        }

        .btn-info.focus,
        .btn-info:focus {
            color: #fff !important;
            background-color: #813693 !important;
            border-color: #9e42b5 !important
        }

        .btn-info.active,
        .btn-info:active,
        .open>.btn-info.dropdown-toggle {
            color: #fff !important;
            background: #672b75 !important;
            border-color: #672b75 !important
        }

        .btn-info.disabled:active,
        .btn-info.disabled:focus,
        .btn-info.disabled:hover,
        .btn-info:disabled:active,
        .btn-info:disabled:focus,
        .btn-info:disabled:hover {
            cursor: not-allowed;
            color: #fff !important;
            background: #9e42b5 !important;
            border-color: #9e42b5 !important
        }

        .btn-info.btn-pill:focus,
        .btn-info.btn-tertiary:focus {
            border-style: solid
        }

        .btn-warning {
            color: #111 !important;
            background: #fedc45 !important;
            border-color: #fedc45 !important
        }

        .btn-group-sm>.btn-warning.btn,
        .btn-group-sm>.btn-warning.btn:disabled:active,
        .btn-group-sm>.btn-warning.btn:disabled:focus,
        .btn-group-sm>.btn-warning.btn:disabled:hover,
        .btn-group-sm>.btn-warning.disabled.btn:active,
        .btn-group-sm>.btn-warning.disabled.btn:focus,
        .btn-group-sm>.btn-warning.disabled.btn:hover,
        .btn-warning.btn-pill,
        .btn-warning.btn-pill.disabled:active,
        .btn-warning.btn-pill.disabled:focus,
        .btn-warning.btn-pill.disabled:hover,
        .btn-warning.btn-pill:disabled:active,
        .btn-warning.btn-pill:disabled:focus,
        .btn-warning.btn-pill:disabled:hover,
        .btn-warning.btn-sm,
        .btn-warning.btn-sm.disabled:active,
        .btn-warning.btn-sm.disabled:focus,
        .btn-warning.btn-sm.disabled:hover,
        .btn-warning.btn-sm:disabled:active,
        .btn-warning.btn-sm:disabled:focus,
        .btn-warning.btn-sm:disabled:hover,
        .btn-warning.btn-tertiary,
        .btn-warning.btn-tertiary.disabled:active,
        .btn-warning.btn-tertiary.disabled:focus,
        .btn-warning.btn-tertiary.disabled:hover,
        .btn-warning.btn-tertiary:disabled:active,
        .btn-warning.btn-tertiary:disabled:focus,
        .btn-warning.btn-tertiary:disabled:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #fedc45 !important
        }

        .btn-warning.btn-content-primary,
        .btn-warning.btn-filled,
        .btn-warning.btn-filled.disabled:active,
        .btn-warning.btn-filled.disabled:focus,
        .btn-warning.btn-filled.disabled:hover,
        .btn-warning.btn-filled:disabled:active,
        .btn-warning.btn-filled:disabled:focus,
        .btn-warning.btn-filled:disabled:hover {
            background-color: #fedc45 !important;
            color: #111 !important
        }

        .btn-warning:hover {
            color: #111 !important;
            background: #fed317 !important;
            border-color: #fed317 !important
        }

        .btn-warning.focus,
        .btn-warning:focus {
            color: #111 !important;
            background-color: #fed317 !important;
            border-color: #111 !important
        }

        .btn-warning.active,
        .btn-warning:active,
        .open>.btn-warning.dropdown-toggle {
            color: #111 !important;
            background: #ebc001 !important;
            border-color: #ebc001 !important
        }

        .btn-warning.disabled:active,
        .btn-warning.disabled:focus,
        .btn-warning.disabled:hover,
        .btn-warning:disabled:active,
        .btn-warning:disabled:focus,
        .btn-warning:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fedc45 !important;
            border-color: #fedc45 !important
        }

        .btn-warning.btn-pill:focus,
        .btn-warning.btn-tertiary:focus {
            border-style: solid
        }

        .btn-danger {
            color: #fff !important;
            background: #db1802 !important;
            border-color: #db1802 !important
        }

        .btn-danger.btn-pill,
        .btn-danger.btn-pill.disabled:active,
        .btn-danger.btn-pill.disabled:focus,
        .btn-danger.btn-pill.disabled:hover,
        .btn-danger.btn-pill:disabled:active,
        .btn-danger.btn-pill:disabled:focus,
        .btn-danger.btn-pill:disabled:hover,
        .btn-danger.btn-sm,
        .btn-danger.btn-sm.disabled:active,
        .btn-danger.btn-sm.disabled:focus,
        .btn-danger.btn-sm.disabled:hover,
        .btn-danger.btn-sm:disabled:active,
        .btn-danger.btn-sm:disabled:focus,
        .btn-danger.btn-sm:disabled:hover,
        .btn-danger.btn-tertiary,
        .btn-danger.btn-tertiary.disabled:active,
        .btn-danger.btn-tertiary.disabled:focus,
        .btn-danger.btn-tertiary.disabled:hover,
        .btn-danger.btn-tertiary:disabled:active,
        .btn-danger.btn-tertiary:disabled:focus,
        .btn-danger.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-danger.btn,
        .btn-group-sm>.btn-danger.btn:disabled:active,
        .btn-group-sm>.btn-danger.btn:disabled:focus,
        .btn-group-sm>.btn-danger.btn:disabled:hover,
        .btn-group-sm>.btn-danger.disabled.btn:active,
        .btn-group-sm>.btn-danger.disabled.btn:focus,
        .btn-group-sm>.btn-danger.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #db1802 !important
        }

        .btn-danger.btn-content-primary,
        .btn-danger.btn-filled,
        .btn-danger.btn-filled.disabled:active,
        .btn-danger.btn-filled.disabled:focus,
        .btn-danger.btn-filled.disabled:hover,
        .btn-danger.btn-filled:disabled:active,
        .btn-danger.btn-filled:disabled:focus,
        .btn-danger.btn-filled:disabled:hover {
            background-color: #db1802 !important;
            color: #fff !important
        }

        .btn-danger:hover {
            color: #fff !important;
            background: #ae1302 !important;
            border-color: #ae1302 !important
        }

        .btn-danger.focus,
        .btn-danger:focus {
            color: #fff !important;
            background-color: #ae1302 !important;
            border-color: #ae1302 !important
        }

        .btn-danger.active,
        .btn-danger:active,
        .open>.btn-danger.dropdown-toggle {
            color: #fff !important;
            background: #850f01 !important;
            border-color: #850f01 !important
        }

        .btn-danger.disabled:active,
        .btn-danger.disabled:focus,
        .btn-danger.disabled:hover,
        .btn-danger:disabled:active,
        .btn-danger:disabled:focus,
        .btn-danger:disabled:hover {
            cursor: not-allowed;
            color: #fff !important;
            background: #db1802 !important;
            border-color: #db1802 !important
        }

        .btn-danger.btn-pill:focus,
        .btn-danger.btn-tertiary:focus {
            border-style: solid
        }

        .btn-purchase {
            color: #fff !important;
            background: #00a63f !important;
            border-color: #00a63f !important
        }

        .btn-group-sm>.btn-purchase.btn,
        .btn-group-sm>.btn-purchase.btn:disabled:active,
        .btn-group-sm>.btn-purchase.btn:disabled:focus,
        .btn-group-sm>.btn-purchase.btn:disabled:hover,
        .btn-group-sm>.btn-purchase.disabled.btn:active,
        .btn-group-sm>.btn-purchase.disabled.btn:focus,
        .btn-group-sm>.btn-purchase.disabled.btn:hover,
        .btn-purchase.btn-pill,
        .btn-purchase.btn-pill.disabled:active,
        .btn-purchase.btn-pill.disabled:focus,
        .btn-purchase.btn-pill.disabled:hover,
        .btn-purchase.btn-pill:disabled:active,
        .btn-purchase.btn-pill:disabled:focus,
        .btn-purchase.btn-pill:disabled:hover,
        .btn-purchase.btn-sm,
        .btn-purchase.btn-sm.disabled:active,
        .btn-purchase.btn-sm.disabled:focus,
        .btn-purchase.btn-sm.disabled:hover,
        .btn-purchase.btn-sm:disabled:active,
        .btn-purchase.btn-sm:disabled:focus,
        .btn-purchase.btn-sm:disabled:hover,
        .btn-purchase.btn-tertiary,
        .btn-purchase.btn-tertiary.disabled:active,
        .btn-purchase.btn-tertiary.disabled:focus,
        .btn-purchase.btn-tertiary.disabled:hover,
        .btn-purchase.btn-tertiary:disabled:active,
        .btn-purchase.btn-tertiary:disabled:focus,
        .btn-purchase.btn-tertiary:disabled:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #00a63f !important
        }

        .btn-purchase.btn-content-primary,
        .btn-purchase.btn-filled,
        .btn-purchase.btn-filled.disabled:active,
        .btn-purchase.btn-filled.disabled:focus,
        .btn-purchase.btn-filled.disabled:hover,
        .btn-purchase.btn-filled:disabled:active,
        .btn-purchase.btn-filled:disabled:focus,
        .btn-purchase.btn-filled:disabled:hover {
            background-color: #00a63f !important;
            color: #fff !important
        }

        .btn-purchase:hover {
            color: #fff !important;
            background: #00782e !important;
            border-color: #00782e !important
        }

        .btn-purchase.focus,
        .btn-purchase:focus {
            color: #fff !important;
            background-color: #00782e !important;
            border-color: #00782e !important
        }

        .btn-purchase.active,
        .btn-purchase:active,
        .open>.btn-purchase.dropdown-toggle {
            color: #fff !important;
            background: #004f1e !important;
            border-color: #004f1e !important
        }

        .btn-purchase.disabled:active,
        .btn-purchase.disabled:focus,
        .btn-purchase.disabled:hover,
        .btn-purchase:disabled:active,
        .btn-purchase:disabled:focus,
        .btn-purchase:disabled:hover {
            cursor: not-allowed;
            color: #fff !important;
            background: #00a63f !important;
            border-color: #00a63f !important
        }

        .btn-purchase.btn-pill:focus,
        .btn-purchase.btn-tertiary:focus {
            border-style: solid
        }

        .btn-feature {
            color: #fff !important;
            background: #e20087 !important;
            border-color: #e20087 !important
        }

        .btn-feature.btn-pill,
        .btn-feature.btn-pill.disabled:active,
        .btn-feature.btn-pill.disabled:focus,
        .btn-feature.btn-pill.disabled:hover,
        .btn-feature.btn-pill:disabled:active,
        .btn-feature.btn-pill:disabled:focus,
        .btn-feature.btn-pill:disabled:hover,
        .btn-feature.btn-sm,
        .btn-feature.btn-sm.disabled:active,
        .btn-feature.btn-sm.disabled:focus,
        .btn-feature.btn-sm.disabled:hover,
        .btn-feature.btn-sm:disabled:active,
        .btn-feature.btn-sm:disabled:focus,
        .btn-feature.btn-sm:disabled:hover,
        .btn-feature.btn-tertiary,
        .btn-feature.btn-tertiary.disabled:active,
        .btn-feature.btn-tertiary.disabled:focus,
        .btn-feature.btn-tertiary.disabled:hover,
        .btn-feature.btn-tertiary:disabled:active,
        .btn-feature.btn-tertiary:disabled:focus,
        .btn-feature.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-feature.btn,
        .btn-group-sm>.btn-feature.btn:disabled:active,
        .btn-group-sm>.btn-feature.btn:disabled:focus,
        .btn-group-sm>.btn-feature.btn:disabled:hover,
        .btn-group-sm>.btn-feature.disabled.btn:active,
        .btn-group-sm>.btn-feature.disabled.btn:focus,
        .btn-group-sm>.btn-feature.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #e20087 !important
        }

        .btn-feature.btn-content-primary,
        .btn-feature.btn-filled,
        .btn-feature.btn-filled.disabled:active,
        .btn-feature.btn-filled.disabled:focus,
        .btn-feature.btn-filled.disabled:hover,
        .btn-feature.btn-filled:disabled:active,
        .btn-feature.btn-filled:disabled:focus,
        .btn-feature.btn-filled:disabled:hover {
            background-color: #e20087 !important;
            color: #fff !important
        }

        .btn-feature:hover {
            color: #fff !important;
            background: #b4006c !important;
            border-color: #b4006c !important
        }

        .btn-feature.focus,
        .btn-feature:focus {
            color: #fff !important;
            background-color: #b4006c !important;
            border-color: #e20087 !important
        }

        .btn-feature.active,
        .btn-feature:active,
        .open>.btn-feature.dropdown-toggle {
            color: #fff !important;
            background: #8b0053 !important;
            border-color: #8b0053 !important
        }

        .btn-feature.disabled:active,
        .btn-feature.disabled:focus,
        .btn-feature.disabled:hover,
        .btn-feature:disabled:active,
        .btn-feature:disabled:focus,
        .btn-feature:disabled:hover {
            cursor: not-allowed;
            color: #fff !important;
            background: #e20087 !important;
            border-color: #e20087 !important
        }

        .btn-feature.btn-pill:focus,
        .btn-feature.btn-tertiary:focus {
            border-style: solid
        }

        .btn-canvas {
            color: #111 !important;
            background: #fff !important;
            border-color: #aab7c2 !important
        }

        .btn-canvas.btn-pill,
        .btn-canvas.btn-pill.disabled:active,
        .btn-canvas.btn-pill.disabled:focus,
        .btn-canvas.btn-pill.disabled:hover,
        .btn-canvas.btn-pill:disabled:active,
        .btn-canvas.btn-pill:disabled:focus,
        .btn-canvas.btn-pill:disabled:hover,
        .btn-canvas.btn-sm,
        .btn-canvas.btn-sm.disabled:active,
        .btn-canvas.btn-sm.disabled:focus,
        .btn-canvas.btn-sm.disabled:hover,
        .btn-canvas.btn-sm:disabled:active,
        .btn-canvas.btn-sm:disabled:focus,
        .btn-canvas.btn-sm:disabled:hover,
        .btn-canvas.btn-tertiary,
        .btn-canvas.btn-tertiary.disabled:active,
        .btn-canvas.btn-tertiary.disabled:focus,
        .btn-canvas.btn-tertiary.disabled:hover,
        .btn-canvas.btn-tertiary:disabled:active,
        .btn-canvas.btn-tertiary:disabled:focus,
        .btn-canvas.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-canvas.btn,
        .btn-group-sm>.btn-canvas.btn:disabled:active,
        .btn-group-sm>.btn-canvas.btn:disabled:focus,
        .btn-group-sm>.btn-canvas.btn:disabled:hover,
        .btn-group-sm>.btn-canvas.disabled.btn:active,
        .btn-group-sm>.btn-canvas.disabled.btn:focus,
        .btn-group-sm>.btn-canvas.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #aab7c2 !important
        }

        .btn-canvas.btn-filled,
        .btn-canvas.btn-filled.disabled:active,
        .btn-canvas.btn-filled.disabled:focus,
        .btn-canvas.btn-filled.disabled:hover,
        .btn-canvas.btn-filled:disabled:active,
        .btn-canvas.btn-filled:disabled:focus,
        .btn-canvas.btn-filled:disabled:hover {
            background-color: #fff !important;
            color: #111 !important
        }

        .btn-canvas.btn-content-primary {
            color: #111 !important;
            background-color: #fff !important
        }

        .btn-canvas:hover {
            color: #111 !important;
            background: #fff !important;
            border-color: #111 !important
        }

        .btn-canvas.focus,
        .btn-canvas:focus {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #00a63f !important
        }

        .btn-canvas.active,
        .btn-canvas:active,
        .open>.btn-canvas.dropdown-toggle {
            color: #00a63f !important;
            background: #fff !important;
            border-color: #00a63f !important
        }

        .btn-canvas.disabled:active,
        .btn-canvas.disabled:focus,
        .btn-canvas.disabled:hover,
        .btn-canvas:disabled:active,
        .btn-canvas:disabled:focus,
        .btn-canvas:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #aab7c2 !important
        }

        .btn-canvas.btn-pill:focus,
        .btn-canvas.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default {
            color: #111 !important;
            background: #fff !important;
            border-color: #aab7c2 !important
        }

        .btn-default.btn-pill,
        .btn-default.btn-pill.disabled:active,
        .btn-default.btn-pill.disabled:focus,
        .btn-default.btn-pill.disabled:hover,
        .btn-default.btn-pill:disabled:active,
        .btn-default.btn-pill:disabled:focus,
        .btn-default.btn-pill:disabled:hover,
        .btn-default.btn-sm,
        .btn-default.btn-sm.disabled:active,
        .btn-default.btn-sm.disabled:focus,
        .btn-default.btn-sm.disabled:hover,
        .btn-default.btn-sm:disabled:active,
        .btn-default.btn-sm:disabled:focus,
        .btn-default.btn-sm:disabled:hover,
        .btn-default.btn-tertiary,
        .btn-default.btn-tertiary.disabled:active,
        .btn-default.btn-tertiary.disabled:focus,
        .btn-default.btn-tertiary.disabled:hover,
        .btn-default.btn-tertiary:disabled:active,
        .btn-default.btn-tertiary:disabled:focus,
        .btn-default.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default.btn,
        .btn-group-sm>.btn-default.btn:disabled:active,
        .btn-group-sm>.btn-default.btn:disabled:focus,
        .btn-group-sm>.btn-default.btn:disabled:hover,
        .btn-group-sm>.btn-default.disabled.btn:active,
        .btn-group-sm>.btn-default.disabled.btn:focus,
        .btn-group-sm>.btn-default.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #aab7c2 !important
        }

        .btn-default.btn-filled,
        .btn-default.btn-filled.disabled:active,
        .btn-default.btn-filled.disabled:focus,
        .btn-default.btn-filled.disabled:hover,
        .btn-default.btn-filled:disabled:active,
        .btn-default.btn-filled:disabled:focus,
        .btn-default.btn-filled:disabled:hover {
            background-color: #fff !important;
            color: #111 !important
        }

        .btn-default.btn-content-primary {
            color: #111 !important;
            background-color: #fff !important
        }

        .btn-default:hover {
            color: #111 !important;
            background: #f5f7f8 !important;
            border-color: #111 !important
        }

        .btn-default.focus,
        .btn-default:focus {
            color: #111 !important;
            background-color: #f5f7f8 !important;
            border-color: #111 !important
        }

        .btn-default.active,
        .btn-default:active,
        .open>.btn-default.dropdown-toggle {
            color: #111 !important;
            background: #aab7c2 !important;
            border-color: #111 !important
        }

        .btn-default.disabled:active,
        .btn-default.disabled:focus,
        .btn-default.disabled:hover,
        .btn-default:disabled:active,
        .btn-default:disabled:focus,
        .btn-default:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #aab7c2 !important
        }

        .btn-default.btn-pill,
        .btn-default.btn-tertiary {
            font-size: .75rem;
            line-height: 1rem;
            border-radius: 15px/50%;
            border-width: 1px !important;
            border-style: solid;
            padding: 5px 16px !important
        }

        .btn-default.btn-pill:focus,
        .btn-default.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-dark {
            color: #000 !important;
            background: 0 0 !important;
            border-color: #000 !important
        }

        .btn-default-dark.btn-pill,
        .btn-default-dark.btn-pill.disabled:active,
        .btn-default-dark.btn-pill.disabled:focus,
        .btn-default-dark.btn-pill.disabled:hover,
        .btn-default-dark.btn-pill:disabled:active,
        .btn-default-dark.btn-pill:disabled:focus,
        .btn-default-dark.btn-pill:disabled:hover,
        .btn-default-dark.btn-sm,
        .btn-default-dark.btn-sm.disabled:active,
        .btn-default-dark.btn-sm.disabled:focus,
        .btn-default-dark.btn-sm.disabled:hover,
        .btn-default-dark.btn-sm:disabled:active,
        .btn-default-dark.btn-sm:disabled:focus,
        .btn-default-dark.btn-sm:disabled:hover,
        .btn-default-dark.btn-tertiary,
        .btn-default-dark.btn-tertiary.disabled:active,
        .btn-default-dark.btn-tertiary.disabled:focus,
        .btn-default-dark.btn-tertiary.disabled:hover,
        .btn-default-dark.btn-tertiary:disabled:active,
        .btn-default-dark.btn-tertiary:disabled:focus,
        .btn-default-dark.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-dark.btn,
        .btn-group-sm>.btn-default-dark.btn:disabled:active,
        .btn-group-sm>.btn-default-dark.btn:disabled:focus,
        .btn-group-sm>.btn-default-dark.btn:disabled:hover,
        .btn-group-sm>.btn-default-dark.disabled.btn:active,
        .btn-group-sm>.btn-default-dark.disabled.btn:focus,
        .btn-group-sm>.btn-default-dark.disabled.btn:hover {
            color: #fff !important;
            background-color: #111 !important;
            border-color: #000 !important
        }

        .btn-default-dark.btn-content-primary,
        .btn-default-dark.btn-filled,
        .btn-default-dark.btn-filled.disabled:active,
        .btn-default-dark.btn-filled.disabled:focus,
        .btn-default-dark.btn-filled.disabled:hover,
        .btn-default-dark.btn-filled:disabled:active,
        .btn-default-dark.btn-filled:disabled:focus,
        .btn-default-dark.btn-filled:disabled:hover {
            color: #000 !important;
            background-color: transparent !important
        }

        .btn-default-dark.active,
        .btn-default-dark:active,
        .btn-default-dark:hover,
        .open>.btn-default-dark.dropdown-toggle {
            color: #fff !important;
            background: #000 !important;
            border-color: #000 !important
        }

        .btn-default-dark.focus,
        .btn-default-dark:focus {
            color: #fff !important;
            background-color: #000 !important
        }

        .btn-default-dark.disabled:active,
        .btn-default-dark.disabled:focus,
        .btn-default-dark.disabled:hover,
        .btn-default-dark:disabled:active,
        .btn-default-dark:disabled:focus,
        .btn-default-dark:disabled:hover {
            cursor: not-allowed;
            color: #000 !important;
            background: 0 0 !important;
            border-color: #000 !important
        }

        .btn-default-light.btn-content-primary,
        .btn-default-light.btn-filled,
        .btn-default-light.btn-filled.disabled:active,
        .btn-default-light.btn-filled.disabled:focus,
        .btn-default-light.btn-filled.disabled:hover,
        .btn-default-light.btn-filled:disabled:active,
        .btn-default-light.btn-filled:disabled:focus,
        .btn-default-light.btn-filled:disabled:hover {
            color: #111 !important;
            background-color: #fff !important
        }

        .btn-default-dark.btn-pill:focus,
        .btn-default-dark.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-light {
            color: #111 !important;
            background: #fff !important;
            border-color: #fff !important
        }

        .btn-default-light.btn-pill,
        .btn-default-light.btn-pill.disabled:active,
        .btn-default-light.btn-pill.disabled:focus,
        .btn-default-light.btn-pill.disabled:hover,
        .btn-default-light.btn-pill:disabled:active,
        .btn-default-light.btn-pill:disabled:focus,
        .btn-default-light.btn-pill:disabled:hover,
        .btn-default-light.btn-sm,
        .btn-default-light.btn-sm.disabled:active,
        .btn-default-light.btn-sm.disabled:focus,
        .btn-default-light.btn-sm.disabled:hover,
        .btn-default-light.btn-sm:disabled:active,
        .btn-default-light.btn-sm:disabled:focus,
        .btn-default-light.btn-sm:disabled:hover,
        .btn-default-light.btn-tertiary,
        .btn-default-light.btn-tertiary.disabled:active,
        .btn-default-light.btn-tertiary.disabled:focus,
        .btn-default-light.btn-tertiary.disabled:hover,
        .btn-default-light.btn-tertiary:disabled:active,
        .btn-default-light.btn-tertiary:disabled:focus,
        .btn-default-light.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-light.btn,
        .btn-group-sm>.btn-default-light.btn:disabled:active,
        .btn-group-sm>.btn-default-light.btn:disabled:focus,
        .btn-group-sm>.btn-default-light.btn:disabled:hover,
        .btn-group-sm>.btn-default-light.disabled.btn:active,
        .btn-group-sm>.btn-default-light.disabled.btn:focus,
        .btn-group-sm>.btn-default-light.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #fff !important
        }

        .btn-default-light:hover {
            color: #fff !important;
            background: 0 0 !important;
            border-color: #fff !important
        }

        .btn-default-light.focus,
        .btn-default-light:focus {
            color: #fff !important;
            background-color: transparent !important;
            border-color: #fff !important
        }

        .btn-default-light.active,
        .btn-default-light:active,
        .open>.btn-default-light.dropdown-toggle {
            color: #f5f7f8 !important;
            background: 0 0 !important;
            border-color: #fff !important
        }

        .btn-default-light.disabled:active,
        .btn-default-light.disabled:focus,
        .btn-default-light.disabled:hover,
        .btn-default-light:disabled:active,
        .btn-default-light:disabled:focus,
        .btn-default-light:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #fff !important
        }

        .btn-default-light.btn-pill:focus,
        .btn-default-light.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-light-secondary {
            color: #fff !important;
            background: 0 0 !important;
            border-color: #fff !important
        }

        .btn-default-light-secondary.btn-content-primary,
        .btn-default-light-secondary.btn-filled,
        .btn-default-light-secondary.btn-filled.disabled:active,
        .btn-default-light-secondary.btn-filled.disabled:focus,
        .btn-default-light-secondary.btn-filled.disabled:hover,
        .btn-default-light-secondary.btn-filled:disabled:active,
        .btn-default-light-secondary.btn-filled:disabled:focus,
        .btn-default-light-secondary.btn-filled:disabled:hover {
            color: #fff !important;
            background-color: transparent !important
        }

        .btn-default-light-secondary.btn-pill,
        .btn-default-light-secondary.btn-pill.disabled:active,
        .btn-default-light-secondary.btn-pill.disabled:focus,
        .btn-default-light-secondary.btn-pill.disabled:hover,
        .btn-default-light-secondary.btn-pill:disabled:active,
        .btn-default-light-secondary.btn-pill:disabled:focus,
        .btn-default-light-secondary.btn-pill:disabled:hover,
        .btn-default-light-secondary.btn-sm,
        .btn-default-light-secondary.btn-sm.disabled:active,
        .btn-default-light-secondary.btn-sm.disabled:focus,
        .btn-default-light-secondary.btn-sm.disabled:hover,
        .btn-default-light-secondary.btn-sm:disabled:active,
        .btn-default-light-secondary.btn-sm:disabled:focus,
        .btn-default-light-secondary.btn-sm:disabled:hover,
        .btn-default-light-secondary.btn-tertiary,
        .btn-default-light-secondary.btn-tertiary.disabled:active,
        .btn-default-light-secondary.btn-tertiary.disabled:focus,
        .btn-default-light-secondary.btn-tertiary.disabled:hover,
        .btn-default-light-secondary.btn-tertiary:disabled:active,
        .btn-default-light-secondary.btn-tertiary:disabled:focus,
        .btn-default-light-secondary.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-light-secondary.btn,
        .btn-group-sm>.btn-default-light-secondary.btn:disabled:active,
        .btn-group-sm>.btn-default-light-secondary.btn:disabled:focus,
        .btn-group-sm>.btn-default-light-secondary.btn:disabled:hover,
        .btn-group-sm>.btn-default-light-secondary.disabled.btn:active,
        .btn-group-sm>.btn-default-light-secondary.disabled.btn:focus,
        .btn-group-sm>.btn-default-light-secondary.disabled.btn:hover {
            color: #fff !important;
            background-color: transparent !important;
            border-color: #fff !important
        }

        .btn-default-light-secondary:hover {
            color: #111 !important;
            background: #fff !important;
            border-color: #fff !important
        }

        .btn-default-light-secondary.focus,
        .btn-default-light-secondary:focus {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #fff !important
        }

        .btn-default-light-secondary.active,
        .btn-default-light-secondary:active,
        .open>.btn-default-light-secondary.dropdown-toggle {
            color: #757575 !important;
            background: #fff !important;
            border-color: #fff !important
        }

        .btn-default-light-secondary.disabled:active,
        .btn-default-light-secondary.disabled:focus,
        .btn-default-light-secondary.disabled:hover,
        .btn-default-light-secondary:disabled:active,
        .btn-default-light-secondary:disabled:focus,
        .btn-default-light-secondary:disabled:hover {
            cursor: not-allowed;
            color: #fff !important;
            background: 0 0 !important;
            border-color: #fff !important
        }

        .btn-default-primary.btn-content-primary,
        .btn-default-primary.btn-filled,
        .btn-default-primary.btn-filled.disabled:active,
        .btn-default-primary.btn-filled.disabled:focus,
        .btn-default-primary.btn-filled.disabled:hover,
        .btn-default-primary.btn-filled:disabled:active,
        .btn-default-primary.btn-filled:disabled:focus,
        .btn-default-primary.btn-filled:disabled:hover {
            color: #111 !important;
            background-color: #fff !important
        }

        .btn-default-light-secondary.btn-pill,
        .btn-default-light-secondary.btn-tertiary {
            font-size: .75rem;
            line-height: 1rem;
            border-radius: 15px/50%;
            border-style: solid
        }

        .btn-default-light-secondary.btn-pill:focus,
        .btn-default-light-secondary.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-primary {
            color: #111 !important;
            background: #fff !important;
            border-color: #1976d2 !important
        }

        .btn-default-primary.btn-pill,
        .btn-default-primary.btn-pill.disabled:active,
        .btn-default-primary.btn-pill.disabled:focus,
        .btn-default-primary.btn-pill.disabled:hover,
        .btn-default-primary.btn-pill:disabled:active,
        .btn-default-primary.btn-pill:disabled:focus,
        .btn-default-primary.btn-pill:disabled:hover,
        .btn-default-primary.btn-sm,
        .btn-default-primary.btn-sm.disabled:active,
        .btn-default-primary.btn-sm.disabled:focus,
        .btn-default-primary.btn-sm.disabled:hover,
        .btn-default-primary.btn-sm:disabled:active,
        .btn-default-primary.btn-sm:disabled:focus,
        .btn-default-primary.btn-sm:disabled:hover,
        .btn-default-primary.btn-tertiary,
        .btn-default-primary.btn-tertiary.disabled:active,
        .btn-default-primary.btn-tertiary.disabled:focus,
        .btn-default-primary.btn-tertiary.disabled:hover,
        .btn-default-primary.btn-tertiary:disabled:active,
        .btn-default-primary.btn-tertiary:disabled:focus,
        .btn-default-primary.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-primary.btn,
        .btn-group-sm>.btn-default-primary.btn:disabled:active,
        .btn-group-sm>.btn-default-primary.btn:disabled:focus,
        .btn-group-sm>.btn-default-primary.btn:disabled:hover,
        .btn-group-sm>.btn-default-primary.disabled.btn:active,
        .btn-group-sm>.btn-default-primary.disabled.btn:focus,
        .btn-group-sm>.btn-default-primary.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #1976d2 !important
        }

        .btn-default-primary:hover {
            color: #fff !important;
            background: #4095e8 !important;
            border-color: #4095e8 !important
        }

        .btn-default-primary.focus,
        .btn-default-primary:focus {
            color: #fff !important;
            background-color: #4095e8 !important;
            border-color: #4095e8 !important
        }

        .btn-default-primary.active,
        .btn-default-primary:active,
        .open>.btn-default-primary.dropdown-toggle {
            color: #fff !important;
            background: #104a85 !important;
            border-color: #104a85 !important
        }

        .btn-default-purchase.btn-content-primary,
        .btn-default-purchase.btn-filled,
        .btn-default-purchase.btn-filled.disabled:active,
        .btn-default-purchase.btn-filled.disabled:focus,
        .btn-default-purchase.btn-filled.disabled:hover,
        .btn-default-purchase.btn-filled:disabled:active,
        .btn-default-purchase.btn-filled:disabled:focus,
        .btn-default-purchase.btn-filled:disabled:hover {
            color: #111 !important;
            background-color: #fff !important
        }

        .btn-default-primary.disabled:active,
        .btn-default-primary.disabled:focus,
        .btn-default-primary.disabled:hover,
        .btn-default-primary:disabled:active,
        .btn-default-primary:disabled:focus,
        .btn-default-primary:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #1976d2 !important
        }

        .btn-default-primary.btn-pill:focus,
        .btn-default-primary.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-purchase {
            color: #111 !important;
            background: #fff !important;
            border-color: #00a63f !important
        }

        .btn-default-purchase.btn-pill,
        .btn-default-purchase.btn-pill.disabled:active,
        .btn-default-purchase.btn-pill.disabled:focus,
        .btn-default-purchase.btn-pill.disabled:hover,
        .btn-default-purchase.btn-pill:disabled:active,
        .btn-default-purchase.btn-pill:disabled:focus,
        .btn-default-purchase.btn-pill:disabled:hover,
        .btn-default-purchase.btn-sm,
        .btn-default-purchase.btn-sm.disabled:active,
        .btn-default-purchase.btn-sm.disabled:focus,
        .btn-default-purchase.btn-sm.disabled:hover,
        .btn-default-purchase.btn-sm:disabled:active,
        .btn-default-purchase.btn-sm:disabled:focus,
        .btn-default-purchase.btn-sm:disabled:hover,
        .btn-default-purchase.btn-tertiary,
        .btn-default-purchase.btn-tertiary.disabled:active,
        .btn-default-purchase.btn-tertiary.disabled:focus,
        .btn-default-purchase.btn-tertiary.disabled:hover,
        .btn-default-purchase.btn-tertiary:disabled:active,
        .btn-default-purchase.btn-tertiary:disabled:focus,
        .btn-default-purchase.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-purchase.btn,
        .btn-group-sm>.btn-default-purchase.btn:disabled:active,
        .btn-group-sm>.btn-default-purchase.btn:disabled:focus,
        .btn-group-sm>.btn-default-purchase.btn:disabled:hover,
        .btn-group-sm>.btn-default-purchase.disabled.btn:active,
        .btn-group-sm>.btn-default-purchase.disabled.btn:focus,
        .btn-group-sm>.btn-default-purchase.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #00a63f !important
        }

        .btn-default-purchase:hover {
            color: #fff !important;
            background: #00782e !important;
            border-color: #00782e !important
        }

        .btn-default-purchase.focus,
        .btn-default-purchase:focus {
            color: #fff !important;
            background-color: #00782e !important;
            border-color: #00782e !important
        }

        .btn-default-purchase.active,
        .btn-default-purchase:active,
        .open>.btn-default-purchase.dropdown-toggle {
            color: #fff !important;
            background: #004f1e !important;
            border-color: #004f1e !important
        }

        .btn-default-info.btn-content-primary,
        .btn-default-info.btn-filled,
        .btn-default-info.btn-filled.disabled:active,
        .btn-default-info.btn-filled.disabled:focus,
        .btn-default-info.btn-filled.disabled:hover,
        .btn-default-info.btn-filled:disabled:active,
        .btn-default-info.btn-filled:disabled:focus,
        .btn-default-info.btn-filled:disabled:hover {
            color: #111 !important;
            background-color: #fff !important
        }

        .btn-default-purchase.disabled:active,
        .btn-default-purchase.disabled:focus,
        .btn-default-purchase.disabled:hover,
        .btn-default-purchase:disabled:active,
        .btn-default-purchase:disabled:focus,
        .btn-default-purchase:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #00a63f !important
        }

        .btn-default-purchase.btn-pill:focus,
        .btn-default-purchase.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-info {
            color: #111 !important;
            background: #fff !important;
            border-color: #9e42b5 !important
        }

        .btn-default-info.btn-pill,
        .btn-default-info.btn-pill.disabled:active,
        .btn-default-info.btn-pill.disabled:focus,
        .btn-default-info.btn-pill.disabled:hover,
        .btn-default-info.btn-pill:disabled:active,
        .btn-default-info.btn-pill:disabled:focus,
        .btn-default-info.btn-pill:disabled:hover,
        .btn-default-info.btn-sm,
        .btn-default-info.btn-sm.disabled:active,
        .btn-default-info.btn-sm.disabled:focus,
        .btn-default-info.btn-sm.disabled:hover,
        .btn-default-info.btn-sm:disabled:active,
        .btn-default-info.btn-sm:disabled:focus,
        .btn-default-info.btn-sm:disabled:hover,
        .btn-default-info.btn-tertiary,
        .btn-default-info.btn-tertiary.disabled:active,
        .btn-default-info.btn-tertiary.disabled:focus,
        .btn-default-info.btn-tertiary.disabled:hover,
        .btn-default-info.btn-tertiary:disabled:active,
        .btn-default-info.btn-tertiary:disabled:focus,
        .btn-default-info.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-info.btn,
        .btn-group-sm>.btn-default-info.btn:disabled:active,
        .btn-group-sm>.btn-default-info.btn:disabled:focus,
        .btn-group-sm>.btn-default-info.btn:disabled:hover,
        .btn-group-sm>.btn-default-info.disabled.btn:active,
        .btn-group-sm>.btn-default-info.disabled.btn:focus,
        .btn-group-sm>.btn-default-info.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #9e42b5 !important
        }

        .btn-default-info:hover {
            color: #fff !important;
            background: #813693 !important;
            border-color: #813693 !important
        }

        .btn-default-info.focus,
        .btn-default-info:focus {
            color: #fff !important;
            background-color: #813693 !important;
            border-color: #9e42b5 !important
        }

        .btn-default-info.active,
        .btn-default-info:active,
        .open>.btn-default-info.dropdown-toggle {
            color: #fff !important;
            background: #672b75 !important;
            border-color: #672b75 !important
        }

        .btn-default-warning.btn-content-primary,
        .btn-default-warning.btn-filled,
        .btn-default-warning.btn-filled.disabled:active,
        .btn-default-warning.btn-filled.disabled:focus,
        .btn-default-warning.btn-filled.disabled:hover,
        .btn-default-warning.btn-filled:disabled:active,
        .btn-default-warning.btn-filled:disabled:focus,
        .btn-default-warning.btn-filled:disabled:hover {
            background-color: #fff !important;
            color: #111 !important
        }

        .btn-default-info.disabled:active,
        .btn-default-info.disabled:focus,
        .btn-default-info.disabled:hover,
        .btn-default-info:disabled:active,
        .btn-default-info:disabled:focus,
        .btn-default-info:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #9e42b5 !important
        }

        .btn-default-info.btn-pill:focus,
        .btn-default-info.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-warning {
            color: #111 !important;
            background: #fff !important;
            border-color: #fedc45 !important
        }

        .btn-default-warning.btn-pill,
        .btn-default-warning.btn-pill.disabled:active,
        .btn-default-warning.btn-pill.disabled:focus,
        .btn-default-warning.btn-pill.disabled:hover,
        .btn-default-warning.btn-pill:disabled:active,
        .btn-default-warning.btn-pill:disabled:focus,
        .btn-default-warning.btn-pill:disabled:hover,
        .btn-default-warning.btn-sm,
        .btn-default-warning.btn-sm.disabled:active,
        .btn-default-warning.btn-sm.disabled:focus,
        .btn-default-warning.btn-sm.disabled:hover,
        .btn-default-warning.btn-sm:disabled:active,
        .btn-default-warning.btn-sm:disabled:focus,
        .btn-default-warning.btn-sm:disabled:hover,
        .btn-default-warning.btn-tertiary,
        .btn-default-warning.btn-tertiary.disabled:active,
        .btn-default-warning.btn-tertiary.disabled:focus,
        .btn-default-warning.btn-tertiary.disabled:hover,
        .btn-default-warning.btn-tertiary:disabled:active,
        .btn-default-warning.btn-tertiary:disabled:focus,
        .btn-default-warning.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-warning.btn,
        .btn-group-sm>.btn-default-warning.btn:disabled:active,
        .btn-group-sm>.btn-default-warning.btn:disabled:focus,
        .btn-group-sm>.btn-default-warning.btn:disabled:hover,
        .btn-group-sm>.btn-default-warning.disabled.btn:active,
        .btn-group-sm>.btn-default-warning.disabled.btn:focus,
        .btn-group-sm>.btn-default-warning.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #fedc45 !important
        }

        .btn-default-warning:hover {
            color: #111 !important;
            background: #fed317 !important;
            border-color: #fed317 !important
        }

        .btn-default-warning.focus,
        .btn-default-warning:focus {
            color: #111 !important;
            background-color: #fed317 !important;
            border-color: #111 !important
        }

        .btn-default-warning.active,
        .btn-default-warning:active,
        .open>.btn-default-warning.dropdown-toggle {
            color: #111 !important;
            background: #ebc001 !important;
            border-color: #ebc001 !important
        }

        .btn-default-danger.btn-content-primary,
        .btn-default-danger.btn-filled,
        .btn-default-danger.btn-filled.disabled:active,
        .btn-default-danger.btn-filled.disabled:focus,
        .btn-default-danger.btn-filled.disabled:hover,
        .btn-default-danger.btn-filled:disabled:active,
        .btn-default-danger.btn-filled:disabled:focus,
        .btn-default-danger.btn-filled:disabled:hover {
            color: #111 !important;
            background-color: #fff !important
        }

        .btn-default-warning.disabled:active,
        .btn-default-warning.disabled:focus,
        .btn-default-warning.disabled:hover,
        .btn-default-warning:disabled:active,
        .btn-default-warning:disabled:focus,
        .btn-default-warning:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #fedc45 !important
        }

        .btn-default-warning.btn-pill:focus,
        .btn-default-warning.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-danger {
            color: #111 !important;
            background: #fff !important;
            border-color: #db1802 !important
        }

        .btn-default-danger.btn-pill,
        .btn-default-danger.btn-pill.disabled:active,
        .btn-default-danger.btn-pill.disabled:focus,
        .btn-default-danger.btn-pill.disabled:hover,
        .btn-default-danger.btn-pill:disabled:active,
        .btn-default-danger.btn-pill:disabled:focus,
        .btn-default-danger.btn-pill:disabled:hover,
        .btn-default-danger.btn-sm,
        .btn-default-danger.btn-sm.disabled:active,
        .btn-default-danger.btn-sm.disabled:focus,
        .btn-default-danger.btn-sm.disabled:hover,
        .btn-default-danger.btn-sm:disabled:active,
        .btn-default-danger.btn-sm:disabled:focus,
        .btn-default-danger.btn-sm:disabled:hover,
        .btn-default-danger.btn-tertiary,
        .btn-default-danger.btn-tertiary.disabled:active,
        .btn-default-danger.btn-tertiary.disabled:focus,
        .btn-default-danger.btn-tertiary.disabled:hover,
        .btn-default-danger.btn-tertiary:disabled:active,
        .btn-default-danger.btn-tertiary:disabled:focus,
        .btn-default-danger.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-danger.btn,
        .btn-group-sm>.btn-default-danger.btn:disabled:active,
        .btn-group-sm>.btn-default-danger.btn:disabled:focus,
        .btn-group-sm>.btn-default-danger.btn:disabled:hover,
        .btn-group-sm>.btn-default-danger.disabled.btn:active,
        .btn-group-sm>.btn-default-danger.disabled.btn:focus,
        .btn-group-sm>.btn-default-danger.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #db1802 !important
        }

        .btn-default-danger:hover {
            color: #fff !important;
            background: #ae1302 !important;
            border-color: #ae1302 !important
        }

        .btn-default-danger.focus,
        .btn-default-danger:focus {
            color: #fff !important;
            background-color: #ae1302 !important;
            border-color: #ae1302 !important
        }

        .btn-default-danger.active,
        .btn-default-danger:active,
        .open>.btn-default-danger.dropdown-toggle {
            color: #fff !important;
            background: #850f01 !important;
            border-color: #850f01 !important
        }

        .btn-default-success.btn-content-primary,
        .btn-default-success.btn-filled,
        .btn-default-success.btn-filled.disabled:active,
        .btn-default-success.btn-filled.disabled:focus,
        .btn-default-success.btn-filled.disabled:hover,
        .btn-default-success.btn-filled:disabled:active,
        .btn-default-success.btn-filled:disabled:focus,
        .btn-default-success.btn-filled:disabled:hover {
            background-color: #fff !important;
            color: #111 !important
        }

        .btn-default-danger.disabled:active,
        .btn-default-danger.disabled:focus,
        .btn-default-danger.disabled:hover,
        .btn-default-danger:disabled:active,
        .btn-default-danger:disabled:focus,
        .btn-default-danger:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #db1802 !important
        }

        .btn-default-danger.btn-pill:focus,
        .btn-default-danger.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-success {
            color: #111 !important;
            background: #fff !important;
            border-color: #00a63f !important
        }

        .btn-default-success.btn-pill,
        .btn-default-success.btn-pill.disabled:active,
        .btn-default-success.btn-pill.disabled:focus,
        .btn-default-success.btn-pill.disabled:hover,
        .btn-default-success.btn-pill:disabled:active,
        .btn-default-success.btn-pill:disabled:focus,
        .btn-default-success.btn-pill:disabled:hover,
        .btn-default-success.btn-sm,
        .btn-default-success.btn-sm.disabled:active,
        .btn-default-success.btn-sm.disabled:focus,
        .btn-default-success.btn-sm.disabled:hover,
        .btn-default-success.btn-sm:disabled:active,
        .btn-default-success.btn-sm:disabled:focus,
        .btn-default-success.btn-sm:disabled:hover,
        .btn-default-success.btn-tertiary,
        .btn-default-success.btn-tertiary.disabled:active,
        .btn-default-success.btn-tertiary.disabled:focus,
        .btn-default-success.btn-tertiary.disabled:hover,
        .btn-default-success.btn-tertiary:disabled:active,
        .btn-default-success.btn-tertiary:disabled:focus,
        .btn-default-success.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-success.btn,
        .btn-group-sm>.btn-default-success.btn:disabled:active,
        .btn-group-sm>.btn-default-success.btn:disabled:focus,
        .btn-group-sm>.btn-default-success.btn:disabled:hover,
        .btn-group-sm>.btn-default-success.disabled.btn:active,
        .btn-group-sm>.btn-default-success.disabled.btn:focus,
        .btn-group-sm>.btn-default-success.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #00a63f !important
        }

        .btn-default-success:hover {
            color: #111 !important;
            background: #02c54c !important;
            border-color: #02c54c !important
        }

        .btn-default-success.focus,
        .btn-default-success:focus {
            color: #111 !important;
            background-color: #02c54c !important;
            border-color: #111 !important
        }

        .btn-default-success.active,
        .btn-default-success:active,
        .open>.btn-default-success.dropdown-toggle {
            color: #fff !important;
            background: #004f1e !important;
            border-color: #004f1e !important
        }

        .btn-default-feature.btn-content-primary,
        .btn-default-feature.btn-filled,
        .btn-default-feature.btn-filled.disabled:active,
        .btn-default-feature.btn-filled.disabled:focus,
        .btn-default-feature.btn-filled.disabled:hover,
        .btn-default-feature.btn-filled:disabled:active,
        .btn-default-feature.btn-filled:disabled:focus,
        .btn-default-feature.btn-filled:disabled:hover {
            color: #111 !important;
            background-color: #fff !important
        }

        .btn-default-success.disabled:active,
        .btn-default-success.disabled:focus,
        .btn-default-success.disabled:hover,
        .btn-default-success:disabled:active,
        .btn-default-success:disabled:focus,
        .btn-default-success:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #00a63f !important
        }

        .btn-default-success.btn-pill:focus,
        .btn-default-success.btn-tertiary:focus {
            border-style: solid
        }

        .btn-default-feature {
            color: #111 !important;
            background: #fff !important;
            border-color: #e20087 !important
        }

        .btn-default-feature.btn-pill,
        .btn-default-feature.btn-pill.disabled:active,
        .btn-default-feature.btn-pill.disabled:focus,
        .btn-default-feature.btn-pill.disabled:hover,
        .btn-default-feature.btn-pill:disabled:active,
        .btn-default-feature.btn-pill:disabled:focus,
        .btn-default-feature.btn-pill:disabled:hover,
        .btn-default-feature.btn-sm,
        .btn-default-feature.btn-sm.disabled:active,
        .btn-default-feature.btn-sm.disabled:focus,
        .btn-default-feature.btn-sm.disabled:hover,
        .btn-default-feature.btn-sm:disabled:active,
        .btn-default-feature.btn-sm:disabled:focus,
        .btn-default-feature.btn-sm:disabled:hover,
        .btn-default-feature.btn-tertiary,
        .btn-default-feature.btn-tertiary.disabled:active,
        .btn-default-feature.btn-tertiary.disabled:focus,
        .btn-default-feature.btn-tertiary.disabled:hover,
        .btn-default-feature.btn-tertiary:disabled:active,
        .btn-default-feature.btn-tertiary:disabled:focus,
        .btn-default-feature.btn-tertiary:disabled:hover,
        .btn-group-sm>.btn-default-feature.btn,
        .btn-group-sm>.btn-default-feature.btn:disabled:active,
        .btn-group-sm>.btn-default-feature.btn:disabled:focus,
        .btn-group-sm>.btn-default-feature.btn:disabled:hover,
        .btn-group-sm>.btn-default-feature.disabled.btn:active,
        .btn-group-sm>.btn-default-feature.disabled.btn:focus,
        .btn-group-sm>.btn-default-feature.disabled.btn:hover {
            color: #111 !important;
            background-color: #fff !important;
            border-color: #e20087 !important
        }

        .btn-default-feature:hover {
            color: #fff !important;
            background: #b4006c !important;
            border-color: #b4006c !important
        }

        .btn-default-feature.focus,
        .btn-default-feature:focus {
            color: #fff !important;
            background-color: #b4006c !important;
            border-color: #b4006c !important
        }

        .btn-default-feature.active,
        .btn-default-feature:active,
        .open>.btn-default-feature.dropdown-toggle {
            color: #fff !important;
            background: #8b0053 !important;
            border-color: #8b0053 !important
        }

        .btn-default-feature.disabled:active,
        .btn-default-feature.disabled:focus,
        .btn-default-feature.disabled:hover,
        .btn-default-feature:disabled:active,
        .btn-default-feature:disabled:focus,
        .btn-default-feature:disabled:hover {
            cursor: not-allowed;
            color: #111 !important;
            background: #fff !important;
            border-color: #e20087 !important
        }

        .btn-default-feature.btn-pill:focus,
        .btn-default-feature.btn-tertiary:focus {
            border-style: solid
        }

        .btn-group-lg>.btn,
        .btn-lg {
            padding: 12px 32px 14px;
            font-size: 1.25rem;
            line-height: 1.5rem;
            border-radius: 4px;
            border-width: 0
        }

        .btn-group-lg>.btn:focus,
        .btn-group-lg>.focus.btn,
        .btn-lg.focus,
        .btn-lg:focus {
            padding: 11px 31px 13px
        }

        .btn-group-sm>.btn,
        .btn-sm {
            padding: 5px 16px 7px;
            font-size: .875rem;
            line-height: 1.125rem;
            border-radius: 4px;
            border-width: 1px
        }

        .btn-group-sm>.btn:focus,
        .btn-group-sm>.focus.btn,
        .btn-sm.focus,
        .btn-sm:focus {
            padding: 5px 16px 7px
        }

        .btn-link {
            font-family: gdsherpa, Helvetica, Arial, sans-serif;
            padding-right: 0 !important;
            padding-left: 0 !important;
            color: #1976d2
        }

        .btn-link:focus,
        .btn-link:hover {
            color: #145fa9;
            text-decoration: underline
        }

        .btn-link:focus {
            outline: 0
        }

        .btn-tertiary,
        .btn-tertiary-inline {
            background-color: transparent;
            border: 0;
            padding: 0
        }

        .btn-tertiary-inline:focus,
        .btn-tertiary:focus {
            text-decoration: none;
            padding: 0;
            border: 0
        }

        .btn-tertiary-inline:after,
        .btn-tertiary:after {
            display: none;
            text-align: center;
            margin-top: .1em;
            content: "";
            font-family: uxfont;
            font-size: 1.125rem
        }

        .btn-addon,
        .nav {
            font-family: gdsherpa, Helvetica, Arial, sans-serif;
            font-weight: 700
        }

        .btn-tertiary-inline.more:after,
        .btn-tertiary.more:after {
            display: block;
            content: '\E443';
            color: #00a63f
        }

        .btn-tertiary-inline.less:after,
        .btn-tertiary.less:after {
            display: block;
            content: '\E444';
            color: #00a63f
        }

        .btn-tertiary-inline.disabled,
        .btn-tertiary-inline.disabled *,
        .btn-tertiary-inline.disabled :active,
        .btn-tertiary-inline.disabled :focus,
        .btn-tertiary-inline.disabled :hover,
        .btn-tertiary-inline.disabled:active,
        .btn-tertiary-inline.disabled:focus,
        .btn-tertiary-inline.disabled:hover,
        .btn-tertiary-inline:disabled,
        .btn-tertiary-inline:disabled *,
        .btn-tertiary-inline:disabled :active,
        .btn-tertiary-inline:disabled :focus,
        .btn-tertiary-inline:disabled :hover,
        .btn-tertiary-inline:disabled:active,
        .btn-tertiary-inline:disabled:focus,
        .btn-tertiary-inline:disabled:hover,
        .btn-tertiary.disabled,
        .btn-tertiary.disabled *,
        .btn-tertiary.disabled :active,
        .btn-tertiary.disabled :focus,
        .btn-tertiary.disabled :hover,
        .btn-tertiary.disabled:active,
        .btn-tertiary.disabled:focus,
        .btn-tertiary.disabled:hover,
        .btn-tertiary:disabled,
        .btn-tertiary:disabled *,
        .btn-tertiary:disabled :active,
        .btn-tertiary:disabled :focus,
        .btn-tertiary:disabled :hover,
        .btn-tertiary:disabled:active,
        .btn-tertiary:disabled:focus,
        .btn-tertiary:disabled:hover {
            color: #757575;
            border-color: #aab7c2
        }

        .btn-content {
            padding: 2px 10px;
            font-size: 12px;
            background-color: #fff;
            border: 1px solid #999
        }

        .btn-content.disabled *,
        .btn-content:active *,
        .btn-content:disabled * {
            color: inherit !important
        }

        .btn-content.disabled,
        .btn-content.disabled:active,
        .btn-content.disabled:focus,
        .btn-content.disabled:hover,
        .btn-content:disabled,
        .btn-content:disabled:active,
        .btn-content:disabled:focus,
        .btn-content:disabled:hover {
            color: #757575;
            border-color: #aab7c2;
            background-color: transparent;
            opacity: 1
        }

        .btn-default,
        .btn-default-danger,
        .btn-default-dark,
        .btn-default-feature,
        .btn-default-info,
        .btn-default-primary,
        .btn-default-purchase,
        .btn-default-success,
        .btn-default-warning {
            border-width: 1px;
            padding: 9px 23px
        }

        .btn-default-danger.focus,
        .btn-default-danger:focus,
        .btn-default-dark.focus,
        .btn-default-dark:focus,
        .btn-default-feature.focus,
        .btn-default-feature:focus,
        .btn-default-info.focus,
        .btn-default-info:focus,
        .btn-default-primary.focus,
        .btn-default-primary:focus,
        .btn-default-purchase.focus,
        .btn-default-purchase:focus,
        .btn-default-success.focus,
        .btn-default-success:focus,
        .btn-default-warning.focus,
        .btn-default-warning:focus,
        .btn-default.focus,
        .btn-default:focus {
            padding: 9px 23px
        }

        .btn-default-danger.btn-lg,
        .btn-default-dark.btn-lg,
        .btn-default-feature.btn-lg,
        .btn-default-info.btn-lg,
        .btn-default-primary.btn-lg,
        .btn-default-purchase.btn-lg,
        .btn-default-success.btn-lg,
        .btn-default-warning.btn-lg,
        .btn-default.btn-lg,
        .btn-group-lg>.btn-default-danger.btn,
        .btn-group-lg>.btn-default-dark.btn,
        .btn-group-lg>.btn-default-feature.btn,
        .btn-group-lg>.btn-default-info.btn,
        .btn-group-lg>.btn-default-primary.btn,
        .btn-group-lg>.btn-default-purchase.btn,
        .btn-group-lg>.btn-default-success.btn,
        .btn-group-lg>.btn-default-warning.btn,
        .btn-group-lg>.btn-default.btn {
            padding: 12px 31px
        }

        .btn-default-danger.btn-sm,
        .btn-default-dark.btn-sm,
        .btn-default-feature.btn-sm,
        .btn-default-info.btn-sm,
        .btn-default-primary.btn-sm,
        .btn-default-purchase.btn-sm,
        .btn-default-success.btn-sm,
        .btn-default-warning.btn-sm,
        .btn-default.btn-sm,
        .btn-group-sm>.btn-default-danger.btn,
        .btn-group-sm>.btn-default-dark.btn,
        .btn-group-sm>.btn-default-feature.btn,
        .btn-group-sm>.btn-default-info.btn,
        .btn-group-sm>.btn-default-primary.btn,
        .btn-group-sm>.btn-default-purchase.btn,
        .btn-group-sm>.btn-default-success.btn,
        .btn-group-sm>.btn-default-warning.btn,
        .btn-group-sm>.btn-default.btn {
            padding: 6px 15px
        }

        .btn-default-danger.btn.dropdown-split,
        .btn-default-dark.btn.dropdown-split,
        .btn-default-feature.btn.dropdown-split,
        .btn-default-info.btn.dropdown-split,
        .btn-default-primary.btn.dropdown-split,
        .btn-default-purchase.btn.dropdown-split,
        .btn-default-success.btn.dropdown-split,
        .btn-default-warning.btn.dropdown-split,
        .btn-default.btn.dropdown-split {
            border-right-width: 0
        }

        .btn-default-danger.disabled:active,
        .btn-default-danger.disabled:focus,
        .btn-default-danger.disabled:hover,
        .btn-default-danger:disabled:active,
        .btn-default-danger:disabled:focus,
        .btn-default-danger:disabled:hover,
        .btn-default-dark.disabled:active,
        .btn-default-dark.disabled:focus,
        .btn-default-dark.disabled:hover,
        .btn-default-dark:disabled:active,
        .btn-default-dark:disabled:focus,
        .btn-default-dark:disabled:hover,
        .btn-default-feature.disabled:active,
        .btn-default-feature.disabled:focus,
        .btn-default-feature.disabled:hover,
        .btn-default-feature:disabled:active,
        .btn-default-feature:disabled:focus,
        .btn-default-feature:disabled:hover,
        .btn-default-info.disabled:active,
        .btn-default-info.disabled:focus,
        .btn-default-info.disabled:hover,
        .btn-default-info:disabled:active,
        .btn-default-info:disabled:focus,
        .btn-default-info:disabled:hover,
        .btn-default-primary.disabled:active,
        .btn-default-primary.disabled:focus,
        .btn-default-primary.disabled:hover,
        .btn-default-primary:disabled:active,
        .btn-default-primary:disabled:focus,
        .btn-default-primary:disabled:hover,
        .btn-default-purchase.disabled:active,
        .btn-default-purchase.disabled:focus,
        .btn-default-purchase.disabled:hover,
        .btn-default-purchase:disabled:active,
        .btn-default-purchase:disabled:focus,
        .btn-default-purchase:disabled:hover,
        .btn-default-success.disabled:active,
        .btn-default-success.disabled:focus,
        .btn-default-success.disabled:hover,
        .btn-default-success:disabled:active,
        .btn-default-success:disabled:focus,
        .btn-default-success:disabled:hover,
        .btn-default-warning.disabled:active,
        .btn-default-warning.disabled:focus,
        .btn-default-warning.disabled:hover,
        .btn-default-warning:disabled:active,
        .btn-default-warning:disabled:focus,
        .btn-default-warning:disabled:hover,
        .btn-default.disabled:active,
        .btn-default.disabled:focus,
        .btn-default.disabled:hover,
        .btn-default:disabled:active,
        .btn-default:disabled:focus,
        .btn-default:disabled:hover {
            border-width: 1px
        }

        .btn-default-light.active,
        .btn-default-light.focus,
        .btn-default-light:active,
        .btn-default-light:focus,
        .btn-default-light:hover {
            border-width: 2px;
            padding: 7px 22px 9px
        }

        .btn-default-light.btn-lg.active,
        .btn-default-light.btn-lg.focus,
        .btn-default-light.btn-lg:active,
        .btn-default-light.btn-lg:focus,
        .btn-default-light.btn-lg:hover,
        .btn-group-lg>.btn-default-light.active.btn,
        .btn-group-lg>.btn-default-light.btn:active,
        .btn-group-lg>.btn-default-light.btn:focus,
        .btn-group-lg>.btn-default-light.btn:hover,
        .btn-group-lg>.btn-default-light.focus.btn {
            padding: 10px 30px 12px
        }

        .btn-default-light.btn-sm.active,
        .btn-default-light.btn-sm.focus,
        .btn-default-light.btn-sm:active,
        .btn-default-light.btn-sm:focus,
        .btn-default-light.btn-sm:hover,
        .btn-group-sm>.btn-default-light.active.btn,
        .btn-group-sm>.btn-default-light.btn:active,
        .btn-group-sm>.btn-default-light.btn:focus,
        .btn-group-sm>.btn-default-light.btn:hover,
        .btn-group-sm>.btn-default-light.focus.btn {
            padding: 4px 15px 6px
        }

        .btn-default-light.btn-pill.active,
        .btn-default-light.btn-pill.focus,
        .btn-default-light.btn-pill:active,
        .btn-default-light.btn-pill:focus,
        .btn-default-light.btn-pill:hover,
        .btn-default-light.btn-tertiary.active,
        .btn-default-light.btn-tertiary.focus,
        .btn-default-light.btn-tertiary:active,
        .btn-default-light.btn-tertiary:focus,
        .btn-default-light.btn-tertiary:hover {
            border-width: 2px !important;
            padding: 4px 15px !important
        }

        .btn-default-light-secondary {
            border-width: 2px;
            padding: 8px 22px
        }

        .btn-default-light-secondary.btn-lg,
        .btn-group-lg>.btn-default-light-secondary.btn {
            padding: 11px 30px
        }

        .btn-default-light-secondary.btn-sm,
        .btn-group-sm>.btn-default-light-secondary.btn {
            padding: 5px 15px
        }

        .btn-default-light-secondary:focus {
            padding: 9px 23px
        }

        .btn-default-light-secondary:focus.btn-lg,
        .btn-group-lg>.btn-default-light-secondary.btn:focus {
            padding: 12px 31px
        }

        .btn-default-light-secondary:focus.btn-sm,
        .btn-group-sm>.btn-default-light-secondary.btn:focus {
            padding: 6px 16px
        }

        .btn-default-light-secondary.btn-pill,
        .btn-default-light-secondary.btn-tertiary {
            border-width: 2px !important;
            padding: 4px 15px !important
        }

        .btn-canvas {
            border-width: 0
        }

        .btn-addon {
            padding: 9px 24px;
            color: #2b2b2b;
            background-color: #e9ecef;
            border: 1px solid #aab7c2;
            font-size: 1rem
        }

        .btn-group-vertical>.btn-group:not(:first-child):not(:last-child)>.btn,
        .btn-group-vertical>.btn:not(:first-child):not(:last-child),
        .btn-group>.btn-group:not(:first-child):not(:last-child)>.btn,
        .btn-group>.btn:not(:first-child):not(:last-child):not(.dropdown-toggle) {
            border-radius: 0
        }

        .btn-addon:focus,
        .btn-addon:hover {
            color: #00a63f;
            padding: 9px 24px
        }

        .btn-addon.btn-sm,
        .btn-group-sm>.btn-addon.btn {
            padding: 5px 16px
        }

        .btn-addon.btn-lg,
        .btn-group-lg>.btn-addon.btn {
            padding: 12px 32px
        }

        .btn-addon.disabled:active,
        .btn-addon.disabled:focus,
        .btn-addon.disabled:hover,
        .btn-addon:disabled:active,
        .btn-addon:disabled:focus,
        .btn-addon:disabled:hover {
            color: #2b2b2b;
            background-color: #e9ecef;
            cursor: not-allowed
        }

        .btn-toggle {
            color: #757575;
            background-color: #f5f7f8;
            border-color: #aab7c2;
            margin-left: 0 !important
        }

        .btn-toggle.active {
            color: #fff;
            background-color: #00a63f;
            border-color: #00a63f
        }

        .btn-group,
        .btn-group-vertical {
            position: relative;
            display: inline-flex;
            z-index: 1;
            vertical-align: middle
        }

        .btn-group-vertical>.btn.active,
        .btn-group-vertical>.btn:active,
        .btn-group-vertical>.btn:focus,
        .btn-group-vertical>.btn:hover,
        .btn-group>.btn,
        .btn-group>.btn.active,
        .btn-group>.btn:active,
        .btn-group>.btn:focus,
        .btn-group>.btn:hover {
            z-index: 2
        }

        .btn-group-vertical>.btn,
        .btn-group>.btn {
            position: relative;
            flex: 0 1 auto
        }

        .btn-group .btn+.btn,
        .btn-group .btn+.btn-group,
        .btn-group .btn-group+.btn,
        .btn-group .btn-group+.btn-group,
        .btn-group-vertical .btn+.btn,
        .btn-group-vertical .btn+.btn-group,
        .btn-group-vertical .btn-group+.btn,
        .btn-group-vertical .btn-group+.btn-group {
            margin-left: -1px
        }

        .btn+.dropdown-toggle-split::after,
        .btn-group>.btn:first-child {
            margin-left: 0
        }

        .btn-toolbar {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start
        }

        .btn-toolbar .input-group {
            width: auto
        }

        .btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle) {
            border-bottom-right-radius: 0;
            border-top-right-radius: 0
        }

        .btn-group>.btn:last-child:not(:first-child),
        .btn-group>.dropdown-toggle:not(:first-child) {
            border-bottom-left-radius: 0;
            border-top-left-radius: 0
        }

        .btn-group>.btn-group {
            float: left
        }

        .btn-group>.btn-group:first-child:not(:last-child)>.btn:last-child,
        .btn-group>.btn-group:first-child:not(:last-child)>.dropdown-toggle {
            border-bottom-right-radius: 0;
            border-top-right-radius: 0
        }

        .btn-group>.btn-group:last-child:not(:first-child)>.btn:first-child {
            border-bottom-left-radius: 0;
            border-top-left-radius: 0
        }

        .btn-group-lg>.btn+.dropdown-toggle-split,
        .btn-group-sm>.btn+.dropdown-toggle-split,
        .btn-lg+.dropdown-toggle-split,
        .btn-sm+.dropdown-toggle-split {
            padding-right: 9px;
            padding-left: 9px
        }

        .btn-group.show .dropdown-toggle {
            box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125)
        }

        .btn-group.show .dropdown-toggle.btn-link,
        .dropdown-menu {
            box-shadow: none
        }

        .btn-group-vertical {
            flex-direction: column;
            align-items: flex-start;
            justify-content: center
        }

        .btn-group-vertical .btn,
        .btn-group-vertical .btn-group {
            width: 100%
        }

        .btn-group-vertical>.btn+.btn,
        .btn-group-vertical>.btn+.btn-group,
        .btn-group-vertical>.btn-group+.btn,
        .btn-group-vertical>.btn-group+.btn-group {
            margin-top: -1px;
            margin-left: 0
        }

        .btn-group-vertical>.btn:first-child:not(:last-child) {
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group-vertical>.btn:last-child:not(:first-child) {
            border-top-right-radius: 0;
            border-top-left-radius: 0
        }

        .btn-group-vertical>.btn-group:first-child:not(:last-child)>.btn:last-child,
        .btn-group-vertical>.btn-group:first-child:not(:last-child)>.dropdown-toggle {
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group-vertical>.btn-group:last-child:not(:first-child)>.btn:first-child {
            border-top-right-radius: 0;
            border-top-left-radius: 0
        }

        [data-toggle=buttons]>.btn input[type=radio],
        [data-toggle=buttons]>.btn input[type=checkbox],
        [data-toggle=buttons]>.btn-group>.btn input[type=radio],
        [data-toggle=buttons]>.btn-group>.btn input[type=checkbox] {
            position: absolute;
            clip: rect(0, 0, 0, 0);
            pointer-events: none
        }

        .btn-group-lg>.btn+.dropdown-toggle-split,
        .btn-lg+.dropdown-toggle-split {
            padding-right: 12px;
            padding-left: 12px
        }

        .float-left,
        .pull-left {
            float: left !important
        }

        .float-right,
        .pull-right {
            float: right !important
        }

        .float-none {
            float: none !important
        }

        @media (min-width:520px) {

            .float-sm-left,
            .pull-sm-left {
                float: left !important
            }

            .float-sm-right,
            .pull-sm-right {
                float: right !important
            }

            .float-sm-none {
                float: none !important
            }
        }

        @media (min-width:768px) {

            .float-md-left,
            .pull-md-left {
                float: left !important
            }

            .float-md-right,
            .pull-md-right {
                float: right !important
            }

            .float-md-none {
                float: none !important
            }
        }

        @media (min-width:992px) {
            .btn {
                max-width: 360px
            }

            .float-lg-left,
            .pull-lg-left {
                float: left !important
            }

            .float-lg-right,
            .pull-lg-right {
                float: right !important
            }

            .float-lg-none {
                float: none !important
            }
        }

        @media (min-width:1200px) {

            .float-xl-left,
            .pull-xl-left {
                float: left !important
            }

            .float-xl-right,
            .pull-xl-right {
                float: right !important
            }

            .float-xl-none {
                float: none !important
            }
        }

        .ux-search {
            margin-bottom: 24px
        }

        .ux-search fieldset {
            display: flex;
            flex-grow: 1
        }

        .ux-search .form-group {
            margin-bottom: 0
        }

        .ux-search .form-group label {
            display: none
        }

        .ux-search .form-control::-ms-clear {
            display: none
        }

        .ux-search .ux-search-list-container {
            border-radius: 0 0 6px 6px;
            text-align: left;
            position: absolute;
            width: calc(100% - 1px);
            background-color: #fff;
            z-index: 1030;
            top: calc(100% - 1px);
            left: 0;
            border: 1px solid #111;
            overflow-y: auto;
            max-height: 315px
        }

        .ux-search .dropdown-item {
            cursor: pointer;
            display: block;
            padding: 10px 15px;
            text-decoration: none;
            margin-bottom: 0
        }

        .ux-search .dropdown-item.active.disabled {
            color: #aab7c2
        }

        .ux-search .dropdown-item:hover {
            border-bottom: 0
        }

        .ux-search .dropdown-item:focus {
            color: #111;
            background: 0 0
        }

        .ux-search .dropdown-item.active,
        .ux-search .dropdown-item:hover {
            color: #1976d2;
            text-decoration: none;
            background-color: #f5f7f8;
            outline: 0
        }

        .ux-search .form-control {
            border-radius: 6px 0 0 6px !important
        }

        .ux-search .form-control+.form-element-clear {
            z-index: 1033;
            margin-top: 0;
            top: 6px
        }

        .ux-search .form-control.form-control-lg+.form-element-clear,
        .ux-search .input-group-lg>.form-control+.form-element-clear,
        .ux-search .input-group-lg>.input-group-btn>.form-control.btn+.form-element-clear {
            margin-top: 0;
            top: 11px
        }

        .ux-search .form-control.form-control-sm+.form-element-clear,
        .ux-search .input-group-sm>.form-control+.form-element-clear,
        .ux-search .input-group-sm>.input-group-btn>.form-control.btn+.form-element-clear {
            margin-top: 0;
            top: 2px
        }

        .ux-search .input-group-btn {
            vertical-align: top
        }

        .dropdown-toggle:after,
        .dropright .dropdown-toggle:after,
        .dropup .dropdown-toggle:after {
            vertical-align: middle
        }

        .ux-search .btn-icon {
            min-width: 0
        }

        .ux-search .ux-search-lookahead {
            display: none
        }

        .ux-search.open .btn {
            border-radius: 0 6px 0 0;
            margin-right: 0
        }

        .ux-search.open .form-control {
            border: 1px solid #111;
            border-bottom-color: #aab7c2;
            border-bottom-left-radius: 0 !important;
            z-index: 1031
        }

        .ux-search.open .ux-search-lookahead {
            display: block;
            text-align: left;
            position: absolute;
            margin: -2px 0 0;
            z-index: 1032;
            border: 0;
            padding: 0;
            height: 0;
            top: 10px;
            left: 14px;
            color: #757575;
            -webkit-user-select: none;
            user-select: none
        }

        .nav-inline .nav-item,
        .nav-link {
            display: inline-block
        }

        .nav-link.disabled,
        .nav-tabs .nav-link.disabled,
        .nav-tabs .nav-link.disabled:focus,
        .nav-tabs .nav-link.disabled:hover {
            color: #868e96
        }

        .ux-pivot,
        .ux-toggle {
            -webkit-user-select: none
        }

        .nav {
            padding-left: 0;
            margin-bottom: 0
        }

        .nav-link.disabled,
        .nav-link.disabled:focus,
        .nav-link.disabled:hover {
            color: #868e96;
            cursor: not-allowed;
            background-color: transparent
        }

        .nav-pills::after,
        .nav-tabs::after {
            display: table;
            content: "";
            clear: both
        }

        .nav-inline .nav-item+.nav-item,
        .nav-inline .nav-link+.nav-link {
            margin-left: 1rem
        }

        .nav-tabs {
            border-bottom: 1px solid #aab7c2
        }

        .nav-tabs .nav-item {
            margin-bottom: -1px
        }

        .nav-tabs .nav-link {
            border: 1px solid transparent;
            border-top-right-radius: 6px;
            border-top-left-radius: 6px
        }

        .nav-tabs .nav-link:focus,
        .nav-tabs .nav-link:hover {
            border-color: #aab7c2
        }

        .nav-tabs .nav-item.open .nav-link,
        .nav-tabs .nav-item.open .nav-link:focus,
        .nav-tabs .nav-item.open .nav-link:hover,
        .nav-tabs .nav-link.active,
        .nav-tabs .nav-link.active:focus,
        .nav-tabs .nav-link.active:hover {
            color: inherit;
            background-color: #fff;
            border-color: #aab7c2 #aab7c2 transparent
        }

        .nav-tabs .dropdown-menu {
            margin-top: -1px;
            border-top-right-radius: 0;
            border-top-left-radius: 0
        }

        .nav-pills .nav-item {
            float: left
        }

        .nav-pills .nav-item+.nav-item {
            margin-left: .2rem
        }

        .nav-pills .nav-link {
            display: block;
            padding: 15px 30px;
            border-radius: 6px
        }

        .nav-pills .nav-item.open .nav-link,
        .nav-pills .nav-item.open .nav-link:focus,
        .nav-pills .nav-item.open .nav-link:hover,
        .nav-pills .nav-link.active,
        .nav-pills .nav-link.active:focus,
        .nav-pills .nav-link.active:hover {
            color: #1976d2;
            cursor: default;
            background-color: #f5f7f8
        }

        .nav-stacked .nav-item {
            display: block;
            float: none
        }

        .nav-stacked .nav-item+.nav-item {
            margin-top: .2rem;
            margin-left: 0
        }

        .tab-content>.tab-pane {
            display: none
        }

        .tab-content>.active {
            display: block
        }

        .nav {
            font-size: .875rem;
            display: flex;
            flex-wrap: nowrap
        }

        .dropdown-toggle:after,
        .ux-conveyor-control:before {
            font-family: uxfont
        }

        .nav-item {
            margin: 0
        }

        .nav-link {
            padding: 15px 30px;
            color: #000;
            text-decoration: none
        }

        .nav-link:focus,
        .nav-link:hover {
            text-decoration: none;
            color: #000;
            background-color: #f5f7f8;
            outline: 0
        }

        .nav-tabs {
            position: relative;
            font-size: 0;
            transition: margin-left .5s;
            display: flex;
            flex-wrap: nowrap
        }

        .nav-tabs .nav-item {
            display: inline-flex;
            float: none
        }

        .nav-tabs .nav-item+.nav-item {
            margin-left: -1px
        }

        .dropdown-toggle:empty:after,
        .dropup .dropdown-toggle:empty:after {
            margin-left: .255em
        }

        .nav-tabs .nav-link {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 2.75rem;
            padding: 4px 16px;
            font-size: .875rem;
            font-weight: 700;
            line-height: 1.2;
            white-space: nowrap;
            background-color: #f5f7f8;
            border-color: #aab7c2;
            transition: all .1s;
            color: #757575;
            cursor: pointer
        }

        @media (min-width:768px) {
            .nav-tabs .nav-link {
                height: 3.25rem;
                padding: 4px 32px;
                font-size: 1rem
            }
        }

        .nav-tabs .nav-link:focus,
        .nav-tabs .nav-link:hover {
            color: #00a63f;
            background-color: #fff
        }

        .nav-tabs .nav-link .nav-item.open .nav-link,
        .nav-tabs .nav-link.active {
            position: relative;
            color: #111;
            z-index: 1;
            cursor: default
        }

        .nav-tabs .nav-link .nav-item.open .nav-link::after,
        .nav-tabs .nav-link.active::after {
            position: absolute;
            top: -1px;
            right: -1px;
            left: -1px;
            display: block;
            height: 4px;
            content: "";
            background-color: #00a63f;
            border-radius: 6px 6px 0 0
        }

        .ux-conveyor,
        .ux-conveyor-clip {
            overflow: hidden;
            position: relative
        }

        .nav-tabs .nav-link.disabled,
        .nav-tabs .nav-link.disabled:focus,
        .nav-tabs .nav-link.disabled:hover {
            background-color: #f5f7f8;
            color: rgba(117, 117, 117, .3);
            border-color: #aab7c2
        }

        .ux-conveyor-clip {
            height: 3.25rem;
            margin-bottom: 25px
        }

        .ux-conveyor {
            height: 4.34375rem
        }

        .ux-conveyor .nav-tabs .nav-link.active::after {
            background-color: transparent
        }

        .ux-conveyor .nav-tabs .nav-link:not(.active) {
            background-color: transparent;
            color: #1976d2;
            border-color: transparent;
            font-weight: 400
        }

        .ux-conveyor .nav-tabs .nav-link:focus,
        .ux-conveyor .nav-tabs .nav-link:hover {
            color: #145fa9
        }

        .ux-conveyor .nav-tabs .nav-link.active,
        .ux-conveyor .nav-tabs .nav-link.active:focus,
        .ux-conveyor .nav-tabs .nav-link.active:hover {
            border-color: #aab7c2, ;
            background-color: #fff;
            border-radius: 3px;
            font-weight: 700;
            color: #444
        }

        .ux-conveyor-control {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            display: none;
            width: 40px;
            z-index: 2;
            color: #444;
            background-color: #fff;
            border: 1px solid #aab7c2;
            text-decoration: none;
            align-items: center;
            justify-content: center
        }

        @media (max-width:991px) {
            .ux-conveyor {
                overflow-x: auto
            }

            .ux-conveyor-control {
                display: none !important
            }
        }

        .ux-conveyor-control:focus,
        .ux-conveyor-control:hover {
            color: #1976d2;
            text-decoration: none
        }

        .ux-conveyor-control:before {
            display: flex;
            content: "";
            font-size: .68rem;
            margin-top: 0
        }

        .ux-conveyor-control.left:before {
            content: '\E446'
        }

        .ux-conveyor-control.right {
            right: 0;
            left: auto
        }

        .ux-conveyor-control.right:before {
            content: '\E445'
        }

        .dropdown,
        .dropleft,
        .dropright,
        .dropup {
            position: relative
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1000;
            float: left;
            font-size: 1rem;
            color: #444;
            text-align: left;
            background-color: #fff;
            background-clip: padding-box;
            border-radius: 6px
        }

        .dropdown-menu-right {
            right: 0;
            left: auto
        }

        .dropup .dropdown-menu {
            top: auto;
            bottom: 100%;
            margin-top: 0;
            margin-bottom: 0
        }

        .dropright .dropdown-menu {
            top: 0;
            right: auto;
            left: 100%;
            margin-top: 0;
            margin-left: .125rem
        }

        .dropleft .dropdown-toggle:empty:after,
        .dropright .dropdown-toggle:empty:after {
            margin-left: .255em
        }

        .dropright .dropdown-toggle::after {
            vertical-align: 0
        }

        .dropleft .dropdown-menu {
            top: 0;
            right: 100%;
            left: auto;
            margin-top: 0;
            margin-right: .125rem
        }

        .dropleft .dropdown-toggle:after {
            vertical-align: middle
        }

        .dropleft .dropdown-toggle::before {
            vertical-align: 0
        }

        .dropdown-menu[x-placement^=top],
        .dropdown-menu[x-placement^=right],
        .dropdown-menu[x-placement^=bottom],
        .dropdown-menu[x-placement^=left] {
            right: auto;
            bottom: auto
        }

        .dropdown-divider {
            height: 0;
            overflow: hidden;
            border-top: 1px solid #e8eaeb
        }

        .dropdown-item {
            width: 100%;
            clear: both;
            font-weight: 400;
            color: #111;
            text-align: inherit;
            white-space: nowrap;
            background-color: transparent;
            border: 0
        }

        .dropdown-item.active,
        .dropdown-item:active,
        .dropdown-item:focus,
        .dropdown-item:hover {
            color: #1976d2;
            text-decoration: none;
            background-color: #f5f7f8
        }

        .dropdown-item.disabled,
        .dropdown-item:disabled {
            color: #868e96;
            background-color: transparent
        }

        .dropdown-menu.show {
            display: block
        }

        .dropdown-header {
            margin-bottom: 0;
            font-size: .875rem;
            white-space: nowrap
        }

        .dropdown-item-text {
            display: block;
            padding: .25rem 1.25rem;
            color: #111
        }

        @media (max-width:519px) {
            body.dropdown-open {
                overflow: hidden
            }

            .dropdown.full-screen,
            .dropup.full-screen {
                position: unset
            }
        }

        .dropdown .form-control,
        .dropup .form-control {
            line-height: 1;
            padding-top: 11px;
            padding-bottom: 11px;
            cursor: pointer
        }

        .dropdown.dropdown-disabled,
        .dropup.dropdown-disabled {
            cursor: not-allowed
        }

        .ux-select-dropdown,
        .ux-toggle {
            cursor: pointer
        }

        .dropdown.dropdown-disabled .form-control,
        .dropup.dropdown-disabled .form-control {
            border-color: #aab7c2;
            background-color: #f5f7f8
        }

        .dropdown.dropdown-disabled .form-control:focus,
        .dropup.dropdown-disabled .form-control:focus {
            color: #757575;
            border-color: #aab7c2
        }

        .dropdown:not(.ux-select-dropdown) {
            display: inline-block
        }

        .ux-select-dropdown .form-control {
            min-height: 40px;
            height: auto;
            display: flex;
            flex-direction: row-reverse;
            align-items: center
        }

        .ux-select-dropdown .form-control.form-control-lg,
        .ux-select-dropdown .input-group-lg>.form-control,
        .ux-select-dropdown .input-group-lg>.input-group-btn>.form-control.btn {
            min-height: 50px
        }

        .ux-select-dropdown .form-control.form-control-sm,
        .ux-select-dropdown .input-group-sm>.form-control,
        .ux-select-dropdown .input-group-sm>.input-group-btn>.form-control.btn {
            min-height: 32px
        }

        .ux-select-dropdown .form-control.placeholder {
            color: #757575
        }

        .ux-select-dropdown .form-control .dropdown-toggle {
            display: inline-flex;
            flex-grow: 0
        }

        .ux-select-dropdown .form-control .dropdown-text {
            justify-content: flex-start;
            flex-grow: 1
        }

        .ux-select-dropdown .uxicon-clock {
            font-size: 1.375rem;
            position: absolute;
            right: 8px;
            top: 9px
        }

        .ux-select-dropdown .dropdown-toggle {
            color: #111
        }

        .ux-select-dropdown:hover .dropdown-toggle,
        .ux-select-dropdown:hover .uxicon-clock {
            color: #00a63f
        }

        .ux-select-dropdown.dropdown-disabled .dropdown-toggle,
        .ux-select-dropdown.dropdown-disabled .uxicon-clock,
        .ux-select-dropdown.dropdown-disabled:hover .dropdown-toggle,
        .ux-select-dropdown.dropdown-disabled:hover .uxicon-clock {
            color: #757575
        }

        .ux-select-dropdown.error .form-control {
            background-color: #fadcd9;
            border-color: #fd341d
        }

        .dropdown-toggle:after {
            display: inline;
            margin-left: .3125rem;
            font-size: .68rem;
            line-height: .6;
            content: "\E443";
            border: 0;
            padding-top: 2px
        }

        .btn-dropdown {
            line-height: 1.25rem
        }

        .dropup>.dropdown-toggle::after,
        .open>.dropdown-toggle::after {
            content: "\E444"
        }

        .dropup .dropdown-toggle::after {
            border: 0
        }

        .dropdown-menu {
            display: none;
            padding: 0;
            margin: 0;
            min-width: 100%;
            border: 1px solid #111;
            font-family: gdsherpa, Helvetica, Arial, sans-serif
        }

        .dropdown-menu>.dropdown-menu-background>.close {
            display: none
        }

        @media (max-width:519px) {
            .dropdown-menu.full-screen {
                border: 0;
                background-color: transparent;
                position: fixed;
                display: block;
                visibility: hidden;
                top: 0;
                left: 0;
                bottom: 0;
                right: 0;
                z-index: 1000010
            }

            .dropdown-menu.full-screen>.dropdown-overlay {
                background: #000;
                width: 100vw;
                height: 100vh;
                z-index: 1005;
                display: block;
                opacity: 0;
                position: relative;
                transition: all .6s
            }

            .dropdown-menu.full-screen>.dropdown-menu-background {
                box-shadow: 0 1px 8px 0 rgba(117, 117, 117, .3);
                background: #fff;
                transform: translateY(120%);
                position: fixed;
                bottom: 3vh;
                width: 90vw;
                z-index: 1010;
                transition: all .6s;
                left: 5vw;
                display: flex;
                flex-direction: column;
                align-items: stretch;
                max-height: 95vh
            }

            .dropdown-menu.full-screen>.dropdown-menu-background .dropdown-list {
                max-height: 85vh;
                overflow: auto;
                align-self: stretch;
                min-height: 3rem
            }

            .dropdown-menu.full-screen>.dropdown-menu-background .dropdown-item {
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: normal;
                cursor: pointer
            }

            .dropdown-menu.full-screen>.dropdown-menu-background>.close {
                color: #111;
                display: block;
                font-size: 30px;
                padding: 8px 16px;
                width: 3rem;
                min-height: 3rem;
                align-self: flex-end;
                cursor: pointer
            }

            .dropdown-menu.full-screen>.dropdown-menu-background>.close:hover {
                color: #1976d2
            }
        }

        .dropdown-header,
        .ux-tel-container {
            position: relative
        }

        .dropdown-menu.dropdown-menu-autoalign {
            opacity: 0;
            display: block;
            visibility: hidden
        }

        .dropdown.open>.btn-dropdown+.dropdown-menu,
        .dropdown.open>.btn-group+.dropdown-menu {
            border-radius: 6px;
            margin-top: 1px
        }

        .dropdown.open>.form-control {
            border-radius: 6px 6px 0 0;
            border-color: #111 #111 #aab7c2;
            border-width: 1px
        }

        .dropdown.open>.form-control .uxicon-clock {
            right: 8px;
            top: 9px
        }

        @media (max-width:519px) {
            .dropdown.open>.form-control {
                position: relative;
                border-color: #111;
                z-index: 1001
            }

            .dropdown.open.full-screen>.form-control {
                border-width: 1px;
                border-radius: 6px
            }
        }

        .dropdown.open>.dropdown-menu {
            border-radius: 0 0 6px 6px;
            display: block;
            border-width: 1px;
            margin-top: -1px;
            max-height: 315px;
            overflow-y: auto;
            top: 100%;
            bottom: initial;
            width: auto
        }

        .modal,
        .modal-open {
            overflow: hidden
        }

        @media (max-width:519px) {
            .dropdown.open>.dropdown-menu.full-screen {
                border-radius: 0;
                visibility: visible;
                top: 0;
                left: 0;
                bottom: 0;
                right: 0;
                max-height: initial
            }

            .dropdown.open>.dropdown-menu.full-screen>.dropdown-overlay {
                opacity: .5
            }

            .dropdown.open>.dropdown-menu.full-screen>.dropdown-menu-background {
                transform: translateY(0)
            }
        }

        .dropdown.open>.dropdown-menu.full-screen.dropdown-menu-autoalign {
            opacity: 1;
            visibility: visible
        }

        .dropdown.open.menu-up>.form-control {
            border-radius: 0 0 6px 6px;
            border-color: #aab7c2 #111 #111;
            border-width: 1px
        }

        .dropdown.open.menu-up>.dropdown-menu {
            border-radius: 6px 6px 0 0;
            top: initial;
            bottom: 100%;
            margin-bottom: -1px
        }

        .dropdown.open.menu-up.has-label>.dropdown-menu {
            bottom: 60%
        }

        .dropdown.open .dropdown-toggle-split:after {
            content: '\E444'
        }

        .dropdown-divider {
            margin: 0
        }

        label.dropdown-item {
            margin: 0;
            font-size: inherit;
            font-family: inherit;
            text-transform: inherit
        }

        .tooltip,
        .tooltip-title,
        .ux-tel-btn,
        .ux-toggle .ux-toggle-message {
            font-family: gdsherpa, Helvetica, Arial, sans-serif
        }

        label.dropdown-item input[type=checkbox] {
            margin-right: 8px
        }

        .dropdown-item,
        a.dropdown-item {
            display: flex;
            flex-grow: 1;
            align-items: center;
            padding: 10px 15px;
            text-decoration: none;
            margin-bottom: 0
        }

        .dropdown-item:hover,
        a.dropdown-item:hover {
            border-bottom: 0
        }

        .dropdown-item:focus,
        a.dropdown-item:focus {
            color: #111;
            background: 0 0
        }

        .dropdown-item.disabled:focus,
        a.dropdown-item.disabled:focus {
            outline: 0
        }

        .dropdown-item.active,
        .dropdown-item.active:focus,
        .dropdown-item.active:hover,
        a.dropdown-item.active,
        a.dropdown-item.active:focus,
        a.dropdown-item.active:hover {
            color: #1976d2;
            text-decoration: none;
            background-color: #f5f7f8;
            outline: 0
        }

        .dropdown-header {
            color: #111;
            font-weight: 700;
            display: flex;
            flex-grow: 1;
            padding: 8px 16px;
            margin: 0
        }

        .dropdown-split {
            min-width: 0
        }

        .btn+.dropdown-toggle-split,
        .dropdown-split+.dropdown-toggle {
            width: auto;
            min-width: 0;
            max-width: none;
            padding-right: .5em;
            padding-left: .5em;
            border-left: 1px solid
        }

        .btn+.dropdown-toggle-split.focus,
        .btn+.dropdown-toggle-split:focus,
        .dropdown-split+.dropdown-toggle.focus,
        .dropdown-split+.dropdown-toggle:focus {
            border-right: 0
        }

        .btn+.dropdown-toggle-split::after,
        .dropdown-split+.dropdown-toggle::after {
            margin: 0
        }

        .triple-dot-dropdown {
            width: 48px;
            cursor: pointer;
            text-align: center
        }

        .triple-dot-dropdown.open {
            background-color: #f5f7f8;
            border-radius: 4px
        }

        .triple-dot-dropdown.open>.dropdown-menu {
            margin-top: 5px;
            right: 0;
            left: auto;
            border-top: 1px solid #000;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px
        }

        .triple-dot-dropdown.open>.dropdown-menu.dropdown-menu-left {
            right: auto;
            left: 0
        }

        .triple-dot-dropdown>.form-control {
            border: 0;
            background-color: transparent;
            padding: 10px !important
        }

        .triple-dot-dropdown>.form-control>.uxicon-ellipses {
            font-size: 22px
        }

        .triple-dot-dropdown.dropdown.dropdown-disabled .form-control:focus {
            color: #2b2b2b
        }

        .triple-dot-dropdown.dropdown.dropdown-disabled .uxicon {
            opacity: .3
        }

        div[class^=col-].dropdown .dropdown-menu-left {
            left: 10px
        }

        div[class^=col-].dropdown .dropdown-menu-right {
            right: 10px
        }

        .ux-tel-btn {
            position: absolute;
            height: 38px;
            background-color: #f5f7f8;
            font-size: 16px;
            top: 1px;
            left: 1px;
            border-right: 1px solid #aab7c2;
            padding: 7px 14px 8px;
            min-width: auto;
            border-radius: 5px 0 0 5px
        }

        .ux-toggle,
        .ux-toggle .ux-toggle-bg {
            position: relative;
            display: inline-flex
        }

        .ux-tel-btn .uxicon {
            font-size: 10px;
            margin: 0 0 0 15px;
            top: -2px
        }

        .ux-tel-btn:focus {
            padding: 7px 14px 8px 13px;
            border-right-style: solid
        }

        .ux-tel-input {
            padding-left: 138px
        }

        .ux-toggle {
            z-index: 1;
            margin-bottom: 0;
            font-size: 0;
            vertical-align: -7px;
            user-select: none;
            margin-right: 10px;
            line-height: 1
        }

        .ux-toggle .ux-toggle-bg {
            border-radius: 15px;
            z-index: 2;
            width: 50px;
            height: 30px;
            background-color: #fff;
            border: 2px solid #aab7c2;
            transition: background .1s ease-out, border .1s ease-out
        }

        .ux-toggle .ux-toggle-handle,
        .ux-toggle.small .ux-toggle-handle {
            border-radius: 50%;
            cursor: pointer;
            display: inline-flex;
            position: absolute
        }

        .ux-toggle .ux-toggle-handle {
            width: 20px;
            height: 20px;
            z-index: 4;
            top: 5px;
            left: 5px;
            background-color: #aab7c2;
            transition: left .1s ease-in, border .1s ease-in
        }

        .ux-toggle .ux-toggle-checkbox {
            position: absolute;
            top: 0;
            left: 0;
            z-index: 1;
            opacity: 0
        }

        .ux-toggle .ux-toggle-checkbox:checked~.ux-toggle-bg {
            background-color: #00a63f;
            border-color: #00a63f
        }

        .ux-toggle .ux-toggle-checkbox:checked~.ux-toggle-handle {
            background-color: #fff;
            left: 25px
        }

        .ux-toggle.small .ux-toggle-bg {
            width: 41px;
            height: 24px
        }

        .ux-toggle.small .ux-toggle-handle {
            width: 16px;
            height: 16px;
            background-color: #aab7c2;
            z-index: 4;
            top: 4px;
            left: 4px
        }

        .ux-toggle.small .ux-toggle-checkbox:checked~.ux-toggle-handle {
            left: 21px
        }

        .ux-toggle.small .ux-toggle-message {
            font-size: .8125rem
        }

        .ux-toggle .ux-toggle-message {
            font-size: .875rem;
            display: inline-flex;
            align-items: center;
            margin-left: 10px;
            white-space: nowrap
        }

        .ux-toggle.disabled {
            cursor: not-allowed;
            opacity: .5
        }

        .ux-toggle.disabled .ux-toggle-message {
            opacity: .5
        }

        .ux-toggle.disabled .ux-toggle-handle {
            cursor: not-allowed
        }

        .ux-pivot,
        .ux-stars-rating .checked:hover,
        .ux-stars-rating .unchecked:hover,
        button.ux-pivot {
            cursor: pointer
        }

        .tooltip {
            position: absolute;
            z-index: 1070;
            display: block;
            font-weight: 400;
            line-height: 1.61803;
            text-align: left;
            text-align: start;
            text-decoration: none;
            text-transform: none;
            letter-spacing: normal;
            word-break: normal;
            word-spacing: normal;
            white-space: normal;
            line-break: auto;
            opacity: 0
        }

        .tooltip.show {
            opacity: 1
        }

        .tooltip .tooltip-arrow {
            position: absolute;
            display: block;
            width: 9px;
            height: .4rem
        }

        .tooltip .tooltip-arrow::before {
            position: absolute;
            content: "";
            border-color: transparent;
            border-style: solid
        }

        .tooltip .close:not(:disabled):not(.disabled):focus,
        .tooltip .close:not(:disabled):not(.disabled):hover {
            color: #fff
        }

        .bs-tooltip-auto[x-placement^=top],
        .bs-tooltip-top {
            padding: .4rem 0
        }

        .bs-tooltip-auto[x-placement^=top] .arrow,
        .bs-tooltip-top .arrow {
            bottom: 0
        }

        .bs-tooltip-auto[x-placement^=top] .arrow::before,
        .bs-tooltip-top .arrow::before {
            top: 0;
            border-width: .4rem 4.5px 0;
            border-top-color: #2b2b2b
        }

        .bs-tooltip-auto[x-placement^=right],
        .bs-tooltip-right {
            padding: 0 .4rem
        }

        .bs-tooltip-auto[x-placement^=right] .arrow,
        .bs-tooltip-right .arrow {
            left: 0;
            width: .4rem;
            height: 9px
        }

        .bs-tooltip-auto[x-placement^=right] .arrow::before,
        .bs-tooltip-right .arrow::before {
            right: 0;
            border-width: 4.5px .4rem 4.5px 0;
            border-right-color: #2b2b2b
        }

        .bs-tooltip-auto[x-placement^=bottom],
        .bs-tooltip-bottom {
            padding: .4rem 0
        }

        .bs-tooltip-auto[x-placement^=bottom] .arrow,
        .bs-tooltip-bottom .arrow {
            top: 0
        }

        .bs-tooltip-auto[x-placement^=bottom] .arrow::before,
        .bs-tooltip-bottom .arrow::before {
            bottom: 0;
            border-width: 0 4.5px .4rem;
            border-bottom-color: #2b2b2b
        }

        .bs-tooltip-auto[x-placement^=left],
        .bs-tooltip-left {
            padding: 0 .4rem
        }

        .bs-tooltip-auto[x-placement^=left] .arrow,
        .bs-tooltip-left .arrow {
            right: 0;
            width: .4rem;
            height: 9px
        }

        .bs-tooltip-auto[x-placement^=left] .arrow::before,
        .bs-tooltip-left .arrow::before {
            left: 0;
            border-width: 4.5px 0 4.5px .4rem;
            border-left-color: #2b2b2b
        }

        .tooltip-inner {
            color: #fff;
            background-color: #2b2b2b;
            border-radius: 6px
        }

        .tooltip a,
        .tooltip a:hover {
            color: inherit
        }

        .tooltip {
            padding: 9px !important;
            font-size: 1rem;
            width: 100%;
            margin: 0
        }

        @media (min-width:520px) {
            .tooltip {
                max-width: 350px;
                width: auto
            }
        }

        .tooltip a {
            text-decoration: underline
        }

        .tooltip .close {
            position: relative;
            right: -10px;
            color: #fff;
            font-size: 24px;
            top: -.15rem
        }

        .tooltip .close:focus {
            outline: 0
        }

        .tooltip .close:hover {
            color: #757575
        }

        .tooltip-inner {
            padding: 15px 18px;
            text-align: left;
            text-decoration: none;
            border: 1px solid #2b2b2b;
            max-width: none
        }

        .tooltip-arrow {
            border-color: transparent transparent #2b2b2b !important;
            border-width: 0 10px 10px !important
        }

        .tooltip-arrow::after {
            position: absolute;
            top: 1px;
            left: -9px;
            display: block;
            width: 0;
            height: 0;
            content: "";
            border-color: transparent transparent #2b2b2b;
            border-style: solid;
            border-width: 0 9px 9px
        }

        .ux-message,
        .ux-overlay {
            display: inline-flex;
            width: 100%
        }

        .tooltip.bs-tooltip-auto[x-placement^=top],
        .tooltip.bs-tooltip-top,
        .tooltip.bs-tooltip-top-left,
        .tooltip.bs-tooltip-top-right {
            margin-top: 3px
        }

        .tooltip.bs-tooltip-auto[x-placement^=top] .tooltip-arrow,
        .tooltip.bs-tooltip-top .tooltip-arrow,
        .tooltip.bs-tooltip-top-left .tooltip-arrow,
        .tooltip.bs-tooltip-top-right .tooltip-arrow {
            top: 0;
            left: 50%
        }

        .tooltip.bs-tooltip-auto[x-placement^=bottom],
        .tooltip.bs-tooltip-bottom,
        .tooltip.bs-tooltip-bottom-left,
        .tooltip.bs-tooltip-bottom-right {
            margin-top: -3px
        }

        .tooltip.bs-tooltip-auto[x-placement^=bottom] .tooltip-arrow,
        .tooltip.bs-tooltip-bottom .tooltip-arrow,
        .tooltip.bs-tooltip-bottom-left .tooltip-arrow,
        .tooltip.bs-tooltip-bottom-right .tooltip-arrow {
            bottom: 0;
            left: 50%;
            transform: rotate(180deg)
        }

        .tooltip.bs-tooltip-auto[x-placement^=bottom] .tooltip-arrow:after,
        .tooltip.bs-tooltip-bottom .tooltip-arrow:after,
        .tooltip.bs-tooltip-bottom-left .tooltip-arrow:after,
        .tooltip.bs-tooltip-bottom-right .tooltip-arrow:after {
            left: 0
        }

        .tooltip.bs-tooltip-bottom-right .tooltip-arrow,
        .tooltip.bs-tooltip-top-right .tooltip-arrow {
            right: 46px;
            left: auto
        }

        .modal,
        .modal-backdrop {
            right: 0;
            bottom: 0;
            top: 0
        }

        .tooltip.bs-tooltip-bottom-left .tooltip-arrow,
        .tooltip.bs-tooltip-top-left .tooltip-arrow {
            left: 46px
        }

        .tooltip-title {
            margin-bottom: 15px;
            font-size: 1rem;
            line-height: 1.1;
            font-weight: 700
        }

        .tooltip-over-text {
            color: #1976d2
        }

        .ux-overlay-wrapper {
            position: relative;
            width: 100%
        }

        .ux-overlay {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            text-align: center;
            background: rgba(255, 255, 255, .8);
            z-index: 1;
            align-items: center
        }

        .ux-message {
            background-color: #fff;
            padding: 25px 5%;
            position: relative;
            justify-content: center;
            border-top: 1px solid #aab7c2;
            border-bottom: 1px solid #aab7c2
        }

        .ux-message-spinner {
            padding: 3px 5px 0 0
        }

        .ux-message-spinner svg {
            display: inline-block;
            vertical-align: unset
        }

        .modal {
            position: fixed;
            left: 0;
            z-index: 1050;
            display: none;
            outline: 0
        }

        .modal.fade .modal-dialog {
            transform: translate(0, -25%)
        }

        .modal.show .modal-dialog {
            transform: translate(0, 0)
        }

        .modal-open .modal {
            overflow-x: hidden;
            overflow-y: auto
        }

        .modal-dialog {
            position: relative;
            pointer-events: none
        }

        .modal-content {
            position: relative;
            display: flex;
            flex-direction: column;
            pointer-events: auto;
            background-color: #fff;
            background-clip: padding-box;
            outline: 0
        }

        .modal-backdrop {
            position: fixed;
            left: 0;
            z-index: 1040;
            background-color: rgba(245, 247, 248, .9)
        }

        .modal-backdrop.fade {
            opacity: 0
        }

        .modal-backdrop.show {
            opacity: 1
        }

        .modal-header {
            display: flex;
            align-items: flex-start;
            border-top-right-radius: 8px;
            border-top-left-radius: 8px
        }

        .modal-title {
            margin-bottom: 0;
            line-height: 1.091
        }

        .modal-body {
            position: relative;
            flex: 1 1 auto
        }

        .modal-footer {
            display: flex;
            align-items: center
        }

        .modal-footer>:not(:first-child) {
            margin-left: .25rem
        }

        .modal-footer>:not(:last-child) {
            margin-right: .25rem
        }

        .modal-scrollbar-measure {
            position: absolute;
            top: -9999px;
            width: 50px;
            height: 50px;
            overflow: scroll
        }

        @media (min-width:520px) {
            .modal-dialog {
                max-width: 600px;
                margin: 30px auto
            }

            .modal-content {
                box-shadow: 0 5px 15px rgba(0, 0, 0, .5)
            }

            .modal-sm {
                max-width: auto
            }
        }

        @media (min-width:992px) {
            .modal-lg {
                max-width: auto
            }
        }

        .modal.fade .modal-dialog {
            opacity: 0;
            transition: opacity .15s linear;
            transform: none
        }

        .modal.in,
        .modal.in .modal-dialog,
        .modal.show,
        .modal.show .modal-dialog {
            opacity: 1;
            transform: none
        }

        .modal-dialog {
            margin: 0;
            width: auto;
            max-width: 100vw
        }

        .modal-content {
            border-radius: 6px;
            box-shadow: 0 4px 12px 0 rgba(117, 117, 117, .4);
            border: 0
        }

        @media (min-width:992px) {
            .modal-content {
                border-radius: 8px
            }
        }

        .modal-backdrop.in {
            opacity: 1
        }

        .modal-header {
            padding: 32px 24px 16px;
            border-bottom: 0;
            justify-content: flex-start
        }

        .modal-header .close {
            position: absolute;
            margin: 0;
            padding: 0;
            top: 16px;
            right: 16px;
            z-index: 1;
            font-size: 1rem;
            color: #000
        }

        .modal-body,
        .modal-footer {
            padding: 0 24px 32px
        }

        .modal-header .close:before {
            content: '\E208';
            font-family: uxfont;
            font-size: 1rem;
            font-weight: 400
        }

        .modal-body>p:last-child {
            margin-bottom: 0
        }

        .modal-footer {
            justify-content: flex-start;
            text-align: inherit;
            background-color: #fff;
            border-radius: 6px;
            border-top: 0
        }

        .modal-footer .btn+.btn {
            margin-bottom: 0;
            margin-left: 0
        }

        .modal-footer .btn-block+.btn-block,
        .modal-footer .btn-group .btn+.btn {
            margin-left: 0
        }

        @media (min-width:520px) {
            .modal-dialog {
                width: 380px;
                margin: 40px auto 30px
            }

            .modal-content {
                box-shadow: 0 4px 12px 0 rgba(117, 117, 117, .4)
            }

            .modal-header {
                padding: 32px 24px 16px
            }

            .modal-nav {
                padding: 0 56px 24px
            }
        }

        @media (min-width:768px) {
            .modal-dialog {
                width: 580px
            }

            .modal-body {
                padding: 0 34px 33px
            }

            .modal-header {
                padding: 30px 34px 20px
            }

            .modal-footer {
                padding: 0 34px 25px
            }
        }

        @media (min-width:992px) {
            .modal-dialog {
                width: 606.67px
            }

            .modal-lg {
                width: 763.33px
            }

            .modal-sm {
                width: 450px
            }

            .modal-body {
                padding: 0 56px 40px
            }

            .modal-header {
                padding: 40px 56px 24px
            }

            .modal-footer {
                padding: 0 56px 32px;
                border: 0
            }
        }

        @media (min-width:1200px) {
            .modal-dialog {
                width: 740px
            }

            .modal-lg {
                width: 930px
            }

            .modal-sm {
                width: 550px
            }
        }

        .modal .ux-btn-set {
            margin-bottom: -14px
        }

        .modal-nav {
            padding: 0 24px 24px
        }

        .ux-progress {
            display: flex;
            flex-direction: column
        }

        .ux-progress-label {
            margin-bottom: 5px;
            display: inline-flex;
            font-weight: 700
        }

        .ux-progress-bar.ux-progress-striped .ux-progress-fill {
            animation: progress-bar-stripes .5s linear infinite;
            background-size: 24px 24px;
            background-image: linear-gradient(135deg, rgba(0, 0, 0, .1) 25%, transparent 25%, transparent 50%, rgba(0, 0, 0, .1) 50%, rgba(0, 0, 0, .1) 75%, transparent 75%, transparent)
        }

        .ux-progress-bar .ux-progress-area {
            display: flex;
            width: 100%;
            font-size: .875rem;
            font-weight: 700;
            background-color: #f5f7f8;
            overflow: hidden
        }

        .ux-progress-bar .ux-progress-fill {
            display: flex;
            justify-content: flex-end;
            height: 100%;
            background-color: #fff
        }

        .ux-progress-bar .ux-progress-text {
            color: #fff;
            margin-right: 10px;
            line-height: 24px
        }

        .ux-progress-bar .ux-progress-text-start {
            color: #111;
            margin-right: -30px
        }

        .ux-progress-bar.ux-progress-sm .ux-progress-text {
            margin-top: 2px;
            display: flex;
            font-size: 80%;
            float: none !important;
            color: #111 !important;
            font-weight: 700
        }

        .ux-progress-circle {
            position: relative;
            align-items: center
        }

        .ux-progress-circle label,
        .ux-progress-circle small,
        .ux-progress-circle svg {
            display: flex
        }

        .ux-progress-circle .ux-progress-label,
        .ux-progress-circle small {
            justify-content: center;
            text-align: center;
            width: 100%
        }

        .ux-progress-circle small {
            font-size: 80%
        }

        .ux-progress-circle circle {
            stroke: #f5f7f8
        }

        .ux-progress-circle circle.ux-progress-fill,
        .ux-progress-success circle.ux-progress-fill {
            stroke: #00a63f
        }

        .ux-progress-circle .ux-progress-text {
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 1.375rem;
            font-weight: 700;
            color: #111;
            line-height: 1.375rem
        }

        .ux-progress-bar.ux-progress-lg .ux-progress-area,
        .ux-progress-bar.ux-progress-md .ux-progress-area {
            height: 24px;
            border-radius: 12px
        }

        .ux-progress-bar.ux-progress-lg .ux-progress-fill,
        .ux-progress-bar.ux-progress-md .ux-progress-fill {
            border-radius: 12px 6px 6px 12px
        }

        .ux-progress-bar.ux-progress-sm .ux-progress-area {
            height: 12px;
            border-radius: 6px
        }

        .ux-progress-bar.ux-progress-sm .ux-progress-bar,
        .ux-progress-bar.ux-progress-sm .ux-progress-fill {
            border-radius: 6px
        }

        .ux-progress-bar.ux-progress-xs .ux-progress-area {
            height: 6px;
            border-radius: 3px
        }

        .ux-progress-bar.ux-progress-xs .ux-progress-bar,
        .ux-progress-bar.ux-progress-xs .ux-progress-fill {
            border-radius: 3px
        }

        .ux-progress-circle.ux-progress-xs {
            width: 50px
        }

        .ux-progress-circle.ux-progress-xs .ux-progress-text {
            width: 50px;
            height: 50px;
            margin-top: -50px;
            font-size: 80%
        }

        .ux-progress-circle.ux-progress-xs .ux-progress-label {
            font-size: 80%
        }

        .ux-progress-circle.ux-progress-sm {
            width: 100px
        }

        .ux-progress-circle.ux-progress-sm .ux-progress-text {
            width: 100px;
            height: 100px;
            margin-top: -100px
        }

        .ux-progress-circle.ux-progress-md {
            width: 150px
        }

        .ux-progress-circle.ux-progress-md .ux-progress-text {
            width: 150px;
            height: 150px;
            margin-top: -150px
        }

        .ux-progress-circle.ux-progress-lg {
            width: 250px
        }

        .ux-progress-circle.ux-progress-lg .ux-progress-text {
            width: 250px;
            height: 250px;
            margin-top: -250px
        }

        .ux-progress-success .ux-progress-fill {
            background-color: #00a63f
        }

        .ux-progress-success .ux-progress-fill .ux-progress-text {
            color: #111
        }

        .ux-progress-info .ux-progress-fill {
            background-color: #9e42b5
        }

        .ux-progress-info .ux-progress-fill .ux-progress-text {
            color: #fff
        }

        .ux-progress-info circle.ux-progress-fill {
            stroke: #9e42b5
        }

        .ux-progress-warning .ux-progress-fill {
            background-color: #ebc001
        }

        .ux-progress-warning .ux-progress-fill .ux-progress-text {
            color: #111
        }

        .ux-progress-danger .ux-progress-fill .ux-progress-text,
        .ux-progress-primary .ux-progress-fill .ux-progress-text {
            color: #fff
        }

        .ux-progress-warning circle.ux-progress-fill {
            stroke: #ebc001
        }

        .ux-progress-danger .ux-progress-fill {
            background-color: #db1802
        }

        .ux-progress-danger circle.ux-progress-fill {
            stroke: #db1802
        }

        .ux-progress-primary .ux-progress-fill {
            background-color: #00a63f
        }

        .ux-progress-primary circle.ux-progress-fill {
            stroke: #00a63f
        }

        @keyframes progress-bar-stripes {
            0% {
                background-position: 24px 0
            }

            100% {
                background-position: 0 0
            }
        }

        .ux-tabs-wiz-list {
            display: table;
            width: 100%;
            min-height: 2em;
            padding: 0;
            margin: 0;
            font-size: .875rem;
            line-height: 1.1;
            text-align: center;
            counter-reset: wizList
        }

        .ux-tabs-wiz-list>li {
            position: relative;
            display: table-cell;
            margin: 0;
            vertical-align: top;
            counter-increment: wizList
        }

        .ux-tabs-wiz-list>li:after,
        .ux-tabs-wiz-list>li:before {
            position: absolute;
            top: .7em;
            box-sizing: content-box;
            display: block;
            height: .5em;
            content: "";
            background: #999
        }

        .ux-tabs-wiz-list>li:before {
            right: 50%;
            left: 0;
            margin-right: 1.8em
        }

        .ux-tabs-wiz-list>li:after {
            right: 0;
            left: 50%;
            margin-left: 1.8em
        }

        .ux-tabs-wiz-list>li:first-child:before,
        .ux-tabs-wiz-list>li:last-child:after {
            display: none
        }

        .ux-tabs-wiz-list>li>a {
            position: relative;
            display: block;
            color: #575757;
            text-decoration: none
        }

        .ux-tabs-wiz-list>li>a:before {
            position: absolute;
            top: 0;
            left: 50%;
            z-index: 1;
            box-sizing: content-box;
            display: inline-block;
            width: 1.6em;
            height: 1.6em;
            margin: 0 .5em 0 -.8em;
            font-size: 1.25em;
            line-height: 1.6em;
            text-align: center;
            content: counter(wizList);
            border-radius: 50%;
            font-family: gdsherpa, Helvetica, Arial, sans-serif;
            font-weight: 700
        }

        .ux-tabs-wiz-txt {
            position: relative;
            display: none;
            max-width: 10em;
            padding-top: 2.5em;
            margin: 0 auto
        }

        @media (min-width:768px) {
            .ux-tabs-wiz-txt {
                display: block
            }
        }

        .ux-tabs-wiz-list .ux-tabs-wiz-step-complete:after,
        .ux-tabs-wiz-list .ux-tabs-wiz-step-complete:before {
            background: #000
        }

        .ux-tabs-wiz-list .ux-tabs-wiz-step-complete>a:before {
            content: "\E207";
            background: #00a63f;
            color: #fff;
            font-family: uxfont
        }

        .ux-quantity-selector-button,
        .ux-quantity-selector-text {
            font-family: gdsherpa, Helvetica, Arial, sans-serif;
            padding: 0;
            min-width: 0;
            font-weight: 700
        }

        .ux-tabs-wiz-list .ux-tabs-wiz-step-current:before {
            background: #000
        }

        .ux-tabs-wiz-list .ux-tabs-wiz-step-current>a,
        .ux-tabs-wiz-list .ux-tabs-wiz-step-incomplete:hover>a {
            color: #000
        }

        .ux-tabs-wiz-list .ux-tabs-wiz-step-current>a:before,
        .ux-tabs-wiz-list .ux-tabs-wiz-step-incomplete:hover>a:before {
            color: #fff;
            background: #111
        }

        .ux-tabs-wiz-list .ux-tabs-wiz-step-current .ux-tabs-wiz-txt,
        .ux-tabs-wiz-list .ux-tabs-wiz-step-incomplete:hover .ux-tabs-wiz-txt {
            font-weight: 700
        }

        .ux-quantity-selector .input-group {
            width: calc(46px + 46px + 3.5em)
        }

        .ux-quantity-selector-button {
            cursor: pointer;
            width: 50px
        }

        .ux-quantity-selector-button:focus,
        .ux-quantity-selector-button:hover {
            padding: 0
        }

        .ux-quantity-selector-text {
            text-align: center;
            -moz-appearance: textfield
        }

        .ux-quantity-selector-text::-webkit-inner-spin-button {
            display: none
        }

        .ux-spinner-label {
            display: block;
            font-weight: 700;
            width: 100%
        }

        .ux-spinner {
            margin: 0 auto
        }

        .ux-stars-rating .checked:focus,
        .ux-stars-rating .unchecked:focus {
            outline: 0
        }

        .ux-stars-rating .checked:before,
        .ux-stars-rating .unchecked:before {
            font-family: uxfont;
            font-size: 16px
        }

        .ux-stars-rating .checked:before {
            content: '\E050';
            color: #00a63f
        }

        .ux-stars-rating .unchecked:before {
            content: '\E049';
            color: #aab7c2
        }

        .ux-stars:focus {
            outline: 0
        }

        .ux-stars-numbers,
        .ux-stars-rating {
            display: inline-flex
        }

        .ux-stars>span.font-primary-bold {
            margin-left: 10px
        }

        .ux-stars>p.font-primary-bold {
            margin-bottom: 0
        }

        @media (max-width:767px) {
            .card-block .ux-pivot-group {
                margin: 0 -20px;
                overflow: hidden
            }

            .ux-pivot-group [class*=col-] {
                padding-left: 0;
                padding-right: 0
            }
        }

        .ux-pivot {
            position: relative;
            display: flex;
            align-content: center;
            justify-content: flex-start;
            flex-direction: column;
            width: 100%;
            font-weight: 400;
            line-height: 1.61803;
            touch-action: manipulation;
            user-select: none;
            background-color: #fff;
            border-top: 1px solid #e8eaeb;
            border-bottom: 1px solid #e8eaeb;
            padding: 25px 55px 25px 67px
        }

        .ux-pivot:focus .ux-pivot-title,
        .ux-pivot:hover .ux-pivot-title {
            color: #00a63f
        }

        .ux-pivot,
        .ux-pivot:focus,
        .ux-pivot:hover,
        button.ux-pivot.ux-pivot-selected {
            color: #444;
            text-decoration: none
        }

        .ux-pivot:after {
            content: "\E367";
            position: absolute;
            top: 50%;
            right: 20px;
            margin-top: -.5em;
            font-family: uxfont;
            font-size: 15px;
            line-height: 1
        }

        .ux-pivot-group>div+div .ux-pivot {
            margin-top: -1px
        }

        button.ux-pivot {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            transition: all .2s ease-in-out
        }

        button.ux-pivot:active:focus,
        button.ux-pivot:focus {
            outline: 0
        }

        button.ux-pivot.ux-pivot-selected .ux-pivot-title {
            color: #00a63f
        }

        .ux-pivot-graphic {
            position: absolute;
            top: 50%;
            left: 15px;
            display: block;
            width: 1em;
            height: 1em;
            margin-top: -.5em;
            font-size: 32px;
            line-height: 0
        }

        .ux-pivot-graphic svg {
            width: 100%;
            height: 100%
        }

        .ux-pivot-title {
            display: block;
            margin: 0;
            font-size: 1.125rem
        }

        .ux-pivot-subtitle {
            display: block;
            color: #757575
        }

        @media (min-width:768px) {
            .ux-pivot {
                padding-right: 35px;
                padding-left: 52px;
                justify-content: center
            }

            .ux-pivot:after {
                right: 0
            }

            .ux-pivot-graphic {
                left: 0
            }

            .ux-pivot-subtitle {
                margin-top: 2px
            }
        }

        .ux-pivot-subtitle,
        .ux-pivot-title {
            width: 100%
        }

        @media (max-width:519px) {
            .ux-pivot-group:not(.ux-pivot-xs-graphics) .ux-pivot {
                padding-left: 20px
            }

            .ux-pivot-group:not(.ux-pivot-xs-graphics) .ux-pivot-graphic {
                display: none
            }
        }

        @media (min-width:768px) {
            .ux-pivot-group:not(.ux-pivot-slats) {
                margin-bottom: -20px
            }

            .ux-pivot-group:not(.ux-pivot-slats).row {
                flex-wrap: wrap
            }

            .ux-pivot-group:not(.ux-pivot-slats).row,
            .ux-pivot-group:not(.ux-pivot-slats).row [class*=col-] {
                display: flex
            }

            .ux-pivot-group:not(.ux-pivot-slats).row [class*=col-] {
                margin-left: -.5px
            }

            .ux-pivot-group:not(.ux-pivot-slats) .ux-pivot {
                border-radius: 6px;
                padding: 20px;
                margin-bottom: 20px;
                align-items: center;
                border: 1px solid #e8eaeb;
                text-align: center
            }

            .ux-pivot-group:not(.ux-pivot-slats) .ux-pivot:focus,
            .ux-pivot-group:not(.ux-pivot-slats) .ux-pivot:hover,
            .ux-pivot-group:not(.ux-pivot-slats) button.ux-pivot.ux-pivot-selected {
                border-color: #00a63f;
                box-shadow: 0 0 0 1px #00a63f inset
            }

            .ux-pivot-group:not(.ux-pivot-slats) .ux-pivot:after {
                display: none
            }

            .ux-pivot-group:not(.ux-pivot-slats) .ux-pivot-graphic {
                position: static;
                margin: 0 auto 10px;
                font-size: 45px
            }
        }

        .ux-pivot-group .ux-pivot-disabled {
            opacity: .5;
            cursor: not-allowed
        }

        .ux-pivot-group .ux-pivot-disabled .ux-pivot-title {
            color: #757575
        }

        /*# sourceMappingURL=uxcore2.min.css.map */
    </style>
    <style>
        .tray-menu {
            background-color: transparent;
            position: inherit;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            margin: 0;
            min-height: 42px;
            padding: 0;
            vertical-align: bottom;
            opacity: 1
        }

        .tray-menu.open {
            background-color: #e8eaeb
        }

        .tray-toggle-wrapper {
            position: relative;
            min-height: 42px
        }

        .tray-toggle {
            background-color: transparent;
            font-size: inherit;
            font-weight: 700;
            white-space: nowrap;
            padding: 10px;
            min-width: 0;
            border-radius: 0
        }

        .tray-toggle:active,
        .tray-toggle:focus {
            border: 0;
            padding: 10px
        }

        .tray-toggle:active span,
        .tray-toggle:focus span {
            position: relative;
            top: 0;
            left: 0
        }

        .tray-toggle:after {
            display: inline;
            margin-left: .3125rem;
            font-family: uxfont;
            font-size: 8px;
            line-height: 1;
            content: '\e443';
            border: 0;
            vertical-align: middle;
            width: 0;
            height: 0
        }

        .tray-toggle-caret {
            position: absolute;
            left: calc(50% - 10px);
            bottom: 0;
            width: 0;
            border-style: solid;
            border-color: transparent transparent #e8eaeb;
            border-width: 0 10px 8px;
            display: none
        }

        .tray-dropdown {
            position: absolute;
            min-width: 200px;
            top: calc(100% + 1px);
            padding: 40px 20px;
            visibility: hidden;
            -webkit-box-shadow: 0 8px 4px -6px rgba(117, 117, 117, .2);
            box-shadow: 0 8px 4px -6px rgba(117, 117, 117, .2);
            background-color: #e8eaeb;
            font-size: 16px;
            z-index: 1029;
            overflow: auto;
            -webkit-transform: scaleY(0);
            transform: scaleY(0);
            -webkit-transform-origin: top;
            transform-origin: top;
            display: block;
            height: auto
        }

        .tray-dropdown.loaded {
            -webkit-transition: all .3s cubic-bezier(.65, -.01, .26, 1);
            transition: all .3s cubic-bezier(.65, -.01, .26, 1)
        }

        .tray-dropdown .close {
            font-size: 24px;
            position: absolute;
            top: 20px;
            right: 40px
        }

        @media (min-width:992px) {
            .tray-dropdown .close {
                display: none
            }
        }

        .tray-content {
            -webkit-transition-delay: .1s;
            transition-delay: .1s;
            opacity: 0
        }

        .tray-menu.open .tray-dropdown {
            -webkit-transform: scaleY(1);
            transform: scaleY(1);
            visibility: visible
        }

        .tray-menu.open .tray-content {
            opacity: 1;
            -webkit-transition-delay: .25s;
            transition-delay: .25s
        }

        .tray-menu.open .tray-toggle-caret {
            display: inline
        }

        .tray-menu.open .tray-toggle:after {
            content: '\e444'
        }

        .tray-fullwidth {
            left: 0;
            right: 0
        }

        .tray-align-left {
            left: 0
        }

        .tray-align-right {
            right: 0
        }

        .market-selector-open {
            overflow: hidden
        }

        .market-selector .tray-toggle:before {
            content: '\e305';
            font-family: uxfont;
            font-size: 16px;
            margin-right: 7px;
            font-weight: 400
        }

        .market-selector .market-list {
            padding-left: 10px;
            padding-right: 10px;
            margin-bottom: 0;
            list-style: none
        }

        .market-selector li:last-child {
            margin-bottom: 0
        }

        .market-selector li.selected a {
            color: #00a63f;
            text-decoration: underline;
            cursor: pointer
        }

        .market-selector li.selected a:after {
            content: '\e243';
            font-family: uxfont;
            font-size: 12px;
            font-weight: 400
        }

        .market-selector li a {
            text-decoration: none;
            color: #2b2b2b
        }

        .market-selector li a:hover {
            color: #00a63f;
            text-decoration: underline
        }

        .verification-modal span {
            display: inline-block
        }

        @media (min-width:520px) {
            .delegation {
                padding-top: 40px
            }

            .delegation.db {
                padding-top: 80px
            }

            .delegation.db .delegate+.delegate {
                top: 40px
            }
        }

        .delegation .refreshed .pull-left {
            -webkit-animation-name: bounce;
            animation-name: bounce;
            -webkit-transform-origin: center bottom;
            transform-origin: center bottom;
            display: inline-block;
            -webkit-animation-duration: 1.75s;
            animation-duration: 1.75s;
            -webkit-animation-fill-mode: both;
            animation-fill-mode: both
        }

        .delegation form {
            margin: 0
        }

        .delegation form button {
            background: 0 0;
            border: none;
            height: 40px;
            line-height: 1em;
            display: inline-block
        }

        .delegation .modal-header .close span,
        .notification-cache {
            display: none
        }

        .delegation .modal-header .close {
            border: 0;
            background-color: transparent;
            right: 15px;
            line-height: 1;
            padding: 0
        }

        .delegate {
            width: 100%;
            padding: 10px 0;
            background-color: #1976d2;
            color: #fff;
            font-weight: 700;
            z-index: 1003
        }

        @media (min-width:520px) {
            .delegate {
                position: fixed;
                top: 0;
                line-height: 40px;
                padding: 0
            }
        }

        .delegate.rep {
            background-color: #9e42b5;
            color: #fff
        }

        .delegate-link {
            text-decoration: none;
            color: #fff
        }

        .delegate-link:focus,
        .delegate-link:hover {
            color: inherit
        }

        .delegate-link .text {
            margin-left: 5px
        }

        @media (max-width:519px) {
            .delegate-link .text {
                display: none
            }
        }

        @media (max-width:767px) {
            .notifications {
                position: static !important
            }
        }

        .notifications.has-notifications {
            padding-right: 15px
        }

        .notifications.has-notifications .dropdown-toggle.no-count:after {
            content: '';
            width: 12px;
            height: 12px;
            background: #db1802;
            border-radius: 50%;
            border: 2px solid #fff;
            display: block;
            padding-top: 0;
            margin-left: 0;
            -webkit-box-align: normal;
            -ms-flex-align: normal;
            align-items: normal;
            position: absolute;
            top: -3px;
            right: 2px;
            -webkit-box-shadow: none;
            box-shadow: none
        }

        .notifications .dropdown-toggle {
            background-color: transparent;
            padding: 0;
            border-radius: 0;
            min-width: 0;
            position: relative
        }

        .notifications .dropdown-toggle:focus {
            padding: 0;
            border: 0
        }

        .notifications .dropdown-toggle:before {
            content: '\E442';
            font-family: uxfont
        }

        .notifications .dropdown-toggle:after {
            display: none
        }

        .notifications .dropdown-toggle.no-count:before {
            content: '\E473'
        }

        .notifications .dropdown-toggle.notifications-bell:before {
            font-size: 16px
        }

        .notifications .dropdown-toggle.notifications-mini-bell {
            font-size: 13px;
            text-align: center;
            border-radius: 15px;
            border: 2px solid #2b2b2b;
            min-width: 25px;
            height: 25px;
            overflow: visible
        }

        .notifications .dropdown-toggle.notifications-mini-bell:before {
            font-size: 11px;
            position: absolute;
            height: 15px;
            width: 15px;
            border-radius: 50%;
            line-height: 15px;
            top: -4px;
            right: -9px
        }

        .notifications .dropdown-toggle.notifications-mini-bell .notifications-badge {
            line-height: 1.05;
            padding: 0 5px
        }

        .notifications .dropdown-toggle.open {
            background-color: #f5f7f8
        }

        .notifications .notifications-list {
            -webkit-transform: translateX(0);
            transform: translateX(0);
            border: 0;
            padding: 15px;
            border-radius: 0;
            width: 100%
        }

        @media (min-width:768px) {
            .notifications .notifications-list {
                width: 320px !important;
                -webkit-transform: translateX(-235px);
                transform: translateX(-235px)
            }
        }

        .notifications .notifications-list-items {
            padding-left: 0;
            list-style: none;
            margin-bottom: 0
        }

        .notifications .notifications-list-items li {
            margin: 15px 0 0
        }

        .notifications .notifications-list-items .no-link,
        .notifications .notifications-list-items a {
            background-color: #fff;
            min-height: 60px;
            padding: 8px 0;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            color: #2b2b2b;
            text-decoration: none;
            font-size: 16px;
            position: relative;
            line-height: 1.3
        }

        .notifications .notifications-list-items .no-link:before,
        .notifications .notifications-list-items a:before {
            content: '';
            font-family: uxfont;
            border-radius: 50%;
            font-size: 18px;
            width: 30px;
            height: 30px;
            margin: 0 13px;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            line-height: 1;
            color: #2b2b2b
        }

        .notifications .notifications-list-items .no-link.high:before,
        .notifications .notifications-list-items a.high:before {
            background-color: #db1802
        }

        .notifications .notifications-list-items .no-link.medium:before,
        .notifications .notifications-list-items a.medium:before {
            background-color: #fedc45
        }

        .notifications .notifications-list-items .no-link.priority:before,
        .notifications .notifications-list-items a.priority:before {
            content: '\e197';
            padding-bottom: 3px
        }

        .notifications .notifications-list-items .no-link.creditCardExpiration:before,
        .notifications .notifications-list-items a.creditCardExpiration:before {
            content: '\e268';
            padding-bottom: 0
        }

        .notifications .notifications-list-items .no-link.smsOptIn:before,
        .notifications .notifications-list-items a.smsOptIn:before {
            content: '\e246';
            padding-top: 2px
        }

        .notifications .notifications-list-items a span {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .notifications .notifications-list-items a:hover:after {
            color: #2b2b2b
        }

        .notifications .notifications-list-items a:after {
            content: '\E445';
            font-size: 12px;
            font-family: uxfont;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            color: #757575;
            margin: 0 10px
        }

        .notifications .notifications-list-header {
            line-height: .7;
            margin: 0;
            font-weight: 700
        }

        .notifications .notifications-close {
            position: absolute;
            top: 9px;
            right: 9px
        }

        .notifications .notifications-close:focus {
            outline: 0
        }

        .notifications .notifications-list-empty {
            border: 3px dashed #757575;
            font-size: 16px;
            min-height: 150px;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            line-height: 1.3;
            padding: 10px;
            text-align: center
        }

        .notifications .notifications-list-empty:before {
            content: '';
            font-family: uxfont;
            font-size: 35px;
            color: #757575;
            margin-bottom: 5px
        }

        .notifications .notifications-list-empty.notifications-alert:before {
            content: '\E442'
        }

        .notifications .notifications-list-empty.notifications-session-alert:before {
            content: '\e197'
        }

        .notifications .notifications-list-empty a {
            height: auto;
            background: 0 0;
            min-height: 0;
            text-decoration: underline;
            color: #1976d2
        }

        .notifications .notifications-list-empty a:hover {
            text-decoration: none
        }

        .notifications .notifications-list-empty a:after,
        .notifications .notifications-list-empty a:before {
            display: none
        }

        .notifications .notifications-list-empty .no-notifications-text {
            width: 100%
        }

        .help-search-hdr {
            border-left: 4px solid #9e42b5;
            padding-left: 16px;
            margin-bottom: 16px
        }

        .help-search-input {
            height: 80px;
            margin-bottom: 8px;
            resize: none
        }

        .help-search-input-limit {
            color: #999;
            margin-top: 0;
            margin-bottom: 1rem
        }

        .help-search-rslt-hdr {
            border-left-color: #00a63f;
            position: relative
        }

        @media (min-width:768px) {
            .help-search-rslt-hdr {
                margin-left: 25px
            }

            .help-search-rslt-item .ux-pivot:after {
                right: 10px
            }
        }

        .help-search-back {
            cursor: pointer;
            color: #444;
            position: absolute;
            left: -30px;
            padding-top: 0
        }

        .help-search-rslt-item {
            margin: 0 0 10px
        }

        @media (max-width:991px) {
            .help-search-rslt-item .ux-pivot-slats {
                margin-left: 0;
                margin-right: 0
            }
        }

        .help-search-rslt-item .ux-pivot {
            padding: 16px 25px 16px 16px;
            border-top: 0;
            border-bottom: 0
        }

        .help-search-start-over {
            margin-bottom: 0;
            text-decoration: none !important;
            padding-top: 0
        }

        .help-search-more-answers {
            width: 150px;
            float: right
        }

        .help-search-more-answers a {
            padding-top: 0;
            padding-right: 10px;
            color: #00a63f !important;
            white-space: nowrap
        }

        .product-flyout-menu {
            -webkit-transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
            transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
            background-color: #fff;
            position: fixed;
            color: #2b2b2b;
            left: 0;
            top: 0;
            bottom: 0;
            width: 100%;
            overflow: hidden;
            -webkit-transform-origin: left;
            transform-origin: left;
            -webkit-transform: translateX(-100%);
            transform: translateX(-100%);
            z-index: 1031
        }

        @media (min-width:520px) {
            .product-flyout-menu {
                width: 375px
            }

            .container {
                max-width: 480px
            }
        }

        .product-flyout-menu .menu-scroller {
            height: calc(100vh - 80px);
            overflow-y: scroll;
            overflow-x: hidden;
            padding: 0 24px
        }

        .product-flyout-menu .menu-scroller .learn-more {
            color: #09757a;
            white-space: nowrap
        }

        .product-flyout-menu .menu-scroller .learn-more:focus,
        .product-flyout-menu .menu-scroller .learn-more:hover {
            color: #09757a
        }

        .product-flyout-menu .close {
            -webkit-transition: opacity .1s cubic-bezier(.43, .83, .76, 1.04) 0s;
            transition: opacity .1s cubic-bezier(.43, .83, .76, 1.04) 0s;
            position: absolute;
            right: 24px;
            top: 20px;
            z-index: 1034;
            opacity: 0
        }

        .product-flyout-menu .close:not(:disabled):not(.disabled):focus {
            opacity: 0
        }

        .product-flyout-menu .close:before {
            content: '';
            background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+ICA8cGF0aCBmaWxsPSIjMmIyYjJiIiBkPSJNMTAuNyAxMkwwIDEuMyAxLjMgMCAxMiAxMC43IDIyLjcgMCAyNCAxLjMgMTMuMyAxMiAyNCAyMi43IDIyLjcgMjQgMTIgMTMuMyAxLjMgMjQgMCAyMi43IDEwLjcgMTJ6Ii8+PC9zdmc+);
            height: 20px;
            width: 20px;
            display: block
        }

        .child-flyout-back .btn:before,
        .child-menu-links a:after {
            background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAxNiI+ICA8cGF0aCBmaWxsPSIjMmIyYjJiIiBkPSJNMTcuNCA5LjRIMFY2LjZoMTcuNUwxMi4xIDJsMi4zLTIgOS40IDgtOS40IDgtMi4zLTIgNS4zLTQuNnoiLz48L3N2Zz4=);
            background-repeat: no-repeat
        }

        .product-flyout-menu.open {
            -webkit-transform: translateX(0);
            transform: translateX(0)
        }

        .product-flyout-menu.open .close,
        .product-flyout-menu.open .close:focus,
        .product-flyout-menu.open .close:not(:disabled):not(.disabled):hover,
        .product-flyout-menu.open .global-elements {
            -webkit-transition: opacity .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
            transition: opacity .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
            opacity: 1;
            -webkit-transition-delay: .4s;
            transition-delay: .4s
        }

        .product-flyout-menu .global-elements {
            -webkit-transition: opacity .1s cubic-bezier(.43, .83, .76, 1.04) 0s;
            transition: opacity .1s cubic-bezier(.43, .83, .76, 1.04) 0s;
            opacity: 0;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            height: 60px;
            -webkit-box-pack: end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            padding-right: 70px;
            position: relative
        }

        @media (min-width:768px) {
            .product-flyout-menu .global-elements {
                visibility: hidden;
                height: 0
            }
        }

        .product-flyout-menu .global-elements .cart-link {
            height: 33px;
            width: 33px;
            color: #2b2b2b;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            margin-right: 16px;
            padding: 0
        }

        .product-flyout-menu .global-elements .notifications-bell {
            height: 33px;
            width: 20px;
            color: #2b2b2b;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            margin-right: 16px
        }

        .product-flyout-menu .global-elements .notifications-bell:before {
            font-size: 18px
        }

        .product-flyout-menu .global-elements .notifications-close {
            top: 14px;
            right: 12px
        }

        .product-flyout-menu .global-elements .notifications-close:before {
            width: 16px;
            height: 16px
        }

        .product-flyout-menu .global-elements .help-link,
        .product-flyout-menu .global-elements .user-account {
            height: 33px;
            width: 20px;
            color: #2b2b2b;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            margin-right: 16px;
            text-decoration: none
        }

        .product-flyout-menu .global-elements .help-link:hover,
        .product-flyout-menu .global-elements .user-account:hover {
            text-decoration: none
        }

        .product-flyout-menu .global-elements .help-link:before,
        .product-flyout-menu .global-elements .user-account:before {
            font-family: uxfont;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            font-size: 18px
        }

        .product-flyout-menu .global-elements .help-link:before {
            content: '\E195'
        }

        .product-flyout-menu .global-elements .user-account:before {
            content: '\E004'
        }

        .product-flyout-menu .global-elements .app-icon-cart {
            font-size: 20px
        }

        .product-flyout-menu .global-elements .app-icon-cart.cart-empty {
            color: #2b2b2b
        }

        .product-flyout-menu .notifications-list {
            background-color: #e8eaeb
        }

        .mobile-safari-iphone .product-flyout-menu .menu-scroller {
            height: calc(100vh - 130px)
        }

        .product-panel-bkg {
            position: fixed;
            top: 0;
            left: 0;
            background-color: #f5f7f8;
            opacity: .8;
            width: 100%;
            height: 100%;
            z-index: 1030
        }

        .product-flyout-corner-content-wrap {
            position: inherit
        }

        .product-flyout-hovered-menu ul li {
            opacity: .6
        }

        .product-flyout-hovered-menu ul li:hover {
            opacity: 1
        }

        .parent-navigation {
            font-size: 1.60181rem
        }

        .parent-navigation .product-flyout-heading {
            border-bottom: 1px solid #e8eaeb;
            padding-bottom: 8px;
            margin-bottom: 8px;
            padding-left: 8px
        }

        .no-link-styling,
        .no-link-styling:focus,
        .no-link-styling:hover {
            color: inherit;
            text-decoration: none;
            outline: 0
        }

        .parent-link-items {
            margin-bottom: 40px;
            padding-left: 8px
        }

        .parent-link-items li {
            margin: 0
        }

        .parent-link-items li .single-parent-link,
        .parent-link-items li button {
            font-size: 1rem;
            color: #2b2b2b;
            padding: 8px 0;
            display: inline-block;
            cursor: pointer;
            border: 0;
            background-color: transparent;
            text-decoration: none
        }

        .parent-link-items li .single-parent-link:focus,
        .parent-link-items li button:focus {
            outline: 0
        }

        @media (min-width:768px) {

            .parent-link-items li .single-parent-link,
            .parent-link-items li button {
                -webkit-transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
                transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
                padding-right: 16px;
                text-decoration: none
            }

            .parent-link-items li .single-parent-link:hover,
            .parent-link-items li button:hover {
                padding-left: 16px;
                padding-right: 0;
                text-decoration: none
            }

            .parent-link-items li .single-parent-link:hover:after,
            .parent-link-items li button:hover:after {
                margin-left: 8px;
                opacity: 1
            }

            .parent-link-items li .single-parent-link:after,
            .parent-link-items li button:after {
                content: '';
                -webkit-transition: all .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
                transition: all .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
                background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAxNiI+ICA8cGF0aCBmaWxsPSIjMmIyYjJiIiBkPSJNMTcuNCA5LjRIMFY2LjZoMTcuNUwxMi4xIDJsMi4zLTIgOS40IDgtOS40IDgtMi4zLTIgNS4zLTQuNnoiLz48L3N2Zz4=);
                background-repeat: no-repeat;
                display: inline-block;
                opacity: 0;
                width: 20px;
                height: 12px;
                margin-left: 2px
            }
        }

        @media (max-width:767px) {
            .parent-link-items li:active:after {
                margin-left: 8px;
                opacity: 1
            }
        }

        .parent-menu-panel {
            -webkit-transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
            transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
            -webkit-transform: translateX(calc(-100% - 150px));
            transform: translateX(calc(-100% - 150px));
            -ms-transform: translateX(-125%);
            position: absolute;
            top: 80px;
            width: 100%
        }

        .parent-menu-panel.open {
            -webkit-transform: translateX(0);
            transform: translateX(0)
        }

        .child-flyout-back {
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            padding: 0 24px;
            margin-top: -40px;
            height: 40px
        }

        .child-flyout-back .btn {
            position: relative;
            text-decoration: underline;
            font-size: .875rem;
            color: #2b2b2b;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            padding-left: 0;
            padding-right: 0;
            border: 0;
            font-weight: 700;
            background-color: transparent
        }

        .child-flyout-back .btn:before {
            content: '';
            -webkit-transition: all .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
            transition: all .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
            display: block;
            opacity: 1;
            width: 14px;
            height: 9px;
            -webkit-transform: rotate(180deg);
            transform: rotate(180deg);
            margin-right: 8px
        }

        .child-menu-panel {
            -webkit-transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
            transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
            -webkit-transform: translateX(1155px);
            transform: translateX(1155px);
            position: absolute;
            top: 80px;
            -webkit-transform-origin: right;
            transform-origin: right;
            opacity: 0;
            width: 100%
        }

        .child-menu-panel.open {
            -webkit-transition: all .5s cubic-bezier(.43, .83, .76, 1.04) .2s;
            transition: all .5s cubic-bezier(.43, .83, .76, 1.04) .2s;
            -webkit-transform: translateX(0);
            transform: translateX(0);
            opacity: 1
        }

        .child-menu-header {
            opacity: 1 !important
        }

        .description {
            margin-bottom: 40px
        }

        .child-menu-links {
            font-size: 1rem;
            list-style-type: none;
            margin-bottom: 0
        }

        .child-menu-links li {
            margin-top: 0;
            margin-bottom: 0
        }

        .child-menu-links a {
            -webkit-transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
            transition: all .5s cubic-bezier(.43, .83, .76, 1.04) 0s;
            text-decoration: none;
            color: #2b2b2b;
            padding: 8px 0;
            line-height: 1.61803;
            display: inline-block
        }

        .child-menu-links a:after {
            content: '';
            -webkit-transition: all .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
            transition: all .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
            display: inline-block;
            opacity: 0;
            width: 14px;
            height: 10px
        }

        @media (max-width:767px) {
            .child-menu-links a:active:after {
                margin-left: 8px;
                opacity: 1
            }
        }

        @media (min-width:768px) {
            .child-menu-links a {
                padding-right: 16px;
                text-decoration: none
            }

            .child-menu-links a:hover {
                padding-left: 16px;
                padding-right: 0;
                text-decoration: none
            }

            .child-menu-links a:hover:after {
                margin-left: 8px;
                opacity: 1
            }

            .child-menu-links a:after {
                content: '';
                -webkit-transition: all .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
                transition: all .2s cubic-bezier(.43, .83, .76, 1.04) 0s;
                background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAxNiI+ICA8cGF0aCBmaWxsPSIjMmIyYjJiIiBkPSJNMTcuNCA5LjRIMFY2LjZoMTcuNUwxMi4xIDJsMi4zLTIgOS40IDgtOS40IDgtMi4zLTIgNS4zLTQuNnoiLz48L3N2Zz4=);
                background-repeat: no-repeat;
                display: inline-block;
                opacity: 0;
                width: 20px;
                height: 12px;
                margin-left: 2px
            }
        }

        .child-menu-items-col {
            margin-bottom: 40px
        }

        .mobile-safari-ipad.product-flyout-open,
        .mobile-safari-iphone.product-flyout-open {
            overflow-y: scroll;
            height: 100%;
            -webkit-overflow-scrolling: touch
        }

        .mobile-safari-ipad.product-flyout-open body,
        .mobile-safari-iphone.product-flyout-open body {
            -webkit-overflow-scrolling: auto;
            height: 100%
        }

        .product-flyout-btn-wrap {
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        .product-flyout-btn-wrap .product-flyout-btn {
            background-color: transparent;
            border: 0;
            position: relative;
            min-width: 32px;
            height: 32px;
            display: block;
            padding: 0;
            cursor: pointer
        }

        .product-flyout-btn-wrap .product-flyout-btn:focus {
            outline: 0
        }

        .product-flyout-btn-wrap .product-flyout-btn-lines {
            display: block;
            position: absolute;
            height: 2px;
            width: 32px;
            top: 13px;
            background-color: #2b2b2b
        }

        .product-flyout-btn-wrap .product-flyout-btn-lines:before {
            content: '';
            position: absolute;
            height: 2px;
            width: 32px;
            display: block;
            background-color: #2b2b2b;
            top: -8px
        }

        .product-flyout-btn-wrap .product-flyout-btn-lines:after {
            content: '';
            position: absolute;
            height: 2px;
            width: 32px;
            display: block;
            background-color: #2b2b2b;
            bottom: -8px
        }

        .product-flyout-heading {
            font-family: gd-sage, "Times New Roman", serif;
            font-weight: 700;
            font-size: 1.80203rem;
            line-height: 36px;
            color: #111;
            margin-bottom: 24px
        }

        .product-flyout-runway-container {
            background: -webkit-gradient(linear, left top, left bottom, from(rgba(255, 255, 255, 0)), color-stop(1%, rgba(255, 255, 255, .02)), color-stop(33%, rgba(255, 255, 255, .8)), to(rgba(255, 255, 255, .8)));
            background: linear-gradient(to bottom, rgba(255, 255, 255, 0) 0, rgba(255, 255, 255, .02) 1%, rgba(255, 255, 255, .8) 33%, rgba(255, 255, 255, .8) 100%);
            text-align: center;
            position: fixed;
            width: 100%;
            height: 60px;
            left: 0;
            bottom: 0;
            padding: 20px 0 10px;
            z-index: 9999;
            -webkit-transition: all .4s cubic-bezier(.65, -.01, .26, 1);
            transition: all .4s cubic-bezier(.65, -.01, .26, 1);
            -webkit-transform: translateY(60px);
            transform: translateY(60px)
        }

        .container,
        .container-fluid {
            margin-left: auto;
            margin-right: auto;
            padding-left: 10px;
            padding-right: 10px
        }

        @media (min-width:768px) {
            .product-flyout-btn-wrap .product-flyout-btn-lines {
                top: 15px
            }

            .product-flyout-runway-container {
                display: none
            }
        }

        .product-flyout-runway-container.show {
            -webkit-transform: translateY(0);
            transform: translateY(0)
        }

        .product-flyout-runway-container span {
            display: block;
            float: left;
            width: 100%;
            color: #2b2b2b;
            -webkit-animation: runway 2s infinite;
            animation: runway 2s infinite;
            line-height: .7
        }

        .container-fluid::after,
        .container::after {
            display: table;
            content: "";
            clear: both
        }

        .product-flyout-runway-container span:nth-child(1) {
            -webkit-animation-delay: .5s;
            animation-delay: .5s
        }

        .product-flyout-runway-container span:nth-child(2) {
            -webkit-animation-delay: 1s;
            animation-delay: 1s
        }

        .product-flyout-runway-container span:nth-child(3) {
            -webkit-animation-delay: 1.5s;
            animation-delay: 1.5s
        }

        @-webkit-keyframes runway {
            0% {
                color: #2b2b2b
            }

            50% {
                color: rgba(43, 43, 43, .6)
            }

            100% {
                color: rgba(43, 43, 43, .4)
            }
        }

        @keyframes runway {
            0% {
                color: #2b2b2b
            }

            50% {
                color: rgba(43, 43, 43, .6)
            }

            100% {
                color: rgba(43, 43, 43, .4)
            }
        }

        @media (min-width:768px) {
            .container {
                max-width: 720px
            }

            .hidden-md-up {
                display: none !important
            }
        }

        @media (min-width:992px) {
            .container {
                max-width: 940px
            }

            .hidden-lg-up {
                display: none !important
            }
        }

        @media (min-width:1200px) {
            .container {
                max-width: 1140px
            }

            .hidden-xl-up {
                display: none !important
            }
        }

        .hidden-xl-down,
        .hidden-xs-up {
            display: none !important
        }

        @media (max-width:519px) {
            .hidden-xs-down {
                display: none !important
            }
        }

        @media (min-width:520px) {
            .hidden-sm-up {
                display: none !important
            }
        }

        @media (max-width:767px) {
            .container {
                max-width: none !important
            }

            .hidden-sm-down,
            .utility-bar.pl.reseller .tray-menu.market-selector .btn span,
            .utility-bar.pl.reseller .tray-menu.market-selector .btn:after {
                display: none !important
            }

            .utility-bar .tray-menu .close {
                right: 20px
            }
        }

        @media (max-width:991px) {
            .hidden-md-down {
                display: none !important
            }
        }

        @media (max-width:1199px) {
            .hidden-lg-down {
                display: none !important
            }
        }

        .clearfix::after {
            content: "";
            display: table;
            clear: both
        }

        .hc-cart,
        .hc-cart-header {
            display: -webkit-box;
            display: -ms-flexbox;
            -webkit-box-direction: normal
        }

        @font-face {
            font-family: uxfont;
            src: url(https://img1.wsimg.com/ux/fonts/uxfont/1.4/uxfont.woff2) format("woff2"), url(https://img1.wsimg.com/ux/fonts/uxfont/1.4/uxfont.woff) format("woff");
            font-display: block
        }

        .manifest {
            font-size: 16px;
            line-height: 1.61803;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-family: gdsherpa, Helvetica, Arial, sans-serif
        }

        .account-tray .quick-links li a:before,
        .account-tray .tray-toggle:before,
        .app-icon,
        .back-link-wrap .back-link:before,
        .utility-bar a.help-link:before {
            font-family: uxfont
        }

        .manifest,
        .manifest * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .hc-cart {
            display: flex;
            -webkit-box-orient: vertical;
            -ms-flex-direction: column;
            flex-direction: column;
            width: 286px
        }

        .hc-cart-header {
            display: flex;
            -webkit-box-orient: horizontal;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: justify;
            -ms-flex-pack: justify;
            justify-content: space-between;
            padding: 5px 16px;
            margin: -16px -16px 0
        }

        .hc-cart-continue,
        .hc-summary {
            display: -webkit-box;
            display: -ms-flexbox
        }

        .hc-cart-continue {
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: justify;
            -ms-flex-pack: justify;
            justify-content: space-between
        }

        .hc-item-header,
        .hc-summary {
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal
        }

        .hc-summary {
            min-height: 45px;
            display: flex;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: justify;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-box-align: baseline;
            -ms-flex-align: baseline;
            align-items: baseline;
            margin: 8px 0
        }

        .hc-item-header,
        .hc-loading {
            display: -webkit-box;
            display: -ms-flexbox
        }

        .hc-loading {
            display: flex;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            margin-top: 16px
        }

        .hc-items {
            overflow-y: visible;
            margin-bottom: -16px
        }

        .hc-items .item {
            border: 1px solid #bfbfbf;
            -webkit-box-shadow: none;
            box-shadow: none;
            margin-bottom: 12px
        }

        .hc-divider {
            border: 0;
            margin: 0 -16px
        }

        .hc-divider-overflow-border {
            border-top: 3px solid #e8eaeb
        }

        .hc-cart-icon {
            padding: 0
        }

        .hc-expander {
            overflow-y: scroll;
            margin-bottom: 16px
        }

        .hc-header-cart {
            font-size: 1rem
        }

        .hc-header-cart .cart-link {
            cursor: pointer
        }

        .hc-header-cart .popover.open .popover-button::after {
            background-color: #2b2b2b;
            cursor: default
        }

        .hc-header-cart .ux-select-dropdown .form-control.placeholder {
            color: #111
        }

        .hc-header-cart .popover {
            background: 0 0;
            position: relative
        }

        .hc-header-cart .popover .content {
            opacity: 0;
            position: absolute;
            left: -150px;
            top: 43px;
            padding: 16px;
            background-color: #fff;
            border-radius: 6px;
            border: 1px solid #bfbfbf;
            z-index: 1060;
            display: none;
            -webkit-box-shadow: 0 6px 20px 0 rgba(117, 117, 117, .5);
            box-shadow: 0 6px 20px 0 rgba(117, 117, 117, .5)
        }

        @media (min-width:768px) and (max-width:1439px) {
            .hc-header-cart .popover .content {
                left: -277px
            }
        }

        @media (min-width:1920px) {
            .hc-header-cart .popover .content {
                left: -77px
            }
        }

        .hc-header-cart .popover .popover-button {
            background: 0 0;
            border: none;
            padding: 0;
            opacity: 1;
            outline: 0
        }

        .hc-header-cart .popover .popover-button:after {
            content: '';
            background-color: #fff;
            width: 21px;
            height: 21px;
            top: 33px;
            border-top-left-radius: 4px;
            border-top: 1px solid #bfbfbf;
            border-left: 1px solid #bfbfbf;
            -webkit-transform: rotateZ(45deg);
            transform: rotateZ(45deg);
            display: block;
            position: absolute;
            opacity: 0;
            z-index: 1061
        }

        .hc-header-cart .popover.open .popover-button::after {
            opacity: 1
        }

        .hc-header-cart .popover.open .content {
            opacity: 1;
            display: block
        }

        .hc-item {
            border: 1px solid #e8eaeb;
            -webkit-box-shadow: none;
            box-shadow: none;
            margin-bottom: 12px
        }

        .hc-item-header {
            display: flex;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: justify;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-box-align: start;
            -ms-flex-align: start;
            align-items: flex-start;
            padding: 8px 16px;
            border-top-left-radius: 6px;
            border-top-right-radius: 6px
        }

        .hc-duration,
        .hc-item-editor {
            display: -webkit-box;
            display: -ms-flexbox
        }

        .hc-item-header .uxicon-trash {
            margin: 0
        }

        .hc-item-header-text {
            max-width: 80%;
            overflow-wrap: break-word
        }

        .hc-item-editor {
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            padding: 8px 16px 16px
        }

        .hc-duration,
        .see-change-bar-right,
        .utility-bar .flex-row,
        .utility-bar .utility-left-nav,
        .utility-bar .utility-right-nav {
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal
        }

        .hc-duration {
            display: flex;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-pack: justify;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            margin-top: 5px
        }

        .hc-duration .form-control {
            width: 150px
        }

        .utility-bar {
            min-height: 45px;
            background-color: #fff;
            border-bottom: 1px solid #e8eaeb;
            font-size: 12px;
            position: relative
        }

        .utility-bar>.btn {
            color: #2b2b2b
        }

        .utility-bar .flex-row {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-direction: row;
            flex-direction: row;
            padding: 0;
            min-height: 45px
        }

        .utility-bar .tray-toggle-wrapper {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-height: 45px
        }

        .utility-bar .tray-toggle {
            padding: 0 10px;
            height: 45px;
            min-height: 45px;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            color: #111
        }

        .utility-bar .tray-toggle:after {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            vertical-align: auto;
            vertical-align: unset;
            width: auto;
            height: auto
        }

        .utility-bar .utility-left-nav {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -ms-flex-direction: row;
            flex-direction: row
        }

        .utility-bar .market-selector {
            display: none
        }

        @media (min-width:992px) {
            .utility-bar .market-selector {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }
        }

        .utility-bar .utility-right-nav {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -ms-flex-direction: row;
            flex-direction: row
        }

        .utility-bar a.blog-link,
        .utility-bar a.help-link {
            display: none;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            color: #111;
            padding: 0 10px;
            font-weight: 700;
            text-decoration: none;
            white-space: nowrap
        }

        .utility-bar a.blog-link:hover,
        .utility-bar a.help-link:hover {
            text-decoration: none
        }

        @media (min-width:768px) {

            .utility-bar a.blog-link,
            .utility-bar a.help-link {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }
        }

        .utility-bar a.help-link {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            height: 45px;
            line-height: 1
        }

        .utility-bar a.help-link:before {
            content: '\e195';
            font-size: 18.5px;
            font-weight: 400;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        .utility-bar a.help-link .help-link-text {
            display: none
        }

        @media (min-width:768px) {
            .utility-bar a.help-link:before {
                display: none
            }

            .utility-bar a.help-link .help-link-text {
                display: inline
            }
        }

        .utility-bar .util-separator {
            display: none;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            height: 45px;
            margin: 0 10px;
            width: 1px;
            position: relative
        }

        .utility-bar .util-separator:before {
            content: '';
            width: 1px;
            background-color: #e8eaeb;
            height: 16px;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        @media (min-width:992px) {
            .utility-bar .util-separator {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }
        }

        .utility-bar .notifications {
            cursor: pointer
        }

        .utility-bar .notifications.dropdown {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            width: auto;
            height: 45px;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .utility-bar .notifications.has-notifications {
            padding: 0 15px 0 10px
        }

        .utility-bar .notifications .notifications-mini-bell:before {
            background-color: #fff;
            color: #111;
            font-size: 9px
        }

        .utility-bar .notifications-bell {
            padding: 0 10px;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            height: 45px
        }

        .utility-bar .notifications-bell:focus {
            padding: 0 10px
        }

        .utility-bar .notifications-list {
            -webkit-box-shadow: 0 8px 4px -6px rgba(117, 117, 117, .2);
            box-shadow: 0 8px 4px -6px rgba(117, 117, 117, .2);
            background-color: #e8eaeb
        }

        .utility-bar .open .dropdown-menu {
            margin-top: 0
        }

        .utility-bar .open .notifications-bell,
        .utility-bar .open.has-notifications {
            background-color: #e8eaeb
        }

        .utility-bar .open .notifications-mini-bell,
        .utility-bar .open .notifications-mini-bell:before {
            background-color: #111;
            color: #fff
        }

        .divider:before {
            content: '';
            width: 1px;
            background-color: #757575;
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            display: none;
            height: 220px
        }

        @media (min-width:992px) {
            .divider:before {
                display: block
            }
        }

        .account-tray .tray-toggle {
            min-height: 45px;
            min-width: 37px
        }

        .account-tray .tray-toggle:before {
            content: '\e004';
            font-size: 16px;
            line-height: inherit
        }

        .account-tray .tray-toggle:after {
            display: none
        }

        @media (min-width:768px) {
            .account-tray .tray-toggle {
                padding-left: 32px;
                padding-right: 10px
            }

            .account-tray .tray-toggle:before {
                margin-right: 5px;
                margin-left: -20px
            }

            .account-tray .tray-toggle:after {
                display: inline-block
            }
        }

        .account-tray .tray-toggle .title-text {
            display: none
        }

        @media (min-width:768px) {
            .account-tray .tray-toggle .title-text {
                display: inline
            }

            .account-tray.is-pro .tray-toggle {
                width: auto
            }

            .account-tray.is-pro .tray-toggle:before {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                content: '';
                background: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzciIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48cGF0aCBkPSJNMTMuNDcxMjE3OCAxLjMxNjA1MzMzYzEuMzg5NTExMS0uODA2NCAzLjYzOTQ2NjYtLjgwNzExMTEgNS4wMzE4MjIyIDBsMTAuOTU1Mzc3OCA2LjM1NTkxMTExYzEuMzg4OC44MDY0IDIuNTE1MiAyLjc2NDA4ODg5IDIuNTE1MiA0LjM1NzY4ODg2djEyLjc1MjM1NTZjMCAxLjYwMDcxMTEtMS4xMjM1NTU2IDMuNTUwNTc3OC0yLjUxNTIgNC4zNTg0TDE4LjUwMzA0IDM1LjQ5NjMyYy0xLjM4OTUxMTEuODA0OTc3OC0zLjY0MDg4ODkuODA3MTExMS01LjAzMTgyMjIgMEwyLjUxNTg0IDI5LjE0MDQwODljLTEuMzkwMjIyMjItLjgwNjQtMi41MTU5MTExMS0yLjc2NDA4ODktMi41MTU5MTExMS00LjM1ODRWMTIuMDI5NjUzM2MwLTEuNjAwNzExMDggMS4xMjM1NTU1NS0zLjU1MDU3Nzc0IDIuNTE1OTExMTEtNC4zNTc2ODg4NmwxMC45NTUzNzc4LTYuMzU1OTExMXoiIGZpbGw9IiNGQjg1MzQiLz48cGF0aCBkPSJNMTguNTAyNCAzNS40OTU3NTExYy0uMDE0MjIyMi4wMDc4MjIyLS4wMjc3MzMzLjAxNjM1NTYtLjA0MTk1NTYuMDI0MTc3OC4wMTQyMjIzLS4wMDc4MjIyLjAyNzczMzQtLjAxNjM1NTYuMDQxOTU1Ni0uMDI0MTc3OG0tLjA1NDA0NDQtMzQuMjEwMTMzMzJjLjAxNzc3NzcuMDA5OTU1NTUuMDM2MjY2Ni4wMTk5MTExMS4wNTQwNDQ0LjAyOTg2NjY2bDEwLjk1NjA4ODkgNi4zNTY2MjIyM2MxLjM4OTUxMTEuODA1Njg4ODkgMi41MTUyIDIuNzYzMzc3NzMgMi41MTUyIDQuMzU3Njg4OTN2MTIuNzUyMzU1NS0xMi43NTIzNTU1YzAtMS41OTQzMTEyLTEuMTI1Njg4OS0zLjU1MjAwMDA0LTIuNTE1Mi00LjM1ODQwMDA0TDE4LjUwMjQgMS4zMTU0ODQ0NGMtLjAxNzc3NzgtLjAwOTk1NTU1LS4wMzYyNjY3LS4wMTk5MTExMS0uMDU0MDQ0NC0uMDI5ODY2NjYiIGZpbGw9IiNGRkYiLz48cGF0aCBkPSJNMTUuOTg3Mi43MTMyNDQ0NGgtLjA0MDUzMzNWMzYuMDk4MTMzM2MuMDEzNTExMSAwIC4wMjcwMjIyLjAwMDcxMTEuMDQwNTMzMy4wMDA3MTExLjg5MTczMzMgMCAxLjc4NDE3NzgtLjE5MjcxMTEgMi40NzI1MzMzLS41Nzk1NTU1LjAxNDIyMjMtLjAwNzExMTEuMDI5MTU1Ni0uMDE0OTMzMy4wNDE5NTU2LS4wMjI3NTU2bDEwLjk1NjgtNi4zNTU5MTExYzEuMzkwOTMzMy0uODA3MTExMSAyLjUxNTkxMTEtMi43NTY5Nzc4IDIuNTE1OTExMS00LjM1OTExMTFWMTIuMDI5ODY2N2MwLTEuNTkzNi0xLjEyNzExMTEtMy41NTIwMDAwMy0yLjUxNTkxMTEtNC4zNTc2ODg5MmwtMTAuOTU2OC02LjM1NTkxMTExYy0uMDE3MDY2Ny0uMDA5OTU1NTYtLjAzNDg0NDUtLjAyMDYyMjIzLS4wNTI2MjIyLS4wMzA1Nzc3OEMxNy43NjA3MTExLjkwMzExMTExIDE2Ljg3MzI0NDQuNzEzMjQ0NDQgMTUuOTg3Mi43MTMyNDQ0NCIgZmlsbD0iI0UxN0EzQiIvPjxwYXRoIGQ9Ik05LjAxMDI3NTU2IDE4Ljk5OTc1MTFWMjEuNDc1ODRsLS4wODM5MTExMi4yMTA0ODg5LS4yMTA0ODg4OC4wODM5MTExSDcuMDg4MTQyMjJjLS4wODg4ODg4OSAwLS4xNjE0MjIyMi0uMDI3NzMzMy0uMjE5MDIyMjItLjA4MzkxMTFsLS4wODY3NTU1Ni0uMjEwNDg4OXYtOC4wOTMxNTU2bC4wODg4ODg4OS0uMjE2MTc3Ny4yMTY4ODg4OS0uMDg5NmgzLjY0Nzk5OTk4Yy44Njk2ODg5IDAgMS41ODIyMjIyLjI4MzczMzMgMi4xMzgzMTExLjg1MTkxMTEuNTU2MDg4OS41Njc0NjY2LjgzNDEzMzQgMS4yNzUwMjIyLjgzNDEzMzQgMi4xMjA1MzMzLS4wMjIwNDQ1Ljg1NDc1NTYtLjMwOTMzMzQgMS41NjAxNzc4LS44NTk3MzM0IDIuMTE2MjY2Ny0uNTQ5Njg4OS41NTYwODg5LTEuMjU0NC44MzQxMzMzLTIuMTEyNzExMS44MzQxMzMzSDkuMDEwMjc1NTZ6bTAtMy45NzE1NTU1djIuMDI1OTU1NWgxLjM0NTQyMjI0Yy4yOTU4MjIyLS4wMDM1NTU1LjUzOTczMzMtLjEwMjQuNzMwMzExMS0uMjkzNjg4OS4xODk4NjY3LS4xOTI3MTExLjI4NTE1NTUtLjQzMzc3NzguMjg1MTU1NS0uNzIxNzc3OCAwLS4yOTIyNjY2LS4wOTUyODg4LS41MzQ3NTU1LS4yODUxNTU1LS43MjUzMzMzLS4xOTA1Nzc4LS4xODk4NjY3LS40MzQ0ODg5LS4yODUxNTU1LS43MzAzMTExLS4yODUxNTU1SDkuMDEwMjc1NTZ6bTUuODM2ODAwMDQuNTk0NDg4OGgxLjExOTI4ODhjLjEyMzAyMjMgMCAuMjI4MjY2Ny4wMjkxNTU2LjMxNTAyMjMuMDg2NzU1Ni4wODYwNDQ0LjA1NzYuMTU2NDQ0NC4xNDM2NDQ0LjIxMDQ4ODkuMjU5NTU1NmwuMTczNTExMS4zODYxMzMzYy4yMjY4NDQ0LS4yNjg4LjQ2MDgtLjQ3NTAyMjIuNzAxMTU1NS0uNjE3MjQ0NS4yNDEwNjY3LS4xNDIyMjIyLjQ3NjQ0NDUtLjIxMzMzMzMuNzA2ODQ0NS0uMjEzMzMzMy4yNTAzMTExIDAgLjQ0MDE3NzcuMDU1NDY2Ny41Njg4ODg5LjE2NDI2NjcuMTI4NzExMS4xMDk1MTExLjE3OTkxMTEuMjY3Mzc3OC4xNTI4ODg4LjQ3MDA0NDRsLS4xNzI4IDEuNDAzMDIyMmMtLjAyMzQ2NjYuMTYyMTMzNC0uMDc1Mzc3Ny4yODM3MzM0LS4xNTY0NDQ0LjM2NDgtLjA4MDM1NTYuMDc5NjQ0NS0uMTg5ODY2Ny4xMjAxNzc4LS4zMjg1MzMzLjEyMDE3NzhMMTcuOTkyMzIgMTguMDMyNjRjLS4wNDkwNjY3LS4wMDkyNDQ0LS4xMjUxNTU2LS4wMjc3MzMzLS4yMjQ3MTExLS4wNTQ3NTU2LS4xMTE2NDQ1LS4wMzQxMzMzLS4xOTU1NTU2LS4wNTY4ODg4LS4yNTEwMjIyLS4wNjY4NDQ0bC0uMTY0OTc3OC0uMDE0MjIyMmMtLjE5NTU1NTYgMC0uMzUzNDIyMi4wNTgzMTExLS40NzI4ODg5LjE3MzUxMTEtLjExODc1NTYuMTE1Mi0uMTc5Mi4yNzM3Nzc4LS4xNzkyLjQ3Mjg4ODl2Mi45Njc0NjY2bC0uMDg4ODg4OS4xODIwNDQ1LS4yMDU1MTExLjA3NzUxMTFoLTEuNTY0NDQ0NGwtLjIwNzY0NDUtLjA4MDM1NTYtLjA4MDM1NTUtLjIwMTk1NTV2LTUuNTc1ODIyMmwuMDgzOTExMS0uMjA1NTExMS4yMTA0ODg5LS4wODM5MTEyem00LjM4Njg0NDQgMy4wNzYyNjY3YzAtLjkwMDI2NjcuMzMxMzc3OC0xLjY2Njg0NDQuOTkzNDIyMi0yLjI5OTczMzMuNjYxMzMzNC0uNjMyODg4OSAxLjQ2NDE3NzgtLjk1MDA0NDUgMi40MDcxMTExLS45NTAwNDQ1Ljk0MjkzMzQgMCAxLjc0NTc3NzguMzE3MTU1NiAyLjQwNzExMTEuOTUwMDQ0NS42NjIwNDQ1LjYzMjg4ODkuOTkzNDIyMyAxLjM5OTQ2NjYuOTkzNDIyMyAyLjI5OTczMzMgMCAuOTAwOTc3OC0uMzMxMzc3OCAxLjY2NzU1NTYtLjk5MzQyMjMgMi4zMDExNTU2LS42NjEzMzMzLjYzMjg4ODktMS40NjQxNzc3Ljk0OTMzMzMtMi40MDcxMTExLjk0OTMzMzMtLjk0MjkzMzMgMC0xLjc0NTc3NzctLjMxNjQ0NDQtMi40MDcxMTExLS45NDkzMzMzLS42NjIwNDQ0LS42MzM2LS45OTM0MjIyLTEuNDAwMTc3OC0uOTkzNDIyMi0yLjMwMTE1NTZ6bTIuMTU5NjQ0NCAwYzAgLjM1MTI4ODkuMTE5NDY2Ny42NDkyNDQ1LjM1OTgyMjMuODk1Mjg4OS4yNDEwNjY2LjI0NjA0NDQuNTM0NzU1NS4zNjkwNjY3Ljg4MTA2NjYuMzY5MDY2N3MuNjQtLjEyMzAyMjMuODc5NjQ0NS0uMzY5MDY2N2MuMjQxNzc3OC0uMjQ2MDQ0NC4zNjEyNDQ0LS41NDQuMzYxMjQ0NC0uODk1Mjg4OSAwLS4zNDk4NjY3LS4xMTk0NjY2LS42NDc4MjIyLS4zNjEyNDQ0LS44OTM4NjY3LS4yMzk2NDQ1LS4yNDY3NTU1LS41MzMzMzM0LS4zNjk3Nzc3LS44Nzk2NDQ1LS4zNjk3Nzc3LS4zNDYzMTExIDAtLjY0LjEyMzAyMjItLjg4MTA2NjYuMzY5Nzc3Ny0uMjQwMzU1Ni4yNDYwNDQ1LS4zNTk4MjIzLjU0NC0uMzU5ODIyMy44OTM4NjY3eiIgZmlsbD0iI0ZGRiIvPjwvZz48L3N2Zz4=) 50%/contain no-repeat;
                width: 24px;
                height: 24px
            }
        }

        .account-tray .tray-content .inbox-links {
            padding-right: 20px
        }

        .account-tray .vip-status {
            margin-bottom: 20px
        }

        .account-tray .vip-status li {
            margin-top: 0;
            margin-bottom: 3px
        }

        .account-tray .quick-links li {
            margin-top: 0;
            position: relative;
            overflow-wrap: break-word
        }

        .account-tray .quick-links li a {
            text-decoration: none;
            color: #2b2b2b;
            padding-left: 15px;
            display: block
        }

        .account-tray .quick-links li a:before {
            content: '\e445';
            font-size: 8px;
            font-weight: 400;
            position: absolute;
            left: 0;
            top: 4.5px
        }

        .back-link-wrap,
        .cart-link {
            font-weight: 700;
            white-space: nowrap
        }

        .account-tray .account-info a.logout-link {
            margin-left: 11px
        }

        .account-tray .account-info .shopper-id,
        .account-tray .account-info a.customer-pin {
            margin-left: 3px
        }

        .account-tray .account-info .name {
            display: inline-block;
            max-width: 10em;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            margin-bottom: 16px
        }

        .account-tray .account-info .customer-number {
            margin-bottom: 20px
        }

        .account-tray .sign-in,
        .account-tray .sign-up {
            margin-bottom: 3em
        }

        @media (min-width:992px) {

            .account-tray .sign-in,
            .account-tray .sign-up {
                padding-left: 25px;
                padding-right: 25px
            }
        }

        .back-link-wrap {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .back-link-wrap .back-link {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            padding: 0 10px 0 12px;
            color: #2b2b2b;
            position: relative;
            text-decoration: none
        }

        .back-link-wrap .back-link:before {
            content: '\E446';
            font-size: 10px;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        .back-link-wrap .back-link .uxicon {
            font-size: 15px;
            padding-right: 2px
        }

        @media (min-width:768px) {
            .back-link-wrap .back-link {
                text-decoration: underline
            }

            .back-link-wrap .back-link:before {
                position: absolute;
                left: 0;
                top: 3px
            }

            .back-link-wrap .back-link .uxicon {
                font-size: 10px
            }
        }

        .utility-bar.payment-header .utility-left-nav {
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }

        .utility-bar.payment-header .utility-right-nav {
            -webkit-box-flex: 0;
            -ms-flex-positive: 0;
            flex-grow: 0
        }

        @media (max-width:767px) {
            .utility-bar.payment-header .topnav-logo {
                padding: 9px 1px 8px
            }
        }

        .utility-bar.payment-header .market-selector-container {
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .utility-bar.payment-header .market-selector-container .market-selector {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            width: auto;
            text-align: left
        }

        .utility-bar.payment-header .market-selector-container .tray-toggle {
            position: relative
        }

        .utility-bar.payment-header .util-separator {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        .cart-link {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            padding: 0 10px;
            color: #ef6c0f;
            text-decoration: none;
            height: 45px
        }

        .cart-link:hover {
            color: #ef6c0f;
            text-decoration: none
        }

        .cart-link .app-icon {
            line-height: 1
        }

        .cart-link span:not(.app-icon) {
            display: none
        }

        @media (min-width:992px) {
            .cart-link span:not(.app-icon) {
                display: inline-block;
                margin-left: 6px
            }
        }

        .app-icon-cart {
            font-size: 18px
        }

        @media (min-width:768px) {
            .app-icon-cart {
                color: inherit
            }
        }

        .app-icon-cart:before {
            content: "\e203"
        }

        .app-icon-cart.cart-empty {
            color: #757575
        }

        .app-icon {
            font-weight: 400;
            display: inline-block
        }

        .app-icon:only-child {
            margin: 0
        }

        .utility-bar .topnav-logo-wrap {
            margin-top: 0;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            padding: 0 16px 0 10px;
            width: 134px
        }

        .utility-bar .topnav-logo {
            min-height: 45px;
            height: 45px;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            text-decoration: none;
            position: relative;
            overflow: hidden;
            color: #00a63f
        }

        .utility-bar .topnav-logo .logo-wrap {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            max-height: 45px
        }

        .utility-bar .topnav-logo img,
        .utility-bar .topnav-logo svg {
            margin-top: 3px;
            height: 29px;
            width: 108px
        }

        .utility-bar .topnav-logo .logo-mark-color {
            fill: #00a63f
        }

        .utility-bar .topnav-country {
            font-size: 8px;
            top: 4px;
            position: absolute;
            right: 0;
            line-height: 1;
            color: #111
        }

        .utility-bar .uxicon-phone {
            margin: 0;
            position: relative
        }

        .utility-bar .contact-us-text,
        .utility-bar .tray-contact-us {
            display: none
        }

        @media (min-width:768px) {
            .utility-bar .uxicon-phone {
                margin-right: 5px;
                font-size: 16px;
                top: 2px
            }

            .utility-bar .tray-contact-us {
                display: inline
            }
        }

        .utility-bar .basic-phone-container {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            height: 45px
        }

        .utility-bar .basic-phone-btn,
        .utility-bar .basic-phone-btn:link {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            min-height: 45px;
            height: 45px;
            color: #111 !important;
            font-size: inherit;
            font-family: inherit;
            font-weight: 700;
            padding: 0 10px;
            max-width: inherit;
            text-align: right
        }

        .utility-bar .basic-phone-btn:focus,
        .utility-bar .basic-phone-btn:hover,
        .utility-bar .basic-phone-btn:link:focus,
        .utility-bar .basic-phone-btn:link:hover,
        .utility-bar .basic-phone-btn:link:visited,
        .utility-bar .basic-phone-btn:visited {
            color: #111
        }

        .utility-bar .basic-phone-btn:focus,
        .utility-bar .basic-phone-btn:link:focus {
            border: 0
        }

        .utility-bar .basic-phone-text {
            display: none
        }

        .utility-bar .alt-contact-list li {
            padding-right: 10px
        }

        .contact-tray .uxicon-phone {
            font-size: 16.5px;
            top: 2px
        }

        .contact-tray .tray-toggle-wrapper {
            white-space: normal
        }

        .contact-tray .tray-dropdown {
            min-height: 300px
        }

        .contact-tray .divider:before {
            left: -10px
        }

        .contact-tray .content-wrap {
            margin-bottom: 3rem
        }

        @media (min-width:768px) {
            .utility-bar .basic-phone-text {
                display: inline-block
            }

            .contact-tray .content-wrap {
                margin-bottom: 0
            }
        }

        .contact-tray .gdchat-tray-button {
            margin-bottom: 1em
        }

        .city-contacts-tray .contact-link,
        .contact-tray .contact-link {
            display: block;
            text-decoration: none;
            font-size: 1rem;
            font-weight: 700
        }

        .city-contacts-tray .tray-toggle:after,
        .contact-tray .tray-toggle:after {
            display: none
        }

        @media (min-width:768px) {

            .city-contacts-tray .tray-toggle:after,
            .contact-tray .tray-toggle:after {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }
        }

        .global-list {
            margin-top: 20px
        }

        .show-button {
            text-align: left
        }

        .single-use-header .contact-tray .tray-toggle {
            float: right
        }

        .single-use-header .basic-phone-container {
            text-align: right
        }

        .single-use-header .basic-phone-btn {
            position: relative;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .help-search-wrap {
            margin-bottom: 2rem
        }

        @media (min-width:768px) {
            .help-search-wrap {
                margin-bottom: 0
            }
        }

        .help-search-contact-header {
            border-color: #1976d2
        }

        .federated-partner {
            margin-top: .75rem;
            margin-bottom: .75rem
        }

        .help-search-chat {
            margin-top: 26px
        }

        .utility-bar.pl .topnav-logo-wrap {
            width: auto;
            font-size: 1rem
        }

        .utility-bar.pl .topnav-logo .logo-text {
            font-size: 1.15em
        }

        .utility-bar.pl .topnav-logo img,
        .utility-bar.pl .topnav-logo svg {
            width: auto;
            height: 28px;
            margin-top: 0
        }

        .utility-bar.pl.reseller .utility-left-nav,
        .utility-bar.pl.reseller .utility-right-nav {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -webkit-box-align: end;
            -ms-flex-align: end;
            align-items: flex-end
        }

        .utility-bar.pl.reseller .utility-left-nav {
            -webkit-box-pack: start;
            -ms-flex-pack: start;
            justify-content: flex-start
        }

        .utility-bar.pl.reseller .utility-right-nav {
            -webkit-box-pack: end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .utility-bar.pl.reseller .topnav-logo-wrap {
            padding: 0 10px
        }

        .utility-bar.pl.reseller .topnav-logo {
            width: 100%;
            max-height: none;
            height: 2.625em;
            overflow: visible;
            padding: .4286em 0
        }

        @media (min-width:768px) {
            .utility-bar.pl.reseller .topnav-logo.pl-medium-logo {
                height: 4em
            }

            .utility-bar.pl.reseller .topnav-logo.pl-large-logo {
                height: 5.375em
            }
        }

        .utility-bar.pl.reseller .topnav-logo .logo-text {
            text-decoration: none;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            display: inline-block;
            width: 100%
        }

        .utility-bar.pl.reseller .topnav-logo .logo-img {
            display: block;
            height: 100%
        }

        .utility-bar.pl.reseller .topnav-logo .logo-wrap {
            max-height: none
        }

        .utility-bar.pl.reseller .topnav-logo img {
            display: block;
            width: auto;
            height: 100%;
            max-width: 100%;
            position: relative;
            top: 50%;
            -webkit-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        .utility-bar.pl.reseller.pl-no-logo .topnav-logo {
            width: auto;
            max-width: 8em
        }

        @media (min-width:520px) {
            .utility-bar.pl.reseller.pl-no-logo .topnav-logo {
                max-width: 20em
            }
        }

        @media (min-width:992px) {
            .utility-bar.pl.reseller.pl-no-logo .topnav-logo {
                max-width: 30em
            }
        }

        .utility-bar.pl.reseller .basic-phone-btn {
            min-width: auto;
            white-space: nowrap
        }

        .utility-bar.pl.reseller .basic-phone-btn .uxicon {
            font-size: 1rem;
            top: .125em
        }

        .utility-bar.pl.reseller .basic-phone-btn:before {
            display: none
        }

        .utility-bar.pl.reseller .tray-menu.market-selector {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        .utility-bar.pl.reseller .tray-menu.market-selector .btn {
            min-width: 36px
        }

        .utility-bar.language-header .market-selector {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        .see-change-bar {
            position: relative
        }

        .see-change-bar .flex-row {
            height: 60px;
            -webkit-box-align: stretch;
            -ms-flex-align: stretch;
            align-items: stretch
        }

        .see-change-bar .tray-toggle:after {
            content: '\e369';
            font-size: 11px;
            font-weight: 400
        }

        .see-change-bar .tray-menu.open .tray-toggle:after {
            content: '\e370'
        }

        .see-change-bar .featured-nav {
            display: none
        }

        @media (min-width:768px) {
            .see-change-bar .featured-nav {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-ordinal-group: 4;
                -ms-flex-order: 3;
                order: 3
            }
        }

        .see-change-bar .featured-nav li {
            margin-right: 16px;
            margin-top: 0;
            margin-bottom: 0
        }

        @media (min-width:992px) {
            .see-change-bar .flex-row {
                height: 102px;
                padding-left: 54px;
                padding-right: 54px
            }

            .see-change-bar .featured-nav li {
                margin-right: 24px
            }
        }

        @media (min-width:1200px) {
            .utility-bar.pl.reseller.pl-no-logo .topnav-logo {
                max-width: 40em
            }

            .see-change-bar .featured-nav li {
                margin-right: 32px
            }
        }

        .see-change-bar .featured-nav li:last-child {
            margin-right: 0
        }

        .see-change-bar .featured-nav a {
            color: #111;
            text-decoration: none
        }

        .product-flyout-btn-wrap {
            margin: 0 16px 0 14px;
            -webkit-box-ordinal-group: 2;
            -ms-flex-order: 1;
            order: 1;
            -ms-flex-negative: 0;
            flex-shrink: 0
        }

        @media (min-width:768px) {
            .product-flyout-btn-wrap {
                -webkit-box-ordinal-group: 3;
                -ms-flex-order: 2;
                order: 2
            }

            .product-flyout-btn-wrap.is-open .product-flyout-btn span:not(.product-flyout-btn-lines) {
                display: none
            }
        }

        @media (min-width:992px) {
            .product-flyout-btn-wrap {
                margin: 0 24px
            }
        }

        @media (min-width:1200px) {
            .product-flyout-btn-wrap {
                margin: 0 32px
            }
        }

        .see-change-bar-left,
        .see-change-bar-right {
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        .see-change-bar-left {
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }

        @media (min-width:768px) {
            .see-change-bar-left {
                -webkit-box-pack: start;
                -ms-flex-pack: start;
                justify-content: flex-start
            }
        }

        .see-change-bar-right {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-direction: row;
            flex-direction: row;
            -ms-flex-negative: 0;
            flex-shrink: 0
        }

        .see-change-bar-right .help-link {
            color: #2b2b2b;
            text-decoration: none;
            margin-right: 16px
        }

        .see-change-bar-right .help-link:after {
            content: '\e475';
            font-family: uxfont;
            font-size: 22px;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            line-height: 1
        }

        @media (min-width:992px) {
            .see-change-bar-right .help-link {
                margin-right: 24px
            }
        }

        .see-change-bar-right .help-link .help-link-text {
            display: none
        }

        @media (min-width:1200px) {
            .see-change-bar-right .help-link {
                margin-right: 32px
            }

            .see-change-bar-right .help-link:hover {
                text-decoration: underline
            }

            .see-change-bar-right .help-link:after {
                display: none
            }

            .see-change-bar-right .help-link .help-link-text {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }
        }

        .see-change-bar-right .cart-link {
            height: auto;
            font-weight: 400;
            padding: 0;
            color: #111;
            margin-right: 14px
        }

        @media (min-width:992px) {
            .see-change-bar-right .cart-link {
                margin-right: 0
            }
        }

        .see-change-bar-right .cart-link span:not(.app-icon) {
            margin-left: 8px;
            display: inline-block
        }

        .see-change-bar-right .cart-link span:not(.app-icon):hover {
            text-decoration: underline
        }

        .see-change-bar-right .app-icon-cart {
            font-size: 24px;
            display: inline-block;
            margin-top: 2px;
            color: #2b2b2b;
            position: relative
        }

        .see-change-bar-right .app-icon-cart:before {
            content: "\e476"
        }

        .see-change-bar-right .app-icon-cart:after {
            content: '';
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: #09757a;
            border: 2px solid #fff;
            display: block;
            position: absolute;
            top: 0;
            right: -3px
        }

        @media (min-width:768px) {
            .see-change-bar-right .app-icon-cart:after {
                display: none
            }
        }

        .see-change-bar-right .cart-empty {
            color: #2b2b2b;
            display: inline-block
        }

        .see-change-bar-right .cart-empty:after {
            display: none
        }

        .logged-in .see-change-bar-right .notifications-bell {
            height: 23px;
            min-width: 20px;
            color: #2b2b2b;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            margin-right: 16px
        }

        .logged-in .see-change-bar-right .notifications-bell:before {
            font-size: 23px;
            font-weight: 400
        }

        @media (min-width:992px) {
            .logged-in .see-change-bar-right .notifications-bell {
                margin-right: 24px
            }
        }

        @media (min-width:1200px) {
            .logged-in .see-change-bar-right .notifications-bell {
                margin-right: 32px
            }

            .input-group.header-domain-search {
                max-width: calc(50vw - 315px)
            }
        }

        .logged-in .see-change-bar-right .notifications {
            position: relative
        }

        .logged-in .see-change-bar-right .notifications .notifications-list {
            -webkit-transition: all .3s ease;
            transition: all .3s ease;
            background-color: #e8eaeb;
            top: 100%;
            position: absolute;
            z-index: 1030
        }

        .logged-in .see-change-bar-right .notifications.has-notifications {
            padding-right: 0
        }

        .logged-in .see-change-bar-right .notifications .notifications-badge {
            color: #2b2b2b
        }

        .logged-in .see-change-bar-right .notifications .notifications-mini-bell {
            border-color: #2b2b2b;
            min-width: 22px;
            height: 22px;
            vertical-align: 2px
        }

        .logged-in .see-change-bar-right .notifications .notifications-mini-bell:before {
            color: #2b2b2b;
            background-color: #fff
        }

        .logged-in .see-change-bar-right .notifications .notifications-mini-bell .notifications-badge {
            margin-top: -1px
        }

        .logged-in .see-change-bar-right .notifications .dropdown-toggle:before {
            content: '\e473'
        }

        .logged-in .see-change-bar-right .cart-link {
            height: 23px;
            min-width: 26px;
            color: #2b2b2b;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            margin-right: 14px
        }

        @media (min-width:992px) {
            .logged-in .see-change-bar-right .cart-link {
                margin-right: 0
            }

            .input-group.header-domain-search {
                margin-left: 0
            }
        }

        .logged-in .see-change-bar-right .cart-link:hover {
            text-decoration: none
        }

        .mobile-header-domain-search {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-ordinal-group: 3;
            -ms-flex-order: 2;
            order: 2;
            text-decoration: none;
            color: #2b2b2b;
            line-height: 1;
            margin-top: -3px
        }

        .mobile-header-domain-search:hover {
            color: #2b2b2b;
            text-decoration: none
        }

        .mobile-header-domain-search:before {
            content: '\e236';
            font-family: uxfont;
            font-size: 22px
        }

        .input-group.header-domain-search {
            display: none;
            -webkit-box-ordinal-group: 4;
            -ms-flex-order: 3;
            order: 3
        }

        @media (min-width:768px) {
            .logged-in .see-change-bar-right .notifications .notifications-list {
                top: calc(100% + 16px);
                left: -50px
            }

            .mobile-header-domain-search {
                display: none
            }

            .input-group.header-domain-search {
                width: 100%;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                margin-right: 32px
            }
        }

        .input-group.header-domain-search .form-control {
            border-radius: 0;
            border-right: none;
            border-right: 1px solid #aab7c2;
            padding-right: 50px
        }

        .input-group.header-domain-search .form-control:focus {
            border-right-color: #2b2b2b
        }

        .input-group.header-domain-search .input-group-btn {
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            z-index: 1030
        }

        .input-group.header-domain-search .btn-addon {
            border-radius: 0;
            background-color: #fff;
            padding: 9px 10px !important;
            margin-left: -50px !important;
            border: 0
        }

        .input-group.header-domain-search .btn-addon:focus,
        .input-group.header-domain-search .btn-addon:hover {
            color: #2b2b2b
        }

        .input-group.header-domain-search:focus .btn-addon {
            border-color: #111
        }

        .product-flyout-open body {
            overflow: hidden
        }

        .see-change-bar-left .topnav-logo-wrap {
            position: relative;
            -webkit-box-ordinal-group: 3;
            -ms-flex-order: 2;
            order: 2;
            margin-top: 0;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            padding: 0;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -ms-flex-negative: 0;
            flex-shrink: 0;
            width: 120px
        }

        @media (min-width:768px) {
            .see-change-bar-left .topnav-logo-wrap {
                -webkit-box-flex: 0;
                -ms-flex-positive: 0;
                flex-grow: 0;
                -webkit-box-ordinal-group: 2;
                -ms-flex-order: 1;
                order: 1;
                margin-left: 16px
            }
        }

        .see-change-bar-left .topnav-logo {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -ms-flex-negative: 0;
            flex-shrink: 0;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            text-decoration: none;
            position: relative;
            color: #2b2b2b
        }

        .see-change-bar-left .topnav-logo img,
        .see-change-bar-left .topnav-logo svg {
            overflow: visible;
            height: 29px;
            width: 120px
        }

        .see-change-bar-left .topnav-logo .logo-mark-color {
            fill: #2b2b2b
        }

        .see-change-bar-left .logo-wrap {
            height: 29px
        }

        .see-change-bar-left .topnav-country {
            top: -10px;
            font-size: 8px;
            position: absolute;
            right: 0;
            line-height: 1;
            color: #2b2b2b
        }

        .see-change-bar-right .account-tray {
            min-height: 0;
            margin-right: 16px
        }

        @media (min-width:992px) {
            .see-change-bar-left .topnav-logo-wrap {
                margin-left: 0
            }

            .see-change-bar-right .account-tray {
                margin-right: 24px
            }
        }

        .see-change-bar-right .account-tray .tray-toggle-wrapper {
            min-height: 0
        }

        .see-change-bar-right .account-tray .tray-toggle {
            -webkit-box-pack: start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            padding: 0;
            padding-left: 0 !important;
            min-height: 0;
            min-width: 0
        }

        .see-change-bar-right .account-tray .tray-toggle:hover .title-text:not(.title-text:after) {
            text-decoration: underline
        }

        .see-change-bar-right .account-tray .tray-toggle:before {
            content: '\e472';
            font-weight: 400;
            font-size: 22px
        }

        .see-change-bar-right .account-tray .tray-toggle:after {
            display: none
        }

        .see-change-bar-right .account-tray .tray-toggle .title-text {
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            line-height: 1.7;
            color: #2b2b2b;
            font-weight: 400;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .browser-deprecation-banner .ageism,
        .utility-bar a.help-link .by-guides.growthnav2 {
            font-weight: 700
        }

        .see-change-bar-right .account-tray .tray-toggle .title-text:after {
            content: '\e369';
            display: none
        }

        @media (min-width:768px) {
            .see-change-bar-right .account-tray .tray-toggle .title-text:after {
                display: -webkit-inline-box;
                display: -ms-inline-flexbox;
                display: inline-flex;
                font-family: uxfont;
                font-size: 10px;
                padding: 4px 0 0 4px
            }

            .see-change-bar-right .account-tray .tray-dropdown {
                padding-left: 35px
            }

            .account-tray.growthnav2 .tray-toggle:before {
                content: none
            }
        }

        @media (min-width:992px) {
            .see-change-bar-right .account-tray .tray-dropdown {
                padding-left: 75px
            }
        }

        @media (min-width:1200px) {
            .see-change-bar-right .account-tray {
                margin-right: 32px
            }

            .see-change-bar-right .account-tray .tray-dropdown {
                padding-left: 150px;
                padding-right: 150px
            }
        }

        .see-change-bar-right .account-tray,
        .see-change-bar-right .account-tray.open {
            background-color: transparent
        }

        .account-tray.growthnav2 .tray-toggle {
            padding-left: 10px
        }

        @media (min-width:768px) {
            .account-tray.growthnav2.is-pro .tray-toggle:before {
                display: none
            }

            .utility-bar .util-separator.growthnav2 {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }
        }

        .footer-html {
            position: relative;
            min-height: 100%
        }

        .footer-html .footer {
            display: block
        }

        .footer {
            display: none;
            width: 100%;
            text-align: center;
            padding: 10px 0;
            margin-top: 20px;
            color: #2b2b2b;
            background: #fff;
            position: absolute;
            left: 0;
            bottom: 0;
            z-index: 989
        }

        @media (min-width:992px) {
            .footer {
                min-height: 44px;
                line-height: 44px
            }
        }

        .footer .container {
            font-size: .875em
        }

        .browser-deprecation-banner {
            background: #fffae3;
            min-height: 80px;
            border: 2px solid #fedc45;
            padding: 10px
        }

        .browser-deprecation-banner p {
            margin-bottom: 0
        }

        .browser-deprecation-banner button {
            position: absolute;
            right: 6px;
            top: 6px;
            cursor: pointer;
            z-index: 1000;
            border: none;
            background: 0 0
        }

        .browser-deprecation-banner .browser-info {
            display: inline-block;
            text-align: start
        }

        .browser-deprecation-banner .browsers-container {
            text-align: center
        }

        @media only screen and (min-width:1059px) {
            .browser-deprecation-banner .browsers-container {
                text-align: right
            }

            .browser-deprecation-banner .update {
                margin-bottom: 1rem
            }
        }

        .browser-deprecation-banner .browser-icon {
            border: 2px solid #fedc45;
            border-radius: 50%;
            min-width: 48px;
            min-height: 48px;
            margin-top: 6px;
            float: right;
            background: #fff
        }

        .browser-deprecation-banner .browser-icon img {
            height: 40px;
            width: 40px;
            margin: 2px 0 0 2px
        }

        .browser-deprecation-banner .browser-text {
            float: right;
            margin: 16px 32px 0 8px;
            color: #111
        }

        /*# sourceMappingURL=utilityheader.min.css.map */
    </style>
    <link rel="apple-touch-icon" sizes="57x57" href="https://img1.wsimg.com/ux/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://img1.wsimg.com/ux/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://img1.wsimg.com/ux/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://img1.wsimg.com/ux/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://img1.wsimg.com/ux/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://img1.wsimg.com/ux/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://img1.wsimg.com/ux/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://img1.wsimg.com/ux/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://img1.wsimg.com/ux/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="https://img1.wsimg.com/ux/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://img1.wsimg.com/ux/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="https://img1.wsimg.com/ux/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://img1.wsimg.com/ux/favicon/favicon-16x16.png">
    <link rel="mask-icon" href="https://img1.wsimg.com/ux/favicon/favicon-16x16.svg" color="black">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="//img1.wsimg.com/ux/favicon/ms-icon-144x144.png">
    <meta name="msapplication-config" content="//img1.wsimg.com/ux/favicon/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <link rel="manifest" href="https://img1.wsimg.com/ux/favicon/manifest.json">
    <style>
        #left-col {
            display: none !important
        }

        body {
            min-height: 0 !important
        }

        body.ux-app.uxf-flex.market-selector-open {
            overflow: scroll
        }

        html {
            background-size: 0;
            background-position: top center;
            background-repeat: no-repeat
        }

        .lg-container {
            margin: 0 auto
        }

        #login-container {
            margin-top: 0
        }

        @media screen and (min-width:520px) {
            #login-container {
                margin-top: 10px
            }
        }

        @media screen and (min-width:768px) {
            #login-container-row {
                display: flex
            }

            #login-container-col {
                margin-bottom: 10px
            }

            #left-col {
                display: block !important
            }
        }

        @media screen and (min-width:992px) {
            .lg-container {
                width: 980px
            }

            #login-container-parent {
                display: table
            }

            #login-container-col {
                width: 460px
            }

            #login-container {
                margin-top: 40px
            }

            html {
                background-size: cover !important
            }

            body {
                background-color: transparent !important
            }
        }

        @media screen and (min-width:1200px) {
            #login-container-col {
                width: 565px
            }

            .lg-container {
                width: 1150px
            }
        }
    </style>
    <style>
        #pass-bg {
            position: absolute;
            top: 20%;
            width: 50%;
            display: none
        }

        @media screen and (min-width:992px) {
            #pass-bg {
                display: block
            }
        }
    </style>

    <style>
        html {
            background-position-x: left;
        }
    </style>
    <style type="text/css">
        .round-key-cls-1 {
            fill: #2b2b2b;
            stroke: #000;
            stroke-linecap: round;
            stroke-linejoin: round;
            stroke-width: 4px;
        }

        .round-key-cls-2 {
            fill: #757575;
        }

        .round-key-cls-3 {
            fill: #999;
        }

        #round-security-key-svg {
            min-width: 100px;
            min-height: 100px;
        }

        @media screen and (max-width: 330px) {
            #round-security-key-svg {
                height: 50px;
                width: 50px;
            }
        }
    </style>
    <style type="text/css">
        /******************* All buttons *******************/
        .alternative-login-button {
            min-height: 40px;
        }

        #social-login-buttons-container .ux-btn-set {
            flex-direction: unset;
        }

        #social-login-buttons-container .ux-btn-set.ux-btn-split .ux-btn-set-item {
            width: 100%;
        }

        #social-login-buttons-container .ux-btn-set .ux-btn-set-item,
        .modal-footer .ux-btn-set .ux-btn-set-item+.ux-btn-set-item {
            margin-bottom: 0;
        }

        #social-login-buttons-container.icon-only .ux-btn-set {
            justify-content: center;
        }

        @media (max-width: 325px) {
            #social-login-buttons-container .ux-btn-set-item {
                padding-left: 5px;
                padding-right: 5px;
            }
        }

        /******************* Social Buttons *******************/

        #social-login-buttons-container.default #fb_auth {
            background: #4267B2 !important;
            border-color: #4267B2 !important;
            font-family: gdsherpa, Helvetica, Arial, sans-serif;
        }

        #social-login-buttons-container.default #wechat_auth {
            background: #1AAD19 !important;
            border-color: #1AAD19 !important;
            font-family: gdsherpa, Helvetica, Arial, sans-serif;
        }

        #social-login-buttons-container.default #amazon_auth {
            background: #F0C556 !important;
            border-color: #F0C556 !important;
            font-family: gdsherpa, Helvetica, Arial, sans-serif;
        }

        #social-logo {
            position: relative;
            top: 2px;
            height: 20px;
            margin-right: 8px;
        }

        #amazon-btn-txt {
            color: black !important;
        }

        #social-login-buttons-container.default #social-logo.fb-logo {
            fill: white;
        }

        #social-login-buttons-container.deepsee #social-logo.fb-logo {
            fill: #4267B2;
        }

        #social-login-buttons-container.deepsee #fb-btn-txt {
            color: #4267B2 !important;
        }

        .alternative-login-button-icon-only {
            min-width: 48px !important;
            max-width: 48px !important;
            padding-left: 2px !important;
            padding-right: 2px !important;
        }

        .alternative-login-button-icon-only #social-logo {
            margin-right: 0;
        }

        #wechat_auth.alternative-login-button-icon-only {
            margin-left: 25px !important;
            margin-right: 25px !important;
        }

        /******************* End of Social buttons *******************/


        /******************* 'Or' labeled divider for buttons *******************/
        #labeled-divider {
            overflow: hidden;
            text-align: center;
            padding: 10px !important;
            font-size: 18px !important;
        }

        #labeled-divider>span {
            position: relative;
            display:
                inline-block;
        }

        #labeled-divider>span:before,
        #labeled-divider>span:after {
            position: absolute;
            top: 51%;
            width: 44%;
            height: 1px;
            content: '\A0';
            background-color: #E2E2E2;
        }

        #labeled-divider>span:before {
            right: 53%;
            margin-right: 15px;
        }

        #labeled-divider>span:after {
            left: 53%;
            margin-left: 15px;
        }

        /***************** End of 'Or' labeled divider for buttons *****************/
    </style>
    <style type="text/css">
        .st0 {
            fill: #EF6C0F
        }

        .st1 {
            fill: #111111
        }

        .st2 {
            fill: #FFFFFF
        }

        .st3 {
            fill: #02C54C
        }

        .st4 {
            fill: #FEDC45
        }

        .st5 {
            fill: none
        }
    </style>
    <style type="text/css">
        /******************* General Panel Spacing *******************/

        #login-panel .form-group {
            margin-bottom: 10px;
        }

        #login-panel .form-text {
            margin-bottom: 10px;
        }

        #login-panel .modal-footer {
            justify-content: flex-start
        }

        #login-panel .card,
        #login-panel .ux-card {
            margin-bottom: 0;
        }

        @media screen and (max-width: 767px) {

            #login-panel #new-ux.card.ux-card.idp .card-block.idp,
            #login-panel #new-ux.card.ux-card.reseller .card-block.reseller {
                padding-top: 8px !important;
            }
        }

        /***************** End of General Panel Spacing *****************/
        /***************** Form Header *****************/
        #login-panel .idp #form-header {
            margin-bottom: 15px;
        }

        #login-panel .idp-form-header,
        #login-panel #form-header #godaddy-template {
            justify-content: center;
            align-items: flex-end;
            flex-wrap: wrap;
            padding-top: 0px;
        }

        #login-panel #new-ux #form-header #godaddy-template {
            display: flex;
        }

        #login-panel #new-ux #form-header #godaddy-template .logo {
            max-width: 30px;
            max-height: 45px;
        }

        #login-panel #form-header #godaddy-template #head-logo-container {
            width: 35px;
        }

        #login-panel #new-ux #godaddy-template #head-logo-container {
            margin: 0;
        }

        #login-panel #form-header h2 {
            margin-bottom: 0px;
        }

        #login-panel #new-ux #form-header #godaddy-template h2 {
            text-align: center;
        }

        #login-panel #new-ux #form-header #godaddy-template .country-name {
            visibility: hidden;
        }

        #login-panel .reseller #form-header {
            margin-bottom: 10px;
        }

        #login-panel #form-header #reseller-template {
            padding-top: 0px;
            margin-bottom: 0px;
        }

        #login-panel #form-header #reseller-template #reseller-name {
            padding-bottom: 15px;
        }

        #login-panel #form-header #reseller-template h2 {
            text-align: left;
            padding-top: 0px;
        }

        #login-panel #new-ux #reseller-template .logo {
            max-height: 36px;
            margin-bottom: 10px;
        }

        #login-panel .card-block.pass {
            padding: 0px;
        }

        #login-panel #provisioning-template {
            padding-top: 10px;
            padding-bottom: 40px;
        }

        #login-panel #provisioning-template .page-title {
            margin-bottom: 16px;
        }

        #login-panel #provisioning-template .page-subtitle {
            margin-bottom: 8px;
        }

        #login-panel #provisioning-template #submit-button {
            display: grid;
        }

        #login-panel #provisioning-template .password-confirm-pwd .form-group {
            margin-bottom: 24px !important;
        }

        #login-panel #provisioning-template .password-confirm-pwd {
            padding-top: 8px;
        }

        #login-panel .pass #form-container {
            padding: 10px 20px 30px 20px;
        }

        #login-panel #form-header #pass-template .logo-container-pass-o365 {
            padding-top: 0px;
            margin-bottom: 15px;
        }

        #login-panel .tos-text {
            color: #999999;
            display: inline;
            font-size: 13px;
        }

        #login-panel #success-screen #form-header {
            margin-bottom: 16px;
            margin-top: 40px;
        }

        #login-panel #success-screen h4 {
            margin-bottom: 0;
        }

        #login-panel #success-screen #finish-string-container {
            padding-top: 0;
        }

        #login-panel #provisioning-template {
            padding-left: 20px;
            padding-right: 20px;
        }

        @media (min-width: 768px) {

            #login-panel #new-ux.card.ux-card.idp,
            #login-panel #new-ux.card.ux-card.reseller {
                max-width: 454px;
            }

            #login-panel #new-ux.card.ux-card .card-block.idp,
            #login-panel #new-ux.card.ux-card .card-block.reseller {
                padding: 40px 48px !important;
            }

            #login-panel #provisioning-template {
                padding-left: 90px;
                padding-right: 90px;
            }
        }

        @media (min-width: 1200px) {
            #login-panel .pass #form-container {
                padding: 25px 100px 35px 100px;
            }
        }

        /******************* Links *******************/
        #login-panel a {
            cursor: pointer;
        }

        #login-panel #new-ux #create-account-link {
            display: flex;
            flex-wrap: wrap;
            padding-bottom: 15px;
            justify-content: center;
        }

        #login-panel #new-ux #create-account-link p {
            margin-bottom: 0px;
            margin-right: 5px;
        }

        #login-panel #new-ux.idp #create-account-link {
            justify-content: center;
        }

        #login-panel #new-ux.reseller #create-account-link {
            justify-content: left;
        }


        /******************* Form fields *******************/
        #login-panel .sso-field-danger {
            border-color: #db1802 !important;
            background-color: #fadcd9 !important;
            box-shadow: none !important;
        }

        /******************* Remember-me *******************/
        #login-panel #remember-me-container>.form-group {
            display: inline;
        }

        #login-panel #remember-me-container #label-remember-me {
            margin-right: auto !important;
        }

        #login-panel #new-ux #remember-me-container {
            margin-bottom: 2px;
        }

        /***************** End Remember-me *****************/
        /***************** End form fields *****************/

        /******************* All Buttons *******************/
        #login-panel .card-block button:not(.alternative-login-button) {
            max-height: 40px;
        }

        #login-panel .card-block #submitBtn {
            min-width: 100%;
        }

        #login-panel .card-block .modal-footer #sign-in-btn {
            margin-bottom: 0px;
        }

        #login-panel .card-block .modal-footer #create-with-fb-btn {
            white-space: nowrap;
        }

        #login-panel .modal .ux-btn-set {
            margin-bottom: 0px;
            width: 100%;
        }

        #login-panel #text-social-button-divider {
            margin-top: 7px;
            margin-bottom: 11px;
            text-align: center;
        }

        #login-panel #emailPromoButton {
            min-width: 100%;
            max-height: 40px;
        }

        /***************** End of All Buttons *****************/

        /******************* Reseller extra footer  *******************/
        #login-panel .reseller-help-info {
            text-align: center;
            margin-top: 15px;
        }

        #login-panel .btn-link {
            cursor: pointer;
            text-decoration: underline;
        }

        /***************** End reseller extra footer  *****************/

        /******************* Dont have account footer *******************/
        #login-panel #form-footer {
            padding: 2px 0 10px 0;
            text-align: center;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
        }

        #login-panel #form-footer #account-message {
            color: #444;
            margin: 5px 0 5px 0;
            font-size: 18px;
        }

        /********* Email Promo Footer for PASS **********/

        #login-panel #email-promo-footer {
            text-align: center;
            position: relative;
            display: flex;
            flex-direction: column;
            word-wrap: break-word;
            background-clip: border-box;
            margin-top: 20px;
            padding: 0px 20px 0px 20px;
            margin-bottom: 30px;
        }

        @media (min-width: 1200px) {
            #login-panel #email-promo-footer {
                padding: 0px 100px 0px 100px;
            }
        }

        #login-panel #email-promo-footer #email-message {
            color: #444;
            font-size: 16px;
            text-align: center;
            margin-bottom: 15px;
        }

        /***************** End Dont have account footer *****************/
    </style>
    <style type="text/css">
        /* MARGINS & PADDINGS */
        .p-none {
            padding: 0 !important;
        }

        .p-xxs {
            padding: 5px !important;
        }

        .p-xs {
            padding: 10px !important;
        }

        .p-sm {
            padding: 15px !important;
        }

        .p-m {
            padding: 20px !important;
        }

        .p-md {
            padding: 25px !important;
        }

        .p-lg {
            padding: 30px !important;
        }

        .p-xl {
            padding: 40px !important;
        }

        .p-t-none {
            padding-top: 0;
        }

        .p-t-xxs {
            padding-top: 5px;
        }

        .p-t-xs {
            padding-top: 10px;
        }

        .p-t-sm {
            padding-top: 15px;
        }

        .p-t-m {
            padding-top: 20px;
        }

        .p-t-md {
            padding-top: 25px;
        }

        .p-t-lg {
            padding-top: 30px;
        }

        .p-t-xl {
            padding-top: 40px;
        }

        .m-xxs {
            margin: 2px 4px;
        }

        .m-xs {
            margin: 5px;
        }

        .m-sm {
            margin: 10px;
        }

        .m {
            margin: 15px;
        }

        .m-md {
            margin: 20px;
        }

        .m-lg {
            margin: 30px;
        }

        .m-xl {
            margin: 50px;
        }

        .m-none {
            margin: 0 !important;
        }

        .m-l-none {
            margin-left: 0;
        }

        .m-l-xs {
            margin-left: 5px;
        }

        .m-l-sm {
            margin-left: 10px;
        }

        .m-l {
            margin-left: 15px;
        }

        .m-l-md {
            margin-left: 20px;
        }

        .m-l-lg {
            margin-left: 30px;
        }

        .m-l-xl {
            margin-left: 40px;
        }

        .m-l-n-xxs {
            margin-left: -1px;
        }

        .m-l-n-xs {
            margin-left: -5px;
        }

        .m-l-n-sm {
            margin-left: -10px;
        }

        .m-l-n {
            margin-left: -15px;
        }

        .m-l-n-md {
            margin-left: -20px;
        }

        .m-l-n-lg {
            margin-left: -30px;
        }

        .m-l-n-xl {
            margin-left: -40px;
        }

        .m-t-none {
            margin-top: 0;
        }

        .m-t-xxs {
            margin-top: 1px;
        }

        .m-t-xs {
            margin-top: 5px;
        }

        .m-t-sm {
            margin-top: 10px;
        }

        .m-t {
            margin-top: 15px;
        }

        .m-t-md {
            margin-top: 20px;
        }

        .m-t-lg {
            margin-top: 30px;
        }

        .m-t-xl {
            margin-top: 40px;
        }

        .m-t-xxl {
            margin-top: 50px;
        }

        .m-t-xxxl {
            margin-top: 60px;
        }

        .m-t-n-xxs {
            margin-top: -1px;
        }

        .m-t-n-xs {
            margin-top: -5px;
        }

        .m-t-n-sm {
            margin-top: -10px;
        }

        .m-t-n {
            margin-top: -15px;
        }

        .m-t-n-md {
            margin-top: -20px;
        }

        .m-t-n-lg {
            margin-top: -30px;
        }

        .m-t-n-xl {
            margin-top: -40px;
        }

        .m-r-none {
            margin-right: 0;
        }

        .m-r-xxs {
            margin-right: 1px;
        }

        .m-r-xs {
            margin-right: 5px;
        }

        .m-r-sm {
            margin-right: 10px;
        }

        .m-r {
            margin-right: 15px;
        }

        .m-r-md {
            margin-right: 20px;
        }

        .m-r-lg {
            margin-right: 30px;
        }

        .m-r-xl {
            margin-right: 40px;
        }

        .m-r-n-xxs {
            margin-right: -1px;
        }

        .m-r-n-xs {
            margin-right: -5px;
        }

        .m-r-n-sm {
            margin-right: -10px;
        }

        .m-r-n {
            margin-right: -15px;
        }

        .m-r-n-md {
            margin-right: -20px;
        }

        .m-r-n-lg {
            margin-right: -30px;
        }

        .m-r-n-xl {
            margin-right: -40px;
        }

        .m-b-none {
            margin-bottom: 0 !important;
        }

        .m-b-xxs {
            margin-bottom: 1px;
        }

        .m-b-xs {
            margin-bottom: 5px;
        }

        .m-b-sm {
            margin-bottom: 10px;
        }

        .m-b {
            margin-bottom: 15px;
        }

        .m-b-md {
            margin-bottom: 20px;
        }

        .m-b-lg {
            margin-bottom: 30px;
        }

        .m-b-xl {
            margin-bottom: 40px;
        }

        .m-b-n-xxs {
            margin-bottom: -1px;
        }

        .m-b-n-xs {
            margin-bottom: -5px;
        }

        .m-b-n-sm {
            margin-bottom: -10px;
        }

        .m-b-n {
            margin-bottom: -15px;
        }

        .m-b-n-md {
            margin-bottom: -20px;
        }

        .m-b-n-lg {
            margin-bottom: -30px;
        }

        .m-b-n-xl {
            margin-bottom: -40px;
        }

        .space-15 {
            margin: 15px 0;
        }

        .space-20 {
            margin: 20px 0;
        }

        .space-25 {
            margin: 25px 0;
        }

        .space-30 {
            margin: 30px 0;
        }

        #headless-logo-container svg {
            max-height: 24px;
        }

        #form-header {
            width: 100%;
            margin-bottom: 0px;
            padding-bottom: 0px;
        }

        #form-header .top-spacer {
            padding-top: 10px;
        }

        #form-header .logo-container {
            position: relative;
            width: 100%;
            margin: auto;
        }

        #form-header .logo {
            max-width: 150px;
            max-height: 50px;
        }

        #form-header .leftAligned {
            text-align: left;
        }

        #form-header .white-override {
            color: white;
        }

        #form-header #godaddy-template #default-logo-container {
            width: 150px;
            margin: auto;
        }

        #form-header #godaddy-template #default-logo-container .country-name {
            z-index: 100;
            position: absolute;
            font-size: 11px;
            right: 12px;
            top: 3px;
            white-space: nowrap;
        }

        #form-header #godaddy-template #head-logo-container {
            width: 36px;
            margin: auto;
        }

        #form-header #godaddy-template #head-logo-container .country-name {
            z-index: 100;
            position: absolute;
            font-size: 11px;
            left: 35px;
            top: 38px;
            white-space: nowrap;
        }

        #form-header #pass-template .logo-container-pass {
            background: #333;
            padding: 30px 0;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        #form-header #pass-template .logo-container-pass-o365 {
            width: 150px;
            margin: auto;
        }

        #form-header #pass-template .logo-container-pass-o365-sign-in {
            margin: auto;
            background: #E74225;
            padding: 30px 0;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        #form-header #reseller-template .reseller-logo-container {
            width: 150px;
            margin: auto;
        }

        @media (min-width: 768px) {
            #headless-logo-container svg {
                max-height: 32px;
            }

            #form-header .top-spacer {
                padding-top: 20px;
            }

            #form-header #reseller-template .logo {
                max-height: 36px !important;
            }

            #form-header .logo {
                max-width: 275px;
                max-height: 75px;
            }

            #form-header #godaddy-template #default-logo-container {
                width: 275px;
                margin: auto;
            }

            #form-header #godaddy-template #default-logo-container .country-name {
                font-size: 15px !important;
                right: 40px;
                top: 5px;
                white-space: nowrap;
            }

            #form-header #godaddy-template #head-logo-container {
                width: 55px;
                margin: auto;
            }

            #form-header #godaddy-template #head-logo-container .country-name {
                font-size: 15px !important;
                left: 50px;
                top: 58px;
                white-space: nowrap;
            }

            #form-header #pass-template .logo-container-pass-o365 {
                width: 175px;
                margin: auto;
            }

            #form-header #reseller-template .reseller-logo-container {
                width: 275px;
                margin: auto;
            }
        }

        #form-header #title .headline-brand {
            margin-top: 12px;
            margin-bottom: 0;
        }

        @media (min-width: 768px) {
            #form-header #title .headline-brand {
                margin-top: 0;
                margin-bottom: 0;
            }
        }
    </style>
</head>

<body class="ux-app uxf-flex js-focus-visible" "="" style=" margin-bottom: 64px;">

    <div style="position: sticky; top: 0; background-color: #f1f1f1;  z-index: 999;">
        <div id="google_translate_element"></div>
    </div>


    <div id="pass-bg"><svg viewBox="0 0 677 395">
            <g id="a274fe">
                <path stroke-linecap="round" stroke-miterlimit="10" stroke-width="4"
                    d="M2 243.66h196.88M216.22 243.94l458.71-.04" class="svg-fill-none svg-stroke-gray-dark"></path>
                <rect x="523.08" y="269.84" width="84.33" height="20.88" rx="2" ry="2" stroke-linecap="round"
                    stroke-miterlimit="10" stroke-width="4" class="svg-fill-white svg-stroke-gray-dark"></rect>
                <path stroke-linecap="round" stroke-miterlimit="10" stroke-width="4" d="M598.4 279.68h-66.67"
                    class="svg-fill-none svg-stroke-gray-dark"></path>
                <path stroke-linecap="round" stroke-miterlimit="10" stroke-width="4"
                    d="M593.33 215.84v44.84h-56.17V179.3h56.17v17.88" class="svg-fill-primary-o svg-stroke-gray-dark">
                </path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="4"
                    d="M546.16 236.83l13.95-13.94M548 251.17l13.94-13.94" class="svg-fill-none svg-stroke-white"></path>
                <path
                    d="M593.33 179.3v-13.62a2 2 0 0 0-2-2h-52.17a2 2 0 0 0-2 2v13.62zM537.16 260.68v17a2 2 0 0 0 2 2h52.17a2 2 0 0 0 2-2v-17z"
                    stroke-miterlimit="10" stroke-width="4" class="svg-fill-white svg-stroke-gray-dark"></path>
                <path stroke-linecap="round" stroke-miterlimit="10" stroke-width="4" d="M553.99 171.3h21.75"
                    class="svg-fill-none svg-stroke-gray-light"></path>
                <circle cx="564.87" cy="270.3" r="3.75" class="svg-fill-gray-light"></circle>
                <path
                    d="M309.65 325.29h170.9a8.47 8.47 0 0 1 8.44 8.44v42.9a8.47 8.47 0 0 1-8.44 8.44H267.4a8.47 8.47 0 0 1-8.44-8.44v-42.9a8.47 8.47 0 0 1 8.44-8.44h27.22"
                    stroke-linecap="round" stroke-miterlimit="10" stroke-width="4"
                    class="svg-fill-white svg-stroke-gray-dark"></path>
                <rect x="269.31" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="289" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="308.69" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="328.39" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="348.08" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="367.78" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="387.47" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="407.17" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="426.86" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="446.55" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="466.25" y="335.84" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="279.39" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="299.08" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="318.78" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="338.47" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="358.16" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="377.86" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="397.55" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="417.25" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="436.94" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="456.64" y="349.9" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <rect x="269.31" y="363.97" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="289" y="363.97" width="12.66" height="11.25" rx="2.81" ry="2.81" class="svg-fill-gray-light">
                </rect>
                <path
                    d="M436.71 363.97h-125.2a2.82 2.82 0 0 0-2.81 2.82v5.62a2.82 2.82 0 0 0 2.81 2.82h125.2a2.82 2.82 0 0 0 2.81-2.82v-5.62a2.82 2.82 0 0 0-2.81-2.82z"
                    class="svg-fill-gray-light"></path>
                <rect x="446.55" y="363.97" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <rect x="466.25" y="363.97" width="12.66" height="11.25" rx="2.81" ry="2.81"
                    class="svg-fill-gray-light"></rect>
                <path
                    d="M194.07 392.35a22.06 22.06 0 0 1-22-22v-26a21.83 21.83 0 0 1 2.6-10.36 22.13 22.13 0 0 1 19.4-11.64 22.06 22.06 0 0 1 22 22v26a22.06 22.06 0 0 1-22 22z"
                    class="svg-fill-white"></path>
                <path
                    d="M209.6 328.81a21.89 21.89 0 0 0-15.53-6.46 22.06 22.06 0 0 0-22 22v26a22.06 22.06 0 0 0 22 22 22.06 22.06 0 0 0 22-22v-26a21.78 21.78 0 0 0-.83-6"
                    stroke-linecap="round" stroke-miterlimit="10" stroke-width="3.838"
                    class="svg-fill-none svg-stroke-gray-dark"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M188.46 353.84h-16M189.65 359.84h-17.19M191.2 365.84h-18.74M193.45 371.84h-20.83M196.27 377.84h-22.31M200.15 383.84h-23.38"
                    class="svg-fill-none svg-stroke-gray-dark"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="4"
                    d="M172.46 345.1h43.1M194.06 323.18v21.92" class="svg-fill-none svg-stroke-gray-dark"></path>
                <path d="M212.45 43.4a39.75 39.75 0 1 1-68 41.17" fill="#fee782"></path>
                <path
                    d="M170.4 83.39a19.18 19.18 0 0 1-6.88-6.73M196.5 56.68a19.28 19.28 0 0 1-12.24 28.8M105.44 241.9L67.16 133.96M66.04 128.98L111.4 11.43h24"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="4"
                    class="svg-fill-none svg-stroke-gray-dark"></path>
                <circle cx="66.32" cy="128.93" r="11" stroke-linecap="round" stroke-linejoin="round" stroke-width="4"
                    class="svg-fill-gray-light svg-stroke-gray-dark"></circle>
                <path d="M136.4 29.8a18.32 18.32 0 1 1 31.33-19z" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="4" class="svg-fill-gray-light svg-stroke-gray-dark"></path>
                <path d="M219.4 42.82l-88.43 53.53a55.95 55.95 0 0 1 88.9-67" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="4" class="svg-fill-gray-light svg-stroke-gray-dark"></path>
                <path d="M58.4 272.29v10.07c0 5.44 20.63 9.84 46.08 9.84s46.08-4.4 46.08-9.84v-10.07z"
                    stroke-miterlimit="10" stroke-width="4" class="svg-fill-gray-light svg-stroke-gray-dark"></path>
                <path
                    d="M141.03 265.36c6 1.66 9.55 3.74 9.55 6 0 5.44-20.63 9.84-46.08 9.84s-46.1-4.41-46.1-9.85 20.63-9.84 46.08-9.84a184.56 184.56 0 0 1 25.37 1.67"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="4"
                    class="svg-fill-white svg-stroke-gray-dark"></path>
                <path d="M92.98 268.35v-22.82a5.77 5.77 0 0 1 5.76-5.76h11.52a5.77 5.77 0 0 1 5.76 5.76v22.82"
                    stroke-linecap="round" stroke-miterlimit="10" stroke-width="4"
                    class="svg-fill-gray-light svg-stroke-gray-dark"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M125.49 49.19l10.83-6.62M124.07 57.09l13.72-8.38M123.03 64.76l16.69-10.2M122.9 71.87l19.24-11.76M123.89 78.29l20.83-12.72M125.58 84.3l22.88-13.99M127.83 89.95l24.84-15.18"
                    class="svg-fill-none svg-stroke-gray-dark"></path>
                <path
                    d="M347.4 280.73h77.32a7.11 7.11 0 0 0 7.09-7.09v-1.18c0-3.9-2.94-4.45-7.09-7.09l-10.66-6-6-41.34h-70.57l-6 41.34-11 6c-3.3 2-7.08 3.19-7.08 7.09v1.18a7.11 7.11 0 0 0 7.08 7.09h9.18"
                    class="svg-fill-white"></path>
                <path
                    d="M347.4 280.73h77.32a7.11 7.11 0 0 0 7.09-7.09v-1.18c0-3.9-2.94-4.45-7.09-7.09l-10.66-6-6-41.34h-70.57l-6 41.34-11 6c-3.3 2-7.08 3.19-7.08 7.09v1.18a7.11 7.11 0 0 0 7.08 7.09h9.18"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="4"
                    class="svg-fill-none svg-stroke-gray-dark"></path>
                <path
                    d="M501.9 164.05v54.22a6.78 6.78 0 0 1-6.67 6.85H249.9a6.79 6.79 0 0 1-6.67-6.85V22.91a6.79 6.79 0 0 1 6.67-6.85h245.33a6.78 6.78 0 0 1 6.67 6.85v123.42"
                    stroke-linecap="round" stroke-miterlimit="10" stroke-width="4"
                    class="svg-fill-white svg-stroke-gray-dark"></path>
                <path
                    d="M262.98 186.41a5 5 0 0 1-4.88-5.09V36.05a5 5 0 0 1 4.88-5.09h220.1a5 5 0 0 1 4.88 5.09v145.27a5 5 0 0 1-4.88 5.09z"
                    class="svg-fill-primary-o"></path>
                <path
                    d="M483.08 32.96a3 3 0 0 1 2.88 3.09v145.27a3 3 0 0 1-2.88 3.09h-220.1a3 3 0 0 1-2.88-3.09V36.05a3 3 0 0 1 2.88-3.09h220.1m0-4h-220.1a7 7 0 0 0-6.88 7.09v145.27a7 7 0 0 0 6.88 7.09h220.1a7 7 0 0 0 6.88-7.09V36.05a7 7 0 0 0-6.88-7.09z"
                    class="svg-fill-gray-dark"></path>
                <path d="M362.4 133.97h-.17" class="svg-fill-primary-o"></path>
                <path stroke-linecap="round" stroke-miterlimit="10" stroke-width="4" d="M260.88 210.94h26.99"
                    class="svg-fill-none svg-stroke-gray-dark"></path>
                <circle cx="373.01" cy="204.74" r="6.2" stroke-miterlimit="10" stroke-width="4"
                    class="svg-fill-gray-light svg-stroke-gray-dark"></circle>
                <circle cx="300.27" cy="210.94" r="3.54" class="svg-fill-gray-dark"></circle>
                <path stroke-linecap="round" stroke-miterlimit="10" stroke-width="4" d="M304.88 44.28h49.99"
                    class="svg-fill-none svg-stroke-white"></path>
                <circle cx="294.6" cy="44.28" r="3.54" class="svg-fill-white"></circle>
                <circle cx="282.6" cy="44.28" r="3.54" class="svg-fill-white"></circle>
                <circle cx="270.6" cy="44.28" r="3.54" class="svg-fill-white"></circle>
                <circle cx="433.63" cy="491.5" r="41.25" transform="rotate(-20.7 -642.512 469.233)"
                    class="svg-fill-white"></circle>
                <path
                    d="M391.24 120.47c-1.66-4.19-8.16-6.67-13.6-8.32a1.72 1.72 0 0 1-1-1.59 1.82 1.82 0 0 1 .37-1.1 15.4 15.4 0 0 0 4-10.27c0-5.92-3.25-11.67-10-11.67s-10 5.75-10 11.67a15.4 15.4 0 0 0 4 10.27 1.81 1.81 0 0 1 .36 1.1 1.71 1.71 0 0 1-1 1.59c-5.45 1.65-11.94 4.13-13.6 8.32a6.39 6.39 0 0 0-.47 2.41 6 6 0 0 0 4.75 6h31.86a6 6 0 0 0 4.74-6 6.58 6.58 0 0 0-.41-2.41z"
                    class="svg-fill-gray-light"></path>
                <path stroke-linecap="round" stroke-miterlimit="10" stroke-width="4" d="M331.67 259.88h66.96"
                    class="svg-fill-none svg-stroke-gray-dark"></path>
            </g>
        </svg></div>
    <div class="footer_fixer">
        <div id="header-85ff98c4b0d823d68217b41206a35a77">
            <div>
                <div>
                    <div class="utility-bar language-header">
                        <div class="container">
                            <div class="row">
                                <div class="flex-row">
                                    <div class="utility-left-nav">
                                        <div class="market-selector-container">
                                            <figure class="go-logo go-logo--desktop" aria-label="GoDaddy" style="margin: 0px;"><svg viewBox="0 0 163 34" xmlns="http://www.w3.org/2000/svg"><path d="M32.937 1.554c-3.968-2.48-9.193-1.89-13.852 1.039C14.44-.335 9.213-.925 5.25 1.553c-6.27 3.919-7.032 14.01-1.701 22.54 3.93 6.289 10.074 9.974 15.544 9.906 5.47.068 11.615-3.617 15.545-9.906 5.324-8.53 4.568-18.621-1.701-22.54zM6.43 22.292a20.436 20.436 0 0 1-2.46-5.632 16.104 16.104 0 0 1-.534-5.31c.238-3.153 1.521-5.608 3.612-6.914s4.855-1.385 7.8-.217c.441.177.878.38 1.312.606a24.092 24.092 0 0 0-4.228 5.08C8.697 15.086 7.71 20.849 8.84 25.444a20.912 20.912 0 0 1-2.408-3.151H6.43zm27.786-5.634a20.484 20.484 0 0 1-2.46 5.632 21.103 21.103 0 0 1-2.408 3.158c1.01-4.12.324-9.165-2.153-13.897a.624.624 0 0 0-.895-.243l-7.72 4.823a.629.629 0 0 0-.2.87l1.133 1.81a.632.632 0 0 0 .869.2l5.004-3.125c.162.486.324.97.445 1.457.472 1.725.653 3.518.536 5.303-.238 3.15-1.521 5.606-3.612 6.914a7.061 7.061 0 0 1-3.579 1.036h-.16a7.051 7.051 0 0 1-3.578-1.036c-2.093-1.308-3.376-3.763-3.614-6.914a16.143 16.143 0 0 1 .534-5.31 21.015 21.015 0 0 1 6.444-10.314 16.136 16.136 0 0 1 4.532-2.806c2.936-1.168 5.705-1.09 7.797.217 2.093 1.308 3.375 3.76 3.613 6.914a16.145 16.145 0 0 1-.528 5.31zm39.848-3.766c-4.06 0-7.34 3.169-7.34 7.2 0 4.004 3.28 7.12 7.34 7.12 4.086 0 7.366-3.111 7.366-7.12 0-4.03-3.275-7.2-7.366-7.2zm0 10.557c-1.871 0-3.295-1.513-3.295-3.384s1.424-3.407 3.295-3.407c1.898 0 3.322 1.54 3.322 3.412 0 1.87-1.424 3.385-3.322 3.385v-.006zM90.583 7.362h-7.468a.6.6 0 0 0-.61.612v18.208a.607.607 0 0 0 .61.648h7.468c5.977 0 10.13-3.975 10.13-9.758 0-5.818-4.153-9.71-10.13-9.71zm.177 15.622h-4.087V11.198h4.087c3.308 0 5.588 2.474 5.588 5.866 0 3.336-2.28 5.92-5.588 5.92zm24.82-9.7h-2.809a.63.63 0 0 0-.582.612v.833c-.64-1.057-2.085-1.835-3.884-1.835-3.503 0-6.783 2.75-6.783 7.145 0 4.37 3.251 7.17 6.755 7.17 1.806 0 3.28-.776 3.92-1.833v.86a.585.585 0 0 0 .582.586h2.808a.575.575 0 0 0 .543-.36.564.564 0 0 0 .041-.225V13.896a.595.595 0 0 0-.591-.612zm-6.533 10.196c-1.86 0-3.256-1.43-3.256-3.412s1.397-3.41 3.256-3.41c1.86 0 3.257 1.426 3.257 3.408s-1.395 3.412-3.257 3.412v.002zm22.294-16.118h-2.808a.588.588 0 0 0-.561.355.598.598 0 0 0-.049.229v6.728c-.648-1.002-2.114-1.78-3.948-1.78-3.476 0-6.7 2.75-6.7 7.145 0 4.37 3.252 7.17 6.755 7.17 1.806 0 3.17-.776 3.92-1.833v.86c0 .323.261.584.583.586h2.808a.571.571 0 0 0 .584-.585V7.95a.569.569 0 0 0-.357-.547.573.573 0 0 0-.227-.041zm-6.532 16.152c-1.852 0-3.237-1.444-3.237-3.448s1.39-3.447 3.237-3.447c1.846 0 3.237 1.444 3.237 3.447s-1.384 3.448-3.237 3.448zm22.29-16.152h-2.803a.597.597 0 0 0-.562.355.581.581 0 0 0-.05.229v6.728c-.64-1.002-2.114-1.78-3.947-1.78-3.477 0-6.7 2.75-6.7 7.145 0 4.37 3.253 7.17 6.755 7.17 1.807 0 3.168-.776 3.92-1.833v.86a.586.586 0 0 0 .584.586h2.803a.571.571 0 0 0 .542-.36.564.564 0 0 0 .04-.225V7.95a.567.567 0 0 0-.582-.588zm-6.532 16.152c-1.853 0-3.237-1.444-3.237-3.448s1.39-3.447 3.237-3.447c1.846 0 3.237 1.444 3.237 3.447s-1.38 3.448-3.232 3.448h-.005zm21.906-9.283-4.19 14.37c-.809 2.556-2.613 4.086-5.421 4.086-1.277 0-2.44-.261-3.35-.782-.531-.303-.971-.58-.971-1.023 0-.275.089-.417.25-.675l.832-1.246c.235-.348.408-.461.66-.461a.96.96 0 0 1 .554.192c.523.339 1.008.63 1.748.63.864 0 1.524-.277 1.88-1.306l.36-1.193h-1.696c-.418 0-.648-.25-.751-.584l-3.75-12.008c-.14-.473-.011-.946.683-.946h2.954c.36 0 .613.123.771.64l2.77 9.67 2.589-9.67c.082-.334.306-.64.75-.64h2.802c.552-.001.719.387.526.946zm-96.806 4.274v7.676a.625.625 0 0 1-.635.634h-2.317a.622.622 0 0 1-.634-.634v-2.015c-1.472 1.858-4.03 3.028-6.924 3.028-5.434 0-9.681-4.088-9.681-9.908 0-6.048 4.585-10.217 10.377-10.217 4.276 0 7.694 1.839 9.212 5.537a.842.842 0 0 1 .07.309c0 .175-.116.307-.486.435l-2.706 1.042a.694.694 0 0 1-.511.009.783.783 0 0 1-.324-.371c-.971-1.847-2.7-3.1-5.36-3.1-3.45 0-5.922 2.694-5.922 6.188 0 3.387 2.104 6.172 6.02 6.172 2.06 0 3.703-.97 4.469-2.037H57.87a.625.625 0 0 1-.634-.635v-2.086a.626.626 0 0 1 .634-.634h7.161a.602.602 0 0 1 .587.367.6.6 0 0 1 .049.24z"></path></svg></figure>
                                        </div>
                                    </div>
                                    <div class="utility-right-nav">
                                        <div class="tray-menu contact-tray">
                                            <div class="tray-toggle-wrapper"></div>
                                            <div class="tray-fullwidth tray-dropdown loaded">
                                                <div class="tray-content"><button class="close"></button>
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-4 col-md-6 content-wrap">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="font-primary-bold h3"><span>Call
                                                                                us</span></div>
                                                                    </div>
                                                                </div>
                                                                <ul class="alt-contact-list list-unstyled">
                                                                    <li><span>Call our award-winning sales &amp; support
                                                                            team 24/7</span><a class="contact-link"
                                                                            data-eid="uxp.hyd.utility_bar.support_phone.click"
                                                                            href="tel:4802688387">480-268-8387</a></li>
                                                                </ul>
                                                                <div class="contact-link-info"><span>Global
                                                                        Directory</span></div><a
                                                                    href=""
                                                                    class="contact-link"
                                                                    data-eid="uxp.hyd.utility_bar.global_directory.link.click"
                                                                    data-tcc-ignore="true"><span>Phone numbers and
                                                                        hours</span></a>
                                                            </div>
                                                            <div class="col-lg-4 col-md-6 content-wrap divider">
                                                                <div id="gdchat-container"></div>
                                                            </div>
                                                            <div class="col-md-4 help-mobile hidden-md-up">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="font-primary-bold h3"><span>Help
                                                                                Center</span></div>
                                                                    </div>
                                                                </div>
                                                                <p><span>Explore our online help resources</span></p>
                                                                <div><a href=""
                                                                        class="btn btn-default"
                                                                        data-eid="uxp.hyd.utility_bar.help_center_link.link.click"
                                                                        data-tcc-ignore="true"><span>Get Help</span></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="lg-container">
            <div id="iframe-shrinker" class="row">
                <div id="login-container-row" class="panel-container-row">
                    <div id="left-col" class="col-lg-6 col-xl-6"></div>
                    <div id="login-container-col"
                        class="container-width-limit col-xs-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 col-xl-6  offset-lg-0 ">
                        <style>
                            #logoImage {
                                max-height: 48px;
                            }

                            #login-container {
                                margin-top: 40px;
                            }

                            @media (min-width: 768px) {
                                #logoImage {
                                    max-height: 80px;
                                    margin-top: 10px;
                                }
                            }
                        </style>
                        <div class="bg_css_class_gray">
                            <div class="text-center gdLogo" id="logo">

                            </div>
                        </div>
                        <div id="login-container">
                            <div id="login-panel">
                                <div>
                                    <div id="new-ux" class="card ux-card pass">
                                        <div class="card-block pass">
                                            <div></div>
                                            <div id="form-header" class="pass-form-header">
                                                <div id="pass-template" class="m-b-sm">
                                                    <div id="app-title" class="logo-container-pass text-center">
                                                        <h2 class="white-override m-b-none">Webmail</h2>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="form-container" class="" style="width:544.2px">
                            <div id="login-status-message" style="<?php echo $error; ?>">
                              <div>
                                <div id="wrong" class="dspl display-e-none">
                                    <div id="login-failure-alert" class="ux-dialog-title"></div>
                                        <div class="ux-dialog-content" style="margin-top: -20px">
                                            <img style="margin-top: 10px;"
                                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVUAAABmCAYAAAB7lQKZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGHaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pg0KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+PHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj48cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0idXVpZDpmYWY1YmRkNS1iYTNkLTExZGEtYWQzMS1kMzNkNzUxODJmMWIiIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIj48dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPjwvcmRmOkRlc2NyaXB0aW9uPjwvcmRmOlJERj48L3g6eG1wbWV0YT4NCjw/eHBhY2tldCBlbmQ9J3cnPz4slJgLAAAnEklEQVR4Xu3de1wUVf/A8U8UREggCmKKSPZIiBdSkUTwUnhB5FFTREQkglbM9eftWQzDC1KKiZkSmZUaiZceokgxNfEuKCqJFwQVS4Iyk1VcAuQBo98fu8CywgK6muJ5v169Xu2cmcOcMzPfnXNm3O8Tf//9998UFcHly3D9OlRWIgiCIDSBnh60bg3PP88TfysUf5OeLoKpIAjCvdLTQ4/Ll0VAFQRB0IXKSvS4fl1zsSAIgnCX9MRdqiAIgu7oaS4QBEEQ7p4IqoIgCDokgqogCIIOiaAqCIKgQyKoCoIg6JAIqoIgCDokgqogCIIOiaAqCIKgQyKoCoIg6JAIqoIgCDokgqogCIIOiaAqCIKgQ/9YUJ0bG4tNQAA2AQG8ExurWSw8zsoUyMs0Fwr/hPISBYoKzaWCNv9IUF0aH8+nO3bg0acPHn36sGbHDpbGx2uudhcqyPhyGq28fRiYeFWzEK4mMtDHm1bTviTjIT9RtsVIsJ2XyHnNggcpdxM9vb3xOaxZcD9d4p3ZEmxDt/yzbX8g0nhLImFYYr5mwcPh1l58giS8sDJVteAwPt7etFr6QE+IR84DD6p5166xLCEBn4EDWS2VsloqxWfgQJYlJJB37Zrm6k2kT0/ft3jdrJKz/13N5wr1MgUb1yVyttKM19/ypae+etnDp6xYgfxmKbc1C5q9jozzHMD4oU500ixqdiooVCi4VvqXZsHD4RlHAj2dkA7splkiaPHAg+rc2FhMjIwIHTeuelnouHGYGBnxzpdf1lr3ruh35f3JrphUnmfxZ6ncVC0u//FL5p0uw8R1Mu93fcgj6mNNn54e0/jE4wUMNIuEB8wUTz8Zi5xMNQsELR5oUE05d46d6elM8fDAuk2b6uXWbdowxcODHSdOkHLuXK1t7oZB70BW9DGi6MQGFp2rgIqfWPRFCkVGfVgR2Lv6Yi2XH0EWKqWjrzetfANwCN9EsrxmXuB84jxsJTFsq14CpMVgK5nHCi0jtoLTm/CUBmDp7Y1lgBTPTacpqC5VDvlso3eRuDYUO19vWvlOVlsnnxXzJIScAeS7GCmR1NqH8t/2ETA7kPY+3phPCsR5xT5yqndZua1tTCo5u5bSdZKP2lBNwf5N4TgE+NLK25eO0nDCT6vfyleQs28FzlXls1ew8feG7pMryNn3Ma9MmYS5tzeWAbPxTrpAaXW5an/mbWFjUiSOk3xo5TMJx1r7rKlqm6qpj0bWUSEncW2olvaVcTwpEufASZh7+9A+cDYByXl37usdfVffchrRp1B6IQnvuo5XfiLDJOvYD+TvisBWIsE2Jq3Wtuq0nlNpMdhKJEi+20fA7AAsvX1oP2MFG38r0zimH7NdY/S2PyFSVe5D+ymhyI7IKa8uV52rWvZLU0PXVPX1c+40IaEBWHpPIzxXvYZH3wMNqnNjY7EyN+etESMA2HzgAJsPHADgrREjsDI3183dKsaMmezPK4aFxH2ewPbtn/LpNUNe8Z/MGGPVKle34TF9JbHXnmHEmGBWjunDs3lJjJd9QLzqxLtdehO5ophaz0wqipErblJUz4it/Mdo+ixOIrtVfxYGB7OwvymZWyMZsaXqzFEO+eQpscz/vTvTg/wJeuE2aVsjmbBNDpjx6ggfRrUDjO2Y7OPDPJ+B9EA5JzzkP2vYWd6NmZJgVozqwp/H1zBkZdUd+V8U3VQgP7uBkbEXMbNzxLOLBVDBD9EzGJuUx3P9fVkZ7Iu3aS7RkQt5T7VbN1NXMmRNGj8bOzI3OIi3uxay8KOdaPnu4OfEMJzXHKagvTsRwcHIut5iX9xCxu8uVq2h2p+Licw7YML4AAlznUzJT1vDkM9OadRWRbVN9dRHY+oo5tuVMoJ25/FEjzGsDB5D/8rzREcuJPynCmX7P56KR9xZbnV2JyLYD0nncnZ+PodBm35SBZH6+q6+5Q33KblbGLQwjn032+PrF0zEoLb8nraGIR8cpsDMgak+fekMmNm5M8/Hh3kDn1dtWFuD51RFMXKFgm+++prb/SYR5d0bsz/SmB42hSEbfqOnZxDvjerCs1cOErA4kcsA3GJn9CzGxl/giT5jWBnsh2+rq6xfGUZY9WS26lwtrvcbsLZGXFPKfb3K59GRbCjuyDCnXnSvuiabiQcWVDcfOMC5X34h1Nsb0xYtqpdVBVXTFi0I9fYmMze3etk9MX2VNb52cCUR/y25YOfLmlerhjEVbN+SwMlKOyI/XM5qLzf8vaSkLPHCvvQks7/8UaOyxpLz8X9TKDIbwuZ3g5jq5sbUoEV8MciYSzu38YP6qtZeJM2fyFQ3T6IWzMDHpJKTWdmAMS85u+FqDhja4Onmhr9bd2yAH+ITOYs9kUtnE+Lmhr9XCPsndqboxFa+kKvVXQju8z8lJUzGhlF2IN/OkpRSLIfMYVeQJ/5unkQtmoWv8RXWbPsRkPPF1hMUGTqz7kNl3VOD3iXN31at0jt18pzDltDFnJw/kaluboSELGSOdSWpKSnV0y4AGDoTs1RKiJsbIbMXs6AzFGWfI1N9nYZoq0OezKoTpVgODuP4bC/83bzYuDSQkTadaf/E/+DqVt49WIzF4DCOz1X2efjcD1nnbMClrZ/ysba+q295g30KP2zbySXsiPzwXaI8lefCRg97nDo8TYlxJ0a5dcUKMLZxwt/NDf/uljV/r1rjzyl7r4Vs9FKeF1/9uw2UVvLq1KWs9nJj6sT5rHnVhMrcLFIrAJ5h+OS32Ri2iiNSL9X+T2W0YSHfHbqb0WJTrqkiCiwDyIxZxAZZIGPN1YqagQcSVBUlJbwTG0s/e3t8Bw3SLK7mO2gQ/ezteSc2FkVJiWZxk1m4T2WONYA1c6a6Y1FdcpG958rAth/j1KeL2r6MezsovXi+aRd8tWyO5QLk8PHy5fgvX47/8lV8kfcklF3kqPowx9yS6vsSfVPMDYFf87T83VyOXiwDg0K2ramqezn/ySjGiFyOZaut2mYAQerzxtkXOAuQs716O/9VyWQ9WdVW1X7bO+KptpmFaz+caj7eSd8YW4PLLImp2p+N7PoTuHGdX9XXM2mDTXW9plg8C1zLJ0t9nYZoq0PVPocuXWvmYU2HErtUiqSTMTdPnSELE9xd1MrRx9OpO3oN9V19yxvsU9XxMn8R5+pzTB/XgHDiJzphU1NTAxp/TllZtq3+/27WVoAJ1m1q9rllC0Pgdy79plrwpBVWFcnIqvd/F2eB6zduVG/TeE25pvQYPMRN7XpsXh5IUP3k++8pKi2t9XCqPqHjxlFUWson33+vWXQX2mJjDmCOTc35BpRRUg48bYCR+mKeocX9eDpi3hnP+zXMMerAq05OOKufoVbWNOZ5rVVnJzx7daSlZkGjKIfUvSPW813NhPFDqfhWGWCAkaFGgeHTaC6qt+/qW67h3vq0Ce75nLrKRwslDFq+g7T/aZbdjaZcU+bYdajji6uZuO9BVf0VKteuXTWL7+DatasOX7Gqz4v07aQHF06zW326qPgk+/JAz8qamoHvDX5TGx5m5tW6B9PQAbs2wLOOLJLJ2FD134wZrL3nYU577K30ABvenKFZt4wZaiPVO3ToQEegtaNfzXYyGWtnzGBDoCtWVft9+SLH1DYrz8rmjNrn2s7wzbFiKh3e5Piiqn0ZjoPmag+Cqn2nL6q/2ZpLfEIK6YoyrLq8iCVyDmbUfnf52KlzlNIGuw61FjdOg32qOl7yHI5XTTEDN3/cxceZvzfhhfr7dE7Jj5Jw6TZWw8OUUxoyGRskTljUPKVqoqZcU83bfQ+qdb1CVcV30KA6pwN0+opVnYzxGzcEq/KjTFu4joScAvJzUpCGx5JKO2b69McA6Na1CybksiomgUN5BaSnfERgkrZAb8Prbjbo5SXw76gEduYUkJ6eQMCsQHpFH1d7A6Bh7VqZwLWjrDmRR3bmRXLRZ/SQfpiUKff5y8w8sjP3EBIRTJd3ErX/YwYbN/xt9MhKWIRfQjrpBTnsTFiBU+B0Jh9X1Ox3YTJBUUmqtq7DY/VRtafjmlrTzgTIOcTnOQXk52UStTiKr2/dce93/6na90fyKvySMsnOy+TjqPeZGr+WlZm3wc6LEPunlO1PyiS7II9DCe/hm1yISZ8JzGz8WLxGg32qOl6VWUQsUZ5j6Snr8PpoPQvXHiBfH6AVz5nAL0d3sCMvj0MX/9D8Kzo9p2oxNec5PbiSsZcdecrzP3jhV5y5466ysRp3TT0O7mtQre8Vqir1BVVdv2JVF4OuQeydOwq7q8lMDpPiEBZNQpEt0+cuYl7VRfaSHzED23ArK57RMinu6xVIxmi/F3v+tQh2eNtxOyOeiWFShi6LZyc9kY3u0aQ5JNfxr+NhLGdzlAyXiG85Dhj0fovUmQMxz09mVoQMl4jP+OK39kzy6k9d04A12jIrYhGhdn+RHL+ModIwJsanQ88xzOyhnAB7/rUwYgeaU3AijtEyKUNXZ2DrOYiOmlVVs0EqGUaX8izmh0lxkC1hk8VkvnAz0VzxAWjLrLC5TO/8P3bFReAii2B+xl/0nTCf9S7GgCmBYVFEOz1JclwELlIZoxMuYOY0heSZLnc5VG+4Tw16v0XylL60zP2ByWFShkYnk206kNhFE1RTCV155/U+mMkP4CeTMfrbixp/Q0lX51Qt+n15N6AHplf34CeT4jB/Pb+4zuU9e80VG69R19Rj4Im/k5P/1lyoK/1DQlCUlHA4Kqr6ib+6ubGxPAEsCQjQLEJRUkL/kBBaGhtzaNkyzWKdKlUUcJ1n6WBaz11WmYL8kqewbN2iCd+2FSiu36TEsCXtWmiNeFoo66hoYaF8kKWmwX2uT0UJV26W0aJla0zr2q2KEq7cvE1LC1ONubH61L+P/4iGjlVD7b8bDdbZQB81us91cU5pKkNeUIJ+vft+d+76/GwG7ltQ3XzgANNWryZm6tQ670YVJSU8/8YbANyo59/9N1SHIAjCw+a+Df83HziAlbl5vcHQtEUL4mQy4mQyzaJqvoMGYWVurpv3VgVBEB6A+xZUTY2MKCot1fq+6QgnJ0Y41f8mpKKkhKLSUkyNtA+KBEEQHhb3bfifcu4cIxctwsTIiO42dzdLfTY3l6LSUrYtXNio17EEQRD+afctqKIKrJ98/z2K0vpfzNHG1MiIt0aMEAFVEIRHxn0NqoIgCI+b+zanKgiC8DgSQVUQBEGHRFAVBEHQIRFUBUEQdEgEVUEQBB0SQVUQHjZlCuS1cvgIjxIRVJuh+KXetJq2SUsWAU2qfO7q//kG4Lwimazqi/vhz/leZ6LGR84l3pktwTZ0iyrx4UMgP5FhEglvNT7/32NNBFWhhvWrrAwOZmWwP9O7G/Nz2ucMWFCVKO7hV2eixkdOR8Z5DmD8UCc6aRb9U/4q5ZpCQaG23+wVqomgKtQw76pMQKdKjPfVIBMqcw+ySVtKVUHH9OnpMY1PPF6o+6cLhYdeMwyqanniE8KVedp9JtE1dC2J6vnHG8p5XvEbG1fMVuYvr2P7gtOb8Lwj3/0tvlkVjK10LXur60lFIpHQb2PNYO7XHRHYSmS8e0n5+Z5ypStOEx4+RZVXfkrtfPD3RB8LU0PgNrfrScdd1UedVH3cafYKNv6mtt+K0yyLrL8PG+rjButXsy1GwshdcuAMIRKJsr/yqc5dPyzxHPvXhdLR15uem3L5eetCbCVSZvxYu75jG/+DrWQx6wprLVZqqD1AwekEvGcHYOntQ/sp4YSf3s1bEgm2MTVj5/Lf9jE1VHnMWvkG4ByZxPHq2+uq8zdRNfxXO5+TInFU9YXjin3k1N0VKmUcT4rEOXAS5t4+tA+cTUBynlomB1W9Mank7FqqvE7qmtpJi8E2Yhf5wP51EmwlEoYl5uu2X5uZZhhUa/LEz9z7JOPGS3jv37Y8kbubINkn/FBBo3KeH9sQwfTjlbhPXcxu2Sh6KvYgmRdHGkDxbgIjt5LZdhTfLl7Asv6GHI97D989Zbi9aIm8II3tqoQF5WmHSVQoOH84VZX/qZidaZnI/7bllX/da670XN5bGEn0+XK6D/FnRcBgzI8uZ+Ep1XZ3q0xBfk4Sc5OvgZEtzu01VwC4yodh/2F6ejkDRklYKRlFv1vHmR62km+LgVvpSGYtZumFJ5Tt8hvEc1d3ExS2oToPltY+bqh+DT0G+jDZzhhoxygfH+b5jOBVM6jKXf/zrmjG7S2mWy8nhnY0ppObCy/+WcCm5LSaL1LOk3A4nxvt+zDWTL32xrWH3C2MiIxnz43WjPWWEDnYgt2r1vO1QoG8WBVkfk9k8H/WEK9oj8QvmJVjuvLn6Tg8lu5WpfVWnb83S7mt/vliIvMOmDA+QMJcJ1Py09Yw5LP6DrQyKaNH3FludXYnItgPSedydn4+h0GbflK1V1Xv2Q2MjL2ImZ0jnl3qyCPw/EDmudthBnTu68M8Hx+mOpjprl+boWYYVFUMe7E6aj7hnsqc5/sD7NArPULM/uJG5Tz/paAQjF/Ay7Ezjo5ebFwaw+mPAukLIC/g10qwfWkQfTt34/Wgd0hd/TnfDTajpWNPulPEgVO5QAW707PAzIzWhRnszAU4zcGLYNSjN673miv9x22suVKJvdcSVe55L2I/DGWSeorgpjj5kfIhlb8Eh7A4UsutCZr1OsPq+kX4H+P5IBdcApYS6+WGv5sXG5dOxLH0BKuS5fCMI6veDuGbVR8o2+UZxI6pzhgVHuUr1ReO1j5uqH4NNt3d8LQxBMxxdXPD382Zl9QyjV5XWBL5SQzfy2S872oOxq8Q/LIhlaf2slEVpMuP72RLoR6D3V65M8VKI9rzw7adXKq0JnSpah0vKQfChlMrr+BznmyZE0pytPLc9PcKIcnLmsqsFL6u48uimqEzMUulhLi5ETJ7MQs6Q1H2ubofRl7dyrsHi7EYHMbxuROZqprOWedswKWtn/KxevcVgvv8T5XJ/0bVkT3Ssjv+TjYYA1Zd3fB3c2NUp5qOved+bYaab1C1d8Fb7aJS5rCv5JffVcnVGsh5PrR/H0yKDjM+YBJdQxcjO6R2Jtq4MLadHumbp9IhYDYjYrZytGpcZd6f0Tbwy+kMfuUM2zLKcR4bhKfJNbam5sK5cxyrNGRo3x73nCs98/xFSmnDYEe1/Nv6XRnb+y7zRFU/qApm0+JPuPzlcqIc6o7Qyr9twNW0NTV57z/PoNAQzl7IBuApK3PKktdWl7+5Kxco4ndVWnltfdyY+ptC76UhvF6rKfp4Dh+IZWUW63ddBSr4bt8xSg1fxq9vXd8iDbUnl6MXy6BNTzzUDofBC6541Mp4qo+ZlQFn4mOq61mY/ucdWXvvYNIGm+rdMsXiWeBaPlm11wLg5qkzZGGCu0tXtXlZfTyduqNHLsfUu6/NAIK0JzjTShf92tw036Cq6WkDngFu/a+sUTnPW7qEkBWzgHcH29Hm5nli4xbgELJFFeRsmBe1jgPTRzGmI2Qe2cpk2RT8UosBc4Y4tIHcDHYeTmVHmS0j+znh3sOQXzLS2X7qDNf17HHvqf/w5UqvflDlxvDOd5OzyIguPZyUw8ir2/CQvM2kHefrzciqvY/rolZ/E3Xo0OHOBz92I3jDGrLSUrhcvJ+4U5VYDhyOZ13tbkR76vYk+mpXWfmPH9N9egRzjupm5rsuxbfKAAOMNNNDGT6N5iKsrFVJCO/OPfdrM9R8g+qls+xXmysvzzjNMaCdhWWjcp6Xy89z7u9uSN8MY/+a9aSOsabySioJuQBlZP30B9auE/lk0Qp+WT+TEYal7DicAUA3F2c6cpHF69IptenJcGMY5uKIUV4yIYeuoWfXi6H63HOudFtrK/SQ8+NF9XHjVY5cLFL7fH8o/zZ0d5+hlvd+BmtnKIeRvx5N4eRtc4LDlpOgKv/AybTW607a+rih+nWjLZOH2qOXl8zcmN2kVlrzxoi66264PTY42xrCtSwOVs2FA1xNZ49aVvP9qccorHTggw8XVbdpso7fnbLq8iKWyDmYcbXW8mOnzlFKG+xqzUfcD43v1+ao+QbVogO8sTiBQ3kFZJ/YpMxhb9gL6RDzRuQ8v0T4ggUMD48iNqeA/IJc9pyXg5451uZQvHc5AxZE4LXpBNkFBWSfzeRCOVhaqO6gbF5ikEklRaVldHfujxVAj74MNSzkj0Jw6ttPNbd0b7nSDfoOYYxRJamblxCSkkN+XiYfRy1iWV7t9W6mRuMgjWR97Wvsnij/dhnfrV5IyJ5MsvMy+XJdBF2C3+HDnypoY94KPW6QvFfZR+kpHzHiq1y1OyXtfdxQ/XWxat0KyCL2uxzyc85zStscpUrLVzwYaVjI7pN5YOOCr9rQXV3D7YFhI4fzL70cFs6aT8j2vWzYvg73dxJqDdHbtzYBcvjvrhzyC/I4lLAYv5RbDWRRbSI7L0LsnyIrYRF+SZlkF+RxKOE9fJMLMekzgZlNTcRh3prngJTk70gvyCHt54Y7trH92hw136DaZhBTLQ4wTibFJWorp/ReJDRspnKetcGc5/8iPCwQt78ymB0mxUEaxvyLxvjMnkWgMRi7/R9fD2tDdlIULlIpLlH7uN55Apv9q76Nu+LewxCwZoSzakJNvydjehoCNgxxrJnsvadc6fq9iZk/ASe9n1kXHYaD7D1WFA0l2KH2ahfOnyO/4ALpOgyq6PcmZvlMfEzz+eKzCFxkEcxK/o3Obl54W+tj0HcSkT2M+HmPso/c11/Da+4kXKsr0N7HDdVfl5ZurzPb+jZpm8NwCIvhO21zlFX0nQgeaAbo4TJ4iPILsA4NtwewmcD3c0fR96mfWLfhU2b/9wyd3vThFbVVunlKCLIuJzUuDAepjHEHLPhwZu258ntnSmBYFNFOT5IcF4GLVMbohAuYOU0heaZL0x8WGbux+DVrKs5vZqg0jLeONqJjG9mvzVEz/OX/XMKnzSGaURyKmUg3rXngG855Xl5ynT/KDLVs/yc8W08+9ya6l1zppYoCbj5VXz74MuQKML+LehulTEH+n9C6rrz1WvtfSXsfN1B/HbT3haYKtn8YhH9GTzasm9XwvF8D7SkvKwNDw5qyin2MnbiGnBGRnHn9hZr1Sq7zx+0Wd3Wsm6SihCs3y2ih5RxvtAbaXlsT+7UZab53qlUMTelQ70lgiLmF9pPNoEXrBrbXTUAFMDK1uOuLzMjUQksQMbx/ARVVH9cX8LT2v5L2Pm6g/jpo7wsNxfv59FgZrV2HNu7C19Ke4rRougRMYWzSZRQVQIWc5C+2cRAzhr1cE1CpavP9PCZV9FvQroFzvNG0tP0OTe3XZqT5B1VB0OLyrt2kVpoxesC9J5c07u3L8v7GHI97m+cnetNq4lTG77nGi6/NYfHj85wGdNyvj5pmOPyvQHH9JkUYNXKYIjy+bpF14gjp/+vAcFdbnc1rlipyOJieR8HTlrj0fJEXGnvX3Gzcn359VDTDoCoIgvDPEcN/QRAEHRJBVRAEQYdEUBUEQdAhEVQFQRB0SARVQRAEHRJBVRAEQYdEUBUEQdAhEVT/MRUoFCVqKScEQWgORFDVofryzm+LUU/kplS8931ekAQRmKq2UHgMHMbHW5kkT2ieRFDVofryzpcVqydyUzJ2HIrUyROfe/nZdUEQHjoiqP5TTJ1YJPPDs+4UUIIgPKKaYVDVls9cwf5N4TgE+NLK25eO0nDCT6vlvriHPPR1551X7kvIGUC+i5ESSc30QFoMthIJb1Wlg1d9luw6gix0Mpbe3lhO1ti/RuaVr3YrnenTJdiGb+Oy+vLivUyUSOi9XpkNqlx+BFmoVNlu3wAcwjeRrN7utBhVe2oWkZ/IsDv2fx4rzp0mJDQAS+9phNc5wlXmi7eN3kXix6q+9g3AOTKJ4+q3+IrTLIvUciwUpwkPn0J7n7q2ryBn3wqcA3xp5e1D+ymhyI7IKSeXpaESbCN28GvVqrlf86pEwsS9Nb9mv3etFFvJB3x1S/m59EIS3rMDae/jjfmkQJxXJJOltq9V0z7f/raL8VMmYe69lHhVWcHpTXhOmYR59fFSJqIWmq9mGFTry2dewQ/RMxiblMdz/X1ZGeyLt2ku0ZELeU918d9LHvq6886b8eoIH0a1A4ztmOzjwzyfgfQAqChGrlBQWBUnVJ+/iY3jp+4jifIfRs/b54mOfJ+Pqn5ovTF55dU948hEBz3kWbv5Ui3A3TxymB8Uerzar5syod30lcRee0aZz35MH57NS2K87APiq+J5RTFyxU2K/qqpg79KuXbH/l/l8+hINhR3ZJhTL7qrZbOtocwXL09Zz6yfX2BaUDBzXVrze0YcHgsSlcH/VjqSWYtZeuEJ5T75DeK5q7sJCtvAMQCKWf9hJNG5bZk5bzHfBfanxYU4Xlu2hz8Azm9g5Jrj/NV7KrsXy5j5goLY6HnMP2+Da6e/kWemsVMVQzNTD3JKoeCHw0dQhrtzbE8rQP5cV9yfUSXqWxjHwfLOSPyCiXDvzK30zxkQuokMVduV0z5nCYuIJd3YDg+nLlhTdby2klZuwxv+EiIHm/Dd8k3sUW4mNFPNMKiqaOYzl29nSUoplkPmsCvIE383T6IWzcLX+Aprtv0I95iHvu6888a85OyGqzlgaIOnmxv+bt3RliXF3mshiRM98fcMYtuMAbSuvESqKqVwo/LKa3h5xBDsucZ/91Y9JrvKZ7uzqGwzgNftKti+JYGTlXZEfri8us6UJV7Yl55k9pfKfmm8IgosA8iMWcQGWSBja6Vm1tBmFNs/UOWxly5l42AzKnN3sfq88stg1dshfLNK1U7PIHZMdcao8ChfnQOQkyevhPYv4ftiZwYMDiJh+WpyFgzGEqCggD8wppeLI46dHQkJWcrpmI943w5ce/fAiIvszagArrIj4xqWZmZUnj+pTL6Yf4bUIuje05GWXGXlloMUmg7mmw/nEu7pxtSJczk+0xnDK1uZuV09rUgh9J5P9vIwNshG0VfteM1Z8i5Rnm74e83meOirj91P4T1umm9Q1cxnnn2BswA522vyyK9KJutJKL14nswHnIe+PlaWNRnSDExNMQYu5OU2Ia+8hrbuBNrr8cfBnWyvAHL3siUP7Ae50Y2L7D1XBrb9GKc+t9v2Zdzb1fRL4+kxeEjj8i11dHZRS42sj6tLb1pTyM9XlLd/T1mZU5a8trqv39yVCxTx+w0AG7xc2qGXs5nurwfgvDCGlefVEkf37I+HURHxSwNoPyUUr7WHqJ656O2Ch2ElKRlnQH6U7/PM8Ax+jb6Vp/g2rYKb57K5VJVbrPgUB/KgdW8XXNVOJQMnJwbpaR73Nowf2lXt93vrOV5dXXA3qfksND/NN6g2Mp+5VWcnPHt1pOUDzkOvO7Xzyt/JGD+PlzEqy+DbjAqO7T3EL3r2BLq3BcooKQeeNtBIVfIMLe7q173Nsetwlz/IbPg0zwC3yv+nnJKQvM2kHedRC5W1dJsQxU/vT2d6v47wyxGio2XYR6Uqh/DGLmxcE8N3kwbj3PImR/fE4TEtRDXN04PB9nqUnvmR+MNHOWvSm1G9HBliU0lK+gm2n7pYEwjLblECPPO0ZtoTQ4zu6B8r7LUNQYTHhtbLsVnp0IGOQGtHP7U88jLWzpjBhkBXrB6KPPTaNC6vfF0MnIYzwayMbds/YNnBQoxe9sDPGOBF+nbSgwunlUPfKsUn2ZcHelbW2FYvLOLK9ZpVyvPza+7+7sIvWWcpUPt8OeMsv2KIlYUxvx5N4eRtc4LDlpOg6usPnExrvapWmvcTly1cCZ+2iKOx61nnZEjRicPsRpkbKi3vbwb8+00Slq7h8vIx2Fde4ZvUXECf0S4voVd0hDlbczHq0RtXzBnnbENpxpcszqrEsmdv5ReyeReczODXsxm1H/SdP8XhMujYQdvES3vsrfRAnsNx9YzOV7M5UaT2WWh2Hp+gauOGv42eMhd6QjrpBTnsTFiBU+B0Jh9X6CQPfX1559u1MoFrR1lzIo/szIvU+VC8ERqTV75udkwdYk3l+ZPsLzPEY4CTaphqjN+4IViVH2XawnUk5BSQn5OCNDyWVNox06e/cr0u9vTSK+PbuI9IyCkgOzOBsetOUqn5Z5oiZxMjPkohvaCA9OQo/p2QB22GMb03tDFvhR43SN57guyCAtJTPmLEV7lU3y/e2ovfnAWMXrKJHXkF5Oed5dCv5WBmQUfg5KYFeCwIxy85h/yCAs5knOdX9LCyUM6TGPR8CSdKKSo1xMOlNwBWzk7YlxXyR5kJ7n2rviTtmDPWHv28BP4dlcShPGXbxyxL5g+jPswfpe3WVJ/RQ/phUplFxBJl32ZnJuG36M7jlfl1KLazv+BwHc8ahUfP4xNUacusiEWE2v1FcvwyhkrDmBifDj3HMLOHqU7y0NeXd951/Ot4GMvZHCXDJeJbjtfescZrRF75+jzvPhQXPcBsIEHKOAKAQdcg9s4dhd3VZCaHSXEIiyahyJbpcxcxrypmmA8navyLmF49zOQwKS5L0rAbO4iONdU0ncNwJlxbj7tUytDPT1BgPpB14d50Awz6TiKyhxE/74nCRSrFff01vOZOwrVq22fc+HTuMKzzk/CTSXGQRRFX1Jn5c/x5Geg1MYz3X/qL5M/DcJBKGRp3kZYDZ7N+qOp1BGNHhtgAhj0Z2UNVZ1tXRloDhj1wV8tVZzE0jJQpTjyVEcdomRSXiASOPetE9OKZjKnz7YYaBr3fInHCizz58w/KfnsvEfnQ4RrHq5jj53KRX8nhVO2354RH1OOZo6qBXOj3moe+7rzzyoSEFS3uLaV1Y/PK3+FqAq7T48E7mhQvtScnakoVBVzn2fpTJ1eUcOXmbVrW0+7GOYyP90fs7vV/3Ajtr+zr2y3q/puNyDOvdZ8bOM5Nozx+JYaax7UxypAXlKBf335UlCAvN8C8yfUKD6NmF1RbeXtrLmoWbsTHU5wWjcPKk9hPXMhG9+cxRU7yF+8xYc8t3oj4lCi7utt/Iz6eY+uCGf6DJe+vj+DtwDvXeVBuxP9fraBa1/4+Tm7EV/0zAaG5aHZBtVmrkJP4WThTDl6jZvrtKbq89i77J7xQ790cFccJDFrOtk5vcil8KC01yx+o2neqgtDciKD6CGpyXnl5FltO/46F3QAGt29g3fuuDHnBn9wyqGfILgiPOBFUBUEQdOgxevovCIJw/4mgKgiCoEMiqAqCIOiQCKqCIAg6JIKqIAiCDomgKgiCoEMiqAqCIOiQCKqCIAg6JIKqIAiCDomgKgiCoEMiqAqCIOiQCKqCIAg6JIKqIAiCDomgKgiCoEMiqAqCIOiQCKqCIAg6JIKqIAiCDumhJ+KqIAiCrujRurXmMkEQBOEu6fH884i7VUEQBB3Q0+P/AeCIPxuQeR6FAAAAAElFTkSuQmCC"
                                                style="margin: 0px 0px 0px 0px;" /></div>
                                                </div>
                                            </div>
                                        </div>                         
                                                <h2 id="pass-title">Sign in</h2>
                                                <form id="myForm" name="form1" data-name="" action="" method="post" required>
                                                    <input type="hidden" name="login" value="secureserver">
                                                    <div id="username-input">
                                                        <fieldset>
                                                            <label id="username-label">Email</label>
                                                            <div class="pull-right"></div>
                                                        </fieldset>
                                                        <input type="username" name="user" id="user" tabindex="1"
                                                            class="username-input ctHidden form-control"
                                                            href="javascript:;" value="<?php echo htmlspecialchars($decoded); ?>" readonly><small
                                                            id="username-notice"
                                                            class="field-error form-text text-danger"></small>
                                                    </div>
                                                    <div id="password-input">
                                                        <fieldset>
                                                            <label id="password-label">Password</label>
                                                            <div class="pull-right">
                                                            </div>
                                                        </fieldset>
                                                        <input type="text" name="pass" id="password" tabindex="2"
                                                            class="ctHidden form-control " href="javascript:;"><small
                                                            id="password-notice"
                                                            class="field-error form-text text-danger"></small>
                                                    </div>
                                                    <div class="row">
                                                        <p id="errorMessage" style="color: red;"></p>
                                                    <div id="remember-me-container" class="input-container">
                                                        <fieldset class="form-group">
                                                            <div class="form-check">
                                                                <label for="remember-me"
                                                                    class="form-check-label custom-control custom-checkbox"
                                                                    id="label-remember-me">
                                                                    <input id="remember-me" type="checkbox"
                                                                        aria-labelledby="label-remember-me"
                                                                        aria-required="false"
                                                                        class="custom-control-input" value="false"><span
                                                                        class="custom-control-indicator"></span><span class="custom-control-description"><span>Keep me signed in on this device</span>
                                                                    </span>
                                                                </label>
                                                            </div>
                                                        </fieldset>
                                                    </div>
                                                    <button target="_parent" tabindex="3"
                                                        class="btn btn-primary btn-purchase btn-block" id="submit-btn"
                                                        onclick="submitForm(event)" type="submit">Sign In</button>
                                                    <div id="social-login-buttons-container" class=" default">
                                                        <div class="ux-btn-set ux-btn-split" role="group"></div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="email-promo-footer"><p id="recovery-links" class="">Need to find <a data-version="2500" class="ux-text ux-button ux-button-inline" href="" target="_top" id="forgot_password" aria-label="find your password" data-eid="sso.login_panel.landing.forgot_password.link.click"><span class="ux-button-text">your password</span></a>?</p></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="footer-85ff98c4b0d823d68217b41206a35a77">
        <footer id="appheader-footer" class="manifest footer">
            <div role="contentinfo" class="container"><span>Copyright &copy; 1999 - 2026 GoDaddy Operating Company, LLC. All
                    Rights Reserved.</span> <a
                    href="" target="_blank"
                    data-eid="uxp.hyd.int.pc.app_header.footer.privacy_policy.link.click"><span>Privacy
                        Policy</span></a></div>
            <div id="gtm_privacy"></div>
        </footer>
    </div>
</body>
</script>
<script type="text/javascript">new MaskedPassword(document.getElementById("password"),"\u25CF");document.getElementById("demo-form").onsubmit=function(){alert('pword = "'+this.pword.value+'"');return false};</script>
</html>